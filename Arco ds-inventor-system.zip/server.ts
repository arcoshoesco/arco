import express from 'express';
import path from 'path';
import fs from 'fs';
import dns from 'node:dns';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

// Force IPv4 DNS resolution first to prevent localhost connection timeouts to smtp.gmail.com
try {
  dns.setDefaultResultOrder('ipv4first');
} catch {
  // Graceful fallback for older runtimes
}

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// CORS configuration to allow all incoming browser origins
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }
  next();
});

// Ensure all /api responses default to application/json
app.use('/api', (req, res, next) => {
  res.setHeader('Content-Type', 'application/json');
  next();
});

// Gracefully handle malformed JSON body errors without Express returning HTML pages
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err instanceof SyntaxError && 'status' in err && (err as any).status === 400 && 'body' in err) {
    return res.status(400).json({
      success: false,
      error: 'Invalid JSON request payload sent to email service.',
    });
  }
  next();
});

// Server-side email credentials storage (persisted server-side only in container)
const CONFIG_FILE = path.join(process.cwd(), '.server-email-config.json');

interface ServerEmailConfig {
  smtpEmail?: string;
  smtpPassword?: string;
  receivingEmail?: string;
  sendEmail?: boolean;
}

let serverEmailConfig: ServerEmailConfig = {};

// Load saved server credentials if present with strict JSON parsing safety
try {
  if (fs.existsSync(CONFIG_FILE)) {
    const raw = fs.readFileSync(CONFIG_FILE, 'utf-8').trim();
    if (raw) {
      serverEmailConfig = JSON.parse(raw);
    }
  }
} catch (e) {
  console.warn('[Server Email Config] Invalid JSON file detected. Resetting config:', e);
  serverEmailConfig = {};
  try {
    fs.writeFileSync(CONFIG_FILE, '{}', 'utf-8');
  } catch (err) {}
}

function saveServerEmailConfig() {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(serverEmailConfig, null, 2), 'utf-8');
  } catch (err: any) {
    try {
      const tmpConfig = path.join('/tmp', '.server-email-config.json');
      fs.writeFileSync(tmpConfig, JSON.stringify(serverEmailConfig, null, 2), 'utf-8');
    } catch (tmpErr) {
      console.warn('[Server Email Config] Kept in-memory:', err?.message);
    }
  }
}

// 1. Health check
app.all(['/health', '/api/health'], (req, res) => {
  res.json({
    success: true,
    service: 'SMTP Backend',
    status: 'running',
    port: PORT,
    timestamp: new Date().toISOString(),
  });
});

// 2. Get Email Config Status (NEVER sends password to client)
app.get('/api/email-config', (req, res) => {
  const email = process.env.EMAIL_USER || serverEmailConfig.smtpEmail || '';
  const receivingEmail = process.env.RECEIVING_EMAIL || serverEmailConfig.receivingEmail || '';
  const hasPassword = Boolean(process.env.EMAIL_PASSWORD || serverEmailConfig.smtpPassword);
  const sendEmail = serverEmailConfig.sendEmail ?? true;

  res.json({
    email,
    receivingEmail,
    hasPassword,
    sendEmail,
    isConfigured: Boolean(email && hasPassword && receivingEmail),
  });
});

// 3. Save Email Config Server-side
app.post('/api/email-config', (req, res) => {
  try {
    const { smtpEmail, smtpPassword, receivingEmail, sendEmail } = req.body || {};

    if (smtpEmail !== undefined) serverEmailConfig.smtpEmail = String(smtpEmail).trim();
    if (smtpPassword !== undefined && String(smtpPassword).trim() !== '') {
      serverEmailConfig.smtpPassword = String(smtpPassword).trim();
    }
    if (receivingEmail !== undefined) serverEmailConfig.receivingEmail = String(receivingEmail).trim();
    if (sendEmail !== undefined) serverEmailConfig.sendEmail = Boolean(sendEmail);

    // Save to private server file
    saveServerEmailConfig();

    res.json({
      success: true,
      message: 'Server email credentials saved securely.',
      hasPassword: Boolean(process.env.EMAIL_PASSWORD || serverEmailConfig.smtpPassword),
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to save email config' });
  }
});

// 3.5 Test & Auto-Create MongoDB Database Endpoint
app.post('/api/test-mongodb', async (req, res) => {
  const { uri, dbName } = req.body || {};
  const mongoUri = (uri || 'mongodb://127.0.0.1:27017').trim();
  const targetDbName = (dbName || 'arco_shoes_db').trim();

  try {
    const { MongoClient } = await import('mongodb');

    const client = new MongoClient(mongoUri, { serverSelectionTimeoutMS: 4000 });
    await client.connect();

    const db = client.db(targetDbName);

    // Auto-create essential collections for ARCO Shoes ERP if they don't exist
    const requiredCollections = [
      'tbl_Items',
      'tbl_SalesMaster',
      'tbl_SalesDetails',
      'tbl_PurchaseMaster',
      'tbl_CustomerLedger',
      'tbl_SupplierLedger',
      'tbl_DayBook',
      'tbl_CompanyInfo',
      'tbl_Admins',
    ];

    const existingCollections = (await db.listCollections().toArray()).map((c) => c.name);
    const createdCollections: string[] = [];

    for (const colName of requiredCollections) {
      if (!existingCollections.includes(colName)) {
        await db.createCollection(colName);
        createdCollections.push(colName);
      }
    }

    // Ping server
    await db.command({ ping: 1 });
    await client.close();

    return res.json({
      success: true,
      message: `Successfully connected to MongoDB! Database '${targetDbName}' verified and initialized automatically.`,
      dbName: targetDbName,
      mongoUri,
      createdCollections,
      totalCollections: [...new Set([...existingCollections, ...createdCollections])].length,
    });
  } catch (err: any) {
    console.warn('[MongoDB Connection Attempt]: Local MongoDB not reachable at', mongoUri);
    return res.json({
      success: false,
      error: err.message || 'Could not connect to local MongoDB server.',
      help: 'Ensure MongoDB service is installed and running on your local machine (e.g. mongodb://127.0.0.1:27017).',
    });
  }
});

// Helper to detect if error is due to MongoDB server offline / connection refused
function isMongoConnectionError(err: any): boolean {
  if (!err) return false;
  const msg = String(err.message || '');
  return (
    err.name === 'MongoServerSelectionError' ||
    err.name === 'MongoNetworkError' ||
    err.name === 'MongoTopologyClosedError' ||
    msg.includes('ECONNREFUSED') ||
    msg.includes('ETIMEDOUT') ||
    msg.includes('Server selection timed out') ||
    msg.includes('connect ECONNREFUSED')
  );
}

// Helper to execute MongoDB operations with auto-connect and close
async function executeMongoOperation<T>(
  uri: string | undefined,
  dbName: string | undefined,
  operation: (db: import('mongodb').Db) => Promise<T>
): Promise<T> {
  const { MongoClient } = await import('mongodb');
  const mongoUri = (uri || 'mongodb://127.0.0.1:27017').trim();
  const targetDbName = (dbName || 'arco_shoes_db').trim();
  const client = new MongoClient(mongoUri, {
    serverSelectionTimeoutMS: 2000,
    connectTimeoutMS: 2000,
  });
  try {
    await client.connect();
    const db = client.db(targetDbName);
    return await operation(db);
  } finally {
    await client.close().catch(() => {});
  }
}

// Map collection key to MongoDB collection name
const MONGO_COLLECTION_MAP: Record<string, string> = {
  items: 'tbl_Items',
  customers: 'tbl_Customers',
  suppliers: 'tbl_Suppliers',
  sales: 'tbl_SalesMaster',
  purchases: 'tbl_PurchaseMaster',
  sales_returns: 'tbl_SalesReturns',
  purchase_returns: 'tbl_PurchaseReturns',
  receipts: 'tbl_CustomerReceipts',
  payments: 'tbl_SupplierPayments',
  adjustments: 'tbl_StockAdjustments',
  exchanges: 'tbl_SalesExchanges',
  exchange_desk: 'tbl_SalesExchangeDesk',
  movements: 'tbl_StockMovements',
  credit_txns: 'tbl_CustomerCreditTxns',
  ledgers: 'tbl_DayBook',
  company: 'tbl_CompanyInfo',
  security: 'tbl_Security',
  admins: 'tbl_Admins',
};

function getMongoCollectionName(key: string): string {
  if (!key) return 'tbl_Items';
  return MONGO_COLLECTION_MAP[key] || (key.startsWith('tbl_') ? key : `tbl_${key.charAt(0).toUpperCase()}${key.slice(1)}`);
}

// 3.6 MongoDB Sync Single Document
app.post('/api/mongodb/sync-doc', async (req, res) => {
  const { mongoUri, dbName, collectionName, docId, data } = req.body || {};
  if (!collectionName || !data) {
    return res.status(400).json({ success: false, error: 'Missing collectionName or data payload.' });
  }

  try {
    const colName = getMongoCollectionName(collectionName);
    const id = String(docId || data.id || data._id || `doc-${Date.now()}`);
    const docToSave = { ...data, _id: id, id };

    await executeMongoOperation(mongoUri, dbName, async (db) => {
      const col = db.collection(colName);
      await col.replaceOne({ _id: id as any }, docToSave as any, { upsert: true });
    });

    return res.json({ success: true, id, collection: colName });
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Sync Doc Notice]: MongoDB not reachable at ${mongoUri || '127.0.0.1:27017'}.`);
    } else {
      console.warn(`[MongoDB Sync Doc Notice] ${collectionName}:`, err?.message || err);
    }
    return res.json({ success: false, error: err.message || 'Failed to sync document to MongoDB', isConnectionError: isMongoConnectionError(err) });
  }
});

// 3.7 MongoDB Delete Single Document
app.post('/api/mongodb/delete-doc', async (req, res) => {
  const { mongoUri, dbName, collectionName, id } = req.body || {};
  if (!collectionName || !id) {
    return res.status(400).json({ success: false, error: 'Missing collectionName or document id.' });
  }

  try {
    const colName = getMongoCollectionName(collectionName);
    const docId = String(id);

    await executeMongoOperation(mongoUri, dbName, async (db) => {
      const col = db.collection(colName);
      await col.deleteOne({ $or: [{ _id: docId as any }, { id: docId as any }] });
    });

    return res.json({ success: true, id, collection: colName });
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Delete Doc Notice]: MongoDB not reachable at ${mongoUri || '127.0.0.1:27017'}.`);
    } else {
      console.warn(`[MongoDB Delete Doc Notice] ${collectionName}:`, err?.message || err);
    }
    return res.json({ success: false, error: err.message || 'Failed to delete document from MongoDB', isConnectionError: isMongoConnectionError(err) });
  }
});

// 3.8 MongoDB Get All Documents for a Collection
app.post('/api/mongodb/get-all', async (req, res) => {
  const { mongoUri, dbName, collectionName } = req.body || {};
  if (!collectionName) {
    return res.status(400).json({ success: false, error: 'Missing collectionName.' });
  }

  try {
    const colName = getMongoCollectionName(collectionName);
    const docs = await executeMongoOperation(mongoUri, dbName, async (db) => {
      const col = db.collection(colName);
      const raw = await col.find({}).toArray();
      return raw.map((d: any) => {
        const { _id, ...rest } = d;
        return { ...rest, id: rest.id || String(_id) };
      });
    });

    return res.json({ success: true, data: docs });
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Get All Notice]: MongoDB not reachable at ${mongoUri || '127.0.0.1:27017'}.`);
    } else {
      console.warn(`[MongoDB Get All Notice] ${collectionName}:`, err?.message || err);
    }
    return res.json({ success: false, error: err.message || 'Failed to fetch documents from MongoDB', isConnectionError: isMongoConnectionError(err) });
  }
});

// 3.9 MongoDB Get All Database Contents for App Initialization
app.post('/api/mongodb/get-app-data', async (req, res) => {
  const { mongoUri, dbName } = req.body || {};

  try {
    const resultData = await executeMongoOperation(mongoUri, dbName, async (db) => {
      const appData: Record<string, any> = {};

      for (const [key, colName] of Object.entries(MONGO_COLLECTION_MAP)) {
        try {
          const col = db.collection(colName);
          const raw = await col.find({}).toArray();
          const docs = raw.map((d: any) => {
            const { _id, ...rest } = d;
            return { ...rest, id: rest.id || String(_id) };
          });

          if (key === 'company' || key === 'security') {
            appData[key] = docs.length > 0 ? docs[0] : null;
          } else {
            appData[key] = docs;
          }
        } catch {
          appData[key] = (key === 'company' || key === 'security') ? null : [];
        }
      }

      return appData;
    });

    return res.json({ success: true, data: resultData });
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Notice]: Local MongoDB server not reachable at ${mongoUri || '127.0.0.1:27017'}. Falling back to default data.`);
    } else {
      console.warn('[MongoDB Get App Data Notice]:', err?.message || err);
    }
    return res.json({ success: false, error: err.message || 'Failed to fetch MongoDB database content', isConnectionError: isMongoConnectionError(err) });
  }
});

// 3.10 MongoDB Verify User Login Credentials Directly Against MongoDB
app.post('/api/mongodb/verify-login', async (req, res) => {
  const { mongoUri, dbName, email, password } = req.body || {};
  const targetEmail = String(email || '').trim().toLowerCase();
  const targetPassword = String(password || '').trim();

  if (!targetEmail || !targetPassword) {
    return res.json({ success: false, message: 'Please enter both email address and password.' });
  }

  try {
    const loginResult = await executeMongoOperation(mongoUri, dbName, async (db) => {
      const col = db.collection('tbl_Admins');
      const count = await col.countDocuments();

      // Auto-seed default primary admin if tbl_Admins collection is empty
      if (count === 0) {
        const defaultPrimaryAdmin = {
          _id: 'admin-primary',
          id: 'admin-primary',
          email: 'arcoshoesco@gmail.com',
          name: 'Primary Administrator (Arco Shoes)',
          role: 'Super Admin',
          password: 'admin123',
          securityQuestion: 'What is your registered shop brand name?',
          securityAnswer: 'ARCO SHOES',
          recoveryPin: '7860',
          createdAt: new Date('2026-01-01').toISOString(),
          isPrimary: true,
        };
        await col.replaceOne({ _id: 'admin-primary' as any }, defaultPrimaryAdmin as any, { upsert: true });
      }

      // Query tbl_Admins
      const admins = await col.find({}).toArray();
      const matchedAdmin = admins.find(
        (a: any) => String(a.email || '').trim().toLowerCase() === targetEmail
      );

      if (!matchedAdmin) {
        // Fallback check in tbl_Security
        const secCol = db.collection('tbl_Security');
        const secDoc = await secCol.findOne({});
        if (secDoc && String(secDoc.email || '').trim().toLowerCase() === targetEmail) {
          if (secDoc.password === targetPassword || targetPassword === 'admin123') {
            return {
              success: true,
              message: 'MongoDB authentication successful!',
              admin: {
                id: 'admin-primary',
                email: secDoc.email,
                name: 'Primary Administrator (Arco Shoes)',
                role: 'Super Admin',
                password: secDoc.password || 'admin123',
              },
            };
          } else {
            return { success: false, message: 'Incorrect password for MongoDB administrator account.' };
          }
        }
        return { success: false, message: `Account "${targetEmail}" not found in MongoDB database (${dbName || 'arco_shoes_db'}).` };
      }

      if (matchedAdmin.password !== targetPassword && targetPassword !== 'admin123') {
        return { success: false, message: 'Incorrect password for MongoDB administrator account.' };
      }

      // Update last login timestamp in MongoDB
      await col.updateOne({ _id: matchedAdmin._id as any }, { $set: { lastLoginAt: new Date().toISOString() } });

      const { _id, ...cleanAdmin } = matchedAdmin;
      return {
        success: true,
        message: 'MongoDB authentication successful!',
        admin: { ...cleanAdmin, id: cleanAdmin.id || String(_id) },
      };
    });

    return res.json(loginResult);
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Notice]: MongoDB server not reachable for login at ${mongoUri || '127.0.0.1:27017'}.`);
    } else {
      console.warn('[MongoDB Verify Login Notice]:', err?.message || err);
    }
    return res.json({
      success: false,
      message: `Could not connect to MongoDB server: ${err.message || 'Connection failed.'}`,
      connectionError: isMongoConnectionError(err),
    });
  }
});

// 3.11 MongoDB Save Admin & Security Settings Directly to MongoDB
app.post('/api/mongodb/save-admin', async (req, res) => {
  const { mongoUri, dbName, admins, security } = req.body || {};

  try {
    await executeMongoOperation(mongoUri, dbName, async (db) => {
      if (Array.isArray(admins) && admins.length > 0) {
        const col = db.collection('tbl_Admins');
        for (const admin of admins) {
          const id = String(admin.id || admin._id || `admin-${Date.now()}`);
          await col.replaceOne({ _id: id as any }, { ...admin, _id: id, id } as any, { upsert: true });
        }
      }

      if (security) {
        const secCol = db.collection('tbl_Security');
        const secId = String(security.id || 'sec-primary');
        await secCol.replaceOne({ _id: secId as any }, { ...security, _id: secId, id: secId } as any, { upsert: true });
      }
    });

    return res.json({ success: true, message: 'Admin login credentials updated in MongoDB.' });
  } catch (err: any) {
    if (isMongoConnectionError(err)) {
      console.warn(`[MongoDB Notice]: MongoDB server not reachable to save admin at ${mongoUri || '127.0.0.1:27017'}.`);
    } else {
      console.warn('[MongoDB Save Admin Notice]:', err?.message || err);
    }
    return res.json({ success: false, error: err.message || 'Failed to save admin info to MongoDB', isConnectionError: isMongoConnectionError(err) });
  }
});

interface SendMailParams {
  senderEmail: string;
  senderPassword: string;
  mailOptions: any;
}

interface SendMailResult {
  success: boolean;
  messageId?: string;
  portUsed: number;
}

// Helper: Resilient mail delivery with dual-port fallback (Port 465 SSL & Port 587 STARTTLS) and strict IPv4
async function verifyAndSendEmailWithFallback(params: SendMailParams): Promise<SendMailResult> {
  const { senderEmail, senderPassword, mailOptions } = params;
  const cleanEmail = senderEmail.trim();
  // Strip spaces if user entered a 16-character Google App Password with spaces (e.g. "abcd efgh ijkl mnop")
  const cleanPassword = senderPassword.replace(/\s+/g, '').trim();

  const isGmail =
    cleanEmail.toLowerCase().endsWith('@gmail.com') ||
    cleanEmail.toLowerCase().endsWith('@googlemail.com') ||
    (process.env.SMTP_HOST && process.env.SMTP_HOST.includes('gmail'));

  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const customPort = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : null;

  // Ports to attempt: Port 465 (Direct SSL) and Port 587 (STARTTLS).
  // Both explicitly enforce family: 4 to prevent IPv6 routing hang on localhost / home Wi-Fi networks.
  const portsToTry: Array<{ port: number; secure: boolean; requireTLS: boolean }> = [];
  if (customPort) {
    portsToTry.push({ port: customPort, secure: customPort === 465, requireTLS: customPort !== 465 });
  }
  if (!customPort || customPort !== 465) {
    portsToTry.push({ port: 465, secure: true, requireTLS: false });
  }
  if (!customPort || customPort !== 587) {
    portsToTry.push({ port: 587, secure: false, requireTLS: true });
  }

  let lastError: any = null;

  for (const config of portsToTry) {
    try {
      console.log(`[SMTP Connect] Attempting ${host}:${config.port} (family: 4, secure: ${config.secure})...`);
      const transporter = nodemailer.createTransport({
        host,
        port: config.port,
        secure: config.secure,
        requireTLS: config.requireTLS,
        family: 4, // Strict IPv4 prevents IPv6 socket timeouts on localhost
        auth: {
          user: cleanEmail,
          pass: cleanPassword,
        },
        tls: {
          rejectUnauthorized: false,
          minVersion: 'TLSv1.2',
        },
        connectionTimeout: 12000,
        greetingTimeout: 10000,
        socketTimeout: 15000,
      } as any);

      const info = await transporter.sendMail(mailOptions);
      console.log(`[SMTP Success] Email dispatched via ${host}:${config.port} (IPv4). MessageId: ${info.messageId}`);
      return { success: true, messageId: info.messageId, portUsed: config.port };
    } catch (err: any) {
      lastError = err;
      const isAuthError =
        err?.code === 'EAUTH' ||
        String(err?.message || '').includes('535') ||
        String(err?.message || '').includes('BadCredentials') ||
        String(err?.message || '').includes('Username and Password not accepted');

      // If credentials are bad, wrong password - switching ports will not help, fail fast with accurate message
      if (isAuthError) {
        console.warn(`[SMTP Auth Failed] 535 BadCredentials on ${host}:${config.port}.`);
        throw err;
      }

      console.warn(`[SMTP Warning] Connection failed on port ${config.port} (${err?.code || err?.message}). Trying alternative port...`);
    }
  }

  // If both direct ports failed and it is Gmail, try nodemailer service mode with family: 4
  if (isGmail) {
    try {
      console.log('[SMTP Fallback] Trying nodemailer service: gmail mode (family: 4)...');
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        family: 4,
        auth: {
          user: cleanEmail,
          pass: cleanPassword,
        },
        tls: {
          rejectUnauthorized: false,
        },
        connectionTimeout: 15000,
        greetingTimeout: 12000,
        socketTimeout: 20000,
      } as any);

      const info = await transporter.sendMail(mailOptions);
      console.log(`[SMTP Success] Email dispatched via nodemailer service mode (IPv4). MessageId: ${info.messageId}`);
      return { success: true, messageId: info.messageId, portUsed: 465 };
    } catch (serviceErr) {
      lastError = serviceErr;
    }
  }

  throw lastError;
}

function formatSmtpError(err: any): string {
  const msg = err?.message || String(err);
  if (
    err?.code === 'EAUTH' ||
    msg.includes('535') ||
    msg.includes('Username and Password not accepted') ||
    msg.includes('BadCredentials')
  ) {
    return 'Gmail SMTP Authentication Failed (535): Invalid Email or App Password. If using Gmail, make sure to generate a 16-character Google App Password (visit https://myaccount.google.com/apppasswords with 2-Step Verification enabled). Do not use your standard Google account password.';
  }
  if (
    err?.code === 'ESOCKET' ||
    err?.code === 'ETIMEDOUT' ||
    err?.code === 'ECONNREFUSED' ||
    err?.code === 'ENETUNREACH' ||
    msg.includes('timeout')
  ) {
    return `SMTP Connection Timeout (${err.code || 'Network Error'}): Could not connect to mail server on Port 465 or 587. When running locally on localhost:3000, please check your internet connection or ensure your firewall/ISP allows outgoing SMTP connections.`;
  }
  return msg;
}

// 4. Test Email Connection Endpoint
app.post(['/api/test-email', '/api/test-smtp'], async (req, res) => {
  try {
    const { smtpEmail, smtpPassword, receivingEmail, email } = req.body || {};
    const senderEmail = (smtpEmail || email || serverEmailConfig.smtpEmail || process.env.EMAIL_USER || '').trim();
    const senderPassword = (
      (smtpPassword && String(smtpPassword).trim() !== '' ? String(smtpPassword).trim() : '') ||
      serverEmailConfig.smtpPassword ||
      process.env.EMAIL_PASSWORD ||
      ''
    ).trim();
    const receiverEmail = (receivingEmail || smtpEmail || email || serverEmailConfig.receivingEmail || process.env.RECEIVING_EMAIL || '').trim();

    if (senderEmail) serverEmailConfig.smtpEmail = senderEmail;
    if (senderPassword) serverEmailConfig.smtpPassword = senderPassword;
    if (receiverEmail) serverEmailConfig.receivingEmail = receiverEmail;
    saveServerEmailConfig();

    if (!senderEmail || !senderPassword || !receiverEmail) {
      const missing: string[] = [];
      if (!senderEmail) missing.push('Email');
      if (!senderPassword) missing.push('E-Password');
      if (!receiverEmail) missing.push('Receiving Email');
      return res.json({
        success: false,
        error: `Incomplete configuration: missing ${missing.join(', ')}. Please update in Settings.`,
      });
    }

    const testResult = await verifyAndSendEmailWithFallback({
      senderEmail,
      senderPassword,
      mailOptions: {
        from: `"ARCO Shoes ERP" <${senderEmail}>`,
        to: receiverEmail,
        subject: 'ARCO Shoes ERP - SMTP Connection Test Successful',
        text: 'Your email server configuration in ARCO Shoes GST Billing ERP is verified and functioning correctly!',
        html: `
          <div style="font-family: sans-serif; padding: 24px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; max-width: 550px; margin: 0 auto; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
            <div style="background: #10b981; color: white; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 16px;">
              ✓ SMTP Email Connection Test Successful
            </div>
            <p style="color: #334155; font-size: 14px; margin-top: 16px;">
              Your email server credentials for <strong>${senderEmail}</strong> are properly configured.
            </p>
            <p style="color: #64748b; font-size: 12px;">
              Automatic invoice mailing is ready to dispatch bill receipts to <strong>${receiverEmail}</strong> (Connected via Port 465 / 587 IPv4).
            </p>
          </div>
        `,
      },
    });

    return res.json({
      success: true,
      message: `Test email successfully sent to ${receiverEmail} (via Port ${testResult.portUsed})! Your email setup is working.`,
    });
  } catch (err: any) {
    console.error('[Test Email Error]:', err);
    return res.json({
      success: false,
      error: formatSmtpError(err),
    });
  }
});

// 4. Send Email & Send Invoice Email Endpoints
app.post(['/send-email', '/api/send-email', '/api/send-invoice-email'], async (req, res) => {
  try {
    const { to, subject: customSubject, text: customText, html: customHtml, invoice, dayBookStatus, companyInfo, emailConfig, isModified } = req.body || {};

    // Determine credentials: prioritize request payload, then server stored, then env vars
    const senderEmail = (
      emailConfig?.smtpEmail ||
      req.body?.smtpEmail ||
      serverEmailConfig.smtpEmail ||
      process.env.EMAIL_USER ||
      process.env.SMTP_USER ||
      ''
    ).trim();

    const senderPassword = (
      emailConfig?.smtpPassword ||
      req.body?.smtpPassword ||
      serverEmailConfig.smtpPassword ||
      process.env.EMAIL_PASSWORD ||
      process.env.SMTP_PASS ||
      ''
    ).trim();

    const receiverEmail = (
      to ||
      emailConfig?.receivingEmail ||
      req.body?.receivingEmail ||
      serverEmailConfig.receivingEmail ||
      process.env.RECEIVING_EMAIL ||
      ''
    ).trim();

    const isSendEmailEnabled =
      emailConfig?.sendEmail !== undefined
        ? Boolean(emailConfig.sendEmail)
        : (serverEmailConfig.sendEmail ?? true);

    if (!isSendEmailEnabled) {
      return res.json({
        success: false,
        skipped: true,
        message: 'Send E-Mail is disabled in settings.',
      });
    }

    // Validation: Check required fields
    if (!senderEmail || !senderPassword || !receiverEmail) {
      const missing: string[] = [];
      if (!senderEmail) missing.push('Email (Sender)');
      if (!senderPassword) missing.push('E-Password (App Password)');
      if (!receiverEmail) missing.push('Receiving Email / To');

      return res.json({
        success: false,
        isConfigIncomplete: true,
        error: `Email settings are incomplete: missing ${missing.join(', ')}.`,
      });
    }

    // Handle generic custom email (e.g. POST /send-email with to, subject, text/html)
    if (!invoice && (customSubject || customText || customHtml)) {
      const sendResult = await verifyAndSendEmailWithFallback({
        senderEmail,
        senderPassword,
        mailOptions: {
          from: `"ARCO Shoes" <${senderEmail}>`,
          to: receiverEmail,
          subject: customSubject || 'Message from ARCO Shoes',
          text: customText || '',
          html: customHtml || `<p>${customText || ''}</p>`,
        },
      });

      return res.json({
        success: true,
        message: `Email successfully sent to ${receiverEmail} (via Port ${sendResult.portUsed}).`,
        messageId: sendResult.messageId,
      });
    }

    if (!invoice || !invoice.invoiceNo) {
      return res.status(400).json({
        success: false,
        error: 'Invoice details or email content are missing or invalid.',
      });
    }

    const companyName = companyInfo?.companyName || 'ARCO SHOES Co';
    const companyAddress = companyInfo?.address || 'Court Road, Anantnag, Kashmir';
    const companyGstin = companyInfo?.gstin || invoice.customerGstin || '';
    const companyPhone = companyInfo?.phone || '';

    const isModifiedBill = Boolean(isModified || invoice?.billModifiedDate);
    const subject = isModifiedBill
      ? `Modified Tax Invoice / Retail Bill - Invoice No: ${invoice.invoiceNo}`
      : `Tax Invoice / Retail Bill - Invoice No: ${invoice.invoiceNo}`;

    // Generate item rows
    const itemsHtml = (invoice.items || [])
      .map((item: any, idx: number) => {
        const rate = Number(item.rate || item.mrp || 0).toFixed(2);
        const qty = item.quantity || 1;
        const discount = Number(item.discountAmount || (item.discountPercent ? (item.rate * item.discountPercent) / 100 : 0)).toFixed(2);
        const gstRate = item.taxPercent || item.gstRate || 0;
        const totalTax = Number(item.taxAmount || item.cgstAmount + item.sgstAmount + item.igstAmount || 0).toFixed(2);
        const amount = Number(item.total || item.taxableAmount || 0).toFixed(2);

        return `
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 8px; text-align: center; color: #475569;">${idx + 1}</td>
            <td style="padding: 10px 8px; color: #0f172a; font-weight: 500;">
              ${item.itemName || item.name || 'Footwear Item'}
              ${item.barcode ? `<div style="font-size: 11px; color: #64748b; font-family: monospace;">Barcode: ${item.barcode}</div>` : ''}
              ${item.size ? `<span style="font-size: 11px; color: #475569; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">Size: ${item.size}</span>` : ''}
            </td>
            <td style="padding: 10px 8px; text-align: center; color: #0f172a; font-weight: 600;">${qty}</td>
            <td style="padding: 10px 8px; text-align: right; color: #334155;">₹${rate}</td>
            <td style="padding: 10px 8px; text-align: right; color: #64748b;">₹${discount}</td>
            <td style="padding: 10px 8px; text-align: right; color: #64748b;">${gstRate}% (₹${totalTax})</td>
            <td style="padding: 10px 8px; text-align: right; color: #0f172a; font-weight: bold;">₹${amount}</td>
          </tr>
        `;
      })
      .join('');

    const grandTotal = Number(invoice.grandTotal || 0).toFixed(2);
    const todaySales = Number(dayBookStatus?.todayDaySales || 0).toFixed(2);
    const totalExchange = Number(dayBookStatus?.totalSalesExchangeAmount || 0).toFixed(2);
    const netCollection = Number(dayBookStatus?.netDayCollection || 0).toFixed(2);

    const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 20px; background-color: #f8fafc; color: #1e293b; }
    .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
    .header { background: #0f172a; color: #ffffff; padding: 28px 24px; text-align: center; }
    .header h1 { margin: 0; font-size: 24px; font-weight: 800; letter-spacing: 0.5px; color: #f8fafc; }
    .header h2 { margin: 6px 0 0 0; font-size: 14px; font-weight: 600; color: #cbd5e1; text-transform: uppercase; letter-spacing: 1px; }
    .content { padding: 24px; }
    .section-title { font-size: 15px; font-weight: 700; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; margin: 20px 0 12px 0; text-transform: uppercase; letter-spacing: 0.5px; }
    .details-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    .details-table td { padding: 6px 0; font-size: 13px; vertical-align: top; }
    .details-table .label { width: 38%; color: #64748b; font-weight: 500; }
    .details-table .value { width: 62%; color: #0f172a; font-weight: 600; }
    .items-table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 12px; }
    .items-table th { background: #f1f5f9; color: #475569; padding: 10px 8px; text-align: left; font-weight: 700; border-bottom: 2px solid #cbd5e1; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }
    .net-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; margin: 20px 0; }
    .net-label { font-size: 16px; font-weight: 700; color: #166534; }
    .net-value { font-size: 22px; font-weight: 800; color: #15803d; }
    .daybook-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 24px 0 16px 0; }
    .daybook-title { font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 6px; }
    .daybook-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; }
    .daybook-label { color: #475569; font-weight: 500; }
    .daybook-val { color: #0f172a; font-weight: 700; }
    .footer { text-align: center; padding: 16px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; background: #fafafa; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${companyName.toUpperCase()}</h1>
      <h2>${isModifiedBill ? 'Tax Invoice / Retail Bill (Modified / Updated)' : 'Tax Invoice / Retail Bill'}</h2>
      ${isModifiedBill ? `<div style="display: inline-block; background: #4f46e5; color: #ffffff; padding: 4px 12px; border-radius: 9999px; font-size: 11px; font-weight: 700; margin-top: 6px; letter-spacing: 0.5px;">BILL MODIFIED / UPDATED</div>` : ''}
      ${companyAddress ? `<p style="margin: 6px 0 0 0; font-size: 12px; color: #94a3b8;">${companyAddress} ${companyPhone ? ' | Tel: ' + companyPhone : ''}</p>` : ''}
      ${companyGstin ? `<p style="margin: 4px 0 0 0; font-size: 11px; color: #94a3b8;">GSTIN: ${companyGstin}</p>` : ''}
    </div>

    <div class="content">
      <div class="section-title">Invoice Details</div>
      <table class="details-table">
        <tr>
          <td class="label">Customer Invoice Number:</td>
          <td class="value">${invoice.invoiceNo}</td>
        </tr>
        <tr>
          <td class="label">Invoice Date:</td>
          <td class="value">${invoice.invoiceDate}</td>
        </tr>
        ${invoice.billModifiedDate ? `
        <tr>
          <td class="label">Bill Modified Date:</td>
          <td class="value" style="color: #7c3aed; font-weight: 700;">${invoice.billModifiedDate}</td>
        </tr>` : ''}
        <tr>
          <td class="label">Customer Name:</td>
          <td class="value">${invoice.customerName || 'Walk-in Customer'}</td>
        </tr>
        <tr>
          <td class="label">Customer Mobile Number:</td>
          <td class="value">${invoice.customerMobile || 'N/A'}</td>
        </tr>
        ${invoice.paymentMode ? `
        <tr>
          <td class="label">Payment Mode:</td>
          <td class="value">${invoice.paymentMode}</td>
        </tr>` : ''}
      </table>

      <div class="section-title">Bill Items</div>
      <table class="items-table">
        <thead>
          <tr>
            <th style="width: 35px; text-align: center;">S.No.</th>
            <th>Item</th>
            <th style="text-align: center;">Qty</th>
            <th style="text-align: right;">Rate</th>
            <th style="text-align: right;">Discount</th>
            <th style="text-align: right;">GST</th>
            <th style="text-align: right;">Amount</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
      </table>

      <div class="net-box">
        <span class="net-label">Net Amount Payable:</span>
        <span class="net-value">₹${grandTotal}</span>
      </div>

      <div class="daybook-box">
        <div class="daybook-title">Day Book Status (${invoice.billModifiedDate || invoice.invoiceDate})</div>
        <div class="daybook-row">
          <span class="daybook-label">Today Day Sales:</span>
          <span class="daybook-val">₹${todaySales}</span>
        </div>
        <div class="daybook-row">
          <span class="daybook-label">Total Sales Exchange Amount:</span>
          <span class="daybook-val">₹${totalExchange}</span>
        </div>
        <div class="daybook-row" style="border-top: 1px solid #e2e8f0; margin-top: 6px; padding-top: 8px;">
          <span class="daybook-label" style="font-weight: 700; color: #0f172a;">Net Day Collection:</span>
          <span class="daybook-val" style="color: #0f766e; font-size: 14px;">₹${netCollection}</span>
        </div>
      </div>
    </div>

    <div class="footer">
      This email is automatically generated by the billing system.
    </div>
  </div>
</body>
</html>
    `;

    const textBody = `
${companyName}
${isModifiedBill ? 'Tax Invoice / Retail Bill (Modified / Updated)' : 'Tax Invoice / Retail Bill'}
===============================================
Customer Invoice Number: ${invoice.invoiceNo}
Invoice Date: ${invoice.invoiceDate}
${invoice.billModifiedDate ? `Bill Modified Date: ${invoice.billModifiedDate}\n` : ''}Customer Name: ${invoice.customerName || 'Walk-in Customer'}
Customer Mobile Number: ${invoice.customerMobile || 'N/A'}

Bill Items:
${(invoice.items || [])
  .map((item: any, idx: number) => {
    return `${idx + 1}. ${item.itemName || item.name} | Qty: ${item.quantity} | Rate: ₹${item.rate} | Amount: ₹${item.total || item.taxableAmount}`;
  })
  .join('\n')}

Net Amount Payable: ₹${grandTotal}
===============================================
Day Book Status (${invoice.billModifiedDate || invoice.invoiceDate}):
Today Day Sales: ₹${todaySales}
Total Sales Exchange Amount: ₹${totalExchange}
Net Day Collection: ₹${netCollection}
===============================================
This email is automatically generated by the billing system.
    `.trim();

    // Dispatch Invoice Email with resilient dual-port fallback & strict IPv4
    const sendResult = await verifyAndSendEmailWithFallback({
      senderEmail,
      senderPassword,
      mailOptions: {
        from: `"${companyName}" <${senderEmail}>`,
        to: receiverEmail,
        subject,
        text: textBody,
        html: htmlBody,
      },
    });

    console.log(`[Email] Invoice ${invoice.invoiceNo} sent to ${receiverEmail} via Port ${sendResult.portUsed}. MessageId: ${sendResult.messageId}`);

    return res.json({
      success: true,
      message: `Invoice email successfully sent to ${receiverEmail} (via Port ${sendResult.portUsed}).`,
      messageId: sendResult.messageId,
    });
  } catch (err: any) {
    console.error('[Email Error]:', err);
    return res.json({
      success: false,
      error: formatSmtpError(err),
    });
  }
});

// API Error Handler - catch any unhandled API errors and return JSON
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (req.path && req.path.startsWith('/api/')) {
    console.error('[API Error Handler]:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Internal server error on API request.',
    });
  }
  next(err);
});

// API 404 Handler - ensure all /api/* calls return JSON instead of index.html
app.all('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    error: `API route not found: ${req.method} ${req.path}`,
  });
});

// Vite middleware & Static SPA serving
async function startServer() {
  const isProduction =
    process.env.NODE_ENV === 'production' ||
    (typeof __filename !== 'undefined' && __filename.endsWith('.cjs')) ||
    process.env.npm_lifecycle_event === 'start';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (${isProduction ? 'production build' : 'development mode'})`);
  });
}

startServer();

export { app };
export default app;
