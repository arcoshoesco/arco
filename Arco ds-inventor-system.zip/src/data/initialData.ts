import { CompanyInfo, Customer, Item, PurchaseInvoice, SalesInvoice, Supplier, LedgerEntry } from '../types';

export const INITIAL_COMPANY: CompanyInfo = {
  companyName: 'ARCO SHOES CO.',
  tagline: 'Wholesale & Retail Footwear Specialist',
  addressLine1: 'Shop No. 14-16, Metro Commercial Complex',
  addressLine2: 'Station Road, Gandhi Market',
  city: 'Mumbai',
  state: 'Maharashtra',
  stateCode: '27',
  pincode: '400001',
  phone: '022-24158970',
  mobile: '+91 98201 54321',
  email: 'arcoshoesco@gmail.com',
  gstin: '27AABCU9603R1ZM',
  pan: 'AABCU9603R',
  bankName: 'State Bank of India',
  bankAccountNo: '309876543210',
  bankIfsc: 'SBIN0000300',
  bankBranch: 'Fort Main Branch, Mumbai',
  upiId: 'arcoshoes@sbi',
  upiAddress: 'arcoshoes@sbi',
  upiAddressList: ['arcoshoes@sbi'],
  invoicePrefix: 'CUS-INV-',
  purchasePrefix: 'PUR-BILL-',
  invoiceTerms: '1. Goods once sold will not be taken back without cash receipt.\n2. Subject to Mumbai Jurisdiction only.\n3. Interest @ 18% p.a. will be charged if payment is not received within 15 days.',
  declaration: 'We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.',
  currencySymbol: '₹',
  smtpEmail: 'arcoshoesco@gmail.com',
  smtpPassword: '',
  receivingEmail: 'arcoshoesco@gmail.com',
  sendEmail: true,
  activeQrTitle: 'GPay / PhonePe UPI',
  defaultTaxCalculation: 'Inclusive',
  qrCodes: [
    {
      id: 'qr-default-1',
      title: 'GPay / PhonePe UPI',
      upiId: 'arcoshoes@sbi',
      qrDataUrl: '',
      notes: 'Main Counter Store UPI QR for customer instant payments',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'qr-default-2',
      title: 'Paytm Business QR',
      upiId: 'arcoshoes@paytm',
      qrDataUrl: '',
      notes: 'Paytm merchant QR code for store transactions',
      createdAt: new Date().toISOString(),
    },
  ],
};

// All demo entries removed - start with clean master and transaction tables
export const INITIAL_ITEMS: Item[] = [];
export const INITIAL_CUSTOMERS: Customer[] = [];
export const INITIAL_SUPPLIERS: Supplier[] = [];
export const INITIAL_SALES: SalesInvoice[] = [];
export const INITIAL_PURCHASES: PurchaseInvoice[] = [];
export const INITIAL_LEDGERS: LedgerEntry[] = [];
