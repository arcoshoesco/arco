import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Briefcase, 
  ShoppingCart, 
  FileText, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Package,
  Calendar,
  Layers,
  IndianRupee,
  Activity,
  BookOpen,
  Receipt,
  RotateCcw,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Filter,
  CheckCircle2,
  Clock,
  Crown,
  Award
} from 'lucide-react';
import { dbService } from '../services/storage';
import { 
  SalesInvoice, 
  PurchaseInvoice, 
  Customer, 
  Supplier, 
  CustomerReceipt, 
  SupplierPayment, 
  SalesReturn, 
  PurchaseReturn, 
  SalesExchange, 
  StockAdjustment 
} from '../types';

interface DashboardProps {
  onNavigateToTab: (tab: any) => void;
}

export const DashboardComponent: React.FC<DashboardProps> = ({ onNavigateToTab }) => {
  const [sales, setSales] = useState<SalesInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [receipts, setReceipts] = useState<CustomerReceipt[]>([]);
  const [payments, setPayments] = useState<SupplierPayment[]>([]);
  const [salesReturns, setSalesReturns] = useState<SalesReturn[]>([]);
  const [purchaseReturns, setPurchaseReturns] = useState<PurchaseReturn[]>([]);
  const [salesExchanges, setSalesExchanges] = useState<SalesExchange[]>([]);
  const [adjustments, setAdjustments] = useState<StockAdjustment[]>([]);

  // Month-wise filter for Sales Trend & Monthly Sales (YYYY-MM)
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  // Activity filter state for Today's Activities
  const [activityFilter, setActivityFilter] = useState<'ALL' | 'SALE' | 'PURCHASE' | 'PAYMENT' | 'RECEIPT' | 'OTHER'>('ALL');

  useEffect(() => {
    const loadData = () => {
      setSales(dbService.getSales());
      setPurchases(dbService.getPurchases());
      setCustomers(dbService.getCustomers());
      setSuppliers(dbService.getSuppliers());
      setReceipts(dbService.getReceipts());
      setPayments(dbService.getPayments());
      setSalesReturns(dbService.getSalesReturns());
      setPurchaseReturns(dbService.getPurchaseReturns());
      setSalesExchanges(dbService.getSalesExchanges());
      setAdjustments(dbService.getAdjustments());
    };

    loadData();
    return dbService.subscribe(loadData);
  }, []);

  // Helper to get local date string YYYY-MM-DD
  const getLocalDateStr = (d: Date = new Date()) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Today's local date string (YYYY-MM-DD)
  const todayStr = useMemo(() => {
    return getLocalDateStr(new Date());
  }, []);

  const formattedTodayDate = useMemo(() => {
    return new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }, []);

  const currentMonthStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }, []);

  // Parse Year and Month for month picker
  const [selectedYearNum, selectedMonthNum] = useMemo(() => {
    const parts = selectedMonth.split('-');
    const y = parseInt(parts[0], 10) || new Date().getFullYear();
    const m = parseInt(parts[1], 10) || (new Date().getMonth() + 1);
    return [y, m];
  }, [selectedMonth]);

  // Selected Month formatted name
  const formattedMonthName = useMemo(() => {
    const d = new Date(selectedYearNum, selectedMonthNum - 1, 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }, [selectedYearNum, selectedMonthNum]);

  // Month navigation handlers
  const handlePrevMonth = () => {
    let prevM = selectedMonthNum - 1;
    let prevY = selectedYearNum;
    if (prevM < 1) {
      prevM = 12;
      prevY -= 1;
    }
    setSelectedMonth(`${prevY}-${String(prevM).padStart(2, '0')}`);
  };

  const handleNextMonth = () => {
    let nextM = selectedMonthNum + 1;
    let nextY = selectedYearNum;
    if (nextM > 12) {
      nextM = 1;
      nextY += 1;
    }
    setSelectedMonth(`${nextY}-${String(nextM).padStart(2, '0')}`);
  };

  const handleCurrentMonth = () => {
    setSelectedMonth(currentMonthStr);
  };

  // 1. Compute Monthly Sales for the chosen Month
  const monthlySales = useMemo(() => {
    return sales.filter((s) => s.invoiceDate && s.invoiceDate.startsWith(selectedMonth));
  }, [sales, selectedMonth]);

  const totalMonthlySalesVal = useMemo(() => {
    return monthlySales.reduce((sum, s) => sum + (s.grandTotal || 0), 0);
  }, [monthlySales]);

  // Top 4 peak sales days of the active selected month based on total sales of each day
  const top4PeakDaysOfMonth = useMemo(() => {
    const dayMap: { [dateStr: string]: { dateStr: string; day: number; totalAmount: number; invoiceCount: number } } = {};

    monthlySales.forEach((s) => {
      if (!s.invoiceDate) return;
      const dateStr = s.invoiceDate;
      const parts = dateStr.split('-');
      const dayNum = parseInt(parts[2] || '1', 10);
      if (!dayMap[dateStr]) {
        dayMap[dateStr] = {
          dateStr,
          day: dayNum,
          totalAmount: 0,
          invoiceCount: 0,
        };
      }
      dayMap[dateStr].totalAmount += (s.grandTotal || 0);
      dayMap[dateStr].invoiceCount += 1;
    });

    return Object.values(dayMap)
      .filter((d) => d.totalAmount > 0)
      .sort((a, b) => b.totalAmount - a.totalAmount)
      .slice(0, 4);
  }, [monthlySales]);

  // Helper to format date into readable Day Month format (e.g. 10 Sep)
  const formatDayDisplay = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
      }
    } catch {}
    return dateStr;
  };

  // 12 months of the active year sorted in descending order of total sales
  const peakSalesMonthsList = useMemo(() => {
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const monthsData = monthNames.map((name, index) => {
      const monthNumStr = String(index + 1).padStart(2, '0');
      const yearMonthPrefix = `${selectedYearNum}-${monthNumStr}`;
      const salesInMonth = sales.filter((s) => s.invoiceDate && s.invoiceDate.startsWith(yearMonthPrefix));
      const totalAmount = salesInMonth.reduce((sum, s) => sum + (s.grandTotal || 0), 0);
      const invoiceCount = salesInMonth.length;

      return {
        monthIndex: index + 1,
        monthName: name,
        shortName: name.slice(0, 3),
        yearMonth: yearMonthPrefix,
        totalAmount,
        invoiceCount,
        isSelected: selectedMonth === yearMonthPrefix,
      };
    });

    // Sort all 12 months in descending order based on total sale of each month
    return [...monthsData].sort((a, b) => b.totalAmount - a.totalAmount);
  }, [sales, selectedYearNum, selectedMonth]);

  // Overall Cumulative Stats
  const totalPurchasesVal = useMemo(() => purchases.reduce((sum, p) => sum + p.grandTotal, 0), [purchases]);
  const totalOutstandingReceivables = useMemo(() => customers.reduce((sum, c) => sum + (c.currentBalance > 0 ? c.currentBalance : 0), 0), [customers]);
  const totalOutstandingPayables = useMemo(() => suppliers.reduce((sum, s) => sum + (s.currentBalance > 0 ? s.currentBalance : 0), 0), [suppliers]);

  // 2. Monthly Sale Trend: Day-by-Day Column Chart Data
  const monthlyChartData = useMemo(() => {
    const daysInMonth = new Date(selectedYearNum, selectedMonthNum, 0).getDate();
    const dayMap: { [day: number]: { amount: number; count: number; dateStr: string } } = {};

    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${selectedYearNum}-${String(selectedMonthNum).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      dayMap[day] = { amount: 0, count: 0, dateStr };
    }

    monthlySales.forEach((s) => {
      const parts = s.invoiceDate.split('-');
      if (parts.length === 3) {
        const dayNum = parseInt(parts[2], 10);
        if (dayMap[dayNum]) {
          dayMap[dayNum].amount += s.grandTotal || 0;
          dayMap[dayNum].count += 1;
        }
      }
    });

    return Array.from({ length: daysInMonth }, (_, idx) => {
      const day = idx + 1;
      const info = dayMap[day];
      const isToday = info.dateStr === todayStr;
      return {
        day,
        dateStr: info.dateStr,
        amount: info.amount,
        count: info.count,
        isToday,
      };
    });
  }, [selectedYearNum, selectedMonthNum, monthlySales, todayStr]);

  const maxDailyAmount = useMemo(() => {
    const maxVal = Math.max(...monthlyChartData.map((d) => d.amount), 0);
    return maxVal > 0 ? maxVal : 1000;
  }, [monthlyChartData]);

  const peakDailySale = useMemo(() => {
    return monthlyChartData.reduce((max, d) => (d.amount > max.amount ? d : max), { day: 0, amount: 0, count: 0, dateStr: '', isToday: false });
  }, [monthlyChartData]);

  const activeSaleDaysCount = useMemo(() => {
    return monthlyChartData.filter((d) => d.amount > 0).length;
  }, [monthlyChartData]);

  // Check if a date string matches today's date
  const isTodayActivity = (dateStr?: string, createdAt?: string): boolean => {
    if (dateStr && dateStr === todayStr) return true;
    if (createdAt) {
      const cd = new Date(createdAt);
      if (!isNaN(cd.getTime()) && getLocalDateStr(cd) === todayStr) {
        return true;
      }
    }
    return false;
  };

  // 4. Today's Activities: Unified list of all activities for today ONLY
  const allTodayActivities = useMemo(() => {
    const list: any[] = [];

    // Helper to extract time or fallback
    const extractTime = (createdAt?: string) => {
      if (!createdAt) return '';
      try {
        const d = new Date(createdAt);
        if (!isNaN(d.getTime())) {
          return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        }
      } catch {}
      return '';
    };

    // Sales of today
    sales.forEach((inv) => {
      if (isTodayActivity(inv.invoiceDate, inv.createdAt)) {
        list.push({
          id: `sale-${inv.id}`,
          date: inv.invoiceDate,
          time: extractTime(inv.createdAt),
          type: 'SALE',
          category: 'SALE',
          label: `Sale Bill: ${inv.invoiceNo}`,
          party: inv.customerName || 'Cash Sale',
          amount: inv.grandTotal,
          color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
          badge: 'Sale',
          rawTimestamp: inv.createdAt ? new Date(inv.createdAt).getTime() : new Date(`${inv.invoiceDate}T12:00:00`).getTime(),
        });
      }
    });

    // Purchases of today
    purchases.forEach((pur) => {
      if (isTodayActivity(pur.purchaseDate, pur.createdAt)) {
        list.push({
          id: `pur-${pur.id}`,
          date: pur.purchaseDate,
          time: extractTime(pur.createdAt),
          type: 'PURCHASE',
          category: 'PURCHASE',
          label: `Purchase: ${pur.supplierBillNo || pur.purchaseNo}`,
          party: pur.supplierName,
          amount: pur.grandTotal,
          color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
          badge: 'Purchase',
          rawTimestamp: pur.createdAt ? new Date(pur.createdAt).getTime() : new Date(`${pur.purchaseDate}T12:00:00`).getTime(),
        });
      }
    });

    // Receipts of today
    receipts.forEach((rcpt) => {
      if (isTodayActivity(rcpt.receiptDate, rcpt.createdAt)) {
        list.push({
          id: `rcpt-${rcpt.id}`,
          date: rcpt.receiptDate,
          time: extractTime(rcpt.createdAt),
          type: 'RECEIPT',
          category: 'RECEIPT',
          label: `Receipt: ${rcpt.receiptNo}`,
          party: rcpt.customerName,
          amount: rcpt.amountReceived,
          color: 'text-teal-400 bg-teal-500/10 border-teal-500/30',
          badge: 'Receipt',
          rawTimestamp: rcpt.createdAt ? new Date(rcpt.createdAt).getTime() : new Date(`${rcpt.receiptDate}T12:00:00`).getTime(),
        });
      }
    });

    // Payments of today
    payments.forEach((pymt) => {
      if (isTodayActivity(pymt.voucherDate, pymt.createdAt)) {
        list.push({
          id: `pymt-${pymt.id}`,
          date: pymt.voucherDate,
          time: extractTime(pymt.createdAt),
          type: 'PAYMENT',
          category: 'PAYMENT',
          label: `Payment: ${pymt.voucherNo}`,
          party: pymt.supplierName,
          amount: pymt.amountPaid,
          color: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
          badge: 'Payment',
          rawTimestamp: pymt.createdAt ? new Date(pymt.createdAt).getTime() : new Date(`${pymt.voucherDate}T12:00:00`).getTime(),
        });
      }
    });

    // Sales Returns of today
    salesReturns.forEach((sr) => {
      if (isTodayActivity(sr.returnDate, sr.createdAt)) {
        list.push({
          id: `sr-${sr.id}`,
          date: sr.returnDate,
          time: sr.returnTime || extractTime(sr.createdAt),
          type: 'RETURN',
          category: 'OTHER',
          label: `Sales Return: ${sr.returnNo}`,
          party: sr.customerName || 'Walk-in Customer',
          amount: sr.grandTotal,
          color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
          badge: 'Return',
          rawTimestamp: sr.createdAt ? new Date(sr.createdAt).getTime() : new Date(`${sr.returnDate}T12:00:00`).getTime(),
        });
      }
    });

    // Purchase Returns of today
    purchaseReturns.forEach((pr) => {
      if (isTodayActivity(pr.returnDate, pr.createdAt)) {
        list.push({
          id: `pr-${pr.id}`,
          date: pr.returnDate,
          time: extractTime(pr.createdAt),
          type: 'PURCHASE_RETURN',
          category: 'OTHER',
          label: `Debit Note: ${pr.returnNo}`,
          party: pr.supplierName,
          amount: pr.grandTotal,
          color: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
          badge: 'Debit Note',
          rawTimestamp: pr.createdAt ? new Date(pr.createdAt).getTime() : new Date(`${pr.returnDate}T12:00:00`).getTime(),
        });
      }
    });

    // Sales Exchanges of today
    salesExchanges.forEach((exc) => {
      if (isTodayActivity(exc.exchangeDate)) {
        list.push({
          id: `exc-${exc.id}`,
          date: exc.exchangeDate,
          time: exc.exchangeTime || '',
          type: 'EXCHANGE',
          category: 'OTHER',
          label: `Sales Exchange: ${exc.exchangeNo}`,
          party: exc.customerName || 'Customer',
          amount: exc.newTotalValue,
          color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
          badge: 'Exchange',
          rawTimestamp: new Date(`${exc.exchangeDate}T${exc.exchangeTime || '12:00:00'}`).getTime(),
        });
      }
    });

    // Stock Adjustments of today
    adjustments.forEach((adj) => {
      if (isTodayActivity(adj.adjustmentDate, adj.createdAt)) {
        const qty = adj.physicalStock ?? adj.adjustedStock ?? 0;
        list.push({
          id: `adj-${adj.id}`,
          date: adj.adjustmentDate,
          time: extractTime(adj.createdAt),
          type: 'ADJUSTMENT',
          category: 'OTHER',
          label: `Stock Adj: ${adj.itemName}`,
          party: `Physical: ${qty} Qty (${adj.reason || 'Correction'})`,
          amount: adj.adjustmentValue || 0,
          color: 'text-slate-300 bg-slate-500/10 border-slate-500/30',
          badge: 'Adjustment',
          rawTimestamp: adj.createdAt ? new Date(adj.createdAt).getTime() : new Date(`${adj.adjustmentDate}T12:00:00`).getTime(),
        });
      }
    });

    // Sort by timestamp descending
    list.sort((a, b) => b.rawTimestamp - a.rawTimestamp);
    return list;
  }, [sales, purchases, receipts, payments, salesReturns, purchaseReturns, salesExchanges, adjustments, todayStr]);

  // Filter today's activities strictly by selected category
  const displayedActivities = useMemo(() => {
    if (activityFilter === 'ALL') return allTodayActivities;
    return allTodayActivities.filter((item) => item.category === activityFilter);
  }, [allTodayActivities, activityFilter]);

  // Today activity counts
  const todayCounts = useMemo(() => {
    return {
      all: allTodayActivities.length,
      sales: allTodayActivities.filter((a) => a.category === 'SALE').length,
      purchases: allTodayActivities.filter((a) => a.category === 'PURCHASE').length,
      payments: allTodayActivities.filter((a) => a.category === 'PAYMENT').length,
      receipts: allTodayActivities.filter((a) => a.category === 'RECEIPT').length,
      others: allTodayActivities.filter((a) => a.category === 'OTHER').length,
    };
  }, [allTodayActivities]);

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions & Month Filter */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-4 sm:p-5 backdrop-blur-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <span>Business Dashboard</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Real-time insights, day-wise monthly sales trends, and operational activities.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Month Selector in Banner */}
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs shadow-inner">
              <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                <span>Month:</span>
              </span>
              <button
                type="button"
                onClick={handlePrevMonth}
                title="Previous Month"
                className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <input
                id="dashboard-month-picker"
                type="month"
                value={selectedMonth}
                onChange={(e) => e.target.value && setSelectedMonth(e.target.value)}
                className="bg-transparent text-slate-200 font-mono font-bold text-xs py-0.5 px-1 border border-slate-700/50 rounded focus:outline-none focus:border-blue-500 cursor-pointer"
              />
              <button
                type="button"
                onClick={handleNextMonth}
                title="Next Month"
                className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              {selectedMonth !== currentMonthStr && (
                <button
                  type="button"
                  onClick={handleCurrentMonth}
                  className="ml-1 px-2 py-0.5 rounded text-[10px] bg-blue-600/30 text-blue-300 hover:bg-blue-600 hover:text-white transition-all font-semibold cursor-pointer"
                >
                  This Month
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* KPI Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* KPI 1: Total Monthly Sale */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition-all shadow-md relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Monthly Sale</span>
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-slate-100 font-sans tracking-tight">
              ₹{totalMonthlySalesVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="text-[10px] text-emerald-400 flex items-center justify-between mt-2.5 font-bold">
            <div className="flex items-center gap-1 truncate">
              <Activity className="w-3 h-3 shrink-0" />
              <span className="truncate">{formattedMonthName} ({monthlySales.length} Bills)</span>
            </div>
            {selectedMonth === currentMonthStr && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">Current</span>
            )}
          </div>
        </div>

        {/* KPI 2: Peak Sales Day of The Month (Active Month's Top 4 Days by Total Sales) */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Peak Sales Day of The Month</span>
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                <Crown className="w-4 h-4" />
              </div>
            </div>

            {top4PeakDaysOfMonth.length > 0 ? (
              <div className="space-y-1.5 max-h-[118px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
                {top4PeakDaysOfMonth.map((d, idx) => {
                  const rankBadgeClass =
                    idx === 0
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : idx === 1
                      ? 'bg-slate-700/50 text-slate-200 border-slate-600/40'
                      : idx === 2
                      ? 'bg-orange-950/50 text-orange-300 border-orange-700/40'
                      : 'bg-indigo-950/50 text-indigo-300 border-indigo-700/40';

                  return (
                    <div
                      key={d.dateStr}
                      className="flex items-center justify-between text-xs py-1.5 px-2.5 rounded-lg bg-slate-950/60 border border-slate-800/70"
                    >
                      <div className="flex items-center gap-2 min-w-0 pr-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border font-mono shrink-0 ${rankBadgeClass}`}>
                          #{idx + 1}
                        </span>
                        <span className="font-medium text-[11px] text-slate-200 truncate">
                          {formatDayDisplay(d.dateStr)}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-xs sm:text-sm text-amber-400 shrink-0">
                        ₹{d.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-4 text-center text-slate-500 text-xs">
                <span>No sales in {formattedMonthName}</span>
              </div>
            )}
          </div>

          <div className="text-[10px] text-amber-400/90 flex items-center justify-between mt-2.5 font-bold pt-1 border-t border-slate-800/60">
            <div className="flex items-center gap-1 truncate">
              <Award className="w-3 h-3 shrink-0" />
              <span className="truncate">Top 4 Days of {formattedMonthName}</span>
            </div>
            {top4PeakDaysOfMonth.length > 0 && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                Top: ₹{top4PeakDaysOfMonth[0].totalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </span>
            )}
          </div>
        </div>

        {/* KPI 3: Peak Sales Month of The Year (All 12 Months in Descending Order of Active Year) */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Peak Sales Month of The Year</span>
              <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400">
                <Calendar className="w-4 h-4" />
              </div>
            </div>

            {/* List of all 12 months in descending order */}
            <div className="space-y-1 max-h-[118px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
              {peakSalesMonthsList.map((m, idx) => {
                const rankClass =
                  idx === 0
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : idx === 1
                    ? 'bg-slate-700/50 text-slate-200 border-slate-600/40'
                    : idx === 2
                    ? 'bg-orange-950/50 text-orange-300 border-orange-700/40'
                    : 'bg-slate-900 text-slate-400 border-slate-800';

                return (
                  <div
                    key={m.yearMonth}
                    onClick={() => setSelectedMonth(m.yearMonth)}
                    className={`flex items-center justify-between text-xs py-1 px-2 rounded-lg border transition-colors cursor-pointer ${
                      m.isSelected
                        ? 'bg-sky-950/60 border-sky-500/60 text-sky-200'
                        : 'bg-slate-950/60 border-slate-800/70 hover:bg-slate-850 hover:border-slate-700 text-slate-300'
                    }`}
                    title={`Click to switch to ${m.monthName} ${selectedYearNum}`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0 pr-1">
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border font-mono shrink-0 ${rankClass}`}>
                        #{idx + 1}
                      </span>
                      <span className="font-medium text-[11px] truncate">
                        {m.monthName}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-[11px] text-sky-400 shrink-0">
                      ₹{m.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-[10px] text-sky-400/90 flex items-center justify-between mt-2.5 font-bold pt-1 border-t border-slate-800/60">
            <div className="flex items-center gap-1 truncate">
              <Activity className="w-3 h-3 shrink-0" />
              <span className="truncate">{selectedYearNum} Ranked</span>
            </div>
            {peakSalesMonthsList.length > 0 && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono">
                Top: {peakSalesMonthsList[0].shortName}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: Monthly Sale Trend & Today's Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Sale Trend (Column Chart with Day-by-day bars and month-wise date picker) */}
        <div className="bg-slate-900/30 border border-slate-800/80 rounded-2xl p-5 lg:col-span-7 backdrop-blur-sm flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Monthly Sale Trend</span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Day-wise sales columns for <span className="text-slate-200 font-semibold">{formattedMonthName}</span>
              </p>
            </div>

            {/* Date picker for month-wise sales trend */}
            <div className="flex items-center gap-1 bg-slate-950/90 border border-slate-800 rounded-xl px-2 py-1 text-xs shrink-0 self-start sm:self-auto">
              <button
                type="button"
                onClick={handlePrevMonth}
                title="Previous Month"
                className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <input
                id="chart-month-picker"
                type="month"
                value={selectedMonth}
                onChange={(e) => e.target.value && setSelectedMonth(e.target.value)}
                className="bg-transparent text-slate-200 font-mono font-bold text-xs py-0.5 px-1 border-0 focus:outline-none focus:ring-0 cursor-pointer"
              />
              <button
                type="button"
                onClick={handleNextMonth}
                title="Next Month"
                className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Month Metrics Summary */}
          <div className="grid grid-cols-3 gap-2 mb-4 p-2.5 rounded-xl bg-slate-950/60 border border-slate-850 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">Total Sales</span>
              <span className="font-bold text-emerald-400 font-mono">
                ₹{totalMonthlySalesVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Active Selling Days</span>
              <span className="font-bold text-blue-400 font-mono">
                {activeSaleDaysCount} / {monthlyChartData.length} Days
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Peak Day Sale</span>
              <span className="font-bold text-amber-300 font-mono">
                {peakDailySale.amount > 0 ? `Day ${peakDailySale.day}: ₹${peakDailySale.amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}` : '₹0'}
              </span>
            </div>
          </div>

          {/* Column Chart Area */}
          <div className="h-64 flex flex-col justify-between relative pt-6">
            {/* Background Grid Lines */}
            <div className="absolute inset-x-0 top-6 bottom-7 flex flex-col justify-between pointer-events-none opacity-20">
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
            </div>

            {/* Bars Column Container */}
            <div className="flex-1 flex items-end gap-1 sm:gap-1.5 px-1 pb-1 border-b border-slate-800 z-0">
              {monthlyChartData.map((d) => {
                const heightPercent = d.amount > 0 ? Math.max(8, (d.amount / maxDailyAmount) * 100) : 4;
                const hasSales = d.amount > 0;

                return (
                  <div key={d.day} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                    {/* Hover Tooltip */}
                    <div className="absolute -top-12 scale-0 group-hover:scale-100 bg-slate-950 text-slate-100 text-[10px] font-medium px-2.5 py-1.5 rounded-lg border border-slate-700 shadow-2xl transition-all duration-150 z-20 whitespace-nowrap pointer-events-none text-center">
                      <div className="font-bold text-blue-300">
                        {new Date(d.dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </div>
                      <div className="font-mono text-emerald-400 font-bold">
                        ₹{d.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="text-slate-400 text-[9px]">{d.count} bill{d.count === 1 ? '' : 's'}</div>
                    </div>

                    {/* Column Bar */}
                    <div 
                      className={`w-full rounded-t transition-all duration-300 cursor-pointer ${
                        d.isToday 
                          ? 'bg-gradient-to-t from-emerald-600 to-teal-400 shadow-emerald-500/30 ring-1 ring-emerald-400' 
                          : hasSales 
                            ? 'bg-gradient-to-t from-blue-600 to-indigo-500 hover:brightness-125 shadow-blue-900/20' 
                            : 'bg-slate-800/40 hover:bg-slate-700/60'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                );
              })}
            </div>
            
            {/* X-Axis day numbers */}
            <div className="flex justify-between items-center pt-2 text-[9px] font-mono text-slate-400 px-1">
              {monthlyChartData.map((d, idx) => {
                // On dense screens, show key days (1, 5, 10, 15, 20, 25, end) or all if width allows
                const isKeyDay = d.day === 1 || d.day === 5 || d.day === 10 || d.day === 15 || d.day === 20 || d.day === 25 || d.day === monthlyChartData.length || d.isToday;
                return (
                  <span 
                    key={idx} 
                    className={`flex-1 text-center truncate ${
                      d.isToday ? 'text-emerald-400 font-bold underline' : isKeyDay ? 'text-slate-300 font-semibold' : 'text-slate-600 hidden sm:inline-block'
                    }`}
                  >
                    {d.day}
                  </span>
                );
              })}
            </div>
          </div>
        </div>

        {/* Today's Activities (Renamed from Recent Vouchers & Invoices) */}
        <div className="bg-slate-900/30 border border-slate-800/80 rounded-2xl p-5 lg:col-span-5 backdrop-blur-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-400" />
                  <span>Today's Activities</span>
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Live transactions of <span className="text-slate-200 font-semibold font-mono">{new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold bg-emerald-950/80 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-800/50 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{todayCounts.all} Today</span>
                </span>
              </div>
            </div>

            {/* Filter Chips */}
            <div className="flex flex-wrap gap-1 mb-3 text-[10.5px]">
              <button
                type="button"
                onClick={() => setActivityFilter('ALL')}
                className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  activityFilter === 'ALL'
                    ? 'bg-blue-600 text-white border-blue-500 font-bold'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                All ({todayCounts.all})
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('SALE')}
                className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  activityFilter === 'SALE'
                    ? 'bg-emerald-600 text-white border-emerald-500 font-bold'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Sales ({todayCounts.sales})
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('PURCHASE')}
                className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  activityFilter === 'PURCHASE'
                    ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Purchases ({todayCounts.purchases})
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('PAYMENT')}
                className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  activityFilter === 'PAYMENT'
                    ? 'bg-rose-600 text-white border-rose-500 font-bold'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Payments ({todayCounts.payments})
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('RECEIPT')}
                className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  activityFilter === 'RECEIPT'
                    ? 'bg-teal-600 text-white border-teal-500 font-bold'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Receipts ({todayCounts.receipts})
              </button>
              {todayCounts.others > 0 && (
                <button
                  type="button"
                  onClick={() => setActivityFilter('OTHER')}
                  className={`px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                    activityFilter === 'OTHER'
                      ? 'bg-amber-600 text-white border-amber-500 font-bold'
                      : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  Others ({todayCounts.others})
                </button>
              )}
            </div>

            {/* Activities List */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin pr-1">
              {displayedActivities.length === 0 ? (
                <div className="text-center py-10 px-4 bg-slate-950/30 rounded-xl border border-dashed border-slate-800">
                  <Clock className="w-6 h-6 text-slate-600 mx-auto mb-2" />
                  <div className="text-xs text-slate-300 font-semibold">
                    No activities recorded for today ({formattedTodayDate})
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
                    Sales, purchases, receipts, and payments created today will appear here in real time.
                  </p>
                </div>
              ) : (
                displayedActivities.map((tx) => (
                  <div 
                    key={tx.id} 
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/50 border border-slate-850 hover:border-slate-750 transition-all"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`p-1.5 rounded-lg text-xs shrink-0 border ${tx.color}`}>
                        {tx.type === 'SALE' && <ShoppingCart className="w-3.5 h-3.5" />}
                        {tx.type === 'PURCHASE' && <FileText className="w-3.5 h-3.5" />}
                        {tx.type === 'RECEIPT' && <ArrowDownLeft className="w-3.5 h-3.5" />}
                        {tx.type === 'PAYMENT' && <ArrowUpRight className="w-3.5 h-3.5" />}
                        {tx.type === 'RETURN' && <RotateCcw className="w-3.5 h-3.5" />}
                        {tx.type === 'PURCHASE_RETURN' && <RotateCcw className="w-3.5 h-3.5" />}
                        {tx.type === 'EXCHANGE' && <RefreshCw className="w-3.5 h-3.5" />}
                        {tx.type === 'ADJUSTMENT' && <Package className="w-3.5 h-3.5" />}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-200 truncate">{tx.label}</span>
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono shrink-0">
                            {tx.badge}
                          </span>
                        </div>
                        <div className="text-[10.5px] text-slate-400 truncate mt-0.5 font-medium">{tx.party}</div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 pl-2">
                      <div className="text-xs font-black text-slate-200 font-mono">
                        {tx.amount > 0 ? `₹${tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '-'}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                        {tx.time ? tx.time : new Date(tx.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Bottom quick navigation to day book */}
          <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between text-xs">
            <span className="text-[11px] text-slate-400">Detailed Day-Book Register</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('invoices')}
              className="text-amber-400 hover:text-amber-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Open Day Book</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
