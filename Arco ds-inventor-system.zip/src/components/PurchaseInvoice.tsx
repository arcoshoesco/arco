import React, { useState, useEffect } from 'react';
import {
  Truck,
  Plus,
  Trash2,
  Save,
  RotateCcw,
  History,
  AlertCircle,
  CheckCircle,
  Search,
  ArrowDownLeft,
} from 'lucide-react';
import { CompanyInfo, InvoiceItem, Item, PurchaseInvoice, Supplier } from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';

interface PurchaseInvoiceProps {
  company: CompanyInfo;
}

export const PurchaseInvoiceComponent: React.FC<PurchaseInvoiceProps> = ({ company }) => {
  const [itemsList, setItemsList] = useState<Item[]>([]);
  const [suppliersList, setSuppliersList] = useState<Supplier[]>([]);

  // Form State
  const [invoiceId, setInvoiceId] = useState<string>('');
  const [purchaseInvoiceNo, setPurchaseInvoiceNo] = useState<string>('');
  const [supplierBillNo, setSupplierBillNo] = useState<string>('');
  const [purchaseDate, setPurchaseDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [supplierGstin, setSupplierGstin] = useState<string>('');
  const [supplierAddress, setSupplierAddress] = useState<string>('');
  const [supplierStateCode, setSupplierStateCode] = useState<string>('09');
  const [isInterState, setIsInterState] = useState<boolean>(true);
  const [paymentMode, setPaymentMode] = useState<'Credit' | 'Bank/NEFT' | 'Cash'>('Credit');
  const [remarks, setRemarks] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<number>(0);

  // Line items state
  const [lineItems, setLineItems] = useState<InvoiceItem[]>([]);

  // Row buffer
  const [activeItemId, setActiveItemId] = useState<string>('');
  const [rowQty, setRowQty] = useState<number>(6);
  const [rowRate, setRowRate] = useState<number>(0);
  const [rowSellingRate, setRowSellingRate] = useState<number | ''>('');
  const [rowMrp, setRowMrp] = useState<number | ''>('');
  const [rowDisc, setRowDisc] = useState<number>(0);

  // History modal
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const activeTaxType = company.defaultTaxCalculation || 'Inclusive';

  const loadMasterData = () => {
    const itms = dbService.getItems();
    const sups = dbService.getSuppliers();
    setItemsList(itms);
    setSuppliersList(sups);
    if (sups.length > 0 && !selectedSupplierId) {
      handleSupplierChange(sups[0].id, sups);
    }
  };

  const resetForm = () => {
    const itms = dbService.getItems();
    const sups = dbService.getSuppliers();
    setItemsList(itms);
    setSuppliersList(sups);

    const nextPurNo = dbService.getNextPurchaseNo();
    setInvoiceId(`PUR-${Date.now()}`);
    setPurchaseInvoiceNo(nextPurNo);
    setSupplierBillNo('');
    setPurchaseDate(new Date().toISOString().split('T')[0]);

    if (sups.length > 0) {
      handleSupplierChange(sups[0].id, sups);
    }

    setPaymentMode('Credit');
    setRemarks('');
    setLineItems([]);
    setAmountPaid(0);
    setActiveItemId('');
    setRowQty(6);
    setRowRate(0);
    setRowSellingRate('');
    setRowMrp('');
    setRowDisc(0);
    setFeedback(null);
  };

  useEffect(() => {
    resetForm();
    return dbService.subscribe(() => {
      setItemsList(dbService.getItems());
      setSuppliersList(dbService.getSuppliers());
    });
  }, []);

  const handleSupplierChange = (supId: string, currentSuppliers = suppliersList) => {
    setSelectedSupplierId(supId);
    const sup = currentSuppliers.find((s) => s.id === supId);
    if (sup) {
      setSupplierGstin(sup.gstin || '');
      setSupplierAddress(sup.address || '');
      setSupplierStateCode(sup.stateCode || '09');
      const isInter = sup.stateCode && sup.stateCode !== company.stateCode;
      setIsInterState(Boolean(isInter));
    }
  };

  const handleItemSelect = (itmId: string) => {
    setActiveItemId(itmId);
    const itm = itemsList.find((i) => i.id === itmId);
    if (itm) {
      setRowRate(itm.purchaseRate || 0);
      setRowSellingRate(itm.sellingRate !== undefined && itm.sellingRate !== null ? itm.sellingRate : '');
      setRowMrp(itm.mrp !== undefined && itm.mrp !== null ? itm.mrp : (itm.sellingRate || ''));
      setRowQty(6);
      setRowDisc(0);
    } else {
      setRowRate(0);
      setRowSellingRate('');
      setRowMrp('');
      setRowQty(6);
      setRowDisc(0);
    }
  };

  const handleAddLineItem = () => {
    if (!activeItemId) {
      setFeedback({ type: 'error', text: 'Select an item to add to purchase inward.' });
      return;
    }
    const itm = itemsList.find((i) => i.id === activeItemId);
    if (!itm) return;

    if (rowQty <= 0) {
      setFeedback({ type: 'error', text: 'Purchase quantity must be greater than 0.' });
      return;
    }

    const calc = calculateLineGST(
      Number(rowQty),
      Number(rowRate) || itm.purchaseRate,
      rowDisc,
      itm.gstRate,
      isInterState,
      activeTaxType
    );
    const newLine: InvoiceItem = {
      id: `PL-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      itemId: itm.id,
      itemCode: itm.itemCode,
      itemName: itm.itemName,
      hsnCode: itm.hsnCode,
      quantity: Number(rowQty),
      unit: itm.unit,
      rate: Number(rowRate) || itm.purchaseRate,
      sellingRate: rowSellingRate !== '' ? Number(rowSellingRate) : itm.sellingRate,
      mrp: rowMrp !== '' ? Number(rowMrp) : (itm.mrp || itm.sellingRate),
      gstRate: itm.gstRate,
      ...calc,
    };

    setLineItems([...lineItems, newLine]);
    setActiveItemId('');
    setRowQty(6);
    setRowRate(0);
    setRowSellingRate('');
    setRowMrp('');
    setRowDisc(0);
  };

  const handleRemoveLineItem = (index: number) => {
    setLineItems(lineItems.filter((_, idx) => idx !== index));
  };

  // Calculations
  const totalQuantity = lineItems.reduce((acc, it) => acc + it.quantity, 0);
  const grossSubtotal = roundTo2(lineItems.reduce((acc, it) => acc + it.grossAmount, 0));
  const totalDiscount = roundTo2(lineItems.reduce((acc, it) => acc + it.discountAmount, 0));
  const totalTaxable = roundTo2(lineItems.reduce((acc, it) => acc + it.taxableAmount, 0));
  const totalCgst = roundTo2(lineItems.reduce((acc, it) => acc + it.cgstAmount, 0));
  const totalSgst = roundTo2(lineItems.reduce((acc, it) => acc + it.sgstAmount, 0));
  const totalIgst = roundTo2(lineItems.reduce((acc, it) => acc + it.igstAmount, 0));
  const totalTax = roundTo2(totalCgst + totalSgst + totalIgst);

  const exactNet = totalTaxable + totalTax;
  const grandTotal = Math.round(exactNet);
  const roundOff = roundTo2(grandTotal - exactNet);

  const selectedSupplier = suppliersList.find((s) => s.id === selectedSupplierId);
  const previousBalance = selectedSupplier ? selectedSupplier.currentBalance : 0;
  const effectivePaid = paymentMode === 'Cash' || paymentMode === 'Bank/NEFT' ? grandTotal : amountPaid;
  const balanceDue = Math.max(0, roundTo2(grandTotal - effectivePaid));
  const newBalance = roundTo2(previousBalance + balanceDue);

  const handleSavePurchase = () => {
    if (lineItems.length === 0) {
      setFeedback({ type: 'error', text: 'Please add at least 1 item to inward purchase.' });
      return;
    }
    if (!supplierBillNo.trim()) {
      setFeedback({ type: 'error', text: 'Supplier Bill / Invoice No. is required for GST input credit audit.' });
      return;
    }

    const currentSup = suppliersList.find((s) => s.id === selectedSupplierId);
    const invoice: PurchaseInvoice = {
      id: invoiceId,
      purchaseNo: purchaseInvoiceNo,
      purchaseInvoiceNo,
      supplierBillNo,
      purchaseDate,
      supplierId: selectedSupplierId,
      supplierName: currentSup ? currentSup.supplierName : 'Vendor',
      supplierGstin,
      supplierAddress,
      supplierStateCode,
      isInterState,
      paymentMode,
      items: lineItems,
      totalQuantity,
      grossSubtotal,
      totalDiscount,
      totalTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalTax,
      freightOtherCharges: 0,
      roundOff,
      grandTotal,
      amountPaid: effectivePaid,
      balanceDue,
      previousBalance,
      newBalance,
      remarks,
      createdAt: new Date().toISOString(),
    };

    const res = dbService.savePurchaseInvoice(invoice);
    if (res.success) {
      setFeedback({ type: 'success', text: res.message });
      setTimeout(() => resetForm(), 1200);
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  const pastPurchases = dbService.getPurchases();

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Header Form */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/40 pb-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center shadow-inner">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>Stock Purchase</span>
                <span className="text-xs font-mono font-normal bg-slate-800/60 text-slate-400 px-2 py-0.5 rounded border border-slate-700/50">
                  frmPurchaseInvoice
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Inward goods entry with automated stock addition, ITC tax tracking & vendor ledger update.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-view-past-purchases"
              onClick={() => setShowHistoryModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all"
            >
              <History className="w-4 h-4 text-sky-400" />
              <span>Past Inward Bills ({pastPurchases.length})</span>
            </button>
            <button
              id="btn-new-purchase"
              onClick={resetForm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all"
            >
              <RotateCcw className="w-4 h-4 text-orange-400" />
              <span>New Entry</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
          {/* 1. PURCHASE BILL NO */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">PURCHASE BILL NO</label>
            <input
              type="text"
              readOnly
              value={purchaseInvoiceNo}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-orange-400 font-mono font-bold cursor-not-allowed"
            />
          </div>

          {/* 2. BILL DATE */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Bill Date</label>
            <input
              type="date"
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
            />
          </div>

          {/* 3. SUPPLIER BILL NUMBER */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-orange-400 uppercase tracking-wider mb-1">Supplier Bill Number *</label>
            <input
              type="text"
              required
              value={supplierBillNo}
              onChange={(e) => setSupplierBillNo(e.target.value)}
              placeholder="e.g. SUP-BILL-001"
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono font-bold focus:border-orange-500 focus:outline-none"
            />
          </div>

          {/* 4. Select Supplier */}
          <div className="sm:col-span-2 lg:col-span-3 bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Select Supplier / Manufacturer</label>
            <select
              value={selectedSupplierId}
              onChange={(e) => handleSupplierChange(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none text-xs"
            >
              {suppliersList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.supplierName} ({formatCurrency(s.currentBalance)} Cr)
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-700/40 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span>Supplier GSTIN: <strong className="font-mono text-slate-200">{supplierGstin || 'Unregistered'}</strong></span>
            <span>•</span>
            <span>
              Type: <strong className="text-orange-300">{isInterState ? 'Inter-State (IGST ITC)' : 'Intra-State (CGST + SGST ITC)'}</strong>
            </span>
            <span>•</span>
            <span>
              Tax Calculation Mode: <strong className="text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-700/40">{activeTaxType} GST</strong>
            </span>
          </div>
          <div>
            <span>Previous Payable Balance: <strong className="text-orange-400 font-mono">{formatCurrency(previousBalance)} Cr</strong></span>
          </div>
        </div>
      </div>

      {/* Item Quick Insertion */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-12 gap-2.5 text-xs items-end">
          <div className="sm:col-span-2 md:col-span-4">
            <label className="block text-slate-400 font-medium mb-1">Select Product / Footwear Article</label>
            <select
              value={activeItemId}
              onChange={(e) => handleItemSelect(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none text-xs"
            >
              <option value="">-- Choose Item to Receive --</option>
              {itemsList.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.itemCode} - {i.itemName} (Cur Stock: {i.currentStock} | Cost: ₹{i.purchaseRate})
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-1 md:col-span-1">
            <label className="block text-slate-400 font-medium mb-1">Inward Qnty</label>
            <input
              type="number"
              min="1"
              value={rowQty}
              onChange={(e) => setRowQty(Math.max(1, Number(e.target.value)))}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-bold font-mono focus:border-orange-500 focus:outline-none text-xs"
            />
          </div>

          <div className="sm:col-span-1 md:col-span-2">
            <label className="block text-slate-400 font-medium mb-1">Purchase Cost (₹)</label>
            <input
              type="number"
              value={rowRate}
              onChange={(e) => setRowRate(Number(e.target.value))}
              placeholder="0.00"
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-orange-500 focus:outline-none text-xs"
            />
          </div>

          {/* Selling Rate box after Purchase Cost */}
          <div className="sm:col-span-1 md:col-span-2">
            <label className="block text-emerald-400 font-medium mb-1 flex items-center justify-between">
              <span>Selling Rate (₹)</span>
            </label>
            <input
              type="number"
              value={rowSellingRate}
              onChange={(e) => setRowSellingRate(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="Sale Price"
              className="w-full bg-slate-950/70 border border-emerald-500/40 rounded-lg px-2.5 py-1.5 text-emerald-300 font-mono font-semibold focus:border-emerald-400 focus:outline-none text-xs"
            />
          </div>

          {/* MRP Print box after Selling Rate */}
          <div className="sm:col-span-1 md:col-span-2">
            <label className="block text-sky-400 font-medium mb-1 flex items-center justify-between">
              <span>MRP Print (₹)</span>
            </label>
            <input
              type="number"
              value={rowMrp}
              onChange={(e) => setRowMrp(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="Printed MRP"
              className="w-full bg-slate-950/70 border border-sky-500/40 rounded-lg px-2.5 py-1.5 text-sky-300 font-mono font-semibold focus:border-sky-400 focus:outline-none text-xs"
            />
          </div>

          <div className="sm:col-span-2 md:col-span-1">
            <button
              id="btn-add-purchase-line"
              type="button"
              onClick={handleAddLineItem}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-semibold rounded-lg shadow-lg shadow-orange-900/20 border border-orange-500/30 transition-all text-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Inward</span>
            </button>
          </div>
        </div>
      </div>

      {/* Line Items Table */}
      <div className="bg-slate-900/20 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden text-slate-200">
        <div className="overflow-x-auto max-h-72">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
              <tr>
                <th className="py-2.5 px-2.5 w-8 text-center">#</th>
                <th className="py-2.5 px-3">Item Details</th>
                <th className="py-2.5 px-2 text-center w-16">HSN</th>
                <th className="py-2.5 px-2 text-right w-16">Inward Qnty</th>
                <th className="py-2.5 px-2 text-right w-20">Cost Rate</th>
                <th className="py-2.5 px-2 text-right w-20">Selling Rate</th>
                <th className="py-2.5 px-2 text-right w-20">MRP Print</th>
                <th className="py-2.5 px-2 text-right w-20">Taxable</th>
                <th className="py-2.5 px-2 text-center w-12">GST%</th>
                <th className="py-2.5 px-2 text-right w-20">GST Tax</th>
                <th className="py-2.5 px-3 text-right w-24">Net Amount</th>
                <th className="py-2.5 px-2 text-center w-10">Act</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {lineItems.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-500 font-sans">
                    No inward items added yet.
                  </td>
                </tr>
              ) : (
                lineItems.map((line, idx) => (
                  <tr key={line.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2.5 px-2.5 text-center text-slate-400">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-100">{line.itemName}</td>
                    <td className="py-2.5 px-2 text-center text-slate-300">{line.hsnCode}</td>
                    <td className="py-2.5 px-2 text-right font-bold text-orange-400">{line.quantity} {line.unit}</td>
                    <td className="py-2.5 px-2 text-right">₹{line.rate.toFixed(2)}</td>
                    <td className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                      {line.sellingRate !== undefined && line.sellingRate !== null ? `₹${line.sellingRate.toFixed(2)}` : '-'}
                    </td>
                    <td className="py-2.5 px-2 text-right text-sky-400 font-semibold">
                      {line.mrp !== undefined && line.mrp !== null ? `₹${line.mrp.toFixed(2)}` : '-'}
                    </td>
                    <td className="py-2.5 px-2 text-right font-semibold">₹{line.taxableAmount.toFixed(2)}</td>
                    <td className="py-2.5 px-2 text-center">{line.gstRate}%</td>
                    <td className="py-2.5 px-2 text-right text-sky-400">
                      ₹{(line.cgstAmount + line.sgstAmount + line.igstAmount).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-orange-300 text-sm">
                      ₹{line.netAmount.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      <button
                        onClick={() => handleRemoveLineItem(idx)}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800/60 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Financial Summary & Save */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Remarks / Freight / Vehicle Info</label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Received via VRL Logistics TR-9982"
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-orange-500 focus:outline-none"
            />
          </div>
          <div>
            <span className="text-slate-400">Total Inward Units: </span>
            <strong className="text-orange-400 font-mono">{totalQuantity} Pairs</strong>
          </div>
        </div>

        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3 text-slate-300">
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/50 backdrop-blur-sm">
            <div className="grid grid-cols-3 gap-2 font-mono">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Taxable Amount</span>
                <span className="font-semibold text-slate-200">₹{totalTaxable.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Total GST (ITC)</span>
                <span className="font-semibold text-sky-400">₹{totalTax.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Round Off</span>
                <span>{roundOff.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Frosted Grand Total Callout */}
          <div className="bg-orange-600/20 p-4 sm:p-5 rounded-xl border border-orange-500/40 flex flex-col justify-center shadow-inner backdrop-blur-md">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-black text-orange-400 tracking-widest block">
                  Total Inward Bill Amount
                </span>
                <span className="text-[10px] text-orange-300 italic mt-0.5 block">
                  Stock automatically incremented in inventory
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl sm:text-3xl font-mono text-white font-bold leading-tight">
                  ₹{grandTotal.toLocaleString('en-IN')}.00
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-700/40">
            <button
              id="btn-save-purchase"
              type="button"
              onClick={handleSavePurchase}
              className="flex items-center gap-1.5 px-5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg shadow-lg shadow-orange-900/30 border border-orange-500/30 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Inward Purchase Bill</span>
            </button>
          </div>
        </div>
      </div>

      {/* Past Purchases History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[85vh] flex flex-col text-slate-100">
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-700/50 flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-100">Past Purchase Inward Records</h3>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 text-xs transition"
              >
                Close
              </button>
            </div>

            <div className="overflow-y-auto flex-1 p-3">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                  <tr>
                    <th className="p-2.5">Inward No</th>
                    <th className="p-2.5">Supplier Bill No</th>
                    <th className="p-2.5">Date</th>
                    <th className="p-2.5">Supplier</th>
                    <th className="p-2.5 text-center">Items</th>
                    <th className="p-2.5 text-right">Taxable</th>
                    <th className="p-2.5 text-right">GST (ITC)</th>
                    <th className="p-2.5 text-right">Grand Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {pastPurchases.map((pur) => (
                    <tr key={pur.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 font-bold text-orange-400">{pur.purchaseInvoiceNo}</td>
                      <td className="p-2.5 text-slate-200">{pur.supplierBillNo}</td>
                      <td className="p-2.5 text-slate-300">{pur.purchaseDate}</td>
                      <td className="p-2.5 font-sans font-medium text-slate-100">{pur.supplierName}</td>
                      <td className="p-2.5 text-center">{pur.totalQuantity}</td>
                      <td className="p-2.5 text-right">₹{pur.totalTaxable.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{pur.totalTax.toFixed(2)}</td>
                      <td className="p-2.5 text-right font-bold text-orange-300 text-sm">
                        ₹{pur.grandTotal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
