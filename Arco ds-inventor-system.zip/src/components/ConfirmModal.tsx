import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface ConfirmModalProps {
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  title = 'Confirm Action',
  message,
  confirmLabel = 'Delete',
  cancelLabel = 'Cancel',
  isDestructive = true,
  onConfirm,
  onCancel,
}) => {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in select-none">
      <div className="bg-slate-900 border-2 border-rose-500/40 rounded-2xl max-w-sm w-full shadow-2xl p-6 text-center text-slate-100 font-sans transform scale-100 transition-all duration-300">
        {/* Icon */}
        <div className="mx-auto w-14 h-14 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-rose-500/10">
          <AlertTriangle className="w-8 h-8 stroke-[2]" />
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold text-slate-100 mb-2">
          {title}
        </h3>

        {/* Message */}
        <p className="text-sm text-slate-300 mb-6 leading-relaxed font-medium">
          {message}
        </p>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-800 text-slate-300 font-semibold rounded-xl text-sm border border-slate-700 shadow-sm transition-all cursor-pointer focus:outline-none"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`flex-1 py-2.5 font-semibold rounded-xl text-sm shadow-md transition-all cursor-pointer focus:outline-none ${
              isDestructive
                ? 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white focus:ring-2 focus:ring-rose-500/50'
                : 'bg-amber-600 hover:bg-amber-500 text-white focus:ring-2 focus:ring-amber-500/50'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
