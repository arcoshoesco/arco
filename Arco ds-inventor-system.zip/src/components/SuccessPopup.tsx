import React, { useEffect, useRef } from 'react';
import { CheckCircle, AlertTriangle, XCircle, Info } from 'lucide-react';

export interface SuccessPopupProps {
  type?: 'success' | 'error' | 'warning' | 'info';
  title?: string;
  message: string;
  buttonText?: string;
  onClose: () => void;
}

export const SuccessPopup: React.FC<SuccessPopupProps> = ({
  type = 'success',
  title,
  message,
  buttonText = 'OK',
  onClose,
}) => {
  const isError = type === 'error';
  const isWarning = type === 'warning';
  const isInfo = type === 'info';
  const okButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    // Focus the OK button on mount
    okButtonRef.current?.focus();

    // Keyboard listener for Enter or Escape
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [onClose]);

  const defaultTitle = isError
    ? 'Action Required'
    : isWarning
    ? 'Warning'
    : isInfo
    ? 'Information'
    : 'Success Operation';

  const displayTitle = title || defaultTitle;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in select-none"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        className={`bg-slate-900 border-2 rounded-2xl max-w-sm w-full shadow-2xl p-6 text-center text-slate-100 font-sans transform scale-100 transition-all duration-300 ${
          isError
            ? 'border-rose-500/50'
            : isWarning
            ? 'border-amber-500/50'
            : isInfo
            ? 'border-blue-500/50'
            : 'border-emerald-500/50'
        }`}
      >
        {/* Animated Icon Circle */}
        <div
          className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-lg border ${
            isError
              ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 shadow-rose-500/10'
              : isWarning
              ? 'bg-amber-500/20 text-amber-400 border-amber-500/30 shadow-amber-500/10'
              : isInfo
              ? 'bg-blue-500/20 text-blue-400 border-blue-500/30 shadow-blue-500/10'
              : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30 shadow-emerald-500/10'
          }`}
        >
          {isError ? (
            <XCircle className="w-10 h-10 stroke-[2]" />
          ) : isWarning ? (
            <AlertTriangle className="w-10 h-10 stroke-[2]" />
          ) : isInfo ? (
            <Info className="w-10 h-10 stroke-[2]" />
          ) : (
            <CheckCircle className="w-10 h-10 stroke-[2]" />
          )}
        </div>

        {/* Header */}
        <h3 className="text-lg font-bold text-slate-100 mb-2">
          {displayTitle}
        </h3>

        {/* Message */}
        <p className="text-sm text-slate-300 mb-6 leading-relaxed font-medium">
          {message}
        </p>

        {/* OK Close Button */}
        <button
          ref={okButtonRef}
          id="btn-dialog-ok"
          type="button"
          onClick={onClose}
          className={`w-full py-2.5 font-bold rounded-xl text-sm shadow-md transition-all cursor-pointer focus:outline-none text-white ring-offset-2 ring-offset-slate-900 ${
            isError
              ? 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 focus:ring-2 focus:ring-rose-500'
              : isWarning
              ? 'bg-amber-600 hover:bg-amber-500 active:bg-amber-700 focus:ring-2 focus:ring-amber-500'
              : isInfo
              ? 'bg-blue-600 hover:bg-blue-500 active:bg-blue-700 focus:ring-2 focus:ring-blue-500'
              : 'bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 focus:ring-2 focus:ring-emerald-500'
          }`}
        >
          {buttonText}
        </button>
      </div>
    </div>
  );
};

