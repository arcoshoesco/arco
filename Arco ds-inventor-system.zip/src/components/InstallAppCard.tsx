import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppCardProps {
  onOpenDetails?: () => void;
}

export const InstallAppCard: React.FC<InstallAppCardProps> = ({ onOpenDetails }) => {
  const {
    isInstalled,
    isInstallable,
    hasPrompt,
    isSecure,
    browserInfo,
    outcome,
    install,
  } = usePWAInstall();

  const [isInstalling, setIsInstalling] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleInstall = async () => {
    setFeedback(null);
    setIsInstalling(true);
    try {
      const res = await install();
      if (res.outcome === 'dismissed') {
        setFeedback('Installation prompt was dismissed.');
      } else if (res.outcome === 'unavailable') {
        if (onOpenDetails) {
          onOpenDetails();
        } else {
          setFeedback('Use the Install icon in your browser address bar (top right) or check the installation guide.');
        }
      }
    } catch (err: any) {
      setFeedback(err?.message || 'Installation error occurred.');
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <div
      id="section-install-app-desktop-shortcut"
      className="bg-gradient-to-br from-slate-900/90 via-slate-900/60 to-slate-950/80 border border-amber-500/40 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3 text-xs relative overflow-hidden"
    >
      <div className="flex items-center justify-between border-b border-slate-700/50 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg p-0.5 bg-slate-800/80 border border-amber-400/50 shadow-sm flex items-center justify-center shrink-0 overflow-hidden">
            <img
              src="/icon.png"
              alt="Install App Icon"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-md"
            />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">Install App</h3>
            <span className="text-[10px] text-slate-400">Desktop &amp; Start Menu</span>
          </div>
        </div>

        {isInstalled ? (
          <span className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            <CheckCircle2 className="w-3 h-3" />
            Installed
          </span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
            <AlertCircle className="w-3 h-3 text-amber-400" />
            Not Installed
          </span>
        )}
      </div>

      <p className="text-slate-300 leading-relaxed">
        Install ARCO SHOES on this computer for quick access from the Desktop and Start Menu.
      </p>

      {/* Installation Status Display */}
      <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
        <span className="text-slate-400">Status:</span>
        {isInstalled ? (
          <span className="font-bold text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            ARCO SHOES is installed on this computer.
          </span>
        ) : (
          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            App is not installed
          </span>
        )}
      </div>

      {feedback && (
        <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[11px]">
          {feedback}
        </div>
      )}

      {/* Action Button */}
      {isInstalled ? (
        <div className="space-y-2">
          <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-200 text-[11px] leading-relaxed">
            Ready to launch anytime directly from your <strong>Windows Desktop shortcut</strong> or <strong>Start Menu</strong>.
          </div>
          {onOpenDetails && (
            <button
              type="button"
              onClick={onOpenDetails}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>View Installation Guide & Details</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          <button
            type="button"
            id="btn-install-arco-shoes-card"
            disabled={isInstalling}
            onClick={handleInstall}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-600/20 border border-amber-400/60 transition cursor-pointer disabled:opacity-50"
          >
            {isInstalling ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <img
                src="/pwa-128x128.png"
                alt="Install"
                referrerPolicy="no-referrer"
                className="w-4 h-4 rounded object-cover border border-slate-950/40"
              />
            )}
            <span>Install App</span>
          </button>

          {onOpenDetails && (
            <button
              type="button"
              onClick={onOpenDetails}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 text-[11px] text-slate-400 hover:text-amber-300 transition cursor-pointer"
            >
              <span>How to install & browser guide</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
