import React, { useState, useEffect, useMemo } from 'react';
import {
  Settings,
  Building,
  Save,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Keyboard,
  FileCode,
  HardDrive,
  Palette,
  Check,
  Sparkles,
  ShieldCheck,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  LogOut,
  AlertCircle,
  Mail,
  QrCode,
  Plus,
  Trash2,
  Cloud,
  RefreshCw,
  UserPlus,
  Users,
  ArrowRightLeft,
  ExternalLink,
  Database,
  Server,
  Copy,
  Shield,
  Activity,
  Monitor
} from 'lucide-react';
import { AppTheme, CompanyInfo, SecurityAuthSettings, QrCodeOption, AdminUser } from '../types';
import { dbService } from '../services/storage';
import { authService } from '../services/authService';
import { getApiUrl, checkBackendHealth } from '../services/apiConfig';
import { BACKEND_DETAILS, firebaseConfig } from '../firebase';
import { INDIAN_STATES } from '../services/gstCalculations';
import { THEME_OPTIONS } from '../data/themes';
import { syncEmailConfigToServer, testEmailConnection } from '../services/emailService';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';
import { InstallAppSection } from './InstallAppSection';
import { InstallAppCard } from './InstallAppCard';

interface CompanySettingsProps {
  company: CompanyInfo;
  onCompanyUpdated: (info: CompanyInfo) => void;
  onLogout?: () => void;
}

export const CompanySettingsComponent: React.FC<CompanySettingsProps> = ({
  company,
  onCompanyUpdated,
  onLogout,
}) => {
  const [formData, setFormData] = useState<CompanyInfo>({ ...company });
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);

  // Sync formData with company prop whenever company prop changes
  useEffect(() => {
    setFormData({ ...company });
  }, [company]);

  // UPI Address Dropdown Management
  const [newUpiAddress, setNewUpiAddress] = useState<string>('');
  const [showAddUpiInput, setShowAddUpiInput] = useState<boolean>(false);

  const upiList = useMemo(() => {
    const list = Array.isArray(formData.upiAddressList) ? [...formData.upiAddressList] : [];
    const active = (formData.upiAddress || formData.upiId || '').trim();
    if (active && !list.includes(active)) {
      list.unshift(active);
    }
    return list;
  }, [formData.upiAddressList, formData.upiAddress, formData.upiId]);

  const handleAddUpiAddress = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newUpiAddress.trim();
    if (!trimmed) {
      setFeedback({ type: 'error', text: 'Please enter a UPI address to add (e.g. yourbusiness@upi).' });
      return;
    }
    const currentList = Array.isArray(formData.upiAddressList) ? [...formData.upiAddressList] : [];
    if (!currentList.includes(trimmed)) {
      currentList.push(trimmed);
    }
    const updated: CompanyInfo = {
      ...formData,
      upiAddress: trimmed,
      upiId: trimmed,
      upiAddressList: currentList,
    };
    setFormData(updated);
    dbService.saveCompanyInfo(updated);
    onCompanyUpdated(updated);
    setNewUpiAddress('');
    setShowAddUpiInput(false);
    setFeedback({ type: 'success', text: `UPI address "${trimmed}" added to list and set as active.` });
  };

  const handleSelectUpiAddress = (selectedUpi: string) => {
    const updated: CompanyInfo = {
      ...formData,
      upiAddress: selectedUpi,
      upiId: selectedUpi,
    };
    setFormData(updated);
    dbService.saveCompanyInfo(updated);
    onCompanyUpdated(updated);
    setFeedback({ type: 'success', text: `Active UPI address set to "${selectedUpi}".` });
  };

  const handleDeleteUpiAddress = () => {
    const active = (formData.upiAddress || formData.upiId || '').trim();
    if (!active) {
      setFeedback({ type: 'error', text: 'No UPI address selected to delete.' });
      return;
    }
    const currentList = (Array.isArray(formData.upiAddressList) ? formData.upiAddressList : [active])
      .filter((addr) => addr !== active);
    const nextActive = currentList.length > 0 ? currentList[0] : '';
    const updated: CompanyInfo = {
      ...formData,
      upiAddress: nextActive,
      upiId: nextActive,
      upiAddressList: currentList,
    };
    setFormData(updated);
    dbService.saveCompanyInfo(updated);
    onCompanyUpdated(updated);
    setFeedback({
      type: 'success',
      text: `UPI address "${active}" removed from the list.` + (nextActive ? ` Active set to "${nextActive}".` : ''),
    });
  };

  // Email Purpose State
  const [showEPassword, setShowEPassword] = useState<boolean>(false);
  const [isTestingEmail, setIsTestingEmail] = useState<boolean>(false);
  const [isTestingMongo, setIsTestingMongo] = useState<boolean>(false);
  const [backendStatus, setBackendStatus] = useState<{
    checked: boolean;
    online: boolean;
    service?: string;
    port?: number;
    message?: string;
  }>({ checked: false, online: false });
  const [showEmailGuide, setShowEmailGuide] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    checkBackendHealth().then((res) => {
      if (!isMounted) return;
      setBackendStatus({
        checked: true,
        online: res.success,
        service: res.service,
        port: res.port || 3000,
        message: res.message,
      });
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleTestEmailConnection = async () => {
    if (isTestingEmail) return;

    const email = (formData.smtpEmail || formData.email || '').trim();
    const pass = (formData.smtpPassword || '').trim();
    const receiver = (formData.receivingEmail || formData.email || formData.smtpEmail || '').trim();

    if (!email) {
      setFeedback({
        type: 'error',
        title: 'Sender Email Required',
        text: 'Please enter your Gmail / Sender Email address in the Email field before testing.',
      });
      return;
    }
    if (!pass) {
      setFeedback({
        type: 'error',
        title: 'E-Password Required',
        text: 'Please enter your 16-character Google App Password in the E-Password field. Standard Gmail passwords are not supported by Google for automated SMTP.',
      });
      return;
    }
    if (!receiver) {
      setFeedback({
        type: 'error',
        title: 'Receiving Email Required',
        text: 'Please enter the Receiving Email address where test and invoice receipts should be sent.',
      });
      return;
    }

    setIsTestingEmail(true);

    // Save current form data locally first
    dbService.saveCompanyInfo(formData);
    onCompanyUpdated(formData);

    const health = await checkBackendHealth();
    setBackendStatus({
      checked: true,
      online: health.success,
      service: health.service,
      port: health.port || 3000,
      message: health.message,
    });

    if (!health.success && health.isHtmlResponse) {
      setIsTestingEmail(false);
      const isRemoteHost = typeof window !== 'undefined' && window.location.hostname && !window.location.hostname.includes('localhost') && !window.location.hostname.includes('127.0.0.1');
      setFeedback({
        type: 'error',
        title: isRemoteHost ? 'Firebase Cloud Backend Required' : 'Backend Server Offline on Port 3000',
        text: isRemoteHost
          ? 'When deployed on Firebase Hosting, static web hosting does not run Node.js Express server code directly. To enable email delivery in production: (1) Deploy your backend for free on Render.com or Railway and paste your live URL into the "Backend Server URL" field below, or (2) Deploy Firebase Cloud Functions (requires Firebase Blaze plan).'
          : 'The Node.js Express backend is not running or unreachable on port 3000. When running locally, start the server using "npm start" (or "npm run dev") so the Express backend is active to handle SMTP mail delivery.',
      });
      return;
    }

    const res = await testEmailConnection(formData);
    setIsTestingEmail(false);
    if (res.success) {
      setFeedback({ type: 'success', title: 'SMTP Email Test Passed', text: res.message });
    } else {
      setFeedback({ type: 'error', title: 'SMTP Email Test Failed', text: res.message });
    }
  };

  const handleSelectDatabaseType = (type: 'firebase' | 'mongodb') => {
    const updatedComp: CompanyInfo = {
      ...formData,
      databaseType: type,
      mongoUri: formData.mongoUri || 'mongodb://127.0.0.1:27017',
      mongoDbName: formData.mongoDbName || 'arco_shoes_db',
    };
    setFormData(updatedComp);
    dbService.saveCompanyInfo(updatedComp);
    onCompanyUpdated(updatedComp);
    setFeedback({
      type: 'success',
      text: `Database engine set to ${type === 'firebase' ? 'Firebase Cloud Database' : 'Local MongoDB Database'}.`,
    });
  };

  const handleTestMongoConnection = async () => {
    if (isTestingMongo) return;
    setIsTestingMongo(true);
    try {
      const uri = formData.mongoUri || 'mongodb://127.0.0.1:27017';
      const dbName = formData.mongoDbName || 'arco_shoes_db';
      const res = await fetch(getApiUrl('/api/test-mongodb'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uri, dbName }),
      });
      const data = await res.json();
      if (data.success) {
        setFeedback({
          type: 'success',
          title: 'MongoDB Connected & Database Created',
          text: data.message,
        });
      } else {
        setFeedback({
          type: 'error',
          title: 'MongoDB Connection Failed',
          text: `${data.error} ${data.help ? `(${data.help})` : ''}`,
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'MongoDB Test Failed',
        text: err.message || 'Error communicating with local MongoDB endpoint.',
      });
    } finally {
      setIsTestingMongo(false);
    }
  };

  // New QR Code State
  const [newQrTitle, setNewQrTitle] = useState<string>('');
  const [newQrUpi, setNewQrUpi] = useState<string>('');
  const [newQrDataUrl, setNewQrDataUrl] = useState<string>('');
  const [newQrFileName, setNewQrFileName] = useState<string>('');

  const handleSelectActiveQrTitle = (title: string) => {
    const updatedCompany: CompanyInfo = {
      ...formData,
      activeQrTitle: title,
    };
    setFormData(updatedCompany);
    dbService.saveCompany(updatedCompany);
    onCompanyUpdated(updatedCompany);
    setFeedback({
      type: 'success',
      text: `Active payment QR switched to "${title}" successfully!`,
    });
  };

  const handleQrFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setNewQrFileName(file.name);
    const reader = new FileReader();
    reader.onload = (evt) => {
      const dataUrl = evt.target?.result as string;
      setNewQrDataUrl(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleAddQrCode = () => {
    if (!newQrTitle.trim()) {
      setFeedback({ type: 'error', text: 'Please enter a QR Title for the new QR code.' });
      return;
    }
    const existingList = formData.qrCodes || [];
    const newEntry: QrCodeOption = {
      id: `qr-${Date.now()}`,
      title: newQrTitle.trim(),
      upiId: newQrUpi.trim() || formData.upiId || 'arcoshoes@sbi',
      qrDataUrl: newQrDataUrl,
      createdAt: new Date().toISOString(),
    };
    const updatedList = [...existingList, newEntry];
    const updatedCompany: CompanyInfo = {
      ...formData,
      qrCodes: updatedList,
      activeQrTitle: formData.activeQrTitle || newEntry.title,
    };
    setFormData(updatedCompany);
    dbService.saveCompany(updatedCompany);
    onCompanyUpdated(updatedCompany);

    setNewQrTitle('');
    setNewQrUpi('');
    setNewQrDataUrl('');
    setNewQrFileName('');
    setFeedback({
      type: 'success',
      text: `QR Code "${newEntry.title}" saved successfully to database!`,
    });
  };

  const handleDeleteQrCode = (qrId: string) => {
    const existingList = formData.qrCodes || [];
    const updatedList = existingList.filter((q) => q.id !== qrId);
    let newActive = formData.activeQrTitle;
    if (!updatedList.some((q) => q.title === newActive)) {
      newActive = updatedList[0]?.title || '';
    }
    const updatedCompany: CompanyInfo = {
      ...formData,
      qrCodes: updatedList,
      activeQrTitle: newActive,
    };
    setFormData(updatedCompany);
    dbService.saveCompany(updatedCompany);
    onCompanyUpdated(updatedCompany);
    setFeedback({ type: 'success', text: 'QR Code deleted from database.' });
  };

  const getActiveQrPreview = () => {
    const list = formData.qrCodes || [];
    return list.find((q) => q.title === formData.activeQrTitle) || list[0];
  };

  // Security & Password state
  const [securitySettings, setSecuritySettings] = useState<SecurityAuthSettings>(() => dbService.getSecuritySettings());
  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [securityAnswer, setSecurityAnswer] = useState<string>(() => securitySettings.securityAnswer || 'ARCO SHOES');
  const [recoveryPin, setRecoveryPin] = useState<string>(() => securitySettings.recoveryPin || '7860');
  const [showCurrentPass, setShowCurrentPass] = useState<boolean>(false);
  const [showNewPass, setShowNewPass] = useState<boolean>(false);
  const [securityFeedback, setSecurityFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [currentTheme, setCurrentTheme] = useState<AppTheme>(() => {
    return (localStorage.getItem('arco_app_theme') as AppTheme) || 'dark';
  });

  const handleThemeChange = (newTheme: AppTheme) => {
    setCurrentTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('arco_app_theme', newTheme);
    setFeedback({
      type: 'success',
      text: `Theme switched to "${THEME_OPTIONS.find(t => t.id === newTheme)?.name}"!`,
    });
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleStateChange = (stName: string) => {
    const st = INDIAN_STATES.find((s) => s.name === stName);
    setFormData({
      ...formData,
      state: stName,
      stateCode: st ? st.code : '27',
    });
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const upi = formData.upiAddress ?? formData.upiId ?? '';
    const updated: CompanyInfo = {
      ...formData,
      upiAddress: upi,
      upiId: upi,
      upiAddressList: formData.upiAddressList || (upi ? [upi] : []),
    };
    dbService.saveCompanyInfo(updated);
    onCompanyUpdated(updated);
    syncEmailConfigToServer(updated);
    setFeedback({ type: 'success', text: 'Configuration & Profile updated successfully!' });
  };

  const handleUpdateSecurityPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityFeedback(null);

    if (!currentPassword) {
      setSecurityFeedback({ type: 'error', text: 'Please enter your current password.' });
      return;
    }

    if (!newPassword || newPassword.length < 4) {
      setSecurityFeedback({ type: 'error', text: 'New password must be at least 4 characters.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setSecurityFeedback({ type: 'error', text: 'New password and confirm password do not match.' });
      return;
    }

    const res = await authService.changePassword(
      currentPassword,
      newPassword,
      securityAnswer,
      recoveryPin
    );

    if (res.success) {
      setSecuritySettings(authService.getStoredSecuritySettings());
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSecurityFeedback({
        type: 'success',
        text: 'Login security password & recovery settings updated successfully!',
      });
      setTimeout(() => setSecurityFeedback(null), 5000);
    } else {
      setSecurityFeedback({
        type: 'error',
        text: res.message,
      });
    }
  };

  const [isFetchingFirebase, setIsFetchingFirebase] = useState<boolean>(false);

  const handleFetchAllFromFirebase = async () => {
    setIsFetchingFirebase(true);
    try {
      const res = await dbService.fetchAllDataFromFirestore();
      const updatedComp = dbService.getCompanyInfo();
      setFormData(updatedComp);
      onCompanyUpdated(updatedComp);
      setFeedback({
        type: res.success ? 'success' : 'error',
        text: res.message,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err.message || 'Error communicating with Firebase database',
      });
    } finally {
      setIsFetchingFirebase(false);
    }
  };

  const handleExportBackup = () => {
    const backupJson = dbService.exportDatabaseJson();
    const blob = new Blob([backupJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VB6_Inventory_MSAccess_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setFeedback({ type: 'success', text: 'Full database backup downloaded successfully.' });
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = event.target?.result as string;
        const res = dbService.importDatabaseJson(json);
        if (res.success) {
          setFeedback({ type: 'success', text: res.message });
          const newComp = dbService.getCompanyInfo();
          setFormData(newComp);
          onCompanyUpdated(newComp);
        } else {
          setFeedback({ type: 'error', text: res.message });
        }
      } catch (err) {
        setFeedback({ type: 'error', text: 'Invalid JSON backup file.' });
      }
    };
    reader.readAsText(file);
  };

  const handleResetDemoData = () => {
    setShowClearConfirm(true);
  };

  const confirmResetData = async () => {
    setShowClearConfirm(false);
    const res = await dbService.emptyDatabaseExceptAdmin();
    const newComp = dbService.getCompanyInfo();
    setFormData(newComp);
    onCompanyUpdated(newComp);
    setFeedback({
      type: res.success ? 'success' : 'error',
      text: res.message,
    });
  };

  // --- Create New Admin & Database Settings Tab State & Handlers ---
  const [settingsTab, setSettingsTab] = useState<'profile' | 'create_admin' | 'database_settings' | 'install_app'>('profile');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [adminUsersList, setAdminUsersList] = useState<AdminUser[]>(() => authService.getAdminUsers());
  const [activeAdminUser, setActiveAdminUser] = useState<AdminUser>(() => authService.getActiveAdmin());

  // Form State for "Create New Admin"
  const [newAdminName, setNewAdminName] = useState<string>('');
  const [newAdminEmail, setNewAdminEmail] = useState<string>('');
  const [newAdminRole, setNewAdminRole] = useState<'Super Admin' | 'Administrator' | 'Branch Admin' | 'Billing Admin' | 'Store Manager'>('Administrator');
  const [newAdminPassword, setNewAdminPassword] = useState<string>('');
  const [newAdminConfirmPassword, setNewAdminConfirmPassword] = useState<string>('');
  const [newAdminSecurityQuestion, setNewAdminSecurityQuestion] = useState<string>('What is your registered shop brand name?');
  const [newAdminSecurityAnswer, setNewAdminSecurityAnswer] = useState<string>('ARCO SHOES');
  const [newAdminRecoveryPin, setNewAdminRecoveryPin] = useState<string>('7860');
  const [switchImmediately, setSwitchImmediately] = useState<boolean>(false);
  const [showNewAdminPass, setShowNewAdminPass] = useState<boolean>(false);
  const [showNewAdminConfirmPass, setShowNewAdminConfirmPass] = useState<boolean>(false);
  const [isAdminCreating, setIsAdminCreating] = useState<boolean>(false);
  const [adminFeedback, setAdminFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Switch Admin Modal State
  const [switchModalAdmin, setSwitchModalAdmin] = useState<AdminUser | null>(null);
  const [switchPassword, setSwitchPassword] = useState<string>('');
  const [showSwitchPass, setShowSwitchPass] = useState<boolean>(false);
  const [switchLoading, setSwitchLoading] = useState<boolean>(false);
  const [switchError, setSwitchError] = useState<string | null>(null);

  // Success Created Admin Modal Dialog State
  const [createdAdminModal, setCreatedAdminModal] = useState<{ admin: AdminUser; switched: boolean } | null>(null);
  const [showCreatedModalPass, setShowCreatedModalPass] = useState<boolean>(false);

  // Delete Admin Confirmation Modal State
  const [deleteAdminTarget, setDeleteAdminTarget] = useState<AdminUser | null>(null);

  const refreshAdmins = () => {
    setAdminUsersList(authService.getAdminUsers());
    setActiveAdminUser(authService.getActiveAdmin());
  };

  const handleCreateNewAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminFeedback(null);

    const name = newAdminName.trim();
    const email = newAdminEmail.trim().toLowerCase();
    const pass = newAdminPassword.trim();
    const confirmPass = newAdminConfirmPassword.trim();

    if (!name) {
      setAdminFeedback({ type: 'error', text: 'Please enter the administrator name.' });
      return;
    }
    if (!email || !email.includes('@')) {
      setAdminFeedback({ type: 'error', text: 'Please enter a valid administrator email address.' });
      return;
    }
    if (!pass || pass.length < 4) {
      setAdminFeedback({ type: 'error', text: 'Password must be at least 4 characters long.' });
      return;
    }
    if (pass !== confirmPass) {
      setAdminFeedback({ type: 'error', text: 'Password and Confirm Password do not match.' });
      return;
    }

    setIsAdminCreating(true);
    try {
      const res = await authService.createAdminUser({
        name,
        email,
        password: pass,
        role: newAdminRole,
        securityQuestion: newAdminSecurityQuestion,
        securityAnswer: newAdminSecurityAnswer,
        recoveryPin: newAdminRecoveryPin,
      });

      if (res.success && res.admin) {
        refreshAdmins();
        const createdAdmin = res.admin;
        setNewAdminName('');
        setNewAdminEmail('');
        setNewAdminPassword('');
        setNewAdminConfirmPassword('');
        setAdminFeedback({ type: 'success', text: res.message });

        let didSwitch = false;
        if (switchImmediately) {
          const switchRes = await authService.loginAsAdmin(createdAdmin.email, pass);
          if (switchRes.success) {
            refreshAdmins();
            didSwitch = true;
          }
        }

        // Display dedicated modal dialog popup window for successful new admin creation
        setCreatedAdminModal({
          admin: createdAdmin,
          switched: didSwitch,
        });
      } else {
        setAdminFeedback({ type: 'error', text: res.message });
      }
    } catch (err: any) {
      setAdminFeedback({ type: 'error', text: err.message || 'Failed to create administrator account.' });
    } finally {
      setIsAdminCreating(false);
    }
  };

  const handleOpenSwitchModal = (admin: AdminUser) => {
    setSwitchModalAdmin(admin);
    setSwitchPassword(admin.password || '');
    setShowSwitchPass(false);
    setSwitchError(null);
  };

  const handleConfirmSwitch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!switchModalAdmin) return;
    setSwitchLoading(true);
    setSwitchError(null);
    try {
      const res = await authService.loginAsAdmin(switchModalAdmin.email, switchPassword);
      if (res.success) {
        refreshAdmins();
        const targetName = switchModalAdmin.name;
        const targetEmail = switchModalAdmin.email;
        const targetRole = switchModalAdmin.role;
        setSwitchModalAdmin(null);
        setSwitchPassword('');
        setFeedback({
          type: 'success',
          title: 'Active Session Switched',
          text: `You are now logged in as ${targetName} (${targetEmail}) with ${targetRole} privileges.`,
        });
      } else {
        setSwitchError(res.message);
      }
    } catch (err: any) {
      setSwitchError(err.message || 'Failed to switch administrator session.');
    } finally {
      setSwitchLoading(false);
    }
  };

  const handleConfirmDeleteAdmin = async () => {
    if (!deleteAdminTarget) return;
    const res = await authService.deleteAdminUser(deleteAdminTarget.id);
    setDeleteAdminTarget(null);
    refreshAdmins();
    setFeedback({
      type: res.success ? 'success' : 'error',
      title: res.success ? 'Administrator Deleted' : 'Operation Failed',
      text: res.message,
    });
  };

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal */}
      {showClearConfirm && (
        <ConfirmModal
          title="Clear All Records"
          message="Are you sure you want to clear all records? This will remove all data from the backend database (including items, customers, suppliers, sales bills, purchases, khata ledgers, sales exchange desk records, and Day Book registers / Total Sales Exchange Amount data), leaving your database completely clean and ready for your real business entries."
          confirmLabel="Clear All Records"
          onConfirm={confirmResetData}
          onCancel={() => setShowClearConfirm(false)}
        />
      )}

      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Top Settings Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-700/60 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="tab-settings-profile"
            onClick={() => setSettingsTab('profile')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              settingsTab === 'profile'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20 border border-amber-500/40'
                : 'bg-slate-900/60 hover:bg-slate-800/80 text-slate-300 border border-slate-700/50 hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Company Profile & System Settings</span>
          </button>

          <button
            type="button"
            id="tab-settings-create-admin"
            onClick={() => {
              setSettingsTab('create_admin');
              refreshAdmins();
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              settingsTab === 'create_admin'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20 border border-amber-500/40'
                : 'bg-slate-900/60 hover:bg-slate-800/80 text-slate-300 border border-slate-700/50 hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4 text-emerald-400" />
            <span>Create New Admin</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 border border-slate-700 text-amber-300 font-mono">
              {adminUsersList.length}
            </span>
          </button>

          <button
            type="button"
            id="tab-settings-database"
            onClick={() => setSettingsTab('database_settings')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              settingsTab === 'database_settings'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20 border border-amber-500/40'
                : 'bg-slate-900/60 hover:bg-slate-800/80 text-slate-300 border border-slate-700/50 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4 text-sky-400" />
            <span>Database Settings</span>
            <span className="flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Live
            </span>
          </button>

          <button
            type="button"
            id="tab-settings-install-app"
            onClick={() => setSettingsTab('install_app')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              settingsTab === 'install_app'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20 border border-amber-500/40'
                : 'bg-slate-900/60 hover:bg-slate-800/80 text-slate-300 border border-slate-700/50 hover:text-white'
            }`}
          >
            <img
              src="/pwa-128x128.png"
              alt="Install App Icon"
              referrerPolicy="no-referrer"
              className="w-4 h-4 rounded object-cover border border-amber-400/50 shrink-0"
            />
            <span>Install App</span>
          </button>
        </div>

        {/* Current Logged In Admin Indicator */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-700/60 text-xs">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-400">Active Admin:</span>
          <span className="font-bold text-amber-300">{activeAdminUser?.name || 'Administrator'}</span>
          <span className="text-[10px] font-mono text-slate-400">({activeAdminUser?.email})</span>
          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            {activeAdminUser?.role || 'Admin'}
          </span>
        </div>
      </div>

      {settingsTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Company Info Form (frmCompanyProfile) */}
        <div className="lg:col-span-8 bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shadow-inner">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <span>Configuration & Profile</span>
                </h2>
                <p className="text-xs text-slate-400">Header info, GSTIN, Bank account & invoice terms</p>
              </div>
            </div>

            <button
              form="form-company-settings"
              type="submit"
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-lg shadow-emerald-900/20 border border-emerald-500/30 transition"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>

          <form id="form-company-settings" onSubmit={handleSaveProfile} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Company / Enterprise Name *</label>
                <input
                  type="text"
                  required
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-bold focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Tagline / Business Slogan</label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Address Line 1</label>
                <input
                  type="text"
                  value={formData.addressLine1}
                  onChange={(e) => setFormData({ ...formData, addressLine1: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Address Line 2</label>
                <input
                  type="text"
                  value={formData.addressLine2}
                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">City</label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">State</label>
                <select
                  value={formData.state}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-1.5 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                >
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.name}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">State Code</label>
                <input
                  type="text"
                  readOnly
                  value={formData.stateCode}
                  className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-2 py-1.5 text-emerald-400 font-mono font-bold text-center"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Pincode</label>
                <input
                  type="text"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">GSTIN No. *</label>
                <input
                  type="text"
                  maxLength={15}
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase font-bold focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">PAN No.</label>
                <input
                  type="text"
                  maxLength={10}
                  value={formData.pan}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value.toUpperCase() })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Phone</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Mobile</label>
                <input
                  type="text"
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Bank Details for Invoices */}
            <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-700/40 space-y-2 backdrop-blur-xs">
              <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block">
                Bank Details for RTGS / NEFT / UPI Printed on Invoices
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Bank Name</label>
                  <input
                    type="text"
                    value={formData.bankName}
                    onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">A/C Number</label>
                  <input
                    type="text"
                    value={formData.bankAccountNo}
                    onChange={(e) => setFormData({ ...formData, bankAccountNo: e.target.value })}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">IFSC Code</label>
                  <input
                    type="text"
                    value={formData.bankIfsc}
                    onChange={(e) => setFormData({ ...formData, bankIfsc: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono uppercase focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Branch Name</label>
                  <input
                    type="text"
                    value={formData.bankBranch}
                    onChange={(e) => setFormData({ ...formData, bankBranch: e.target.value })}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div id="upi-address-control-group">
                  <div className="flex items-center justify-between mb-0.5">
                    <label htmlFor="upi-address-select" className="block text-emerald-400 font-bold text-xs">
                      UPI Address
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {upiList.length} saved
                    </span>
                  </div>

                  {/* Dropdown with Add & Delete action icon buttons */}
                  <div className="flex items-center gap-1.5">
                    <select
                      id="upi-address-select"
                      value={formData.upiAddress ?? formData.upiId ?? ''}
                      onChange={(e) => handleSelectUpiAddress(e.target.value)}
                      className="flex-1 min-w-0 bg-slate-900/80 border border-emerald-500/60 rounded px-2 py-1 text-emerald-300 font-mono font-medium text-xs focus:border-emerald-400 focus:outline-none"
                    >
                      {upiList.length === 0 ? (
                        <option value="">-- No UPI Address Saved --</option>
                      ) : (
                        upiList.map((addr) => (
                          <option key={addr} value={addr}>
                            {addr}
                          </option>
                        ))
                      )}
                    </select>

                    {/* Small Add Icon Action Button */}
                    <button
                      type="button"
                      id="btn-upi-add-toggle"
                      onClick={() => setShowAddUpiInput((prev) => !prev)}
                      title="Add new UPI Address"
                      aria-label="Add UPI Address"
                      className={`p-1.5 rounded border transition-colors flex items-center justify-center shrink-0 cursor-pointer ${
                        showAddUpiInput
                          ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                          : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border-emerald-500/40'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>

                    {/* Small Delete Icon Action Button */}
                    <button
                      type="button"
                      id="btn-upi-delete"
                      onClick={handleDeleteUpiAddress}
                      disabled={!formData.upiAddress && !formData.upiId}
                      title="Delete selected UPI Address"
                      aria-label="Delete selected UPI Address"
                      className="p-1.5 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/40 transition-colors flex items-center justify-center shrink-0 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* User types UPI address and presses Add button to append to drop-down list */}
                  {showAddUpiInput && (
                    <div id="upi-add-input-container" className="p-1.5 bg-slate-950/90 border border-emerald-500/50 rounded flex items-center gap-1.5 mt-1.5 shadow-inner">
                      <input
                        type="text"
                        autoFocus
                        id="input-type-upi-address"
                        value={newUpiAddress}
                        onChange={(e) => setNewUpiAddress(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddUpiAddress();
                          } else if (e.key === 'Escape') {
                            setShowAddUpiInput(false);
                          }
                        }}
                        placeholder="Type UPI address (e.g. yourbusiness@sbi)"
                        className="flex-1 min-w-0 bg-slate-900 border border-slate-700/80 rounded px-2 py-1 text-xs text-emerald-200 font-mono focus:border-emerald-400 focus:outline-none"
                      />
                      <button
                        type="button"
                        id="btn-submit-add-upi"
                        onClick={handleAddUpiAddress}
                        title="Add to drop-down list"
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
              <p className="text-[10px] text-slate-400 pt-0.5">
                <strong className="text-emerald-400">UPI Address:</strong> Select or add a UPI address for dynamic payment QR generation on invoices (e.g. <span className="font-mono text-slate-300">arcoshoes@sbi</span>).
              </p>
            </div>

            {/* Item Related Settings */}
            <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-700/40 space-y-2 backdrop-blur-xs">
              <div className="flex items-center gap-2 mb-1">
                <Settings className="w-4 h-4 text-emerald-400" />
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block">
                  Item & Sales Billing Settings
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Global Tax Calculation Mode</label>
                  <select
                    value={formData.defaultTaxCalculation || 'Inclusive'}
                    onChange={(e) => setFormData({ ...formData, defaultTaxCalculation: e.target.value as 'Inclusive' | 'Exclusive' })}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-100 focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="Inclusive">Inclusive (Tax Included in MRP/Rate)</option>
                    <option value="Exclusive">Exclusive (Tax Charged Extra on Top of Rate)</option>
                  </select>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Defines the default tax calculation formula for all items in inventory and manual entries in sales billing.
                  </p>
                </div>
              </div>
            </div>

            {/* 1. Email Configuration (Email Purpose) */}
            <div className="p-3.5 bg-slate-950/60 rounded-lg border border-slate-700/50 space-y-2.5 backdrop-blur-xs">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-sky-400" />
                  <span className="text-[11px] font-bold text-sky-300 uppercase tracking-wider">
                    Email Purpose Configuration
                  </span>
                  {backendStatus.checked && (
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded flex items-center gap-1 border ${
                        backendStatus.online
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                      }`}
                      title={backendStatus.message}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${backendStatus.online ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                      {backendStatus.online ? `API Server Online (Port ${backendStatus.port || 3000})` : 'API Server Offline (Run: npm start)'}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">Invoice Mailing & Database Alerts</span>
                  <button
                    type="button"
                    onClick={() => setShowEmailGuide(!showEmailGuide)}
                    className="text-[10.5px] text-sky-400 hover:text-sky-300 underline font-medium cursor-pointer"
                  >
                    {showEmailGuide ? 'Hide Setup Help' : 'Setup Guide (Gmail / Localhost)'}
                  </button>
                </div>
              </div>

              {showEmailGuide && (
                <div className="p-3 bg-slate-900/90 rounded-lg border border-sky-500/30 text-xs space-y-2 text-slate-300">
                  <div className="font-bold text-sky-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    How to configure and send emails from localhost:3000:
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
                    <li>
                      <strong>Start the Full-Stack Server:</strong> When deploying or running on your local machine, run <code className="bg-slate-950 px-1 py-0.5 rounded text-sky-300 font-mono">npm start</code> (or <code className="bg-slate-950 px-1 py-0.5 rounded text-sky-300 font-mono">npm run dev</code>). This launches both the React interface and the Node.js Express backend together on <code className="bg-slate-950 px-1 py-0.5 rounded text-sky-300 font-mono">http://localhost:3000</code>.
                    </li>
                    <li>
                      <strong>Generate 16-character Google App Password:</strong> Standard Gmail login passwords are not accepted by Google for SMTP. Go to your <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer" className="text-sky-400 underline hover:text-sky-300">Google Account &rarr; Security &rarr; 2-Step Verification &rarr; App passwords</a>.
                    </li>
                    <li>
                      <strong>Select App:</strong> Choose "Mail", click Generate, and copy the 16 letters (e.g., <code className="bg-slate-950 px-1 py-0.5 rounded text-sky-300 font-mono">abcd efgh ijkl mnop</code>). Paste it into the <strong>E-Password</strong> field below.
                    </li>
                    <li>
                      <strong>Dual-Port IPv4 Fallback:</strong> The backend automatically tries Port 465 (SSL direct) and seamlessly falls back to Port 587 (STARTTLS) with IPv4 enforcement to ensure connections never hang on local broadband/Wi-Fi routers.
                    </li>
                  </ol>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                <div className="sm:col-span-3">
                  <label className="block text-slate-400 font-medium mb-1">Email *</label>
                  <input
                    type="email"
                    value={formData.smtpEmail || ''}
                    onChange={(e) => setFormData({ ...formData, smtpEmail: e.target.value })}
                    placeholder="arcoshoesco@gmail.com"
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-100 font-mono text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-slate-400 font-medium mb-1">E-Password *</label>
                  <div className="relative">
                    <input
                      type={showEPassword ? 'text' : 'password'}
                      value={formData.smtpPassword || ''}
                      onChange={(e) => setFormData({ ...formData, smtpPassword: e.target.value })}
                      placeholder="••••••••••••"
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2.5 py-1.5 pr-8 text-slate-100 font-mono text-xs focus:border-sky-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowEPassword(!showEPassword)}
                      className="absolute inset-y-0 right-0 pr-2 flex items-center text-slate-400 hover:text-slate-200"
                    >
                      {showEPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-slate-400 font-medium mb-1">Receiving Email *</label>
                  <input
                    type="email"
                    value={formData.receivingEmail || ''}
                    onChange={(e) => setFormData({ ...formData, receivingEmail: e.target.value })}
                    placeholder="arcoshoesco@gmail.com"
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-100 font-mono text-xs focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-3 flex gap-2 items-center">
                  <label className="flex-1 flex items-center gap-2 h-[34px] px-3 bg-slate-900/80 hover:bg-slate-900 rounded border border-slate-700/60 cursor-pointer select-none transition">
                    <input
                      type="checkbox"
                      id="chk-send-email"
                      checked={formData.sendEmail ?? true}
                      onChange={(e) => setFormData({ ...formData, sendEmail: e.target.checked })}
                      className="rounded bg-slate-950 border-slate-700 text-sky-500 focus:ring-sky-500/40 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-xs font-semibold text-sky-200">Send E-Mail</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleTestEmailConnection}
                    disabled={isTestingEmail}
                    className="h-[34px] px-3 bg-sky-600/30 hover:bg-sky-600/50 text-sky-200 font-semibold text-xs rounded border border-sky-500/40 flex items-center gap-1.5 transition disabled:opacity-50 select-none shrink-0 cursor-pointer"
                    title="Send a test email to verify SMTP settings"
                  >
                    {isTestingEmail ? (
                      <RefreshCw className="w-3.5 h-3.5 text-sky-300 animate-spin" />
                    ) : (
                      <Mail className="w-3.5 h-3.5 text-sky-300" />
                    )}
                    <span>{isTestingEmail ? 'Testing SMTP...' : 'Test Mail'}</span>
                  </button>
                </div>
              </div>

              {/* Cloud / Remote Backend Server URL (for Firebase Hosting & Cloud Deploys) */}
              <div className="pt-2 border-t border-slate-800/80 space-y-1">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <label className="block text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5 text-sky-400" />
                    <span>Backend Server URL (for Firebase Hosting / Cloud / Render / Railway)</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">Leave empty for local dev / same-origin</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formData.customBackendUrl || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setFormData({ ...formData, customBackendUrl: val });
                      localStorage.setItem('arco_backend_api_url', val.trim());
                    }}
                    placeholder="https://your-email-api.onrender.com (or leave empty)"
                    className="flex-1 bg-slate-900/80 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-100 font-mono text-xs focus:border-sky-500 focus:outline-none"
                  />
                  {formData.customBackendUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, customBackendUrl: '' });
                        localStorage.removeItem('arco_backend_api_url');
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs border border-slate-700 cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-2 text-[10.5px] text-slate-400 bg-slate-900/60 rounded px-2.5 py-1.5 border border-slate-800/80 flex items-center gap-2">
                <span className="text-sky-400 font-bold">ℹ Note for Gmail:</span>
                <span>Use a 16-character Google App Password (generated in Google Account → Security → 2-Step Verification → App passwords). Standard Gmail passwords are not supported by Google for SMTP.</span>
              </div>
            </div>

            {/* 2 & 3. QR Codes Management & Selected QR Title Console */}
            <div className="p-3.5 bg-slate-950/60 rounded-lg border border-slate-700/50 space-y-3 backdrop-blur-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-amber-400" />
                  <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                    QR Codes & Counter Display Console
                  </span>
                </div>
                <span className="text-[10px] text-amber-400/80 font-mono bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/50">
                  Store Payment QR Database
                </span>
              </div>

              {/* Upload QR Row with Title box */}
              <div className="p-2.5 bg-slate-900/60 rounded-lg border border-slate-800 space-y-2">
                <span className="text-[11px] font-semibold text-slate-300 block">
                  Add / Upload New QR Code
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
                  <div className="sm:col-span-4">
                    <label className="block text-slate-400 text-[10px] mb-1">Title (Given by Admin) *</label>
                    <input
                      type="text"
                      value={newQrTitle}
                      onChange={(e) => setNewQrTitle(e.target.value)}
                      placeholder="e.g. GPay Counter QR"
                      className="w-full bg-slate-950 border border-slate-700/70 rounded px-2.5 py-1.5 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-slate-400 text-[10px] mb-1">Associated UPI ID</label>
                    <input
                      type="text"
                      value={newQrUpi}
                      onChange={(e) => setNewQrUpi(e.target.value)}
                      placeholder="arcoshoes@sbi"
                      className="w-full bg-slate-950 border border-slate-700/70 rounded px-2.5 py-1.5 text-slate-100 font-mono text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-slate-400 text-[10px] mb-1">Upload QR File</label>
                    <label className="w-full flex items-center justify-center gap-1.5 px-2 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-200 text-xs cursor-pointer transition">
                      <Upload className="w-3.5 h-3.5 text-amber-400" />
                      <span className="truncate">{newQrFileName || 'Upload QR'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleQrFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="sm:col-span-2">
                    <button
                      type="button"
                      onClick={handleAddQrCode}
                      className="w-full py-1.5 px-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded text-xs shadow flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save QR</span>
                    </button>
                  </div>
                </div>

                {newQrDataUrl && (
                  <div className="flex items-center gap-2 pt-1">
                    <img src={newQrDataUrl} alt="Uploaded Preview" className="w-10 h-10 object-cover rounded border border-amber-500/50 bg-white p-0.5" />
                    <span className="text-[11px] text-emerald-400 font-mono">Image loaded! Click "Save QR" to store in database.</span>
                  </div>
                )}
              </div>

              {/* Dropdown Box with List of QR titles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-amber-300 font-bold text-[11px] mb-1">
                    Select Active QR Title (Displayed on Home Page) *
                  </label>
                  <select
                    value={formData.activeQrTitle || ''}
                    onChange={(e) => handleSelectActiveQrTitle(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/60 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold focus:border-amber-400 focus:outline-none"
                  >
                    {(formData.qrCodes || []).map((qr) => (
                      <option key={qr.id} value={qr.title}>
                        {qr.title} {qr.upiId ? `(${qr.upiId})` : ''}
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-400 mt-1">
                    The selected QR type will be displayed on the Home page under the 'Show QR' button.
                  </p>
                </div>

                {/* Active QR Code Preview Card */}
                <div className="p-2.5 bg-amber-950/20 rounded-lg border border-amber-500/30 flex items-center gap-3">
                  {getActiveQrPreview() ? (
                    <>
                      {getActiveQrPreview()?.qrDataUrl ? (
                        <img
                          src={getActiveQrPreview()?.qrDataUrl}
                          alt="Active QR"
                          className="w-14 h-14 object-contain rounded border border-amber-400/40 bg-white p-1"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded border border-amber-400/40 bg-white p-1 flex items-center justify-center shrink-0">
                          <QrCode className="w-10 h-10 text-slate-900" />
                        </div>
                      )}
                      <div className="space-y-0.5 text-xs overflow-hidden">
                        <span className="text-[9px] uppercase font-bold text-amber-400 tracking-wider block">Home Page Selected QR</span>
                        <h4 className="font-bold text-slate-100 truncate">{formData.activeQrTitle}</h4>
                        {getActiveQrPreview()?.upiId && (
                          <p className="text-[10px] font-mono text-amber-300 truncate">UPI: {getActiveQrPreview()?.upiId}</p>
                        )}
                      </div>
                    </>
                  ) : (
                    <span className="text-xs text-slate-400 italic">No QR selected. Add or select a QR title above.</span>
                  )}
                </div>
              </div>

              {/* List of Registered QRs table */}
              {(formData.qrCodes || []).length > 0 && (
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Saved QR Code Titles ({formData.qrCodes?.length})
                  </span>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {formData.qrCodes?.map((qr) => (
                      <div
                        key={qr.id}
                        className={`p-2 rounded border flex items-center justify-between text-xs ${
                          formData.activeQrTitle === qr.title
                            ? 'bg-amber-950/40 border-amber-500/60 text-amber-200'
                            : 'bg-slate-900/40 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <QrCode className="w-4 h-4 text-amber-400 shrink-0" />
                          <div className="truncate">
                            <span className="font-bold">{qr.title}</span>
                            {qr.upiId && <span className="text-[10px] font-mono text-slate-400 ml-2">({qr.upiId})</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {formData.activeQrTitle === qr.title ? (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40">
                              Active
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleSelectActiveQrTitle(qr.title)}
                              className="text-[10px] text-amber-400 font-bold underline hover:text-amber-300 cursor-pointer"
                            >
                              Set Active
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteQrCode(qr.id)}
                            className="text-slate-400 hover:text-rose-400 p-1"
                            title="Delete QR Code"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Invoice Terms & Conditions</label>
              <textarea
                rows={3}
                value={formData.invoiceTerms}
                onChange={(e) => setFormData({ ...formData, invoiceTerms: e.target.value })}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 font-mono text-[11px] focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </form>
        </div>

        {/* Database Backup, Restore & Keyboard Shortcuts */}
        <div className="lg:col-span-4 space-y-4">
          {/* Install App / Desktop Shortcut Card */}
          <InstallAppCard onOpenDetails={() => setSettingsTab('install_app')} />

          {/* Security & Password Settings Card (Change Security) */}
          <div id="section-change-security" className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-700/40 pb-2">
              <div className="flex items-center gap-2">
                <div className="p-1 rounded bg-amber-500/20 text-amber-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">Change Security Password</h3>
                  <span className="text-[10px] text-slate-400">Manage login credentials & PIN</span>
                </div>
              </div>
              <span className="text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Protected
              </span>
            </div>

            {/* Registered Email Info */}
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-[11px]">
              <div>
                <span className="text-slate-400 block text-[10px]">Admin Account Email</span>
                <span className="font-mono font-semibold text-amber-300">{securitySettings.email}</span>
              </div>
              <span className="text-[10px] text-slate-500">
                {securitySettings.lastChangedAt ? `Updated: ${new Date(securitySettings.lastChangedAt).toLocaleDateString()}` : 'Default'}
              </span>
            </div>

            {securityFeedback && (
              <div
                className={`p-2.5 rounded-lg text-xs flex items-start gap-2 ${
                  securityFeedback.type === 'success'
                    ? 'bg-emerald-950/60 border border-emerald-600/50 text-emerald-300'
                    : 'bg-rose-950/60 border border-rose-600/50 text-rose-300'
                }`}
              >
                {securityFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-rose-400" />
                )}
                <span>{securityFeedback.text}</span>
              </div>
            )}

            <form onSubmit={handleUpdateSecurityPassword} className="space-y-2.5 pt-1">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Current Password
                </label>
                <div className="relative">
                  <input
                    id="input-current-password"
                    type={showCurrentPass ? 'text' : 'password'}
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full bg-slate-950/80 border border-slate-700/60 rounded px-2.5 py-1.5 pr-8 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPass(!showCurrentPass)}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-200"
                  >
                    {showCurrentPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  New Password
                </label>
                <div className="relative">
                  <input
                    id="input-new-password"
                    type={showNewPass ? 'text' : 'password'}
                    required
                    minLength={4}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full bg-slate-950/80 border border-slate-700/60 rounded px-2.5 py-1.5 pr-8 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-200"
                  >
                    {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Confirm New Password
                </label>
                <input
                  id="input-confirm-password"
                  type={showNewPass ? 'text' : 'password'}
                  required
                  minLength={4}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-type new password"
                  className="w-full bg-slate-950/80 border border-slate-700/60 rounded px-2.5 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">
                    Recovery PIN
                  </label>
                  <input
                    type="text"
                    value={recoveryPin}
                    onChange={(e) => setRecoveryPin(e.target.value)}
                    placeholder="7860"
                    className="w-full bg-slate-950/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">
                    Security Answer
                  </label>
                  <input
                    type="text"
                    value={securityAnswer}
                    onChange={(e) => setSecurityAnswer(e.target.value)}
                    placeholder="ARCO SHOES"
                    className="w-full bg-slate-950/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                id="btn-save-security-password"
                type="submit"
                className="w-full mt-2 py-2 px-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg shadow border border-amber-500/40 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                <span>Update Security Password</span>
              </button>
            </form>

            {onLogout && (
              <div className="pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={onLogout}
                  className="w-full py-1.5 px-3 bg-slate-800/60 hover:bg-slate-700/60 text-slate-300 hover:text-white rounded-lg border border-slate-700/50 flex items-center justify-center gap-2 transition text-[11px]"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-400" />
                  <span>Lock & Return to Welcome Screen</span>
                </button>
              </div>
            )}
          </div>

          {/* Theme & Color Schemes Selector */}
          <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-700/40 pb-2">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm">Theme & Color Designs</h3>
              </div>
              <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {THEME_OPTIONS.length} Palettes
              </span>
            </div>

            <p className="text-slate-400">
              Select your preferred billing aesthetic for optimal day/night contrast and minimal eye fatigue.
            </p>

            <div className="space-y-2 pt-1">
              {THEME_OPTIONS.map((t) => {
                const isSelected = currentTheme === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => handleThemeChange(t.id)}
                    className={`w-full text-left p-2.5 rounded-lg border flex items-center justify-between transition ${
                      isSelected
                        ? 'border-amber-500 bg-amber-500/10 font-bold'
                        : 'border-slate-700/50 bg-slate-800/40 hover:bg-slate-800/70 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="flex -space-x-1">
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/30 shadow-xs"
                          style={{ backgroundColor: t.bgHex }}
                        />
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/30 shadow-xs"
                          style={{ backgroundColor: t.cardHex }}
                        />
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/30 shadow-xs"
                          style={{ backgroundColor: t.accentHex }}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-slate-200">{t.name}</span>
                          <span className="text-[9px] px-1 py-0.2 rounded bg-black/20 text-slate-300 font-mono">
                            {t.category}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-normal line-clamp-1">
                          {t.tagline}
                        </span>
                      </div>
                    </div>

                    {isSelected && (
                      <span className="p-1 rounded-full bg-amber-500 text-white shadow-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Database Settings Shortcut Card */}
          <div className="bg-slate-900/40 border border-sky-800/40 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-2.5 text-xs">
            <div className="flex items-center justify-between border-b border-slate-700/40 pb-2">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-sm">Firebase Cloud Database</h3>
              </div>
              <span className="flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Live Sync
              </span>
            </div>
            <p className="text-slate-400 text-[11px]">
              Firebase database credentials, live cloud project details (<code className="text-amber-300 font-mono">arcoanantnag</code>), real-time sync status, and backup utilities have been moved to the dedicated <strong>Database Settings</strong> tab.
            </p>
            <button
              type="button"
              onClick={() => setSettingsTab('database_settings')}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg shadow border border-sky-400/30 transition cursor-pointer"
            >
              <Database className="w-4 h-4" />
              <span>Open Database Settings Tab</span>
            </button>
          </div>
        </div>
      </div>
      )}

      {/* DATABASE SETTINGS TAB */}
      {settingsTab === 'database_settings' && (
        <div className="space-y-5">
          {/* Header Banner */}
          <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 sm:p-5 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-sky-500/15 text-sky-400 border border-sky-500/30 flex items-center justify-center shadow-inner">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                  <span>Database Settings & Synchronization</span>
                  <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                    formData.databaseType === 'mongodb'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  }`}>
                    {formData.databaseType === 'mongodb' ? 'MongoDB Selected' : 'Firebase Connected'}
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  {formData.databaseType === 'mongodb'
                    ? 'Local MongoDB database connection settings, database auto-creation tools, and maintenance utilities.'
                    : 'Live Firestore cloud database configuration, credentials, real-time synchronization stats, and maintenance utilities.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {formData.databaseType === 'mongodb' ? (
                <button
                  type="button"
                  onClick={handleTestMongoConnection}
                  disabled={isTestingMongo}
                  className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-md border border-emerald-400/30 transition cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isTestingMongo ? 'animate-spin' : ''}`} />
                  <span>{isTestingMongo ? 'Connecting...' : 'Test Local MongoDB'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleFetchAllFromFirebase}
                  disabled={isFetchingFirebase}
                  className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-md border border-emerald-400/30 transition cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isFetchingFirebase ? 'animate-spin' : ''}`} />
                  <span>{isFetchingFirebase ? 'Syncing...' : 'Sync Data Now'}</span>
                </button>
              )}
            </div>
          </div>

          {/* 1. DATABASE TYPE SELECTION ROW */}
          <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 sm:p-5 backdrop-blur-md space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-sky-400" />
                <span className="text-xs font-bold text-slate-100 uppercase tracking-wider">
                  Database Type
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                Select Active Database System
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Option 1: Firebase */}
              <label
                onClick={() => handleSelectDatabaseType('firebase')}
                className={`p-4 rounded-xl border flex items-start gap-3.5 cursor-pointer transition select-none ${
                  (formData.databaseType || 'firebase') === 'firebase'
                    ? 'bg-sky-950/40 border-sky-500/60 ring-1 ring-sky-500/40'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40'
                }`}
              >
                <input
                  type="radio"
                  name="database_type_choice"
                  checked={(formData.databaseType || 'firebase') === 'firebase'}
                  onChange={() => handleSelectDatabaseType('firebase')}
                  className="mt-1 text-sky-500 focus:ring-sky-500/30"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-100">Firebase</span>
                    <span className="text-[9px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Cloud Database
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-snug">
                    Uses current Google Cloud Firestore database with live real-time cloud synchronization.
                  </p>
                </div>
              </label>

              {/* Option 2: MongoDB */}
              <label
                onClick={() => handleSelectDatabaseType('mongodb')}
                className={`p-4 rounded-xl border flex items-start gap-3.5 cursor-pointer transition select-none ${
                  formData.databaseType === 'mongodb'
                    ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/40'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40'
                }`}
              >
                <input
                  type="radio"
                  name="database_type_choice"
                  checked={formData.databaseType === 'mongodb'}
                  onChange={() => handleSelectDatabaseType('mongodb')}
                  className="mt-1 text-emerald-500 focus:ring-emerald-500/30"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-100">MongoDB</span>
                    <span className="text-[9px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Local Computer DB
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-snug">
                    Connects to local MongoDB database installed on your computer (<code className="text-emerald-300 font-mono">127.0.0.1:27017</code>).
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* 2. CONDITIONAL DATABASE CONFIGURATION PANEL */}
          {formData.databaseType === 'mongodb' ? (
            /* MONGODB DATABASE CONFIGURATION */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left Column: MongoDB Connection Settings Form */}
              <div className="lg:col-span-8 space-y-5">
                <div className="bg-slate-900/40 border border-emerald-500/40 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <Server className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-100">MongoDB Database Connection Settings</h3>
                        <p className="text-[11px] text-slate-400">Configure local MongoDB connection parameters and database creation</p>
                      </div>
                    </div>
                    <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Local Database Mode
                    </span>
                  </div>

                  <div className="space-y-4 text-xs">
                    {/* Server Connection URI */}
                    <div>
                      <label className="block text-slate-300 font-bold mb-1.5">
                        MongoDB Connection URI *
                      </label>
                      <input
                        type="text"
                        value={formData.mongoUri || 'mongodb://127.0.0.1:27017'}
                        onChange={(e) => setFormData({ ...formData, mongoUri: e.target.value })}
                        placeholder="mongodb://127.0.0.1:27017"
                        className="w-full bg-slate-950/80 border border-slate-700/70 rounded-lg px-3 py-2 text-emerald-300 font-mono text-xs focus:border-emerald-500 focus:outline-none"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        Default local MongoDB port is <code className="text-emerald-400 font-mono">27017</code>. For authenticated local server: <code className="text-slate-300 font-mono">mongodb://user:pass@127.0.0.1:27017</code>.
                      </p>
                    </div>

                    {/* Database Name */}
                    <div>
                      <label className="block text-slate-300 font-bold mb-1.5">
                        Database Name *
                      </label>
                      <input
                        type="text"
                        value={formData.mongoDbName || 'arco_shoes_db'}
                        onChange={(e) => setFormData({ ...formData, mongoDbName: e.target.value })}
                        placeholder="arco_shoes_db"
                        className="w-full bg-slate-950/80 border border-slate-700/70 rounded-lg px-3 py-2 text-slate-100 font-mono text-xs focus:border-emerald-500 focus:outline-none"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        If this database does not exist on your computer, MongoDB will create <code className="text-emerald-300 font-mono">{formData.mongoDbName || 'arco_shoes_db'}</code> automatically upon connection.
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col sm:flex-row gap-3 pt-2">
                      <button
                        type="button"
                        onClick={handleTestMongoConnection}
                        disabled={isTestingMongo}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white font-bold text-xs rounded-xl shadow border border-emerald-400/30 transition cursor-pointer"
                      >
                        <RefreshCw className={`w-4 h-4 ${isTestingMongo ? 'animate-spin' : ''}`} />
                        <span>{isTestingMongo ? 'Verifying & Creating...' : 'Test Connection & Create Database'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleSaveProfile}
                        className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs rounded-xl border border-slate-700 shadow transition cursor-pointer"
                      >
                        <span>Save MongoDB Settings</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Auto-Created Collections Grid */}
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    Auto-Created Database Collections
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    The database system automatically initializes the following 9 collections inside <strong className="text-emerald-300 font-mono">{formData.mongoDbName || 'arco_shoes_db'}</strong>:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                    {[
                      { name: 'tbl_Items', label: 'Stock & Footwear Items' },
                      { name: 'tbl_SalesMaster', label: 'Sales Invoices & Receipts' },
                      { name: 'tbl_SalesDetails', label: 'Invoice Item Line Details' },
                      { name: 'tbl_PurchaseMaster', label: 'Purchase Voucher Entries' },
                      { name: 'tbl_CustomerLedger', label: 'Customer Khata Records' },
                      { name: 'tbl_SupplierLedger', label: 'Supplier Payment Khata' },
                      { name: 'tbl_DayBook', label: 'Daily Cash & Bank Book' },
                      { name: 'tbl_CompanyInfo', label: 'Company & Tax Profile' },
                      { name: 'tbl_Admins', label: 'User Admin Accounts' },
                    ].map((col) => (
                      <div key={col.name} className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800/80 space-y-0.5">
                        <div className="font-mono text-emerald-300 font-bold text-[11px]">{col.name}</div>
                        <div className="text-[10px] text-slate-400">{col.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Local MongoDB Operating Guide & Backup */}
              <div className="lg:col-span-4 space-y-5">
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <div className="flex items-center gap-2 border-b border-slate-700/40 pb-2.5">
                    <HardDrive className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-bold text-sm text-slate-100">Local MongoDB Setup</h3>
                  </div>

                  <div className="space-y-2.5 text-slate-300 leading-relaxed text-[11px]">
                    <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-800/50 text-emerald-200">
                      <strong>✓ Local Service:</strong> Ensure MongoDB Server or MongoDB Compass is active on <code className="text-emerald-300 font-mono">127.0.0.1:27017</code>.
                    </div>

                    <p>
                      <strong>Automatic Creation:</strong> Clicking <em>Test Connection & Create Database</em> initializes the database <code className="text-emerald-300 font-mono">{formData.mongoDbName || 'arco_shoes_db'}</code> and all collections automatically.
                    </p>

                    <div className="space-y-1 pt-1">
                      <div className="font-bold text-slate-200">Default Command Prompt Command:</div>
                      <code className="block bg-slate-950 p-2 rounded text-[10px] font-mono text-emerald-400 border border-slate-800">
                        mongod --dbpath "C:\data\db"
                      </code>
                    </div>
                  </div>
                </div>

                {/* Database Backup & Restore Card */}
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <div className="flex items-center gap-2 border-b border-slate-700/40 pb-2.5">
                    <Download className="w-5 h-5 text-sky-400" />
                    <h3 className="font-bold text-sm text-slate-100">Backup & Utilities</h3>
                  </div>

                  <p className="text-slate-400 text-[11px]">
                    Export or import direct JSON snapshots mirroring original MS Access tables.
                  </p>

                  <div className="space-y-2.5 pt-1">
                    <button
                      type="button"
                      onClick={handleExportBackup}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-xl border border-slate-700 shadow transition cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span>Export Full Database Backup</span>
                    </button>

                    <label className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-xl border border-slate-700 shadow transition cursor-pointer">
                      <Upload className="w-4 h-4 text-sky-400" />
                      <span>Restore Database From File</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleImportBackup}
                        className="hidden"
                      />
                    </label>

                    <button
                      type="button"
                      onClick={handleResetDemoData}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 font-bold rounded-xl border border-rose-800/60 transition cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Clear All Records</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Current Firebase Backend Credentials Grid */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left Column: Firebase Backend Details & Connection Summary */}
              <div className="lg:col-span-8 space-y-5">
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
                        <Server className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-100">Firebase Backend Connection Credentials</h3>
                        <p className="text-[11px] text-slate-400">Authoritative Google Cloud Firestore & Auth SDK details</p>
                      </div>
                    </div>
                    <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Online & Active
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs">
                    {/* Project ID */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span>Firebase Project ID</span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(BACKEND_DETAILS.projectId);
                            setCopiedField('projectId');
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="text-slate-400 hover:text-amber-300 transition"
                          title="Copy Project ID"
                        >
                          {copiedField === 'projectId' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="font-mono text-amber-300 font-bold text-xs truncate">
                        {BACKEND_DETAILS.projectId}
                      </div>
                    </div>

                    {/* Firestore Database ID */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span>Firestore Database ID</span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(BACKEND_DETAILS.firestoreDatabaseId);
                            setCopiedField('dbId');
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="text-slate-400 hover:text-amber-300 transition"
                          title="Copy Database ID"
                        >
                          {copiedField === 'dbId' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="font-mono text-emerald-300 font-bold text-xs truncate">
                        {BACKEND_DETAILS.firestoreDatabaseId}
                      </div>
                    </div>

                    {/* Web App ID */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span>Firebase Web App ID</span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(BACKEND_DETAILS.appId || '');
                            setCopiedField('appId');
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="text-slate-400 hover:text-amber-300 transition"
                          title="Copy App ID"
                        >
                          {copiedField === 'appId' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="font-mono text-slate-200 font-semibold text-[11px] truncate" title={BACKEND_DETAILS.appId}>
                        {BACKEND_DETAILS.appId}
                      </div>
                    </div>

                    {/* API Key */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span>Web API Key</span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(firebaseConfig.apiKey || '');
                            setCopiedField('apiKey');
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="text-slate-400 hover:text-amber-300 transition"
                          title="Copy API Key"
                        >
                          {copiedField === 'apiKey' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="font-mono text-slate-300 font-semibold text-[11px] truncate">
                        {firebaseConfig.apiKey}
                      </div>
                    </div>

                    {/* Auth Domain */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="text-slate-400 text-[11px]">Auth Domain</div>
                      <div className="font-mono text-slate-300 text-[11px] truncate">
                        {BACKEND_DETAILS.authDomain}
                      </div>
                    </div>

                    {/* Storage Bucket */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="text-slate-400 text-[11px]">Storage Bucket</div>
                      <div className="font-mono text-slate-300 text-[11px] truncate">
                        {BACKEND_DETAILS.storageBucket}
                      </div>
                    </div>

                    {/* Messaging Sender ID */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="text-slate-400 text-[11px]">Messaging Sender ID</div>
                      <div className="font-mono text-slate-300 text-[11px] truncate">
                        {BACKEND_DETAILS.messagingSenderId}
                      </div>
                    </div>

                    {/* Measurement ID */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                      <div className="text-slate-400 text-[11px]">Measurement ID</div>
                      <div className="font-mono text-slate-300 text-[11px] truncate">
                        {(firebaseConfig as any).measurementId || 'G-JEP76T6Q2Q'}
                      </div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="text-slate-400 text-[11px]">Direct Firebase Firestore Console:</span>
                      <a
                        href={BACKEND_DETAILS.consoleDirectUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/30 rounded-lg font-mono text-[11px] transition"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Open Firebase Console</span>
                      </a>
                    </div>
                  </div>
                </div>

                {/* Status & Security Module */}
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Backend Security & Authentication Architecture
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                    <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800 space-y-1">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Auth Engine</div>
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Firebase Auth SDK
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight mt-1">Multi-admin login with session tokens & security question pin recovery.</p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800 space-y-1">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Database Rules</div>
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Deployed Firestore Rules
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight mt-1">Authorized collection access for sales, purchases, khata & stock items.</p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800 space-y-1">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Sync Pipeline</div>
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Bidirectional Auto-Save
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight mt-1">Automatic real-time snapshot sync across web preview & production deployment.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Database Maintenance & Backup Utilities */}
              <div className="lg:col-span-4 space-y-5">
                {/* Cloud Fetch Card */}
                <div className="bg-slate-900/40 border border-emerald-700/40 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <div className="flex items-center gap-2 border-b border-slate-700/40 pb-2.5">
                    <Cloud className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-bold text-sm text-slate-100">Live Cloud Sync</h3>
                  </div>

                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Directly fetch and re-sync all sales invoices, purchases, customer ledgers, and items from the <strong className="text-amber-300 font-mono">arcoanantnag</strong> Firestore cloud database.
                  </p>

                  <button
                    type="button"
                    onClick={handleFetchAllFromFirebase}
                    disabled={isFetchingFirebase}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white font-bold rounded-xl shadow-md border border-emerald-400/30 transition cursor-pointer"
                  >
                    <RefreshCw className={`w-4 h-4 ${isFetchingFirebase ? 'animate-spin' : ''}`} />
                    <span>{isFetchingFirebase ? 'Fetching Cloud Records...' : 'Fetch All Data from Firebase'}</span>
                  </button>
                </div>

                {/* Database Backup & Restore Card */}
                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md space-y-3 text-xs">
                  <div className="flex items-center gap-2 border-b border-slate-700/40 pb-2.5">
                    <HardDrive className="w-5 h-5 text-sky-400" />
                    <h3 className="font-bold text-sm text-slate-100">Database Backup & Utilities</h3>
                  </div>

                  <p className="text-slate-400 text-[11px]">
                    Export or import direct JSON snapshots mirroring original MS Access tables (<code className="text-sky-300 font-mono">tbl_Items</code>, <code className="text-sky-300 font-mono">tbl_SalesMaster</code>, <code className="text-sky-300 font-mono">tbl_CustomerLedger</code>).
                  </p>

                  <div className="space-y-2.5 pt-1">
                    <button
                      type="button"
                      onClick={handleExportBackup}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-xl border border-slate-700 shadow transition cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span>Export Full Database Backup</span>
                    </button>

                    <label className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold rounded-xl border border-slate-700 shadow transition cursor-pointer">
                      <Upload className="w-4 h-4 text-sky-400" />
                      <span>Restore Database From File</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleImportBackup}
                        className="hidden"
                      />
                    </label>

                    <button
                      type="button"
                      onClick={handleResetDemoData}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 font-bold rounded-xl border border-rose-800/60 transition cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Clear All Records</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CREATE NEW ADMIN TAB */}
      {settingsTab === 'create_admin' && (
        <div className="space-y-4">
          {/* Header Banner */}
          <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 sm:p-5 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
                <UserPlus className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                  <span>Administrator Accounts & Multi-Admin Access</span>
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Active System
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Register new administrators with dedicated roles and credentials, or switch active sessions to login as a different admin.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 bg-slate-950/60 px-3.5 py-2 rounded-xl border border-slate-700/60 text-xs">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Current Active Session</div>
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <span>{activeAdminUser?.name || 'Administrator'}</span>
                  <span className="text-[10px] text-slate-400 font-mono font-normal">({activeAdminUser?.email})</span>
                </div>
              </div>
            </div>
          </div>

          {/* Form & List Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left Column: Create New Admin Form */}
            <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
                    <UserPlus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-slate-100">Register New Administrator</h3>
                    <p className="text-[11px] text-slate-400">Create a new admin account to login with different credentials</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  New Admin
                </span>
              </div>

              {adminFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
                    adminFeedback.type === 'success'
                      ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                      : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
                  }`}
                >
                  {adminFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  )}
                  <span>{adminFeedback.text}</span>
                </div>
              )}

              <form onSubmit={handleCreateNewAdmin} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Administrator Full Name <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={newAdminName}
                      onChange={(e) => setNewAdminName(e.target.value)}
                      placeholder="e.g. Branch Manager Store 2"
                      className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950/70 border border-slate-700/60 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Administrator Email Address <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500 pointer-events-none" />
                      <input
                        type="email"
                        required
                        value={newAdminEmail}
                        onChange={(e) => setNewAdminEmail(e.target.value)}
                        placeholder="e.g. manager@arcoshoes.com"
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-950/70 border border-slate-700/60 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Administrative Role & Privileges
                  </label>
                  <select
                    value={newAdminRole}
                    onChange={(e: any) => setNewAdminRole(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950/70 border border-slate-700/60 text-white focus:outline-none focus:border-amber-500 transition"
                  >
                    <option value="Administrator">Administrator (Full ERP Operations & Billing Access)</option>
                    <option value="Super Admin">Super Admin (Store Owner / Master Access)</option>
                    <option value="Branch Admin">Branch Admin (Store Branch Manager)</option>
                    <option value="Billing Admin">Billing Admin (Sales Counters & Invoicing)</option>
                    <option value="Store Manager">Store Manager (Inventory & Vendor Relations)</option>
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Login Password <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500 pointer-events-none" />
                      <input
                        type={showNewAdminPass ? 'text' : 'password'}
                        required
                        value={newAdminPassword}
                        onChange={(e) => setNewAdminPassword(e.target.value)}
                        placeholder="Min. 4 characters"
                        className="w-full pl-9 pr-9 py-2 text-xs rounded-lg bg-slate-950/70 border border-slate-700/60 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewAdminPass(!showNewAdminPass)}
                        className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-200 transition"
                      >
                        {showNewAdminPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Confirm Password <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500 pointer-events-none" />
                      <input
                        type={showNewAdminConfirmPass ? 'text' : 'password'}
                        required
                        value={newAdminConfirmPassword}
                        onChange={(e) => setNewAdminConfirmPassword(e.target.value)}
                        placeholder="Re-enter password"
                        className="w-full pl-9 pr-9 py-2 text-xs rounded-lg bg-slate-950/70 border border-slate-700/60 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewAdminConfirmPass(!showNewAdminConfirmPass)}
                        className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-200 transition"
                      >
                        {showNewAdminConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Password Recovery Details Box */}
                <div className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                    <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                    <span>Security Recovery Configuration</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Security Question</label>
                      <input
                        type="text"
                        value={newAdminSecurityQuestion}
                        onChange={(e) => setNewAdminSecurityQuestion(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-700/60 text-slate-200"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Security Answer</label>
                      <input
                        type="text"
                        value={newAdminSecurityAnswer}
                        onChange={(e) => setNewAdminSecurityAnswer(e.target.value)}
                        placeholder="e.g. ARCO SHOES"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-700/60 text-slate-200 uppercase font-semibold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">4-Digit Recovery PIN</label>
                    <input
                      type="text"
                      maxLength={6}
                      value={newAdminRecoveryPin}
                      onChange={(e) => setNewAdminRecoveryPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="7860"
                      className="w-36 px-2.5 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-700/60 text-amber-400 font-mono tracking-widest font-bold"
                    />
                  </div>
                </div>

                {/* Switch immediately option */}
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={switchImmediately}
                    onChange={(e) => setSwitchImmediately(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-amber-600 focus:ring-amber-500/40 w-4 h-4"
                  />
                  <span>Switch and login as this administrator immediately upon creation</span>
                </label>

                {/* Submit button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isAdminCreating}
                    className="w-full flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold rounded-xl shadow-lg shadow-amber-600/20 border border-amber-400/40 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isAdminCreating ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Creating Administrator...</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Create Administrator Account</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Right Column: Registered Administrators & Switch Login */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shadow-inner">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-slate-100">Registered Administrators</h3>
                      <p className="text-[11px] text-slate-400">Manage accounts & switch login session</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-400 border border-slate-700">
                    {adminUsersList.length} Total
                  </span>
                </div>

                {/* List of Admins */}
                <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                  {adminUsersList.map((admin) => {
                    const isCurrent = activeAdminUser?.email?.toLowerCase() === admin.email.toLowerCase();
                    return (
                      <div
                        key={admin.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isCurrent
                            ? 'bg-amber-950/20 border-amber-500/40 shadow-md shadow-amber-500/5'
                            : 'bg-slate-950/50 hover:bg-slate-800/40 border-slate-800/80'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2.5 min-w-0">
                            <div
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                                admin.isPrimary
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              }`}
                            >
                              {admin.name.charAt(0).toUpperCase()}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-xs text-slate-100 truncate">{admin.name}</span>
                                {admin.isPrimary && (
                                  <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                    Primary
                                  </span>
                                )}
                                {isCurrent && (
                                  <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                    Active
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] font-mono text-slate-400 truncate">{admin.email}</div>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700/60 font-medium">
                                  {admin.role || 'Admin'}
                                </span>
                                {admin.lastLoginAt && (
                                  <span className="text-[10px] text-slate-500">
                                    Active {new Date(admin.lastLoginAt).toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isCurrent ? (
                              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/40 px-2 py-1 rounded-md border border-emerald-500/30">
                                Active
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleOpenSwitchModal(admin)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 hover:text-white border border-blue-500/40 text-[11px] font-semibold transition cursor-pointer"
                                title={`Login as ${admin.name}`}
                              >
                                <ArrowRightLeft className="w-3 h-3" />
                                <span>Login</span>
                              </button>
                            )}

                            {!admin.isPrimary && admin.email.toLowerCase() !== 'arcoshoesco@gmail.com' && (
                              <button
                                type="button"
                                onClick={() => setDeleteAdminTarget(admin)}
                                className="p-1 rounded-lg hover:bg-rose-950/40 text-slate-500 hover:text-rose-400 transition"
                                title={`Delete ${admin.name}`}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Login Guide Box */}
              <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>How Multi-Admin Access Works</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Each administrator created here can sign into Arco Shoes ERP using their email and password from the Welcome Login screen, or you can switch between active administrator sessions instantly using the <strong className="text-slate-200">"Login"</strong> button.
                </p>
                <div className="text-[10px] text-amber-400/80 bg-amber-950/20 p-2 rounded-lg border border-amber-500/20">
                  Tip: All administrator changes are backed up to local storage and the cloud database automatically.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Switch Admin Password Prompt Modal */}
      {switchModalAdmin && (
        <div className="fixed inset-0 z-[120] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
                  <ArrowRightLeft className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Switch Administrator Session</h3>
                  <p className="text-xs text-slate-400">Login and switch active ERP identity</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSwitchModalAdmin(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {switchError && (
              <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{switchError}</span>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
              <div className="text-xs text-slate-400">Switching to:</div>
              <div className="font-bold text-sm text-white flex items-center gap-2">
                <span>{switchModalAdmin.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {switchModalAdmin.role}
                </span>
              </div>
              <div className="text-xs font-mono text-slate-400">{switchModalAdmin.email}</div>
            </div>

            <form onSubmit={handleConfirmSwitch} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Confirm Password for {switchModalAdmin.name}
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type={showSwitchPass ? 'text' : 'password'}
                    required
                    value={switchPassword}
                    onChange={(e) => setSwitchPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full pl-9 pr-9 py-2 text-xs rounded-lg bg-slate-950 border border-slate-700 text-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSwitchPass(!showSwitchPass)}
                    className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-200"
                  >
                    {showSwitchPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSwitchModalAdmin(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={switchLoading}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-600/20 transition disabled:opacity-50"
                >
                  {switchLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Switching...</span>
                    </>
                  ) : (
                    <>
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                      <span>Confirm & Login</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Success Modal Dialog Popup Window for New Admin Creation */}
      {createdAdminModal && (
        <div className="fixed inset-0 z-[130] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-900 p-5 border-b border-emerald-500/30 flex items-start justify-between gap-3">
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/10">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-white">Administrator Created!</h3>
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Success
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">New administrator account is registered and ready</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCreatedAdminModal(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                ✕
              </button>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              {/* Status Message */}
              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-200 flex items-start gap-2.5">
                <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 mt-1 animate-pulse" />
                <div>
                  {createdAdminModal.switched ? (
                    <span>Active session has been switched to <strong>{createdAdminModal.admin.name}</strong>. You are currently operating with {createdAdminModal.admin.role} privileges.</span>
                  ) : (
                    <span>Account created successfully! Credentials have been saved and can now be used to log in.</span>
                  )}
                </div>
              </div>

              {/* Account Credentials Card */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Admin Name</span>
                  <span className="font-bold text-white">{createdAdminModal.admin.name}</span>
                </div>

                <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Login Email</span>
                  <span className="font-mono font-semibold text-amber-300">{createdAdminModal.admin.email}</span>
                </div>

                <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Privilege Role</span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                    {createdAdminModal.admin.role}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Login Password</span>
                  <div className="flex items-center gap-1.5 font-mono text-xs text-slate-200 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    <span>{showCreatedModalPass ? createdAdminModal.admin.password : '••••••••'}</span>
                    <button
                      type="button"
                      onClick={() => setShowCreatedModalPass(!showCreatedModalPass)}
                      className="text-slate-400 hover:text-slate-200 ml-1"
                      title={showCreatedModalPass ? 'Hide password' : 'Show password'}
                    >
                      {showCreatedModalPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {createdAdminModal.admin.recoveryPin && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Recovery PIN</span>
                    <span className="font-mono text-xs font-bold text-amber-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {createdAdminModal.admin.recoveryPin}
                    </span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-end gap-2 pt-2 border-t border-slate-800/80">
                {!createdAdminModal.switched ? (
                  <>
                    <button
                      type="button"
                      onClick={() => setCreatedAdminModal(null)}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
                    >
                      Keep Current Session
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        const targetAdmin = createdAdminModal.admin;
                        setCreatedAdminModal(null);
                        const switchRes = await authService.loginAsAdmin(targetAdmin.email, targetAdmin.password);
                        if (switchRes.success) {
                          refreshAdmins();
                          setFeedback({
                            type: 'success',
                            title: 'Active Session Switched',
                            text: `You are now logged in as ${targetAdmin.name} (${targetAdmin.email}).`,
                          });
                        }
                      }}
                      className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-600/20 transition cursor-pointer"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                      <span>Login as this Admin Now</span>
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => setCreatedAdminModal(null)}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 transition cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Done & Continue</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Install App / Desktop Shortcut Tab */}
      {settingsTab === 'install_app' && (
        <InstallAppSection />
      )}

      {/* Delete Admin Confirmation Modal */}
      {deleteAdminTarget && (
        <ConfirmModal
          title="Delete Administrator Account"
          message={`Are you sure you want to remove administrator "${deleteAdminTarget.name}" (${deleteAdminTarget.email})? This user will no longer be able to log in.`}
          confirmLabel="Delete Administrator"
          onConfirm={handleConfirmDeleteAdmin}
          onCancel={() => setDeleteAdminTarget(null)}
        />
      )}
    </div>
  );
};
