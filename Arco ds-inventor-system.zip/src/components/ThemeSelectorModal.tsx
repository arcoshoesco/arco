import React, { useState } from 'react';
import { Palette, Check, Sparkles, X, Sun, Moon, Eye, Layers } from 'lucide-react';
import { AppTheme, ThemeOption } from '../types';
import { THEME_OPTIONS } from '../data/themes';

interface ThemeSelectorModalProps {
  currentTheme: AppTheme;
  onSelectTheme: (theme: AppTheme) => void;
  onClose: () => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  currentTheme,
  onSelectTheme,
  onClose,
}) => {
  const [filterCategory, setFilterCategory] = useState<'All' | 'Cream' | 'Dark' | 'White'>('All');
  const [previewTheme, setPreviewTheme] = useState<AppTheme>(currentTheme);

  const filteredThemes = THEME_OPTIONS.filter((t) => {
    if (filterCategory === 'All') return true;
    return t.category === filterCategory;
  });

  const handleApplyTheme = (themeId: AppTheme) => {
    onSelectTheme(themeId);
    setPreviewTheme(themeId);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/75 backdrop-blur-md p-3 sm:p-6 overflow-y-auto select-none">
      <div 
        className="rounded-2xl border shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden transition-all"
        style={{
          backgroundColor: 'var(--theme-card, #FFFFFF)',
          borderColor: 'var(--theme-border, #E2E8F0)',
          color: 'var(--theme-text-main, #0F172A)',
        }}
      >
        {/* Header */}
        <div 
          className="p-4 sm:p-5 border-b flex items-center justify-between gap-3"
          style={{ 
            borderColor: 'var(--theme-border, #E2E8F0)',
            backgroundColor: 'var(--theme-card-subtle, #F8FAFC)' 
          }}
        >
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md font-bold text-white"
              style={{ backgroundColor: 'var(--theme-accent, #D97706)' }}
            >
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-lg tracking-tight">Select Theme & Color Palette</h2>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-700 border border-amber-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  Curated Billing Palettes
                </span>
              </div>
              <p className="text-xs opacity-75 mt-0.5">
                Choose from Directorate Institutional Navy & Gold, Executive Linen, Cashmere Sand, Royal Oxford Navy, or Obsidian Dark mode for optimal billing contrast.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl opacity-75 hover:opacity-100 hover:bg-black/5 transition"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div 
          className="px-4 sm:px-6 py-2.5 border-b flex items-center justify-between flex-wrap gap-2 text-xs"
          style={{ 
            borderColor: 'var(--theme-border, #E2E8F0)',
            backgroundColor: 'var(--theme-card, #FFFFFF)'
          }}
        >
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold uppercase tracking-wider opacity-60 mr-1">Filter:</span>
            {(['All', 'White', 'Cream', 'Dark'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1 rounded-lg font-medium transition ${
                  filterCategory === cat
                    ? 'bg-amber-600 text-white font-semibold shadow-sm'
                    : 'opacity-70 hover:opacity-100 hover:bg-black/5'
                }`}
              >
                {cat === 'White' && '🏛️ Institutional Navy & Gold'}
                {cat === 'Cream' && '🌾 Linen & Cashmere'}
                {cat === 'Dark' && '🌙 Dark Mode'}
                {cat === 'All' && `All Designs (${THEME_OPTIONS.length})`}
              </button>
            ))}
          </div>

          <div className="text-[11px] opacity-70 font-mono flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-amber-600" />
            <span>Active: <strong className="font-bold uppercase">{currentTheme}</strong></span>
          </div>
        </div>

        {/* Themes Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto max-h-[60vh] space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredThemes.map((theme) => {
              const isSelected = currentTheme === theme.id;

              return (
                <div
                  key={theme.id}
                  onClick={() => handleApplyTheme(theme.id)}
                  className={`group relative rounded-xl border-2 p-4 cursor-pointer transition-all duration-200 shadow-sm hover:shadow-md flex flex-col justify-between ${
                    isSelected
                      ? 'border-amber-500 ring-2 ring-amber-500/20 shadow-md'
                      : 'border-slate-200/80 hover:border-amber-400/80'
                  }`}
                  style={{
                    backgroundColor: theme.bgHex,
                    color: theme.textHex,
                  }}
                >
                  {/* Theme Top Row */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-base tracking-tight" style={{ color: theme.textHex }}>
                            {theme.name}
                          </h3>
                          <span
                            className="text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider"
                            style={{
                              backgroundColor: `${theme.accentHex}1A`,
                              color: theme.accentHex,
                              border: `1px solid ${theme.accentHex}40`,
                            }}
                          >
                            {theme.category}
                          </span>
                        </div>
                        <p className="text-xs font-medium opacity-80 mt-0.5" style={{ color: theme.textHex }}>
                          {theme.tagline}
                        </p>
                      </div>

                      {/* Selection Checkmark */}
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center border transition ${
                          isSelected
                            ? 'bg-amber-600 text-white border-amber-600 shadow'
                            : 'border-slate-300 opacity-40 group-hover:opacity-100'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>

                    <p className="text-xs leading-relaxed opacity-75 my-2.5" style={{ color: theme.textHex }}>
                      {theme.description}
                    </p>

                    {/* Live Miniature Mockup Card */}
                    <div
                      className="rounded-lg p-2.5 my-2 border shadow-xs text-xs space-y-2"
                      style={{
                        backgroundColor: theme.cardHex,
                        borderColor: theme.borderHex,
                        color: theme.textHex,
                      }}
                    >
                      <div className="flex items-center justify-between border-b pb-1.5" style={{ borderColor: theme.borderHex }}>
                        <span className="font-bold text-[11px]">ARCO SHOES CO. — Sales Invoice</span>
                        <span
                          className="px-1.5 py-0.5 rounded text-[10px] font-bold"
                          style={{ backgroundColor: `${theme.accentHex}20`, color: theme.accentHex }}
                        >
                          GST 18%
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                        <div className="p-1 rounded border opacity-90" style={{ borderColor: theme.borderHex, backgroundColor: theme.bgHex }}>
                          <span className="opacity-60 block">Item</span>
                          <span className="font-semibold truncate block">Formal Leather Shoes</span>
                        </div>
                        <div className="p-1 rounded border opacity-90 text-center" style={{ borderColor: theme.borderHex, backgroundColor: theme.bgHex }}>
                          <span className="opacity-60 block">Qty</span>
                          <span className="font-bold">12 Pairs</span>
                        </div>
                        <div className="p-1 rounded border opacity-90 text-right" style={{ borderColor: theme.borderHex, backgroundColor: theme.bgHex }}>
                          <span className="opacity-60 block">Net Total</span>
                          <span className="font-bold" style={{ color: theme.accentHex }}>₹24,780.00</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Swatches & Apply Button */}
                  <div className="mt-3 pt-2.5 border-t flex items-center justify-between gap-2" style={{ borderColor: `${theme.borderHex}` }}>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] opacity-60 font-semibold mr-0.5">Palette:</span>
                      <span className="w-4 h-4 rounded-full border shadow-xs" title="Background" style={{ backgroundColor: theme.bgHex, borderColor: theme.borderHex }}></span>
                      <span className="w-4 h-4 rounded-full border shadow-xs" title="Surface Card" style={{ backgroundColor: theme.cardHex, borderColor: theme.borderHex }}></span>
                      <span className="w-4 h-4 rounded-full border shadow-xs" title="Accent Tone" style={{ backgroundColor: theme.accentHex, borderColor: theme.borderHex }}></span>
                      <span className="w-4 h-4 rounded-full border shadow-xs" title="Text Color" style={{ backgroundColor: theme.textHex, borderColor: theme.borderHex }}></span>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApplyTheme(theme.id);
                      }}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-xs ${
                        isSelected
                          ? 'bg-amber-600 text-white hover:bg-amber-700'
                          : 'bg-black/10 hover:bg-black/20 text-current'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>Active Theme</span>
                        </>
                      ) : (
                        <span>Apply {theme.name.split(' ')[0]}</span>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Notes & Quick Tip */}
        <div 
          className="p-4 border-t flex items-center justify-between flex-wrap gap-2 text-xs"
          style={{ 
            borderColor: 'var(--theme-border, #E2E8F0)',
            backgroundColor: 'var(--theme-card-subtle, #F8FAFC)'
          }}
        >
          <div className="flex items-center gap-2 opacity-80">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Theme choice is saved permanently in your browser. All hotkeys (F1–F10) & fast billing remain instantaneous.</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl font-bold text-white shadow-md transition"
            style={{ backgroundColor: 'var(--theme-accent, #D97706)' }}
          >
            Done & Continue
          </button>
        </div>
      </div>
    </div>
  );
};
