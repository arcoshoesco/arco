import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Filter,
  Calendar,
  User,
  ShoppingBag,
  RotateCcw,
  Trash2,
  Save,
  Printer,
  Plus,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Clock,
  ChevronRight,
  RefreshCw,
  FileText,
  DollarSign,
  Tag,
  Hash,
  X,
  Edit3,
  Lock,
  ArrowLeftRight,
  Mail,
  Loader2
} from 'lucide-react';
import { CompanyInfo, Customer, InvoiceItem, Item, SalesInvoice, SalesExchangeDeskRecord } from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2 } from '../services/gstCalculations';
import { sendInvoiceEmail } from '../services/emailService';
import { InvoicePrintModal } from './InvoicePrintModal';
import { ConfirmModal } from './ConfirmModal';
import { SuccessPopup } from './SuccessPopup';
import { ReturnExchangeComponent } from './ReturnExchangeComponent';
import { SalesExchangeDesk } from './SalesExchangeDesk';

interface SalesReturnProps {
  company: CompanyInfo;
  initialInvoiceId?: string;
  onNavigateToSales?: () => void;
  onOpenQrModal?: (amount?: number) => void;
  onOpenPrintPreviewTab?: (invoice: SalesInvoice, autoPrint?: boolean) => void;
}

type DateFilterPreset = 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'all' | 'custom';

export const SalesReturnComponent: React.FC<SalesReturnProps> = ({ company, initialInvoiceId, onNavigateToSales, onOpenQrModal, onOpenPrintPreviewTab }) => {
  const [activeView, setActiveView] = useState<'REGISTER' | 'COUNTER' | 'EXCHANGE'>('REGISTER');

  // Master Data
  const [allSales, setAllSales] = useState<SalesInvoice[]>([]);
  const [itemsList, setItemsList] = useState<Item[]>([]);
  const [customersList, setCustomersList] = useState<Customer[]>([]);

  // Filter States
  const todayStr = new Date().toISOString().split('T')[0];
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('today');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedCustomerIdFilter, setSelectedCustomerIdFilter] = useState<string>('ALL');
  const [invoiceNoFilter, setInvoiceNoFilter] = useState<string>('');
  const [itemNameFilter, setItemNameFilter] = useState<string>('');

  // Selected Bill for Viewing / Editing / Returning
  const [selectedInvoice, setSelectedInvoice] = useState<SalesInvoice | null>(null);

  // Editable fields for the selected bill
  const [editInvoiceDate, setEditInvoiceDate] = useState<string>('');
  const [editCustomerId, setEditCustomerId] = useState<string>('');
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editCustomerMobile, setEditCustomerMobile] = useState<string>('');
  const [editCustomerGstin, setEditCustomerGstin] = useState<string>('');
  const [editPaymentMode, setEditPaymentMode] = useState<'Cash' | 'Credit' | 'Bank/UPI' | 'Card' | 'Split' | 'Customer Credit'>('Cash');
  const [editSalesmanName, setEditSalesmanName] = useState<string>('');
  const [editRemarks, setEditRemarks] = useState<string>('');
  const [editLineItems, setEditLineItems] = useState<InvoiceItem[]>([]);
  const [isInterState, setIsInterState] = useState<boolean>(false);

  // Quick Add Item buffer for selected bill
  const [showAddItem, setShowAddItem] = useState<boolean>(false);
  const [isAddExistingItem, setIsAddExistingItem] = useState<boolean>(false);
  const [addSelectedItemId, setAddSelectedItemId] = useState<string>('');
  const [addManualName, setAddManualName] = useState<string>('');
  const [addQty, setAddQty] = useState<string>('');
  const [addRate, setAddRate] = useState<string>('');
  const [addDisc, setAddDisc] = useState<string>('');
  const [itemSearchQuery, setItemSearchQuery] = useState<string>('');

  // Modals & Feedback
  const [invoiceToDelete, setInvoiceToDelete] = useState<{ id: string; no: string } | null>(null);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'warning' | 'info';
    title?: string;
    text: string;
    onClose?: () => void;
  } | null>(null);
  const [saveStatus, setSaveStatus] = useState<'saving' | 'sending_email' | null>(null);
  const [isSendingManualEmail, setIsSendingManualEmail] = useState<boolean>(false);

  // Load Data
  const loadData = () => {
    setAllSales(dbService.getSales());
    setItemsList(dbService.getItems());
    setCustomersList(dbService.getCustomers());
  };

  useEffect(() => {
    loadData();
    return dbService.subscribe(loadData);
  }, []);

  useEffect(() => {
    if (initialInvoiceId) {
      setActiveView('REGISTER');
      const targetInv = allSales.find((s) => s.id === initialInvoiceId);
      if (targetInv) {
        handleSelectBill(targetInv);
        setDatePreset('all');
        setStartDate('');
        setEndDate('');
      }
    }
  }, [initialInvoiceId, allSales]);

  // Handle Preset Date changes
  const handleDatePresetChange = (preset: DateFilterPreset) => {
    setDatePreset(preset);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yStr = y.toISOString().split('T')[0];
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'last7') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      setStartDate(d7.toISOString().split('T')[0]);
      setEndDate(today);
    } else if (preset === 'thisMonth') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filter Sales list
  const filteredSales = allSales.filter((inv) => {
    // Date filtering
    if (datePreset !== 'all') {
      if (startDate && inv.invoiceDate < startDate) return false;
      if (endDate && inv.invoiceDate > endDate) return false;
    }

    // Customer filter
    if (selectedCustomerIdFilter !== 'ALL') {
      if (selectedCustomerIdFilter === 'CUST-000') {
        if (inv.customerId !== 'CUST-000') return false;
      } else {
        if (inv.customerId !== selectedCustomerIdFilter) return false;
      }
    }

    // Invoice No filter
    if (invoiceNoFilter.trim()) {
      const q = invoiceNoFilter.trim().toLowerCase();
      if (!inv.invoiceNo.toLowerCase().includes(q)) return false;
    }

    // Item Name filter
    if (itemNameFilter.trim()) {
      const q = itemNameFilter.trim().toLowerCase();
      const hasItem = inv.items.some(
        (it) =>
          it.itemName.toLowerCase().includes(q) ||
          (it.itemCode && it.itemCode.toLowerCase().includes(q))
      );
      if (!hasItem) return false;
    }

    return true;
  });

  // When user selects a bill from the Active List
  const handleSelectBill = (inv: SalesInvoice) => {
    setSelectedInvoice(inv);
    setEditInvoiceDate(inv.invoiceDate || todayStr);
    setEditCustomerId(inv.customerId || '');
    setEditCustomerName(inv.customerName || '');
    setEditCustomerMobile(inv.customerMobile || '');
    setEditCustomerGstin(inv.customerGstin || '');
    setEditPaymentMode(inv.paymentMode || 'Cash');
    setEditSalesmanName(inv.salesmanName || '');
    setEditRemarks(inv.remarks || '');
    setEditLineItems(inv.items.map((line) => ({ ...line })));
    setIsInterState(inv.isInterState || false);
    setShowAddItem(false);
    setIsAddExistingItem(false);
    setAddSelectedItemId('');
    setAddManualName('');
    setAddQty('');
    setAddRate('');
    setAddDisc('');
    setFeedback(null);
  };

  // Deselect active bill
  const handleCloseSelectedBill = () => {
    setSelectedInvoice(null);
    setShowAddItem(false);
    setIsAddExistingItem(false);
    setAddSelectedItemId('');
    setAddManualName('');
    setAddQty('');
    setAddRate('');
    setAddDisc('');
  };

  const handleAddExistingItemToggle = (checked: boolean) => {
    setIsAddExistingItem(checked);
    setAddSelectedItemId('');
    setAddManualName('');
    setAddQty('');
    setAddRate('');
    setAddDisc('');
  };

  const handleAddExistingItemSelect = (itmId: string) => {
    setIsAddExistingItem(true);
    setAddManualName('');
    setAddSelectedItemId(itmId);
    setAddRate('');
    setAddQty('');
    setAddDisc('');
  };

  // Line Item modifications
  const handleUpdateLineQty = (index: number, newQty: number) => {
    if (newQty < 0 || isNaN(newQty)) return;
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      newQty,
      target.rate,
      target.discountPercent,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      quantity: newQty,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineRate = (index: number, newRate: number) => {
    if (newRate < 0 || isNaN(newRate)) return;
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      target.quantity,
      newRate,
      target.discountPercent,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      rate: newRate,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleUpdateLineDiscount = (index: number, discInput: string | number) => {
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const updated = [...editLineItems];
    const target = updated[index];

    const calc = calculateLineGST(
      target.quantity,
      target.rate,
      discInput,
      target.gstRate,
      isInterState,
      activeTaxType
    );

    updated[index] = {
      ...target,
      ...calc,
    };
    setEditLineItems(updated);
  };

  const handleRemoveLineItem = (index: number) => {
    if (editLineItems.length <= 1) {
      if (!window.confirm('Removing the only item will leave this bill empty. You can delete the bill instead if you want to void it. Continue removing?')) {
        return;
      }
    }
    const updated = editLineItems.filter((_, idx) => idx !== index);
    setEditLineItems(updated);
  };

  // Add Item to current selected bill
  const handleAddNewItemToBill = () => {
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const qtyNum = Number(addQty);
    const rateNum = Number(addRate);
    const discInput = addDisc.trim();

    if (!isAddExistingItem) {
      if (!addManualName.trim()) {
        setFeedback({ type: 'error', text: 'Please enter custom item name.' });
        return;
      }
      if (!addQty || isNaN(qtyNum) || qtyNum <= 0) {
        setFeedback({ type: 'error', text: 'Please enter a valid quantity (min 1).' });
        return;
      }
      if (addRate === '' || isNaN(rateNum) || rateNum < 0) {
        setFeedback({ type: 'error', text: 'Please enter a valid rate.' });
        return;
      }

      const calc = calculateLineGST(qtyNum, rateNum, discInput, 5, isInterState, activeTaxType);
      const existingIdx = editLineItems.findIndex(
        (l) => l.itemId === 'ITEM-MANUAL' && l.itemName.toLowerCase() === addManualName.trim().toLowerCase()
      );

      if (existingIdx >= 0) {
        const updated = [...editLineItems];
        const newQty = updated[existingIdx].quantity + qtyNum;
        const newCalc = calculateLineGST(newQty, rateNum, discInput, 5, isInterState, activeTaxType);
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: newQty,
          rate: rateNum,
          ...newCalc,
        };
        setEditLineItems(updated);
      } else {
        const newItem: InvoiceItem = {
          id: `L-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          itemId: 'ITEM-MANUAL',
          itemCode: 'MANUAL',
          itemName: addManualName.trim(),
          hsnCode: '6403',
          quantity: qtyNum,
          unit: 'Pairs',
          rate: rateNum,
          gstRate: 5,
          ...calc,
        };
        setEditLineItems([...editLineItems, newItem]);
      }

      setAddSelectedItemId('');
      setAddManualName('');
      setAddQty('');
      setAddRate('');
      setAddDisc('');
      setShowAddItem(false);
      setFeedback(null);
      return;
    }

    // Existing Item from Master
    if (!addSelectedItemId) {
      setFeedback({ type: 'error', text: 'Please select an item from master catalog.' });
      return;
    }
    const itm = itemsList.find((i) => i.id === addSelectedItemId);
    if (!itm) return;

    if (!addQty || isNaN(qtyNum) || qtyNum <= 0) {
      setFeedback({ type: 'error', text: 'Please enter a valid quantity (min 1).' });
      return;
    }
    if (addRate === '' || isNaN(rateNum) || rateNum < 0) {
      setFeedback({ type: 'error', text: 'Please enter a valid rate.' });
      return;
    }

    const calc = calculateLineGST(qtyNum, rateNum, discInput, itm.gstRate, isInterState, activeTaxType);
    const existingIdx = editLineItems.findIndex((l) => l.itemId === itm.id);

    if (existingIdx >= 0) {
      const updated = [...editLineItems];
      const newQty = updated[existingIdx].quantity + qtyNum;
      const newCalc = calculateLineGST(newQty, rateNum, discInput, itm.gstRate, isInterState, activeTaxType);
      updated[existingIdx] = {
        ...updated[existingIdx],
        quantity: newQty,
        rate: rateNum,
        ...newCalc,
      };
      setEditLineItems(updated);
    } else {
      const newItem: InvoiceItem = {
        id: `L-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemId: itm.id,
        itemCode: itm.itemCode,
        itemName: itm.itemName,
        hsnCode: itm.hsnCode,
        quantity: qtyNum,
        unit: itm.unit,
        rate: rateNum,
        gstRate: itm.gstRate,
        ...calc,
      };
      setEditLineItems([...editLineItems, newItem]);
    }

    setAddSelectedItemId('');
    setAddManualName('');
    setAddQty('');
    setAddRate('');
    setAddDisc('');
    setShowAddItem(false);
    setFeedback(null);
  };

  // Grand totals recalculations for selected bill
  const totalQuantity = editLineItems.reduce((acc, it) => acc + it.quantity, 0);
  const grossSubtotal = roundTo2(editLineItems.reduce((acc, it) => acc + it.grossAmount, 0));
  const totalDiscount = roundTo2(editLineItems.reduce((acc, it) => acc + it.discountAmount, 0));
  const totalTaxable = roundTo2(editLineItems.reduce((acc, it) => acc + it.taxableAmount, 0));
  const totalCgst = roundTo2(editLineItems.reduce((acc, it) => acc + it.cgstAmount, 0));
  const totalSgst = roundTo2(editLineItems.reduce((acc, it) => acc + it.sgstAmount, 0));
  const totalIgst = roundTo2(editLineItems.reduce((acc, it) => acc + it.igstAmount, 0));
  const totalTax = roundTo2(totalCgst + totalSgst + totalIgst);

  const exactNet = totalTaxable + totalTax;
  const roundedGrand = Math.round(exactNet);
  const roundOff = roundTo2(roundedGrand - exactNet);
  const grandTotal = roundedGrand;

  // Handle Save / Update Bill
  const handleSaveUpdatedBill = async () => {
    if (!selectedInvoice || saveStatus) return;
    if (editLineItems.length === 0) {
      setFeedback({
        type: 'error',
        title: 'Empty Bill',
        text: 'Cannot save an empty bill. Please add at least one line item or delete the bill.',
      });
      return;
    }

    setSaveStatus('saving');

    const now = new Date();
    const localDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const isoDate = now.toISOString().split('T')[0];
    const currentModifiedDate = localDate;

    // Check if the invoice date and current date are the same (matching local date or UTC ISO date)
    const invDate = (editInvoiceDate || selectedInvoice.invoiceDate || '').trim();
    const isSameDate = invDate === localDate || invDate === isoDate;

    const updatedInvoice: SalesInvoice = {
      ...selectedInvoice,
      invoiceDate: editInvoiceDate,
      billModifiedDate: isSameDate ? undefined : currentModifiedDate,
      customerId: editCustomerId,
      customerName: editCustomerName,
      customerMobile: editCustomerMobile,
      customerGstin: editCustomerGstin,
      paymentMode: editPaymentMode,
      salesmanName: editSalesmanName,
      remarks: editRemarks,
      isInterState,
      items: editLineItems,
      totalQuantity,
      grossSubtotal,
      totalDiscount,
      totalTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalTax,
      roundOff,
      grandTotal,
      amountReceived: editPaymentMode === 'Credit' ? 0 : grandTotal,
      balanceDue: editPaymentMode === 'Credit' ? grandTotal : 0,
    };

    const res = dbService.saveSaleInvoice(updatedInvoice);
    if (!res.success) {
      setSaveStatus(null);
      setFeedback({ type: 'error', title: 'Update Failed', text: res.message });
      return;
    }

    if (!isSameDate) {
      // Record Sales Exchange Desk Audit entry for updated bill only when invoice date differs from current date
      const originalBillAmount = selectedInvoice.grandTotal;
      const newBillAmount = grandTotal;
      const netAmount = roundTo2(newBillAmount - originalBillAmount);

      const exchangeDeskRecord: SalesExchangeDeskRecord = {
        id: `EXD-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        invoiceId: updatedInvoice.id,
        invoiceNo: updatedInvoice.invoiceNo,
        invoiceDate: updatedInvoice.invoiceDate,
        billModifiedDate: currentModifiedDate,
        customerId: updatedInvoice.customerId,
        customerName: updatedInvoice.customerName,
        customerMobile: updatedInvoice.customerMobile || '',
        originalBillAmount,
        newBillAmount,
        netAmount,
        itemsBefore: selectedInvoice.items,
        itemsAfter: editLineItems,
        remarks: editRemarks || 'Bill updated via Sales Register',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      dbService.saveSalesExchangeDeskRecord(exchangeDeskRecord);
    } else {
      // If invoice date and current date are same, do NOT update Sales Exchange Desk. Only update Sales Register.
      // Also ensure any previous exchange desk record for this invoice is cleared from Sales Exchange Desk.
      const existingDeskRecords = dbService
        .getSalesExchangeDeskRecords()
        .filter((r) => r.invoiceId === updatedInvoice.id || r.invoiceNo === updatedInvoice.invoiceNo);
      existingDeskRecords.forEach((r) => dbService.deleteSalesExchangeDeskRecord(r.id));
    }

    // Automatic email dispatch mirroring Tax Invoice & Retail Billing page
    const isEmailEnabled = company.sendEmail !== false;
    let finalMessage = `Invoice #${updatedInvoice.invoiceNo} has been updated. Stock, balances, and ledger entries were recalculated.`;
    let finalPopupType: 'success' | 'warning' = 'success';
    let finalTitle = 'Sales Bill Updated Successfully';

    if (isEmailEnabled) {
      setSaveStatus('sending_email');

      try {
        const emailRes = await sendInvoiceEmail(updatedInvoice, company, {
          isModified: true,
          targetDate: currentModifiedDate,
        });

        if (emailRes.success) {
          finalMessage = `Invoice #${updatedInvoice.invoiceNo} was updated successfully and the updated invoice email was sent to ${company.receivingEmail || 'designated email'}.`;
          finalTitle = 'Bill Updated & Email Sent';
          finalPopupType = 'success';
        } else if (emailRes.skipped) {
          finalMessage = `Invoice #${updatedInvoice.invoiceNo} has been updated successfully.`;
          finalTitle = 'Bill Updated Successfully';
          finalPopupType = 'success';
        } else if (emailRes.isConfigIncomplete) {
          finalMessage = `Invoice #${updatedInvoice.invoiceNo} was updated, but email was not sent because email settings are incomplete. (${emailRes.error || 'Check Email & E-Password in Settings'})`;
          finalTitle = 'Bill Updated (Email Notice)';
          finalPopupType = 'warning';
        } else {
          finalMessage = `Invoice #${updatedInvoice.invoiceNo} was updated, but the email could not be sent. (${emailRes.error || 'SMTP connection failed'})`;
          finalTitle = 'Bill Updated (Email Failed)';
          finalPopupType = 'warning';
        }
      } catch (err: any) {
        finalMessage = `Invoice #${updatedInvoice.invoiceNo} was updated, but invoice email could not be sent. (${err.message || 'Error occurred'})`;
        finalTitle = 'Bill Updated (Email Failed)';
        finalPopupType = 'warning';
      }
    } else {
      finalMessage = `Invoice #${updatedInvoice.invoiceNo} has been updated successfully.`;
      finalTitle = 'Bill Updated Successfully';
      finalPopupType = 'success';
    }

    setSaveStatus(null);

    // Display persistent Success/Notice dialog with OK button (does not auto-dismiss)
    setFeedback({
      type: finalPopupType,
      title: finalTitle,
      text: finalMessage,
      onClose: () => {
        setSelectedInvoice(updatedInvoice);
        loadData();
      },
    });
  };

  // Manual Email Dispatch for selected bill
  const handleManualSendEmail = async (inv: SalesInvoice) => {
    if (isSendingManualEmail || saveStatus) return;
    setIsSendingManualEmail(true);

    try {
      const emailRes = await sendInvoiceEmail(inv, company, {
        isModified: Boolean(inv.billModifiedDate),
        targetDate: inv.billModifiedDate || inv.invoiceDate,
      });

      if (emailRes.success) {
        setFeedback({
          type: 'success',
          title: 'Invoice Email Sent',
          text: `Invoice #${inv.invoiceNo} was successfully emailed to ${company.receivingEmail || 'designated email'}.`,
        });
      } else if (emailRes.skipped) {
        setFeedback({
          type: 'info',
          title: 'Email Disabled',
          text: 'Send E-Mail checkbox is disabled in Settings. Please enable it to send emails.',
        });
      } else if (emailRes.isConfigIncomplete) {
        setFeedback({
          type: 'warning',
          title: 'Email Settings Incomplete',
          text: `Cannot send email: ${emailRes.error || 'Please configure Email and E-Password in Settings.'}`,
        });
      } else {
        setFeedback({
          type: 'error',
          title: 'Email Delivery Failed',
          text: emailRes.error || 'Failed to send invoice email. Please check your SMTP settings.',
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Email Error',
        text: err.message || 'An error occurred while attempting to send the email.',
      });
    } finally {
      setIsSendingManualEmail(false);
    }
  };

  // Handle Delete / Void Bill
  const handleConfirmDelete = () => {
    if (!invoiceToDelete) return;
    const res = dbService.deleteSaleInvoice(invoiceToDelete.id);
    if (res.success) {
      // Clean up any exchange desk records for the deleted invoice
      const relatedDeskRecords = dbService
        .getSalesExchangeDeskRecords()
        .filter((r) => r.invoiceId === invoiceToDelete.id || r.invoiceNo === invoiceToDelete.no);
      relatedDeskRecords.forEach((r) => dbService.deleteSalesExchangeDeskRecord(r.id));

      setFeedback({
        type: 'success',
        title: 'Bill Deleted / Voided',
        text: `Invoice #${invoiceToDelete.no} has been deleted. Stock and customer balance have been safely restored.`,
      });
      if (selectedInvoice && selectedInvoice.id === invoiceToDelete.id) {
        setSelectedInvoice(null);
      }
      setInvoiceToDelete(null);
      loadData();
    } else {
      setFeedback({ type: 'error', text: res.message });
      setInvoiceToDelete(null);
    }
  };

  // Total summary of current filtered list
  const totalFilteredCount = filteredSales.length;
  const totalFilteredAmount = filteredSales.reduce((acc, s) => acc + s.grandTotal, 0);
  const totalTodayCount = allSales.filter((s) => s.invoiceDate === todayStr).length;
  const totalTodayAmount = allSales
    .filter((s) => s.invoiceDate === todayStr)
    .reduce((acc, s) => acc + s.grandTotal, 0);

  return (
    <div className="space-y-4 pb-12">
      {/* Top Banner / View Switcher Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 sm:p-5 backdrop-blur-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-xl text-purple-400">
            <RotateCcw className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-lg sm:text-xl font-bold text-slate-100">Sales Register</h1>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Review, filter, and process sales returns with real-time stock and store credit updates.
            </p>
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800 flex-wrap">
          <button
            id="tab-sales-register-main"
            onClick={() => setActiveView('REGISTER')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeView === 'REGISTER'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Sales Register Desk</span>
          </button>
          <button
            id="tab-sales-return-desk"
            onClick={() => setActiveView('COUNTER')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeView === 'COUNTER'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Sales Return Desk</span>
          </button>
          <button
            id="tab-sales-exchange-desk"
            onClick={() => setActiveView('EXCHANGE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeView === 'EXCHANGE'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>Sales Exchange Desk</span>
          </button>
        </div>
      </div>

      {/* Render View Tabs */}
      {activeView === 'COUNTER' ? (
        <ReturnExchangeComponent
          company={company}
          preselectedInvoiceId={initialInvoiceId}
          onNavigateBack={onNavigateToSales}
          onOpenQrModal={onOpenQrModal}
        />
      ) : activeView === 'EXCHANGE' ? (
        <SalesExchangeDesk company={company} onNavigateToSales={onNavigateToSales} />
      ) : (
        <>

      {/* Filter Control Box */}
      <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-sm space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Filter className="w-4 h-4 text-purple-400" />
            <span>Search & Filter Sales Bills</span>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['today', 'yesterday', 'last7', 'thisMonth', 'all'] as DateFilterPreset[]).map((p) => (
              <button
                key={p}
                onClick={() => handleDatePresetChange(p)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  datePreset === p
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300'
                }`}
              >
                {p === 'today' && 'Today'}
                {p === 'yesterday' && 'Yesterday'}
                {p === 'last7' && 'Last 7 Days'}
                {p === 'thisMonth' && 'This Month'}
                {p === 'all' && 'All Dates'}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Inputs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Date Picker Range */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Date Range
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <input
                type="date"
                value={startDate}
                onChange={(e) => {
                  setStartDate(e.target.value);
                  setDatePreset('custom');
                }}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none"
              />
              <input
                type="date"
                value={endDate}
                onChange={(e) => {
                  setEndDate(e.target.value);
                  setDatePreset('custom');
                }}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Customer Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Customer Wise
            </label>
            <select
              value={selectedCustomerIdFilter}
              onChange={(e) => setSelectedCustomerIdFilter(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none"
            >
              <option value="ALL">All Customers</option>
              <option value="CUST-000">Cash / Counter Sale</option>
              {customersList
                .filter((c) => c.id !== 'CUST-000')
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.customerName} {c.mobile ? `(${c.mobile})` : ''}
                  </option>
                ))}
            </select>
          </div>

          {/* Invoice No Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Customer Invoice Number
            </label>
            <div className="relative">
              <Hash className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="e.g. CUS-INV-001"
                value={invoiceNoFilter}
                onChange={(e) => setInvoiceNoFilter(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg pl-8 pr-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none placeholder-slate-600 font-mono"
              />
              {invoiceNoFilter && (
                <button
                  onClick={() => setInvoiceNoFilter('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Item Name Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Contains Item Name
            </label>
            <div className="relative">
              <ShoppingBag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search Item in Bill..."
                value={itemNameFilter}
                onChange={(e) => setItemNameFilter(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg pl-8 pr-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none placeholder-slate-600"
              />
              {itemNameFilter && (
                <button
                  onClick={() => setItemNameFilter('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Section: Split / Detail View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Side: Active List of Invoices (4 Cols on LG, or Full if no bill selected) */}
        <div className={`${selectedInvoice ? 'lg:col-span-4' : 'lg:col-span-12'} space-y-3`}>
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-400" />
              <h2 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Active Bills List ({filteredSales.length})
              </h2>
            </div>
            <span className="text-[11px] text-slate-400">
              {datePreset === 'today' ? 'Showing Today\'s Invoices' : 'Filtered Invoices'}
            </span>
          </div>

          {filteredSales.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-8 text-center text-slate-400">
              <ShoppingBag className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p className="font-semibold text-slate-300 text-sm">No Sales Invoices Found</p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                No bills match your active filters. Try selecting "All Dates" or clearing the search terms.
              </p>
              <button
                onClick={() => {
                  setDatePreset('all');
                  setStartDate('');
                  setEndDate('');
                  setSelectedCustomerIdFilter('ALL');
                  setInvoiceNoFilter('');
                  setItemNameFilter('');
                }}
                className="mt-4 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium cursor-pointer transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div
              className={`space-y-2 overflow-y-auto pr-1 ${
                selectedInvoice ? 'max-h-[680px]' : 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 space-y-0'
              }`}
            >
              {filteredSales.map((inv) => {
                const isSelected = selectedInvoice?.id === inv.id;
                return (
                  <div
                    key={inv.id}
                    onClick={() => handleSelectBill(inv)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left relative ${
                      isSelected
                        ? 'bg-purple-950/40 border-purple-500/70 shadow-lg shadow-purple-950/40 ring-1 ring-purple-500/40'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-xs text-slate-100">{inv.invoiceNo}</span>
                          {inv.invoiceDate === todayStr && (
                            <span className="px-1.5 py-0.2 bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 rounded text-[9px] font-bold">
                              TODAY
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-medium text-slate-300 mt-0.5 flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" />
                          <span>{inv.customerName}</span>
                          {inv.customerMobile && (
                            <span className="text-[10px] text-slate-400 font-mono">({inv.customerMobile})</span>
                          )}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-xs text-emerald-400">
                          {formatCurrency(inv.grandTotal)}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">{inv.invoiceDate}</div>
                      </div>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 bg-slate-950/60 rounded border border-slate-800 font-mono text-[10px]">
                          {inv.totalQuantity} {inv.totalQuantity === 1 ? 'item' : 'items'}
                        </span>
                        <span className="px-1.5 py-0.5 bg-slate-950/60 rounded border border-slate-800 text-[10px] text-slate-300">
                          {inv.paymentMode}
                        </span>
                      </div>

                      <div className="flex items-center gap-1 text-purple-400 font-medium">
                        <span>{isSelected ? 'Editing' : 'Select'}</span>
                        <ChevronRight className="w-3 h-3" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Side: Selected Bill Detail & Edit Form (8 Cols on LG) */}
        {selectedInvoice && (
          <div className="lg:col-span-8 bg-slate-900/70 border border-purple-500/30 rounded-2xl p-4 sm:p-5 backdrop-blur-md shadow-2xl space-y-4 animate-in fade-in duration-200">
            {/* Selected Bill Header Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-purple-500/20 rounded-lg text-purple-300">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-slate-100">
                      Edit Sales Bill: <span className="font-mono text-purple-300">{selectedInvoice.invoiceNo}</span>
                    </h3>
                    <span className="text-[10px] bg-slate-950 text-slate-400 border border-slate-800 px-2 py-0.5 rounded font-mono">
                      {editInvoiceDate}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Modify line items, quantities for returns, party details, or void the bill.
                  </p>
                </div>
              </div>

              {/* Header Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  disabled={isSendingManualEmail || Boolean(saveStatus)}
                  onClick={() => handleManualSendEmail(selectedInvoice)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
                  title="Send invoice email to receiving address"
                >
                  {isSendingManualEmail ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400" />
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <Mail className="w-3.5 h-3.5 text-sky-400" />
                      <span>Email Bill</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPrintInvoice(selectedInvoice)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-3.5 h-3.5 text-blue-400" />
                  <span>Print</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInvoiceToDelete({ id: selectedInvoice.id, no: selectedInvoice.invoiceNo })}
                  className="px-2.5 py-1.5 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/60 text-rose-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Bill</span>
                </button>
                <button
                  type="button"
                  onClick={handleCloseSelectedBill}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg cursor-pointer transition-colors"
                  title="Close Edit View"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Editable Bill Metadata Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs bg-slate-950/50 p-3 rounded-xl border border-slate-800/80">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>INVOICE DATE</span>
                  <span className="text-[9px] text-amber-400 font-mono font-normal flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Locked
                  </span>
                </label>
                <input
                  type="date"
                  readOnly
                  disabled
                  value={editInvoiceDate}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 font-mono text-xs cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>CUSTOMER NAME</span>
                  <span className="text-[9px] text-amber-400 font-mono font-normal flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Locked
                  </span>
                </label>
                <input
                  type="text"
                  readOnly
                  disabled
                  value={selectedInvoice?.customerName || editCustomerName || 'Cash Sale'}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 font-semibold text-xs cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>CUSTOMER TYPE</span>
                  <span className="text-[9px] text-amber-400 font-mono font-normal flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Locked
                  </span>
                </label>
                <div className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 font-semibold text-xs flex items-center justify-between min-h-[30px] cursor-not-allowed">
                  <span
                    className={
                      selectedInvoice &&
                      (selectedInvoice.customerId !== 'CUST-000' || selectedInvoice.paymentMode === 'Credit')
                        ? 'text-purple-300 font-bold'
                        : 'text-emerald-300 font-bold'
                    }
                  >
                    {selectedInvoice &&
                    (selectedInvoice.customerId !== 'CUST-000' || selectedInvoice.paymentMode === 'Credit')
                      ? 'Credit Line'
                      : 'Cash(Counter)'}
                  </span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-mono uppercase tracking-wider ${
                      selectedInvoice &&
                      (selectedInvoice.customerId !== 'CUST-000' || selectedInvoice.paymentMode === 'Credit')
                        ? 'bg-purple-950/80 text-purple-300 border border-purple-800/60'
                        : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                    }`}
                  >
                    {selectedInvoice &&
                    (selectedInvoice.customerId !== 'CUST-000' || selectedInvoice.paymentMode === 'Credit')
                      ? 'Khata'
                      : 'Counter'}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  SOLD BY
                </label>
                <input
                  type="text"
                  placeholder=""
                  value={editSalesmanName}
                  onChange={(e) => setEditSalesmanName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700/60 rounded-lg px-2.5 py-1 text-slate-100 focus:border-purple-500 focus:outline-none text-xs"
                />
              </div>
            </div>

            {/* Line Items Table & Return adjustments */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-purple-400" />
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Bill Items & Quantities ({editLineItems.length})
                  </h4>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAddItem(!showAddItem)}
                  className="px-2.5 py-1 bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{showAddItem ? 'Cancel Add Item' : 'Add Item to Bill'}</span>
                </button>
              </div>

              {/* Quick Add Item Subform */}
              {showAddItem && (
                <div className="bg-slate-950 border border-purple-500/40 p-3.5 rounded-xl space-y-3 animate-in fade-in">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
                    <div className="text-[11px] font-bold text-purple-300">Add Item into this Invoice</div>
                    <label className="flex items-center gap-1.5 text-[11px] text-slate-200 cursor-pointer select-none font-semibold bg-slate-900 border border-slate-700/80 hover:border-purple-500/60 px-2.5 py-1 rounded-md transition-colors">
                      <input
                        type="checkbox"
                        checked={isAddExistingItem}
                        onChange={(e) => handleAddExistingItemToggle(e.target.checked)}
                        className="rounded border-slate-700 bg-slate-950 text-purple-500 focus:ring-purple-500 h-3.5 w-3.5 accent-purple-600 cursor-pointer"
                      />
                      <span>Existing ITEM</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs items-end">
                    {/* Item Selector / Manual Input */}
                    {isAddExistingItem ? (
                      <div className="sm:col-span-5">
                        <label className="block text-[10px] text-slate-400 font-medium mb-1">Select Item from Catalog</label>
                        <select
                          value={addSelectedItemId}
                          onChange={(e) => handleAddExistingItemSelect(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                        >
                          <option value="">-- Choose from Item Master --</option>
                          {itemsList
                            .filter((itm) => itm.isActive !== false)
                            .map((itm) => (
                              <option key={itm.id} value={itm.id}>
                                {itm.itemCode} - {itm.itemName} (Stock: {itm.currentStock} {itm.unit} | ₹{itm.sellingRate})
                              </option>
                            ))}
                        </select>
                      </div>
                    ) : (
                      <div className="sm:col-span-5">
                        <label className="block text-[10px] text-slate-400 font-medium mb-1">Item Name</label>
                        <input
                          type="text"
                          placeholder="Enter Item Name"
                          value={addManualName}
                          onChange={(e) => setAddManualName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleAddNewItemToBill();
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                        />
                      </div>
                    )}

                    {/* Rate */}
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] text-slate-400 font-medium mb-1">Rate (₹)</label>
                      <input
                        type="text"
                        inputMode="decimal"
                        placeholder=""
                        value={addRate}
                        onChange={(e) => setAddRate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                      />
                    </div>

                    {/* Quantity */}
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] text-slate-400 font-medium mb-1">Quantity</label>
                      <input
                        type="text"
                        inputMode="numeric"
                        placeholder=""
                        value={addQty}
                        onChange={(e) => setAddQty(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-100 text-xs font-mono font-bold focus:outline-none focus:border-purple-500"
                      />
                    </div>

                    {/* Disc */}
                    <div className="sm:col-span-1">
                      <label className="block text-[10px] text-slate-400 font-medium mb-1">Disc% / ₹</label>
                      <input
                        type="text"
                        placeholder="e.g. 10"
                        value={addDisc}
                        onChange={(e) => setAddDisc(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                      />
                    </div>

                    {/* Insert Button */}
                    <div className="sm:col-span-2">
                      <button
                        type="button"
                        onClick={handleAddNewItemToBill}
                        className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-1.5 px-3 rounded-lg text-xs cursor-pointer transition-colors flex items-center justify-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Insert Item</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Items Grid Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800 text-[11px]">
                      <th className="py-2.5 px-2 text-center w-8">#</th>
                      <th className="py-2.5 px-3 min-w-[140px]">Item Description</th>
                      <th className="py-2.5 px-2 text-center w-16">HSN</th>
                      <th className="py-2.5 px-2 text-center w-24">Qty (Pcs/Prs)</th>
                      <th className="py-2.5 px-2 text-right w-24">Rate (₹)</th>
                      <th className="py-2.5 px-2 text-right w-24">Disc% / Amt</th>
                      <th className="py-2.5 px-2 text-right w-24">Taxable</th>
                      <th className="py-2.5 px-2 text-center w-14">GST%</th>
                      <th className="py-2.5 px-2 text-right w-24">Total (₹)</th>
                      <th className="py-2.5 px-2 text-center w-10">Act</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                    {editLineItems.map((line, idx) => (
                      <tr key={line.id || idx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-2 px-2 text-center font-mono text-slate-500 text-[11px]">{idx + 1}</td>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-slate-200">{line.itemName}</div>
                          {line.itemCode && line.itemCode !== 'MANUAL' && (
                            <span className="text-[10px] font-mono text-slate-400">{line.itemCode}</span>
                          )}
                        </td>
                        <td className="py-2 px-2 text-center font-mono text-slate-400">{line.hsnCode || '6403'}</td>
                        <td className="py-2 px-2 text-center">
                          <input
                            type="text"
                            inputMode="numeric"
                            value={line.quantity}
                            onChange={(e) => handleUpdateLineQty(idx, Number(e.target.value) || 0)}
                            className="w-16 bg-slate-950 border border-slate-700/80 rounded px-1.5 py-0.5 text-center text-slate-100 font-mono text-xs focus:border-purple-500 focus:outline-none"
                            title="Adjust quantity (e.g. reduce for customer returns)"
                          />
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={line.rate}
                            onChange={(e) => handleUpdateLineRate(idx, Number(e.target.value) || 0)}
                            className="w-20 bg-slate-950 border border-slate-700/80 rounded px-1.5 py-0.5 text-right text-slate-100 font-mono text-xs focus:border-purple-500 focus:outline-none"
                          />
                        </td>
                        <td className="py-2 px-2 text-right">
                          <input
                            type="text"
                            placeholder=""
                            defaultValue={
                              line.discountAmount > 0
                                ? line.discountPercent > 0
                                  ? `${line.discountPercent}%`
                                  : line.discountAmount
                                : ''
                            }
                            onBlur={(e) => handleUpdateLineDiscount(idx, e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleUpdateLineDiscount(idx, (e.target as HTMLInputElement).value);
                              }
                            }}
                            className="w-16 bg-slate-950 border border-slate-700/80 rounded px-1.5 py-0.5 text-right text-slate-100 font-mono text-xs focus:border-purple-500 focus:outline-none"
                          />
                        </td>
                        <td className="py-2 px-2 text-right font-mono text-slate-300">
                          {formatCurrency(line.taxableAmount)}
                        </td>
                        <td className="py-2 px-2 text-center font-mono text-purple-300">{line.gstRate}%</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-emerald-400">
                          {formatCurrency(line.netAmount)}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveLineItem(idx)}
                            className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Remove line item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Calculations & Action Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
              {/* Remarks / Narration */}
              <div className="space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Update Narration / Return Remarks
                </label>
                <textarea
                  rows={2}
                  value={editRemarks}
                  onChange={(e) => setEditRemarks(e.target.value)}
                  placeholder="e.g. Exchanged 1 pair of Oxford shoes for size replacement..."
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg p-2 text-slate-200 text-xs focus:border-purple-500 focus:outline-none"
                />
                <div className="text-[11px] text-slate-500">
                  Tax Calculation: <strong className="text-purple-300">{company.defaultTaxCalculation || 'Inclusive'} GST</strong>
                </div>
              </div>

              {/* Grand Total Summary Box */}
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Gross Subtotal:</span>
                  <span className="font-mono">{formatCurrency(grossSubtotal)}</span>
                </div>
                {totalDiscount > 0 && (
                  <div className="flex justify-between text-amber-400">
                    <span>Total Discount:</span>
                    <span className="font-mono">- {formatCurrency(totalDiscount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-300">
                  <span>Taxable Subtotal:</span>
                  <span className="font-mono">{formatCurrency(totalTaxable)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Total GST ({isInterState ? 'IGST' : 'CGST + SGST'}):</span>
                  <span className="font-mono">{formatCurrency(totalTax)}</span>
                </div>
                {roundOff !== 0 && (
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>Round Off:</span>
                    <span className="font-mono">{roundOff > 0 ? `+${roundOff}` : roundOff}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-bold">
                  <span className="text-slate-100">Updated Grand Total:</span>
                  <span className="font-mono text-emerald-400 text-base">{formatCurrency(grandTotal)}</span>
                </div>
              </div>
            </div>

            {/* Bottom Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleCloseSelectedBill}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Close & Back to List
              </button>
              <button
                type="button"
                disabled={Boolean(saveStatus) || editLineItems.length === 0}
                onClick={handleSaveUpdatedBill}
                className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg transition-all ${
                  saveStatus
                    ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-900/30 cursor-pointer'
                }`}
              >
                {saveStatus === 'saving' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Saving & Updating Bill...</span>
                  </>
                ) : saveStatus === 'sending_email' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-sky-200" />
                    <span className="text-sky-200">Sending Email...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save & Update Bill</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {invoiceToDelete && (
        <ConfirmModal
          title="Delete / Void Sales Invoice"
          message={`Are you sure you want to completely delete Invoice #${invoiceToDelete.no}? All item stock will be restored and customer balance/ledger entry will be reversed.`}
          confirmLabel="Yes, Delete Bill"
          cancelLabel="Keep Bill"
          isDestructive={true}
          onConfirm={handleConfirmDelete}
          onCancel={() => setInvoiceToDelete(null)}
        />
      )}

      {/* Print Modal */}
      {selectedPrintInvoice && (
        <InvoicePrintModal
          invoice={selectedPrintInvoice}
          company={company}
          onClose={() => setSelectedPrintInvoice(null)}
          onAttachToNav={
            onOpenPrintPreviewTab
              ? () => {
                  const inv = selectedPrintInvoice;
                  setSelectedPrintInvoice(null);
                  onOpenPrintPreviewTab(inv, false);
                }
              : undefined
          }
        />
      )}

      {/* Feedback Toast */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          buttonText="OK"
          onClose={() => {
            const cb = feedback.onClose;
            setFeedback(null);
            if (cb) {
              cb();
            }
          }}
        />
      )}
        </>
      )}
    </div>
  );
};
