import React, { useState, useEffect } from 'react';
import { Printer, X, FileText, CheckCircle2 } from 'lucide-react';
import { CompanyInfo, Supplier } from '../types';
import { formatCurrency, numberToWords } from '../services/gstCalculations';

export interface SupplierLedgerPrintRow {
  id: string;
  date: string;
  voucherType: string;
  voucherNo: string;
  narration?: string;
  debit: number;
  credit: number;
  calculatedBalance: number;
}

export interface SupplierLedgerPrintModalProps {
  company: CompanyInfo;
  supplier: Supplier;
  fromDate: string;
  toDate: string;
  openingBalance: number;
  rows: SupplierLedgerPrintRow[];
  periodTotalDebit: number;
  periodTotalCredit: number;
  closingBalance: number;
  onClose: () => void;
}

export const SupplierLedgerPrintModal: React.FC<SupplierLedgerPrintModalProps> = ({
  company,
  supplier,
  fromDate,
  toDate,
  openingBalance,
  rows,
  periodTotalDebit,
  periodTotalCredit,
  closingBalance,
  onClose,
}) => {
  const [printFormat, setPrintFormat] = useState<'Thermal70' | 'Thermal80' | 'A4'>('Thermal70');

  // Listen for Ctrl+P and Esc
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePrint();
      }
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [printFormat, rows, closingBalance]);

  const handlePrint = () => {
    const printableEl = document.getElementById('printable-supplier-ledger-content');
    if (!printableEl) {
      window.print();
      return;
    }

    try {
      // Remove any existing print iframe
      const oldFrame = document.getElementById('supplier-ledger-print-frame');
      if (oldFrame) {
        oldFrame.remove();
      }

      // Create a clean hidden iframe
      const iframe = document.createElement('iframe');
      iframe.id = 'supplier-ledger-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0px';
      iframe.style.height = '0px';
      iframe.style.border = 'none';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!doc) {
        window.print();
        return;
      }

      const headLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
        .map((el) => el.outerHTML)
        .join('\n');

      const widthCss =
        printFormat === 'Thermal70'
          ? `@page { size: 70mm auto; margin: 2mm 0mm 0mm 0mm; }
             html, body {
               width: 70mm !important;
               max-width: 70mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding: 2mm 0 0 0 !important;
               overflow-x: hidden !important;
               text-align: left !important;
               font-family: monospace, 'Courier New', Courier, monospace !important;
               font-weight: 700 !important;
               font-size: 12px !important;
               background: #ffffff !important;
               color: #000000 !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
             }
             * {
               box-sizing: border-box !important;
             }
             .print-container,
             .thermal-70mm-slip,
             #thermal-70mm-supplier-ledger-slip {
               width: 70mm !important;
               max-width: 70mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding-top: 2mm !important;
               padding-right: 0mm !important;
               padding-bottom: 0 !important;
               padding-left: 0 !important;
               overflow: hidden !important;
               box-sizing: border-box !important;
               border: none !important;
               box-shadow: none !important;
               background-color: #ffffff !important;
               color: #000000 !important;
             }
             .thermal-70mm-slip,
             .thermal-70mm-slip * {
               background-color: #ffffff !important;
               color: #000000 !important;
               font-weight: 700 !important;
             }
             table {
               width: 100% !important;
               max-width: 100% !important;
               table-layout: fixed !important;
               border-collapse: collapse !important;
               margin: 4px 0 !important;
             }
             td, th {
               box-sizing: border-box !important;
               overflow-wrap: break-word !important;
               word-break: break-word !important;
             }`
          : printFormat === 'Thermal80'
          ? `@page { size: 80mm auto; margin: 2mm 0mm 0mm 0mm; }
             html, body {
               width: 80mm !important;
               max-width: 80mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding: 2mm 0 0 0 !important;
               overflow-x: hidden !important;
               text-align: left !important;
               font-family: monospace, 'Courier New', Courier, monospace !important;
               font-weight: 700 !important;
               font-size: 13px !important;
               background: #ffffff !important;
               color: #000000 !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
             }
             * {
               box-sizing: border-box !important;
             }
             .print-container,
             .thermal-80mm-slip,
             #thermal-80mm-supplier-ledger-slip {
               width: 80mm !important;
               max-width: 80mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding-top: 2mm !important;
               padding-right: 0mm !important;
               padding-bottom: 0 !important;
               padding-left: 0 !important;
               overflow: hidden !important;
               box-sizing: border-box !important;
               border: none !important;
               box-shadow: none !important;
               background-color: #ffffff !important;
               color: #000000 !important;
             }
             .thermal-80mm-slip,
             .thermal-80mm-slip * {
               background-color: #ffffff !important;
               color: #000000 !important;
               font-weight: 700 !important;
             }
             table {
               width: 100% !important;
               max-width: 100% !important;
               table-layout: fixed !important;
               border-collapse: collapse !important;
               margin: 4px 0 !important;
             }
             td, th {
               box-sizing: border-box !important;
               overflow-wrap: break-word !important;
               word-break: break-word !important;
             }`
          : `@page { size: A4 portrait; margin: 8mm; }
             html, body {
               width: 100% !important;
               margin: 0 !important;
               padding: 0 !important;
               font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
               background: #ffffff !important;
               color: #000000 !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
             }`;

      const htmlContent = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <title>Supplier Ledger - ${supplier.supplierName}</title>
            ${headLinks}
            <style>
              ${widthCss}
              * {
                box-sizing: border-box;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              body {
                background: #ffffff !important;
                color: #000000 !important;
                visibility: visible !important;
              }
              .no-print, .print\\:hidden {
                display: none !important;
              }
            </style>
          </head>
          <body>
            ${printableEl.innerHTML}
          </body>
        </html>
      `;

      doc.open();
      doc.write(htmlContent);
      doc.close();

      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch (err) {
          console.error('Iframe print error, falling back to window.print():', err);
          window.print();
        }
      }, 300);
    } catch (e) {
      console.error('Print trigger error:', e);
      window.print();
    }
  };

  const balanceText = `${formatCurrency(Math.abs(closingBalance))} ${closingBalance >= 0 ? 'Cr (Payable)' : 'Dr (Advance)'}`;
  const closingWords = numberToWords(Math.abs(closingBalance));

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900/95 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[94vh] flex flex-col overflow-hidden text-slate-100">
        {/* Top Control Bar */}
        <div className="p-3 bg-slate-950/80 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center shadow-inner">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-sm sm:text-base text-slate-100">
                Supplier Statement Print
              </span>
              <span className="block text-[11px] text-slate-400">
                {supplier.supplierName} ({supplier.supplierCode})
              </span>
            </div>
          </div>

          {/* Format selector buttons */}
          <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button
              type="button"
              onClick={() => setPrintFormat('Thermal70')}
              className={`px-3 py-1 text-xs font-semibold rounded transition flex items-center gap-1 cursor-pointer ${
                printFormat === 'Thermal70'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {printFormat === 'Thermal70' && <CheckCircle2 className="w-3 h-3" />}
              <span>70mm POS Slip</span>
            </button>
            <button
              type="button"
              onClick={() => setPrintFormat('Thermal80')}
              className={`px-3 py-1 text-xs font-semibold rounded transition flex items-center gap-1 cursor-pointer ${
                printFormat === 'Thermal80'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {printFormat === 'Thermal80' && <CheckCircle2 className="w-3 h-3" />}
              <span>80mm POS Slip</span>
            </button>
            <button
              type="button"
              onClick={() => setPrintFormat('A4')}
              className={`px-3 py-1 text-xs font-semibold rounded transition flex items-center gap-1 cursor-pointer ${
                printFormat === 'A4'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {printFormat === 'A4' && <CheckCircle2 className="w-3 h-3" />}
              <span>Standard A4</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-md transition text-xs cursor-pointer active:scale-95"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print [Ctrl+P]</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Preview Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950/60 flex justify-center items-start">
          <div id="printable-supplier-ledger-content" className="w-full flex justify-center">
            {/* FORMAT 1: 70mm POS Thermal Slip */}
            {printFormat === 'Thermal70' && (
              <div
                id="thermal-70mm-supplier-ledger-slip"
                className="thermal-70mm-slip bg-white text-black font-mono font-bold shadow-2xl p-2 select-text"
                style={{ width: '70mm', minWidth: '70mm', maxWidth: '70mm', boxSizing: 'border-box', backgroundColor: '#ffffff', color: '#000000' }}
              >
                {/* Store Header */}
                <div className="text-center pb-2 border-b-2 border-dashed border-black">
                  <h1
                    className="font-black leading-tight uppercase tracking-tight"
                    style={{ fontSize: '28px', color: '#000000' }}
                  >
                    {company.companyName || 'ARCO FOOTWEAR'}
                  </h1>
                  {company.tagline && (
                    <p className="font-bold text-[10px] uppercase text-black">{company.tagline}</p>
                  )}
                  <p className="font-bold text-[10px] text-black leading-tight mt-0.5">
                    {[company.addressLine1, company.city, company.state, company.pincode].filter(Boolean).join(', ')}
                  </p>
                  {company.phone && (
                    <p className="font-bold text-[10px] text-black">Tel: {company.phone}</p>
                  )}
                  {company.gstin && (
                    <p className="font-bold text-[10px] text-black">GSTIN: {company.gstin}</p>
                  )}
                </div>

                {/* Slip Title */}
                <div className="text-center py-1.5 border-b-2 border-dashed border-black">
                  <div className="text-[13px] font-black uppercase tracking-wider text-black">
                    SUPPLIER ACCOUNT STATEMENT
                  </div>
                  <div className="text-[10px] font-bold text-black mt-0.5">
                    Period: {fromDate} to {toDate}
                  </div>
                </div>

                {/* Supplier Info */}
                <div className="py-1.5 border-b border-black text-[11px] leading-snug">
                  <div>
                    <span className="font-black">Supplier: </span>
                    <span className="font-bold">{supplier.supplierName}</span>
                  </div>
                  <div>
                    <span className="font-black">Code: </span>
                    <span>{supplier.supplierCode}</span>
                  </div>
                  {supplier.mobile && (
                    <div>
                      <span className="font-black">Mob: </span>
                      <span>{supplier.mobile}</span>
                    </div>
                  )}
                  {supplier.gstin && (
                    <div>
                      <span className="font-black">GSTIN: </span>
                      <span>{supplier.gstin}</span>
                    </div>
                  )}
                  {supplier.city && (
                    <div>
                      <span className="font-black">City: </span>
                      <span>{supplier.city}</span>
                    </div>
                  )}
                  {supplier.address && (
                    <div>
                      <span className="font-black">Addr: </span>
                      <span>{supplier.address}</span>
                    </div>
                  )}
                </div>

                {/* Opening Balance */}
                <div className="py-1 border-b border-dashed border-black text-[11px] flex justify-between font-black">
                  <span>Opening Bal ({fromDate}):</span>
                  <span>
                    {formatCurrency(Math.abs(openingBalance))} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                  </span>
                </div>

                {/* Transactions Table */}
                <table className="w-full text-[10px] my-1 border-collapse" style={{ tableLayout: 'fixed' }}>
                  <thead>
                    <tr className="border-b-2 border-black text-black">
                      <th className="py-1 text-left" style={{ width: '22%' }}>Date</th>
                      <th className="py-1 text-left" style={{ width: '30%' }}>Voucher</th>
                      <th className="py-1 text-right" style={{ width: '24%' }}>Paid Dr</th>
                      <th className="py-1 text-right" style={{ width: '24%' }}>Bill Cr</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-2 text-center text-black font-bold">
                          No transactions in period
                        </td>
                      </tr>
                    ) : (
                      rows.map((row) => (
                        <tr key={row.id} className="border-b border-dotted border-gray-400">
                          <td className="py-1 align-top text-left text-[9px] font-bold">
                            {row.date.split('-').slice(1).join('/')}
                          </td>
                          <td className="py-1 align-top text-left text-[9px]">
                            <div className="font-bold truncate">{row.voucherNo || row.voucherType}</div>
                            <div className="text-[8px] text-gray-700 truncate">{row.voucherType}</div>
                          </td>
                          <td className="py-1 align-top text-right font-bold text-[9px]">
                            {row.debit > 0 ? row.debit.toFixed(2) : '-'}
                          </td>
                          <td className="py-1 align-top text-right font-bold text-[9px]">
                            {row.credit > 0 ? row.credit.toFixed(2) : '-'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>

                {/* Period Totals */}
                <div className="pt-1.5 border-t-2 border-black space-y-1 text-[11px]">
                  <div className="flex justify-between font-bold">
                    <span>Total Inward Bills (+ Cr):</span>
                    <span>{formatCurrency(periodTotalCredit)}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Total Payments (- Dr):</span>
                    <span>{formatCurrency(periodTotalDebit)}</span>
                  </div>
                </div>

                {/* Net Closing Balance Box */}
                <div className="my-2 p-1.5 border-2 border-black bg-gray-100 text-center">
                  <div className="text-[10px] font-black uppercase text-black">Net Closing Balance</div>
                  <div className="text-[17px] font-black text-black leading-tight">
                    {formatCurrency(Math.abs(closingBalance))} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                  </div>
                  <div className="text-[9px] font-bold text-black mt-0.5">
                    {closingBalance >= 0 ? '(Net Amount Payable to Vendor)' : '(Advance / Debit Balance)'}
                  </div>
                </div>

                {/* Footer */}
                <div className="text-center pt-2 border-t-2 border-dashed border-black text-[9px] space-y-1">
                  <p className="font-bold">Computer generated statement</p>
                  <p className="font-bold">For {company.companyName}</p>
                  <div className="pt-4 font-bold">Authorized Signatory</div>
                  <p className="text-[8px] text-gray-600">Printed on {new Date().toLocaleString('en-IN')}</p>
                </div>
              </div>
            )}

            {/* FORMAT 2: 80mm POS Thermal Slip */}
            {printFormat === 'Thermal80' && (
              <div
                id="thermal-80mm-supplier-ledger-slip"
                className="thermal-80mm-slip bg-white text-black font-mono font-bold shadow-2xl p-3 select-text"
                style={{ width: '80mm', minWidth: '80mm', maxWidth: '80mm', boxSizing: 'border-box', backgroundColor: '#ffffff', color: '#000000' }}
              >
                {/* Store Header */}
                <div className="text-center pb-2 border-b-2 border-dashed border-black">
                  <h1
                    className="font-black leading-tight uppercase tracking-tight"
                    style={{ fontSize: '32px', color: '#000000' }}
                  >
                    {company.companyName || 'ARCO FOOTWEAR'}
                  </h1>
                  {company.tagline && (
                    <p className="font-bold text-[11px] uppercase text-black">{company.tagline}</p>
                  )}
                  <p className="font-bold text-[11px] text-black leading-tight mt-0.5">
                    {[company.addressLine1, company.city, company.state, company.pincode].filter(Boolean).join(', ')}
                  </p>
                  {company.phone && (
                    <p className="font-bold text-[11px] text-black">Tel: {company.phone}</p>
                  )}
                  {company.gstin && (
                    <p className="font-bold text-[11px] text-black">GSTIN: {company.gstin}</p>
                  )}
                </div>

                {/* Slip Title */}
                <div className="text-center py-2 border-b-2 border-dashed border-black">
                  <div className="text-[14px] font-black uppercase tracking-wider text-black">
                    SUPPLIER ACCOUNT STATEMENT
                  </div>
                  <div className="text-[11px] font-bold text-black mt-0.5">
                    Period: {fromDate} to {toDate}
                  </div>
                </div>

                {/* Supplier Info */}
                <div className="py-2 border-b border-black text-[12px] leading-snug">
                  <div>
                    <span className="font-black">Supplier: </span>
                    <span className="font-bold">{supplier.supplierName}</span>
                  </div>
                  <div>
                    <span className="font-black">Vendor Code: </span>
                    <span>{supplier.supplierCode}</span>
                  </div>
                  {supplier.mobile && (
                    <div>
                      <span className="font-black">Mobile: </span>
                      <span>{supplier.mobile}</span>
                    </div>
                  )}
                  {supplier.gstin && (
                    <div>
                      <span className="font-black">GSTIN: </span>
                      <span>{supplier.gstin}</span>
                    </div>
                  )}
                  {supplier.city && (
                    <div>
                      <span className="font-black">City: </span>
                      <span>{supplier.city}</span>
                    </div>
                  )}
                  {supplier.address && (
                    <div>
                      <span className="font-black">Address: </span>
                      <span>{supplier.address}</span>
                    </div>
                  )}
                </div>

                {/* Opening Balance */}
                <div className="py-1.5 border-b border-dashed border-black text-[12px] flex justify-between font-black">
                  <span>Opening Balance ({fromDate}):</span>
                  <span>
                    {formatCurrency(Math.abs(openingBalance))} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                  </span>
                </div>

                {/* Transactions Table */}
                <table className="w-full text-[11px] my-1.5 border-collapse" style={{ tableLayout: 'fixed' }}>
                  <thead>
                    <tr className="border-b-2 border-black text-black">
                      <th className="py-1 text-left" style={{ width: '20%' }}>Date</th>
                      <th className="py-1 text-left" style={{ width: '32%' }}>Voucher</th>
                      <th className="py-1 text-right" style={{ width: '24%' }}>Paid Dr</th>
                      <th className="py-1 text-right" style={{ width: '24%' }}>Bill Cr</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-2.5 text-center text-black font-bold">
                          No transactions in period
                        </td>
                      </tr>
                    ) : (
                      rows.map((row) => (
                        <tr key={row.id} className="border-b border-dotted border-gray-400">
                          <td className="py-1 align-top text-left text-[10px] font-bold">
                            {row.date.split('-').slice(1).join('/')}
                          </td>
                          <td className="py-1 align-top text-left text-[10px]">
                            <div className="font-bold truncate">{row.voucherNo || row.voucherType}</div>
                            <div className="text-[9px] text-gray-700 truncate">{row.voucherType}</div>
                          </td>
                          <td className="py-1 align-top text-right font-bold text-[10px]">
                            {row.debit > 0 ? row.debit.toFixed(2) : '-'}
                          </td>
                          <td className="py-1 align-top text-right font-bold text-[10px]">
                            {row.credit > 0 ? row.credit.toFixed(2) : '-'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>

                {/* Period Totals */}
                <div className="pt-2 border-t-2 border-black space-y-1 text-[12px]">
                  <div className="flex justify-between font-bold">
                    <span>Total Inward Bills (+ Cr):</span>
                    <span>{formatCurrency(periodTotalCredit)}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Total Payments (- Dr):</span>
                    <span>{formatCurrency(periodTotalDebit)}</span>
                  </div>
                </div>

                {/* Net Closing Balance Box */}
                <div className="my-2.5 p-2 border-2 border-black bg-gray-100 text-center">
                  <div className="text-[11px] font-black uppercase text-black">Net Closing Balance</div>
                  <div className="text-[19px] font-black text-black leading-tight">
                    {formatCurrency(Math.abs(closingBalance))} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                  </div>
                  <div className="text-[10px] font-bold text-black mt-0.5">
                    {closingBalance >= 0 ? '(Net Amount Payable to Vendor)' : '(Advance / Debit Available)'}
                  </div>
                </div>

                {/* Footer */}
                <div className="text-center pt-2.5 border-t-2 border-dashed border-black text-[10px] space-y-1">
                  <p className="font-bold">Computer generated statement of accounts</p>
                  <p className="font-bold">For {company.companyName}</p>
                  <div className="pt-5 font-bold">Authorized Signatory</div>
                  <p className="text-[9px] text-gray-600">Printed on {new Date().toLocaleString('en-IN')}</p>
                </div>
              </div>
            )}

            {/* FORMAT 3: Standard A4 Statement */}
            {printFormat === 'A4' && (
              <div
                id="standard-a4-supplier-ledger-statement"
                className="bg-white text-black font-sans shadow-2xl p-8 select-text w-full max-w-[210mm] min-h-[297mm] mx-auto text-xs"
                style={{ backgroundColor: '#ffffff', color: '#000000' }}
              >
                {/* Letterhead */}
                <div className="border-b-2 border-slate-900 pb-4 mb-4 flex justify-between items-start">
                  <div>
                    <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
                      {company.companyName || 'ARCO FOOTWEAR CO.'}
                    </h1>
                    {company.tagline && (
                      <p className="text-xs font-semibold text-slate-700 uppercase">{company.tagline}</p>
                    )}
                    <p className="text-xs text-slate-800 mt-1 max-w-md">
                      {[company.addressLine1, company.addressLine2, company.city, company.state, company.pincode].filter(Boolean).join(', ')}
                    </p>
                    <div className="text-xs text-slate-800 mt-1 flex flex-wrap gap-x-4">
                      {company.phone && <span><strong>Phone:</strong> {company.phone}</span>}
                      {company.mobile && <span><strong>Mobile:</strong> {company.mobile}</span>}
                      {company.email && <span><strong>Email:</strong> {company.email}</span>}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="inline-block bg-slate-900 text-white font-bold text-xs uppercase px-3 py-1 rounded">
                      Supplier Statement of Account
                    </div>
                    <div className="text-xs text-slate-800 mt-2 space-y-0.5">
                      <div><strong>Statement Date:</strong> {new Date().toLocaleDateString('en-IN')}</div>
                      <div><strong>From:</strong> {fromDate} <strong>To:</strong> {toDate}</div>
                      {company.gstin && <div><strong>Company GSTIN:</strong> {company.gstin}</div>}
                      {company.pan && <div><strong>PAN:</strong> {company.pan}</div>}
                    </div>
                  </div>
                </div>

                {/* Supplier Box & Statement Summary Grid */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="border border-slate-300 rounded p-3 bg-slate-50">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 border-b border-slate-200 pb-1">
                      Supplier / Vendor Details
                    </h3>
                    <div className="text-sm font-bold text-slate-900">{supplier.supplierName}</div>
                    <div className="text-xs text-slate-700 mt-0.5">Supplier Code: <strong>{supplier.supplierCode}</strong></div>
                    {supplier.contactPerson && (
                      <div className="text-xs text-slate-700">Contact Person: {supplier.contactPerson}</div>
                    )}
                    {supplier.mobile && (
                      <div className="text-xs text-slate-700">Mobile: {supplier.mobile}</div>
                    )}
                    {supplier.address && (
                      <div className="text-xs text-slate-700">Address: {supplier.address}, {supplier.city}</div>
                    )}
                    {supplier.gstin && (
                      <div className="text-xs text-slate-700">GSTIN: <strong>{supplier.gstin}</strong></div>
                    )}
                  </div>

                  <div className="border border-slate-300 rounded p-3 bg-slate-50 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 border-b border-slate-200 pb-1">
                        Statement Account Summary
                      </h3>
                      <div className="grid grid-cols-2 gap-2 text-xs py-1">
                        <div>
                          <span className="text-slate-600">Opening Balance:</span>
                          <div className="font-bold text-slate-900">
                            {formatCurrency(Math.abs(openingBalance))} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                          </div>
                        </div>
                        <div>
                          <span className="text-slate-600">Total Inward Purchases (Cr):</span>
                          <div className="font-bold text-blue-700">{formatCurrency(periodTotalCredit)}</div>
                        </div>
                        <div>
                          <span className="text-slate-600">Total Payments Made (Dr):</span>
                          <div className="font-bold text-emerald-700">{formatCurrency(periodTotalDebit)}</div>
                        </div>
                        <div>
                          <span className="text-slate-600">Net Period Activity:</span>
                          <div className="font-bold text-slate-900">
                            {formatCurrency(Math.abs(periodTotalCredit - periodTotalDebit))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-300 pt-2 mt-2 flex justify-between items-center bg-white p-2 rounded border">
                      <span className="font-bold uppercase text-slate-800 text-xs">Net Closing Balance:</span>
                      <span className={`text-base font-black ${closingBalance >= 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                        {balanceText}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Ledger Transactions Table */}
                <div className="mb-4">
                  <table className="w-full border-collapse border border-slate-300 text-xs">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                        <th className="border border-slate-300 px-2 py-1.5 text-center w-8">#</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-left w-20">Date</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-left w-24">Voucher Type</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-left w-24">Bill / Ref No</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-left">Particulars / Narration</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-right w-24">Payments Dr (₹)</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-right w-24">Purchases Cr (₹)</th>
                        <th className="border border-slate-300 px-2 py-1.5 text-right w-28">Balance (₹)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Opening Balance Row */}
                      <tr className="bg-slate-50/80 font-bold text-slate-800 border-b border-slate-200">
                        <td className="border border-slate-300 px-2 py-1.5 text-center">-</td>
                        <td className="border border-slate-300 px-2 py-1.5">{fromDate}</td>
                        <td className="border border-slate-300 px-2 py-1.5">OPENING</td>
                        <td className="border border-slate-300 px-2 py-1.5">-</td>
                        <td className="border border-slate-300 px-2 py-1.5 italic text-slate-700">
                          Opening Balance as on {fromDate}
                        </td>
                        <td className="border border-slate-300 px-2 py-1.5 text-right">
                          {openingBalance < 0 ? Math.abs(openingBalance).toFixed(2) : '-'}
                        </td>
                        <td className="border border-slate-300 px-2 py-1.5 text-right">
                          {openingBalance > 0 ? openingBalance.toFixed(2) : '-'}
                        </td>
                        <td className="border border-slate-300 px-2 py-1.5 text-right font-mono font-bold">
                          {Math.abs(openingBalance).toFixed(2)} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                        </td>
                      </tr>

                      {rows.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="border border-slate-300 py-6 text-center text-slate-500">
                            No transactions recorded in this date range.
                          </td>
                        </tr>
                      ) : (
                        rows.map((row, idx) => (
                          <tr key={row.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                            <td className="border border-slate-300 px-2 py-1.5 text-center text-slate-500 font-mono text-[11px]">
                              {idx + 1}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 text-slate-800 font-mono text-[11px]">
                              {row.date}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 font-semibold text-slate-800">
                              {row.voucherType}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 font-mono text-slate-800">
                              {row.voucherNo}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 text-slate-700">
                              {row.narration || '-'}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 text-right font-mono text-slate-900 font-semibold">
                              {row.debit > 0 ? row.debit.toFixed(2) : '-'}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 text-right font-mono text-slate-900 font-semibold">
                              {row.credit > 0 ? row.credit.toFixed(2) : '-'}
                            </td>
                            <td className="border border-slate-300 px-2 py-1.5 text-right font-mono font-bold text-slate-900">
                              {Math.abs(row.calculatedBalance).toFixed(2)} {row.calculatedBalance >= 0 ? 'Cr' : 'Dr'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-400">
                        <td colSpan={5} className="border border-slate-300 px-3 py-2 text-right uppercase tracking-wider">
                          Period Totals:
                        </td>
                        <td className="border border-slate-300 px-2 py-2 text-right font-mono text-slate-900">
                          ₹{periodTotalDebit.toFixed(2)}
                        </td>
                        <td className="border border-slate-300 px-2 py-2 text-right font-mono text-slate-900">
                          ₹{periodTotalCredit.toFixed(2)}
                        </td>
                        <td className="border border-slate-300 px-2 py-2 text-right font-mono font-black text-slate-900">
                          {Math.abs(closingBalance).toFixed(2)} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Amount in words & Supplier bank info */}
                <div className="border border-slate-300 rounded p-3 bg-slate-50 mb-4 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-slate-700">Net Balance In Words: </span>
                    <span className="italic font-semibold text-slate-900">{closingWords}</span>
                  </div>
                  {supplier.bankAccountNo && (
                    <div className="text-right text-[11px] text-slate-700">
                      <span><strong>Vendor Bank:</strong> {supplier.bankName} | <strong>A/C:</strong> {supplier.bankAccountNo} | <strong>IFSC:</strong> {supplier.bankIfsc}</span>
                    </div>
                  )}
                </div>

                {/* Signatory & Notes */}
                <div className="pt-6 flex justify-between items-end text-xs">
                  <div className="text-slate-600 max-w-sm">
                    <p className="font-bold text-slate-800">Statement Verification:</p>
                    <p className="text-[11px] mt-0.5">
                      This is a computer-generated statement of accounts for supplier purchases and disbursements. Please verify and confirm balances.
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-slate-900 mb-8">For {company.companyName}</div>
                    <div className="border-t border-slate-400 pt-1 px-8 font-semibold text-slate-700">
                      Authorized Signatory
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
