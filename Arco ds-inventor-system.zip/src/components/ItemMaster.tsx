import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  Save,
  Trash2,
  Search,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Tag,
  Boxes,
  ArrowUpDown,
  Filter,
} from 'lucide-react';
import { Item } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';

export const ItemMasterComponent: React.FC = () => {
  const [items, setItems] = useState<Item[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [itemToDelete, setItemToDelete] = useState<{ id: string; label: string } | null>(null);

  // Form Fields
  const [itemCode, setItemCode] = useState<string>('');
  const [barcode, setBarcode] = useState<string>('');
  const [itemName, setItemName] = useState<string>('');
  const [category, setCategory] = useState<string>('General Footwear');
  const [unit, setUnit] = useState<string>('Pairs');
  const [hsnCode, setHsnCode] = useState<string>('6403');
  const [purchaseRate, setPurchaseRate] = useState<number | ''>('');
  const [sellingRate, setSellingRate] = useState<number | ''>('');
  const [mrp, setMrp] = useState<number | ''>('');
  const [gstRate, setGstRate] = useState<number>(5);
  const [minStockLevel, setMinStockLevel] = useState<number>(1);
  const [openingStock, setOpeningStock] = useState<number>(0);
  const [openingStockValue, setOpeningStockValue] = useState<number>(0);
  const [currentStock, setCurrentStock] = useState<number>(0);
  const [locationRack, setLocationRack] = useState<string>('Rack A-1');
  const [isActive, setIsActive] = useState<boolean>(true);

  // Filtering & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [showLowStockOnly, setShowLowStockOnly] = useState<boolean>(false);

  // Feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadItems = () => {
    const list = dbService.getItems();
    setItems(list);
  };

  useEffect(() => {
    loadItems();
    return dbService.subscribe(loadItems);
  }, []);

  const resetForm = () => {
    setSelectedId(null);
    const count = items.length + 1;
    setItemCode(`SH-ART-${String(count).padStart(3, '0')}`);
    setBarcode(`890100100${String(count).padStart(3, '0')}`);
    setItemName('');
    setCategory('General Footwear');
    setUnit('Pairs');
    setHsnCode('6403');
    setPurchaseRate('');
    setSellingRate('');
    setMrp('');
    setGstRate(5);
    setMinStockLevel(1);
    setOpeningStock(0);
    setOpeningStockValue(0);
    setCurrentStock(0);
    setLocationRack('Rack A-1');
    setIsActive(true);
    setFeedback(null);
  };

  const handleSelectItem = (it: Item) => {
    setSelectedId(it.id);
    setItemCode(it.itemCode);
    setBarcode(it.barcode || '');
    setItemName(it.itemName);
    setCategory(it.category);
    setUnit(it.unit);
    setHsnCode(it.hsnCode);
    setPurchaseRate(it.purchaseRate || '');
    setSellingRate(it.sellingRate || '');
    setMrp(it.mrp || it.sellingRate || '');
    setGstRate(it.gstRate);
    setMinStockLevel(it.minStockLevel || 10);
    setOpeningStock(it.openingStock || 0);
    setOpeningStockValue(it.openingStockValue || 0);
    setCurrentStock(it.currentStock);
    setLocationRack(it.locationRack || '');
    setIsActive(it.isActive);
    setFeedback(null);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemCode.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Item Code / Article Number is required.' });
      return;
    }
    if (!itemName.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Item / Product Name is required.' });
      return;
    }

    const isUpdate = Boolean(selectedId);
    const item: Item = {
      id: selectedId || `ITM-${Date.now()}`,
      itemCode: itemCode.trim().toUpperCase(),
      barcode: barcode.trim(),
      itemName: itemName.trim(),
      category,
      unit,
      hsnCode: hsnCode.trim(),
      purchaseRate: Number(purchaseRate) || 0,
      sellingRate: Number(sellingRate) || 0,
      mrp: Number(mrp) || Number(sellingRate) || 0,
      gstRate: Number(gstRate) || 0,
      taxType: dbService.getCompanyInfo().defaultTaxCalculation || 'Inclusive',
      openingStock: Number(openingStock) || 0,
      openingStockValue: Number(openingStockValue) || Number(openingStock) * Number(purchaseRate),
      currentStock: selectedId ? Number(currentStock) : Number(openingStock) || 0,
      minStockLevel: Number(minStockLevel) || 0,
      locationRack: locationRack.trim(),
      isActive,
      createdAt: selectedId ? items.find((i) => i.id === selectedId)?.createdAt || '' : new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    dbService.saveItem(item);
    loadItems();
    setFeedback({
      type: 'success',
      title: isUpdate ? 'Item Updated Successfully' : 'Item Saved Successfully',
      text: isUpdate
        ? `Item "${item.itemName}" (${item.itemCode}) has been updated successfully in the catalog!`
        : `Item "${item.itemName}" (${item.itemCode}) has been saved successfully to the catalog!`,
    });
    if (!selectedId) {
      resetForm();
    }
  };

  const handleDelete = (targetId?: string | React.MouseEvent) => {
    const id = (typeof targetId === 'string' && targetId) ? targetId : selectedId;
    if (!id) return;
    const itemObj = items.find((i) => i.id === id);
    const label = itemObj ? `"${itemObj.itemName}" (${itemObj.itemCode})` : 'this item';
    setItemToDelete({ id, label });
  };

  const confirmDelete = () => {
    if (!itemToDelete) return;
    const { id, label } = itemToDelete;
    const res = dbService.deleteItem(id, true);
    setItemToDelete(null);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Item Deleted Successfully',
        text: `Item ${label} has been deleted from the catalog successfully!`,
      });
      loadItems();
      if (selectedId === id) {
        resetForm();
      }
    } else {
      setFeedback({ type: 'error', title: 'Delete Operation Failed', text: res.message });
    }
  };

  const filteredItems = items.filter((it) => {
    const matchQuery =
      it.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      it.itemCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (it.barcode && it.barcode.includes(searchQuery)) ||
      (it.hsnCode && it.hsnCode.includes(searchQuery));
    const matchCategory = filterCategory === 'ALL' || it.category === filterCategory;
    const matchLowStock = !showLowStockOnly || it.currentStock <= (it.minStockLevel || 10);
    return matchQuery && matchCategory && matchLowStock;
  });

  const categories = Array.from(new Set(items.map((i) => i.category)));

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal */}
      {itemToDelete && (
        <ConfirmModal
          title="Delete Catalog Item"
          message={`Are you sure you want to permanently delete ${itemToDelete.label} from the catalog?`}
          confirmLabel="Delete Item"
          onConfirm={confirmDelete}
          onCancel={() => setItemToDelete(null)}
        />
      )}

      {/* Modal Popup for all Messages (Success, Errors, Updates) */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      {/* Main Grid: Form on Left/Top, List on Right/Bottom */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form Panel (frmItemMaster) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-700/40 pb-3 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-amber-600/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                    <span>{selectedId ? 'Edit Item/Product' : 'New Item/Product'}</span>
                  </h2>
                  <p className="text-xs text-slate-400">Footwear article, HSN, pricing & stock tracking</p>
                </div>
              </div>

              <button
                id="btn-new-item"
                type="button"
                onClick={resetForm}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 text-xs font-medium border border-slate-700/50 backdrop-blur-sm transition"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                <span>New</span>
              </button>
            </div>

            <form id="form-item-master" onSubmit={handleSave} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Item / Article Code *</label>
                  <input
                    type="text"
                    required
                    value={itemCode}
                    onChange={(e) => setItemCode(e.target.value)}
                    placeholder="e.g. SH-FOR-OX-01"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold uppercase focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Barcode / EAN</label>
                  <input
                    type="text"
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    placeholder="e.g. 890100100001"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Item Description / Name *</label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="e.g. Men's Oxford Leather Formal Shoes (Black)"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-medium focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none text-xs"
                  >
                    <option value="Formal Shoes">Formal Shoes</option>
                    <option value="Casual Shoes">Casual Shoes</option>
                    <option value="Sports & Running">Sports & Running</option>
                    <option value="School Shoes">School Shoes</option>
                    <option value="Sandals & Slippers">Sandals & Slippers</option>
                    <option value="Accessories">Accessories</option>
                    <option value="General Footwear">General Footwear</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Unit</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none text-xs"
                  >
                    <option value="Pairs">Pairs (Prs)</option>
                    <option value="Pcs">Pieces (Pcs)</option>
                    <option value="Box">Box (Bx)</option>
                    <option value="Doz">Dozen (Doz)</option>
                    <option value="Set">Set</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">HSN / SAC Code</label>
                  <input
                    type="text"
                    value={hsnCode}
                    onChange={(e) => setHsnCode(e.target.value)}
                    placeholder="6403"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Pricing & GST */}
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                  Pricing & GST Tax Details
                </span>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">Purchase Rate (₹)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={purchaseRate}
                      onChange={(e) => setPurchaseRate(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">Selling Rate (₹)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={sellingRate}
                      onChange={(e) => {
                        const val = e.target.value === '' ? '' : Number(e.target.value);
                        setSellingRate(val);
                        setMrp(val);
                      }}
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-emerald-400 font-bold font-mono focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-medium mb-0.5">MRP Print (₹)</label>
                    <input
                      type="number"
                      step="any"
                      placeholder="0.00"
                      value={mrp}
                      onChange={(e) => setMrp(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <label className="block text-slate-400 font-medium mb-0.5">GST Rate %</label>
                  <select
                    value={gstRate}
                    onChange={(e) => setGstRate(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-amber-500 focus:outline-none text-xs"
                  >
                    <option value={0}>0% (Exempted)</option>
                    <option value={3}>3% (Precious / Gold)</option>
                    <option value={5}>5% (Footwear &lt; ₹1000)</option>
                    <option value={12}>12% (Footwear &gt; ₹1000 / Accessories)</option>
                    <option value={18}>18% (Standard Footwear / Leather)</option>
                    <option value={28}>28% (Luxury items)</option>
                  </select>
                </div>
              </div>

              {/* Stock Parameters */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Min Reorder Level</label>
                  <input
                    type="number"
                    value={minStockLevel}
                    onChange={(e) => setMinStockLevel(Number(e.target.value))}
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Rack / Shelf</label>
                  <input
                    type="text"
                    value={locationRack}
                    onChange={(e) => setLocationRack(e.target.value)}
                    placeholder="Rack A-1"
                    className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-700/40">
                {selectedId ? (
                  <button
                    type="button"
                    onClick={handleDelete}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold backdrop-blur-sm transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                ) : (
                  <div />
                )}

                <button
                  id="btn-save-item-master"
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg shadow-lg shadow-amber-900/20 border border-amber-500/30 transition"
                >
                  <Save className="w-4 h-4" />
                  <span>{selectedId ? 'Update Item' : 'Save Item [F8]'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Items Grid Panel */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3 mb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Item/Product Catalog List</span>
                <span className="bg-slate-800/60 text-amber-400 font-mono text-xs px-2 py-0.5 rounded border border-slate-700/50">
                  {filteredItems.length} records
                </span>
              </h3>
            </div>

            {/* Quick Filters */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                <input
                  type="text"
                  placeholder="Search code/name/HSN..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 focus:border-amber-500 focus:outline-none text-xs"
                />
              </div>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1 text-slate-300 focus:border-amber-500 focus:outline-none text-xs"
              >
                <option value="ALL">All Categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => setShowLowStockOnly(!showLowStockOnly)}
                className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1 transition ${
                  showLowStockOnly
                    ? 'bg-rose-900/60 text-rose-300 border-rose-700'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/50 hover:text-slate-200'
                }`}
              >
                <AlertTriangle className="w-3 h-3 text-rose-400" />
                <span>Low Stock</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto flex-1 max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-2.5">Code</th>
                  <th className="py-2.5 px-2">Item Name</th>
                  <th className="py-2.5 px-2">Category</th>
                  <th className="py-2.5 px-2 text-center">HSN</th>
                  <th className="py-2.5 px-2 text-right">Cost</th>
                  <th className="py-2.5 px-2 text-right">Sale Price</th>
                  <th className="py-2.5 px-2 text-center">GST</th>
                  <th className="py-2.5 px-2 text-right">Stock</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredItems.map((it) => {
                  const isLow = it.currentStock <= (it.minStockLevel || 10);
                  const isSelected = selectedId === it.id;
                  return (
                    <tr
                      key={it.id}
                      onClick={() => handleSelectItem(it)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-amber-950/40 border-l-4 border-amber-500 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-mono font-bold text-amber-400">{it.itemCode}</td>
                      <td className="py-2.5 px-2">
                        <div className="font-semibold text-slate-100">{it.itemName}</div>
                        {it.barcode && <div className="text-[10px] text-slate-500 font-mono">EAN: {it.barcode}</div>}
                      </td>
                      <td className="py-2.5 px-2 text-slate-400">{it.category}</td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">{it.hsnCode}</td>
                      <td className="py-2.5 px-2 text-right font-mono">₹{it.purchaseRate.toFixed(2)}</td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-emerald-400">
                        ₹{it.sellingRate.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">{it.gstRate}%</td>
                      <td className="py-2.5 px-2 text-right font-mono">
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded ${
                            isLow
                              ? 'bg-rose-950/80 text-rose-400 border border-rose-800/60'
                              : 'text-slate-200'
                          }`}
                        >
                          {it.currentStock} {it.unit}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleDelete(it.id)}
                          title="Delete Item"
                          className="p-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900/80 text-rose-400 border border-rose-800/50 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
