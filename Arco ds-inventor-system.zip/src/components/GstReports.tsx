import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  Layers,
  ArrowRight,
  Receipt,
  Building,
  Users,
  Search,
  Filter,
} from 'lucide-react';
import { CompanyInfo, Customer, PurchaseInvoice, SalesInvoice, Supplier } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';

interface GstReportsProps {
  company: CompanyInfo;
}

export const GstReportsComponent: React.FC<GstReportsProps> = ({ company }) => {
  const [activeReportTab, setActiveReportTab] = useState<'GSTR1' | 'GSTR3B' | 'SALES_REG' | 'PUR_REG' | 'KHATA_LEDGER'>('GSTR1');
  const [fromDate, setFromDate] = useState<string>('2026-08-01');
  const [toDate, setToDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // For Khata Ledger party selection
  const [selectedPartyType, setSelectedPartyType] = useState<'CUSTOMER' | 'SUPPLIER'>('CUSTOMER');
  const [selectedPartyId, setSelectedPartyId] = useState<string>('CUST-001');

  const sales = dbService.getSales();
  const purchases = dbService.getPurchases();
  const customers = dbService.getCustomers();
  const suppliers = dbService.getSuppliers();
  const customerLedgers = dbService.getCustomerLedgers();
  const supplierLedgers = dbService.getSupplierLedgers();

  // Filtered by date range
  const filteredSales = sales.filter((s) => s.invoiceDate >= fromDate && s.invoiceDate <= toDate);
  const filteredPurchases = purchases.filter((p) => p.purchaseDate >= fromDate && p.purchaseDate <= toDate);

  // GSTR-1 Metrics
  const b2bSales = filteredSales.filter((s) => s.customerGstin && s.customerGstin.trim().length === 15);
  const b2cSales = filteredSales.filter((s) => !s.customerGstin || s.customerGstin.trim().length !== 15);

  const totalSalesTaxable = roundTo2(filteredSales.reduce((acc, s) => acc + s.totalTaxable, 0));
  const totalSalesCgst = roundTo2(filteredSales.reduce((acc, s) => acc + s.totalCgst, 0));
  const totalSalesSgst = roundTo2(filteredSales.reduce((acc, s) => acc + s.totalSgst, 0));
  const totalSalesIgst = roundTo2(filteredSales.reduce((acc, s) => acc + s.totalIgst, 0));
  const totalSalesTax = roundTo2(totalSalesCgst + totalSalesSgst + totalSalesIgst);
  const totalSalesGrand = roundTo2(filteredSales.reduce((acc, s) => acc + s.grandTotal, 0));

  // GSTR-3B Metrics (ITC from purchases)
  const totalPurTaxable = roundTo2(filteredPurchases.reduce((acc, p) => acc + p.totalTaxable, 0));
  const totalPurCgst = roundTo2(filteredPurchases.reduce((acc, p) => acc + p.totalCgst, 0));
  const totalPurSgst = roundTo2(filteredPurchases.reduce((acc, p) => acc + p.totalSgst, 0));
  const totalPurIgst = roundTo2(filteredPurchases.reduce((acc, p) => acc + p.totalIgst, 0));
  const totalPurItc = roundTo2(totalPurCgst + totalPurSgst + totalPurIgst);

  // Net GST Payable after ITC offset
  const netCgstPayable = Math.max(0, roundTo2(totalSalesCgst - totalPurCgst));
  const netSgstPayable = Math.max(0, roundTo2(totalSalesSgst - totalPurSgst));
  const netIgstPayable = Math.max(0, roundTo2(totalSalesIgst - totalPurIgst));
  const netTotalGstPayable = roundTo2(netCgstPayable + netSgstPayable + netIgstPayable);

  // HSN Summary aggregation
  const hsnMap: { [hsn: string]: { hsn: string; desc: string; qty: number; uqc: string; taxable: number; cgst: number; sgst: number; igst: number; total: number } } = {};
  filteredSales.forEach((s) => {
    s.items.forEach((it) => {
      const hsn = it.hsnCode || '6403';
      if (!hsnMap[hsn]) {
        hsnMap[hsn] = {
          hsn,
          desc: 'Footwear & Leather Goods',
          qty: 0,
          uqc: it.unit || 'PRS',
          taxable: 0,
          cgst: 0,
          sgst: 0,
          igst: 0,
          total: 0,
        };
      }
      hsnMap[hsn].qty += it.quantity;
      hsnMap[hsn].taxable = roundTo2(hsnMap[hsn].taxable + it.taxableAmount);
      hsnMap[hsn].cgst = roundTo2(hsnMap[hsn].cgst + it.cgstAmount);
      hsnMap[hsn].sgst = roundTo2(hsnMap[hsn].sgst + it.sgstAmount);
      hsnMap[hsn].igst = roundTo2(hsnMap[hsn].igst + it.igstAmount);
      hsnMap[hsn].total = roundTo2(hsnMap[hsn].total + it.netAmount);
    });
  });
  const hsnList = Object.values(hsnMap);

  // Selected Khata Ledger entries
  const partyLedgerEntries = selectedPartyType === 'CUSTOMER'
    ? customerLedgers.filter((l) => l.customerId === selectedPartyId && l.date >= fromDate && l.date <= toDate)
    : supplierLedgers.filter((l) => l.supplierId === selectedPartyId && l.date >= fromDate && l.date <= toDate);

  const currentPartyName = selectedPartyType === 'CUSTOMER'
    ? customers.find((c) => c.id === selectedPartyId)?.customerName || 'Customer'
    : suppliers.find((s) => s.id === selectedPartyId)?.supplierName || 'Supplier';

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Header & Date Controls */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shadow-inner">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
              <span>GST Statutory Returns & Financial Registers</span>
              <span className="text-xs font-mono bg-slate-800/60 text-slate-400 px-2 py-0.5 rounded border border-slate-700/50">
                frmGSTReports
              </span>
            </h2>
            <p className="text-xs text-slate-400">GSTR-1, GSTR-3B ITC Reconciliation & Party Khata Ledgers</p>
          </div>
        </div>

        {/* Date Filter & Print */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">From:</span>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="bg-transparent text-slate-200 font-mono focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">To:</span>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="bg-transparent text-slate-200 font-mono focus:outline-none"
            />
          </div>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 font-medium backdrop-blur-sm transition"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Module Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-700/40 pb-1 text-xs">
        <button
          onClick={() => setActiveReportTab('GSTR1')}
          className={`px-3.5 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition ${
            activeReportTab === 'GSTR1'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 border border-emerald-500/30'
              : 'bg-slate-900/40 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-slate-700/50 backdrop-blur-sm'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>GSTR-1 (Outward Supplies)</span>
        </button>

        <button
          onClick={() => setActiveReportTab('GSTR3B')}
          className={`px-3.5 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition ${
            activeReportTab === 'GSTR3B'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 border border-emerald-500/30'
              : 'bg-slate-900/40 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-slate-700/50 backdrop-blur-sm'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>GSTR-3B (Tax & ITC Offset)</span>
        </button>

        <button
          onClick={() => setActiveReportTab('SALES_REG')}
          className={`px-3.5 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition ${
            activeReportTab === 'SALES_REG'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 border border-emerald-500/30'
              : 'bg-slate-900/40 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-slate-700/50 backdrop-blur-sm'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Sales Register ({filteredSales.length})</span>
        </button>

        <button
          onClick={() => setActiveReportTab('PUR_REG')}
          className={`px-3.5 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition ${
            activeReportTab === 'PUR_REG'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 border border-emerald-500/30'
              : 'bg-slate-900/40 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-slate-700/50 backdrop-blur-sm'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Purchase Register ({filteredPurchases.length})</span>
        </button>

        <button
          onClick={() => setActiveReportTab('KHATA_LEDGER')}
          className={`px-3.5 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition ${
            activeReportTab === 'KHATA_LEDGER'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 border border-emerald-500/30'
              : 'bg-slate-900/40 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-slate-700/50 backdrop-blur-sm'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Party Khata Ledger</span>
        </button>
      </div>

      {/* TAB 1: GSTR-1 View */}
      {activeReportTab === 'GSTR1' && (
        <div className="space-y-4">
          {/* GSTR-1 Summary Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs font-mono">
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[11px]">Total Taxable Outward</span>
              <span className="text-lg font-bold text-slate-100 mt-1 block">₹{totalSalesTaxable.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[11px]">CGST Collected</span>
              <span className="text-lg font-bold text-sky-400 mt-1 block">₹{totalSalesCgst.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[11px]">SGST Collected</span>
              <span className="text-lg font-bold text-sky-400 mt-1 block">₹{totalSalesSgst.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[11px]">IGST Collected</span>
              <span className="text-lg font-bold text-amber-400 mt-1 block">₹{totalSalesIgst.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md bg-gradient-to-r from-emerald-950/60 to-slate-900/40">
              <span className="text-emerald-400 block text-[11px] font-bold">Total Invoice Value</span>
              <span className="text-xl font-black text-emerald-300 mt-1 block">₹{totalSalesGrand.toFixed(2)}</span>
            </div>
          </div>

          {/* Table 4A: B2B Invoices */}
          <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
            <h3 className="font-bold text-sm mb-3 flex items-center justify-between">
              <span>Table 4A - B2B Invoices (Registered Buyers with GSTIN)</span>
              <span className="text-xs text-slate-400 font-mono">{b2bSales.length} Invoices</span>
            </h3>
            <div className="overflow-x-auto rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
                  <tr>
                    <th className="p-2.5">GSTIN of Recipient</th>
                    <th className="p-2.5">Receiver Name</th>
                    <th className="p-2.5">Invoice No</th>
                    <th className="p-2.5">Invoice Date</th>
                    <th className="p-2.5 text-right">Invoice Value</th>
                    <th className="p-2.5 text-center">Place of Supply</th>
                    <th className="p-2.5 text-right">Taxable Value</th>
                    <th className="p-2.5 text-right">CGST</th>
                    <th className="p-2.5 text-right">SGST</th>
                    <th className="p-2.5 text-right">IGST</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {b2bSales.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 text-emerald-400 font-bold">{s.customerGstin}</td>
                      <td className="p-2.5 font-sans font-medium text-slate-200">{s.customerName}</td>
                      <td className="p-2.5 text-slate-100 font-bold">{s.invoiceNo}</td>
                      <td className="p-2.5 text-slate-300">{s.invoiceDate}</td>
                      <td className="p-2.5 text-right font-bold text-slate-100">₹{s.grandTotal.toFixed(2)}</td>
                      <td className="p-2.5 text-center">{s.customerStateCode || '27'}-MH</td>
                      <td className="p-2.5 text-right">₹{s.totalTaxable.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{s.totalCgst.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{s.totalSgst.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-amber-400">₹{s.totalIgst.toFixed(2)}</td>
                    </tr>
                  ))}
                  {b2bSales.length === 0 && (
                    <tr>
                      <td colSpan={10} className="p-4 text-center text-slate-500 font-sans">
                        No B2B invoices in this period.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 12: HSN Summary */}
          <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
            <h3 className="font-bold text-sm mb-3">Table 12 - HSN-wise Summary of Outward Supplies</h3>
            <div className="overflow-x-auto rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
                  <tr>
                    <th className="p-2.5">HSN Code</th>
                    <th className="p-2.5">Description</th>
                    <th className="p-2.5 text-center">UQC</th>
                    <th className="p-2.5 text-right">Total Qty</th>
                    <th className="p-2.5 text-right">Total Value</th>
                    <th className="p-2.5 text-right">Taxable Value</th>
                    <th className="p-2.5 text-right">Integrated Tax</th>
                    <th className="p-2.5 text-right">Central Tax</th>
                    <th className="p-2.5 text-right">State Tax</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {hsnList.map((h) => (
                    <tr key={h.hsn} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 font-bold text-amber-400">{h.hsn}</td>
                      <td className="p-2.5 font-sans text-slate-200">{h.desc}</td>
                      <td className="p-2.5 text-center">{h.uqc}</td>
                      <td className="p-2.5 text-right font-bold text-slate-100">{h.qty}</td>
                      <td className="p-2.5 text-right font-bold">₹{h.total.toFixed(2)}</td>
                      <td className="p-2.5 text-right">₹{h.taxable.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-amber-400">₹{h.igst.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{h.cgst.toFixed(2)}</td>
                      <td className="p-2.5 text-right text-sky-400">₹{h.sgst.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GSTR-3B Computation & ITC Offset */}
      {activeReportTab === 'GSTR3B' && (
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-5">
          <div className="border-b border-slate-700/40 pb-3">
            <h3 className="font-bold text-base text-slate-100">GSTR-3B Monthly Return Computation Sheet</h3>
            <p className="text-xs text-slate-400">
              Tax on Outward Supplies vs Input Tax Credit (ITC) Available from Purchase Invoices
            </p>
          </div>

          {/* Section 3.1: Details of Outward Supplies */}
          <div className="space-y-2">
            <h4 className="font-bold text-xs uppercase text-emerald-400 tracking-wider">
              3.1 Details of Outward Supplies and inward supplies liable to reverse charge
            </h4>
            <div className="overflow-x-auto rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
                  <tr>
                    <th className="p-2.5 font-sans">Nature of Supplies</th>
                    <th className="p-2.5 text-right">Total Taxable Value</th>
                    <th className="p-2.5 text-right">Integrated Tax (₹)</th>
                    <th className="p-2.5 text-right">Central Tax (₹)</th>
                    <th className="p-2.5 text-right">State/UT Tax (₹)</th>
                    <th className="p-2.5 text-right font-sans">Cess</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  <tr className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 font-sans font-medium text-slate-200">
                      (a) Outward taxable supplies (other than zero rated, nil rated and exempted)
                    </td>
                    <td className="p-2.5 text-right font-bold text-slate-100">₹{totalSalesTaxable.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-amber-400">₹{totalSalesIgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{totalSalesCgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{totalSalesSgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-slate-500">₹0.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 4: Eligible ITC */}
          <div className="space-y-2 pt-2">
            <h4 className="font-bold text-xs uppercase text-sky-400 tracking-wider">
              4. Eligible Input Tax Credit (ITC) from Inward Purchases
            </h4>
            <div className="overflow-x-auto rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
              <table className="w-full text-xs text-left border-collapse font-mono">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
                  <tr>
                    <th className="p-2.5 font-sans">Details of ITC</th>
                    <th className="p-2.5 text-right">Integrated Tax (₹)</th>
                    <th className="p-2.5 text-right">Central Tax (₹)</th>
                    <th className="p-2.5 text-right">State/UT Tax (₹)</th>
                    <th className="p-2.5 text-right">Total ITC Available</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  <tr className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 font-sans font-medium text-slate-200">
                      (A) (5) All other ITC (Inward supplies from registered suppliers)
                    </td>
                    <td className="p-2.5 text-right text-amber-400 font-bold">₹{totalPurIgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400 font-bold">₹{totalPurCgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400 font-bold">₹{totalPurSgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-emerald-400 font-black">₹{totalPurItc.toFixed(2)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 5: Net Tax Payable */}
          <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-3 backdrop-blur-xs">
            <h4 className="font-bold text-xs uppercase text-amber-400 tracking-wider">
              5. Net GST Cash Liability (After ITC Set-off)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-700/50 backdrop-blur-sm">
                <span className="text-slate-400 block text-[11px]">Net CGST to Pay</span>
                <span className="text-base font-bold text-slate-100 mt-1 block">₹{netCgstPayable.toFixed(2)}</span>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-700/50 backdrop-blur-sm">
                <span className="text-slate-400 block text-[11px]">Net SGST to Pay</span>
                <span className="text-base font-bold text-slate-100 mt-1 block">₹{netSgstPayable.toFixed(2)}</span>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-700/50 backdrop-blur-sm">
                <span className="text-slate-400 block text-[11px]">Net IGST to Pay</span>
                <span className="text-base font-bold text-slate-100 mt-1 block">₹{netIgstPayable.toFixed(2)}</span>
              </div>

              <div className="p-3 bg-gradient-to-r from-amber-950/60 to-slate-900/60 rounded-lg border border-amber-800/60 backdrop-blur-sm">
                <span className="text-amber-300 block text-[11px] font-bold">Total Net Cash Payable</span>
                <span className="text-lg font-black text-amber-400 mt-1 block">₹{netTotalGstPayable.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Sales Register */}
      {activeReportTab === 'SALES_REG' && (
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
          <div className="overflow-x-auto max-h-[550px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse font-mono">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                <tr>
                  <th className="p-2.5">Inv No</th>
                  <th className="p-2.5">Date</th>
                  <th className="p-2.5">Party Name</th>
                  <th className="p-2.5 text-center">GSTIN</th>
                  <th className="p-2.5 text-right">Taxable</th>
                  <th className="p-2.5 text-right">CGST</th>
                  <th className="p-2.5 text-right">SGST</th>
                  <th className="p-2.5 text-right">IGST</th>
                  <th className="p-2.5 text-right">Grand Total</th>
                  <th className="p-2.5 text-center">Payment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredSales.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 font-bold text-slate-100">{s.invoiceNo}</td>
                    <td className="p-2.5 text-slate-300">{s.invoiceDate}</td>
                    <td className="p-2.5 font-sans font-medium text-slate-200">{s.customerName}</td>
                    <td className="p-2.5 text-center text-[10px] text-slate-400">{s.customerGstin || 'Retail'}</td>
                    <td className="p-2.5 text-right">₹{s.totalTaxable.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{s.totalCgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{s.totalSgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-amber-400">₹{s.totalIgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-400 text-sm">₹{s.grandTotal.toFixed(2)}</td>
                    <td className="p-2.5 text-center">
                      <span className="bg-slate-800/60 px-1.5 py-0.5 rounded text-[10px] text-slate-300 border border-slate-700/50">
                        {s.paymentMode}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Purchase Register */}
      {activeReportTab === 'PUR_REG' && (
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
          <div className="overflow-x-auto max-h-[550px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse font-mono">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                <tr>
                  <th className="p-2.5">Voucher No</th>
                  <th className="p-2.5">Supplier Bill No</th>
                  <th className="p-2.5">Date</th>
                  <th className="p-2.5">Supplier Name</th>
                  <th className="p-2.5 text-center">Supplier GSTIN</th>
                  <th className="p-2.5 text-right">Taxable</th>
                  <th className="p-2.5 text-right">CGST (ITC)</th>
                  <th className="p-2.5 text-right">SGST (ITC)</th>
                  <th className="p-2.5 text-right">IGST (ITC)</th>
                  <th className="p-2.5 text-right">Total Inward</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredPurchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 font-bold text-orange-400">{p.purchaseInvoiceNo || p.purchaseNo}</td>
                    <td className="p-2.5 text-slate-200">{p.supplierBillNo}</td>
                    <td className="p-2.5 text-slate-300">{p.purchaseDate}</td>
                    <td className="p-2.5 font-sans font-medium text-slate-100">{p.supplierName}</td>
                    <td className="p-2.5 text-center text-[10px] text-slate-400">{p.supplierGstin || 'Unregistered'}</td>
                    <td className="p-2.5 text-right">₹{p.totalTaxable.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{p.totalCgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-sky-400">₹{p.totalSgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right text-amber-400">₹{p.totalIgst.toFixed(2)}</td>
                    <td className="p-2.5 text-right font-bold text-orange-300 text-sm">₹{p.grandTotal.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: Party Khata Ledger Statement */}
      {activeReportTab === 'KHATA_LEDGER' && (
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/40 pb-3">
            <div className="flex items-center gap-3">
              <select
                value={selectedPartyType}
                onChange={(e) => {
                  setSelectedPartyType(e.target.value as any);
                  if (e.target.value === 'CUSTOMER') {
                    setSelectedPartyId(customers[0]?.id || '');
                  } else {
                    setSelectedPartyId(suppliers[0]?.id || '');
                  }
                }}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-bold focus:outline-none"
              >
                <option value="CUSTOMER">Customer Ledger (Debtors)</option>
                <option value="SUPPLIER">Supplier Ledger (Creditors)</option>
              </select>

              <select
                value={selectedPartyId}
                onChange={(e) => setSelectedPartyId(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-semibold focus:outline-none min-w-[240px]"
              >
                {selectedPartyType === 'CUSTOMER'
                  ? customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.customerName} ({formatCurrency(c.currentBalance)} Dr)
                      </option>
                    ))
                  : suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.supplierName} ({formatCurrency(s.currentBalance)} Cr)
                      </option>
                    ))}
              </select>
            </div>

            <div className="text-xs text-slate-300">
              Statement for: <strong className="text-emerald-400">{currentPartyName}</strong>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse font-mono">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
                <tr>
                  <th className="p-2.5">Date</th>
                  <th className="p-2.5 font-sans">Particulars / Transaction</th>
                  <th className="p-2.5">Voucher Type</th>
                  <th className="p-2.5">Voucher Ref #</th>
                  <th className="p-2.5 text-right">Debit (Dr) (₹)</th>
                  <th className="p-2.5 text-right">Credit (Cr) (₹)</th>
                  <th className="p-2.5 text-right">Running Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {partyLedgerEntries.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 text-slate-300">{l.date}</td>
                    <td className="p-2.5 font-sans text-slate-200">{l.particulars}</td>
                    <td className="p-2.5">
                      <span className="bg-slate-800/60 px-1.5 py-0.5 rounded text-[10px] text-slate-300 font-sans border border-slate-700/50">
                        {l.voucherType}
                      </span>
                    </td>
                    <td className="p-2.5 text-slate-400">{l.voucherNo}</td>
                    <td className="p-2.5 text-right font-bold text-amber-400">
                      {l.debit > 0 ? `₹${l.debit.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-2.5 text-right font-bold text-emerald-400">
                      {l.credit > 0 ? `₹${l.credit.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-2.5 text-right font-black text-slate-100 text-sm">
                      ₹{l.balance.toFixed(2)}
                    </td>
                  </tr>
                ))}
                {partyLedgerEntries.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-slate-500 font-sans">
                      No ledger transactions found in this date range.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
