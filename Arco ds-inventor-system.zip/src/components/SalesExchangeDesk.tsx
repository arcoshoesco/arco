import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeftRight,
  Search,
  Calendar,
  Filter,
  Eye,
  FileText,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  X,
  Phone,
  User,
  IndianRupee,
  Layers,
} from 'lucide-react';
import { SalesExchangeDeskRecord, CompanyInfo } from '../types';
import { dbService } from '../services/storage';

interface SalesExchangeDeskProps {
  company: CompanyInfo;
  onNavigateToSales?: () => void;
}

type DateFilterPreset = 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'all' | 'custom';

export const SalesExchangeDesk: React.FC<SalesExchangeDeskProps> = ({ company }) => {
  const [exchangeRecords, setExchangeRecords] = useState<SalesExchangeDeskRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Date Filters
  const todayStr = new Date().toISOString().split('T')[0];
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('today');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);

  // Modal State for Viewing Detailed Comparison
  const [selectedRecord, setSelectedRecord] = useState<SalesExchangeDeskRecord | null>(null);

  // Load records from DB
  const loadRecords = () => {
    setExchangeRecords(dbService.getSalesExchangeDeskRecords());
  };

  useEffect(() => {
    loadRecords();
    return dbService.subscribe(loadRecords);
  }, []);

  const handleDatePresetChange = (preset: DateFilterPreset) => {
    setDatePreset(preset);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yStr = y.toISOString().split('T')[0];
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'last7') {
      const past = new Date();
      past.setDate(past.getDate() - 6);
      setStartDate(past.toISOString().split('T')[0]);
      setEndDate(today);
    } else if (preset === 'thisMonth') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filtered list: defaults to bills modified today
  const filteredRecords = useMemo(() => {
    return exchangeRecords.filter((rec) => {
      // Exclude same-day modified records (same-day modifications are kept strictly in Sales Register)
      if (rec.invoiceDate && rec.billModifiedDate && rec.invoiceDate === rec.billModifiedDate) {
        return false;
      }

      // Date filter based on Bill Modified Date (with fallbacks for legacy records)
      const modDate =
        rec.billModifiedDate ||
        (rec.updatedAt ? rec.updatedAt.split('T')[0] : (rec.createdAt ? rec.createdAt.split('T')[0] : rec.invoiceDate));

      if (startDate && modDate < startDate) return false;
      if (endDate && modDate > endDate) return false;

      // Text search: invoice number, customer name, mobile number
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchInvoice = rec.invoiceNo?.toLowerCase().includes(query);
        const matchCustomer = rec.customerName?.toLowerCase().includes(query);
        const matchMobile = rec.customerMobile?.toLowerCase().includes(query);
        if (!matchInvoice && !matchCustomer && !matchMobile) return false;
      }

      return true;
    });
  }, [exchangeRecords, startDate, endDate, searchQuery]);

  // Aggregate Metrics
  const totalExchanges = filteredRecords.length;
  const totalOriginalAmount = filteredRecords.reduce((sum, r) => sum + (r.originalBillAmount || 0), 0);
  const totalNewAmount = filteredRecords.reduce((sum, r) => sum + (r.newBillAmount || 0), 0);
  const totalNetAmount = filteredRecords.reduce((sum, r) => sum + (r.netAmount || 0), 0);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2,
    }).format(val || 0);
  };

  return (
    <div className="space-y-4 pb-8" id="sales-exchange-desk-container">
      {/* Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Exchanges</span>
            <div className="p-2 bg-purple-500/10 rounded-lg text-purple-400">
              <ArrowLeftRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-100 mt-2">{totalExchanges}</div>
          <span className="text-[11px] text-slate-400">Bills updated & exchanged</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Original Bill Amount</span>
            <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-100 mt-2">{formatCurrency(totalOriginalAmount)}</div>
          <span className="text-[11px] text-slate-400">Sum before revision</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">New Bill Amount</span>
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-100 mt-2">{formatCurrency(totalNewAmount)}</div>
          <span className="text-[11px] text-slate-400">Sum after revision</span>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Net Amount Diff</span>
            <div
              className={`p-2 rounded-lg ${
                totalNetAmount >= 0
                  ? 'bg-emerald-500/10 text-emerald-400'
                  : 'bg-rose-500/10 text-rose-400'
              }`}
            >
              {totalNetAmount >= 0 ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
            </div>
          </div>
          <div
            className={`text-xl font-bold mt-2 ${
              totalNetAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {totalNetAmount > 0 ? `+${formatCurrency(totalNetAmount)}` : formatCurrency(totalNetAmount)}
          </div>
          <span className="text-[11px] text-slate-400">Net difference collected / refunded</span>
        </div>
      </div>

      {/* Filter & Search Controls */}
      <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-sm space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Filter className="w-4 h-4 text-purple-400" />
            <span>Search & Filter Sales Exchanges</span>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['today', 'yesterday', 'last7', 'thisMonth', 'all'] as DateFilterPreset[]).map((p) => (
              <button
                key={p}
                id={`exchange-filter-${p}`}
                onClick={() => handleDatePresetChange(p)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  datePreset === p
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300'
                }`}
              >
                {p === 'today' && 'Today'}
                {p === 'yesterday' && 'Yesterday'}
                {p === 'last7' && 'Last 7 Days'}
                {p === 'thisMonth' && 'This Month'}
                {p === 'all' && 'All Dates'}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-center">
          {/* Search Box */}
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500" />
            <input
              id="exchange-search-input"
              type="text"
              placeholder="Search by Customer Invoice No, Customer Name, or Mobile..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-950/70 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
            />
            {searchQuery && (
              <button
                id="clear-search-btn"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Date Range Start */}
          <div className="md:col-span-3 flex items-center gap-1.5 bg-slate-950/70 border border-slate-800 rounded-xl px-3 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-[9px] uppercase tracking-wider text-slate-400">From</span>
              <input
                id="exchange-start-date"
                type="date"
                value={startDate}
                onChange={(e) => {
                  setStartDate(e.target.value);
                  setDatePreset('custom');
                }}
                className="bg-transparent text-xs text-slate-200 focus:outline-none w-full"
              />
            </div>
          </div>

          {/* Date Range End */}
          <div className="md:col-span-3 flex items-center gap-1.5 bg-slate-950/70 border border-slate-800 rounded-xl px-3 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-[9px] uppercase tracking-wider text-slate-400">To</span>
              <input
                id="exchange-end-date"
                type="date"
                value={endDate}
                onChange={(e) => {
                  setEndDate(e.target.value);
                  setDatePreset('custom');
                }}
                className="bg-transparent text-xs text-slate-200 focus:outline-none w-full"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Sales Exchange Desk Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden backdrop-blur-md shadow-xl">
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-bold text-slate-100">Sales Exchange Register</span>
            <span className="text-xs bg-purple-500/10 border border-purple-500/30 text-purple-300 px-2 py-0.5 rounded-full font-mono">
              {filteredRecords.length} {filteredRecords.length === 1 ? 'Record' : 'Records'}
            </span>
          </div>
          <button
            id="exchange-refresh-btn"
            onClick={loadRecords}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 px-2.5 py-1 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="p-12 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-3">
              <ArrowLeftRight className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-200">No Sales Exchange Records</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md">
              Sales Exchange records will automatically appear here when an existing bill is edited and updated through the Sales Register tab.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-4 font-semibold">#</th>
                  <th className="py-3 px-4 font-semibold">Customer Invoice Number</th>
                  <th className="py-3 px-4 font-semibold">Invoice Date</th>
                  <th className="py-3 px-4 font-semibold text-purple-300">Bill Modified Date</th>
                  <th className="py-3 px-4 font-semibold">Customer Name</th>
                  <th className="py-3 px-4 font-semibold">Customer Mobile number</th>
                  <th className="py-3 px-4 font-semibold text-right">Original Bill Amount</th>
                  <th className="py-3 px-4 font-semibold text-right">New Bill Amount</th>
                  <th className="py-3 px-4 font-semibold text-right">Net Amount</th>
                  <th className="py-3 px-4 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredRecords.map((rec, index) => {
                  const netDiff = rec.netAmount;
                  const isPositive = netDiff > 0;
                  const isNegative = netDiff < 0;

                  return (
                    <tr
                      key={rec.id || index}
                      id={`exchange-row-${rec.id || index}`}
                      className="hover:bg-slate-800/30 transition-colors group cursor-pointer"
                      onClick={() => setSelectedRecord(rec)}
                    >
                      <td className="py-3 px-4 text-slate-400 font-mono">{index + 1}</td>
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-purple-300 bg-purple-950/40 border border-purple-800/40 px-2 py-0.5 rounded">
                          {rec.invoiceNo}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                        {rec.invoiceDate}
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-purple-300 whitespace-nowrap">
                        {rec.billModifiedDate ||
                          (rec.updatedAt
                            ? rec.updatedAt.split('T')[0]
                            : rec.createdAt
                            ? rec.createdAt.split('T')[0]
                            : rec.invoiceDate)}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-100 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>{rec.customerName || 'Walk-in Customer'}</span>
                      </td>
                      <td className="py-3 px-4 text-slate-300 font-mono">
                        {rec.customerMobile ? (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400 flex-shrink-0" />
                            {rec.customerMobile}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-300">
                        {formatCurrency(rec.originalBillAmount)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                        {formatCurrency(rec.newBillAmount)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono">
                        <span
                          className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded font-bold ${
                            isPositive
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : isNegative
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              : 'bg-slate-800 text-slate-300 border border-slate-700'
                          }`}
                        >
                          {isPositive && '+'}
                          {formatCurrency(netDiff)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          id={`view-exchange-detail-${rec.id || index}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedRecord(rec);
                          }}
                          className="p-1.5 bg-slate-800 hover:bg-purple-600 hover:text-white rounded-lg text-slate-400 transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Exchange Detail Comparison Modal */}
      {selectedRecord && (
        <div
          id="exchange-detail-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn"
          onClick={() => setSelectedRecord(null)}
        >
          <div
            className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-purple-500/10 border border-purple-500/30 rounded-xl text-purple-400">
                  <ArrowLeftRight className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                    <span>Invoice #{selectedRecord.invoiceNo}</span>
                    <span className="text-xs font-mono font-normal bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded">
                      Exchange Record
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Updated on {new Date(selectedRecord.createdAt || selectedRecord.updatedAt).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
              <button
                id="close-exchange-modal-btn"
                onClick={() => setSelectedRecord(null)}
                className="p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800/80 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
              {/* Customer Info Box */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Customer Name</span>
                  <span className="font-semibold text-slate-200 mt-0.5 block">
                    {selectedRecord.customerName || 'Walk-in Customer'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Mobile Number</span>
                  <span className="font-semibold text-slate-200 mt-0.5 block font-mono">
                    {selectedRecord.customerMobile || 'N/A'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Invoice Date</span>
                  <span className="font-semibold text-slate-200 mt-0.5 block font-mono">
                    {selectedRecord.invoiceDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px] text-purple-300">Bill Modified Date</span>
                  <span className="font-semibold text-purple-300 mt-0.5 block font-mono">
                    {selectedRecord.billModifiedDate ||
                      (selectedRecord.updatedAt
                        ? selectedRecord.updatedAt.split('T')[0]
                        : selectedRecord.createdAt
                        ? selectedRecord.createdAt.split('T')[0]
                        : selectedRecord.invoiceDate)}
                  </span>
                </div>
              </div>

              {/* Financial Breakdown Comparison */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3 text-center">
                  <span className="text-[11px] text-slate-400 block">Original Bill Amount</span>
                  <span className="text-base font-bold text-slate-300 mt-1 block font-mono">
                    {formatCurrency(selectedRecord.originalBillAmount)}
                  </span>
                </div>
                <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3 text-center">
                  <span className="text-[11px] text-slate-400 block">New Bill Amount</span>
                  <span className="text-base font-bold text-slate-100 mt-1 block font-mono">
                    {formatCurrency(selectedRecord.newBillAmount)}
                  </span>
                </div>
                <div
                  className={`border rounded-xl p-3 text-center ${
                    selectedRecord.netAmount >= 0
                      ? 'bg-emerald-950/20 border-emerald-800/40'
                      : 'bg-rose-950/20 border-rose-800/40'
                  }`}
                >
                  <span className="text-[11px] text-slate-400 block">Net Amount</span>
                  <span
                    className={`text-base font-bold mt-1 block font-mono ${
                      selectedRecord.netAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {selectedRecord.netAmount > 0 && '+'}
                    {formatCurrency(selectedRecord.netAmount)}
                  </span>
                </div>
              </div>

              {/* Updated Line Items (if saved) */}
              {selectedRecord.itemsAfter && selectedRecord.itemsAfter.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                    <Layers className="w-3.5 h-3.5 text-purple-400" />
                    <span>Revised Bill Items ({selectedRecord.itemsAfter.length})</span>
                  </div>
                  <div className="border border-slate-800 rounded-xl overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="bg-slate-950 border-b border-slate-800 text-[10px] uppercase tracking-wider text-slate-400">
                          <th className="py-2 px-3">Item</th>
                          <th className="py-2 px-3 text-center">Qty</th>
                          <th className="py-2 px-3 text-right">Rate</th>
                          <th className="py-2 px-3 text-right">Amount</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {selectedRecord.itemsAfter.map((it, idx) => (
                          <tr key={idx} className="hover:bg-slate-800/20">
                            <td className="py-2 px-3 text-slate-200">
                              <span className="font-medium">{it.itemName}</span>
                              {it.itemCode && (
                                <span className="text-[10px] text-slate-400 block font-mono">
                                  {it.itemCode}
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-center font-mono text-slate-300">
                              {it.quantity} {it.unit || ''}
                            </td>
                            <td className="py-2 px-3 text-right font-mono text-slate-400">
                              {formatCurrency(it.rate)}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-semibold text-slate-200">
                              {formatCurrency(it.netAmount)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {selectedRecord.remarks && (
                <div className="text-xs bg-slate-950/50 border border-slate-800/60 rounded-xl p-3 text-slate-400">
                  <span className="font-semibold text-slate-300 block mb-0.5">Remarks / Reason:</span>
                  {selectedRecord.remarks}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
              <button
                id="close-exchange-detail-btn"
                onClick={() => setSelectedRecord(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
