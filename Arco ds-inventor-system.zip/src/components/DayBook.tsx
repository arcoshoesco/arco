import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Search, 
  FileText, 
  ShoppingCart, 
  ArrowDownLeft, 
  ArrowUpRight, 
  RotateCcw,
  BookOpen,
  Download,
  Printer,
  X,
  Filter,
  ArrowLeftRight
} from 'lucide-react';
import { dbService } from '../services/storage';
import { SalesExchangeDeskRecord } from '../types';

export const DayBookComponent: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [filterType, setFilterType] = useState<string>('SALE');
  const [entries, setEntries] = useState<any[]>([]);
  const [exchangeDeskEntries, setExchangeDeskEntries] = useState<SalesExchangeDeskRecord[]>([]);

  useEffect(() => {
    const loadDayEntries = () => {
      const targetDate = selectedDate;
      const allSales = dbService.getSales();
      const allPurchases = dbService.getPurchases();
      const allSalesReturns = dbService.getSalesReturns();
      const allSalesExchanges = dbService.getSalesExchanges();
      const allSalesExchangeDesk = dbService.getSalesExchangeDeskRecords();
      const allPurchaseReturns = dbService.getPurchaseReturns();
      const allReceipts = dbService.getReceipts();
      const allPayments = dbService.getPayments();

      const dayList: any[] = [];

      // Filter exchange desk records for selected day (exclude same-day modifications)
      const dayDeskList = allSalesExchangeDesk.filter(ed => 
        (ed.billModifiedDate === targetDate || ed.invoiceDate === targetDate || (ed.createdAt && ed.createdAt.startsWith(targetDate))) &&
        !(ed.invoiceDate && ed.billModifiedDate && ed.invoiceDate === ed.billModifiedDate)
      );
      setExchangeDeskEntries(dayDeskList);

      // Filter each list by matching date string
      allSales.forEach(s => {
        if (s.invoiceDate === targetDate) {
          dayList.push({
            id: s.id,
            time: s.createdAt ? new Date(s.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
            voucherNo: s.invoiceNo,
            voucherType: 'Sale Bill',
            particulars: s.customerName,
            paymentMode: s.paymentMode,
            amount: s.grandTotal,
            rawType: 'SALE',
            color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
          });
        }
      });

      // Sales Exchange Desk Records
      dayDeskList.forEach(ed => {
        dayList.push({
          id: ed.id,
          time: ed.createdAt ? new Date(ed.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
          voucherNo: ed.invoiceNo,
          voucherType: 'Exchange Desk',
          particulars: `${ed.customerName || 'Customer'} (Orig: ₹${ed.originalBillAmount} → New: ₹${ed.newBillAmount})`,
          paymentMode: ed.netAmount >= 0 ? `Net Diff (+₹${ed.netAmount})` : `Net Diff (-₹${Math.abs(ed.netAmount)})`,
          amount: ed.netAmount,
          rawType: 'SALES_EXCHANGE_DESK',
          color: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
        });
      });

      allPurchases.forEach(p => {
        if (p.purchaseDate === targetDate) {
          dayList.push({
            id: p.id,
            time: p.createdAt ? new Date(p.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
            voucherNo: p.supplierBillNo || p.purchaseNo,
            voucherType: 'Purchase Inward',
            particulars: p.supplierName,
            paymentMode: p.paymentMode,
            amount: p.grandTotal,
            rawType: 'PURCHASE',
            color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20'
          });
        }
      });

      allSalesReturns.forEach(sr => {
        if (sr.returnDate === targetDate) {
          dayList.push({
            id: sr.id,
            time: sr.returnTime || (sr.createdAt ? new Date(sr.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A'),
            voucherNo: sr.returnNo,
            voucherType: 'Sales Return',
            particulars: `${sr.customerName} (Ref: ${sr.originalInvoiceNo})`,
            paymentMode: sr.refundMode,
            amount: sr.grandTotal,
            rawType: 'SALES_RETURN',
            color: 'text-blue-400 bg-blue-500/10 border-blue-500/20'
          });
        }
      });

      allSalesExchanges.forEach(exc => {
        if (exc.exchangeDate === targetDate) {
          dayList.push({
            id: exc.id,
            time: exc.exchangeTime || (exc.createdAt ? new Date(exc.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A'),
            voucherNo: exc.exchangeNo,
            voucherType: 'Sales Exchange',
            particulars: `${exc.customerName} (Ref: ${exc.originalInvoiceNo})`,
            paymentMode: exc.settlementType === 'CUSTOMER_PAID' ? `Paid (${exc.paymentMethod || 'Cash'})` : exc.settlementType === 'STORE_CREDIT_ISSUED' ? 'Credit Note' : exc.settlementType === 'REFUND_PAID' ? 'Refund' : 'Even',
            amount: exc.newTotalValue,
            rawType: 'SALES_EXCHANGE',
            color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20'
          });
        }
      });

      allPurchaseReturns.forEach(pr => {
        if (pr.returnDate === targetDate) {
          dayList.push({
            id: pr.id,
            time: pr.createdAt ? new Date(pr.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
            voucherNo: pr.returnNo,
            voucherType: 'Purchase Return',
            particulars: pr.supplierName,
            paymentMode: pr.refundMode,
            amount: pr.grandTotal,
            rawType: 'PURCHASE_RETURN',
            color: 'text-violet-400 bg-violet-500/10 border-violet-500/20'
          });
        }
      });

      allReceipts.forEach(r => {
        if (r.receiptDate === targetDate) {
          dayList.push({
            id: r.id,
            time: r.createdAt ? new Date(r.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
            voucherNo: r.receiptNo,
            voucherType: 'Receipt voucher',
            particulars: r.customerName,
            paymentMode: r.paymentMode,
            amount: r.amountReceived,
            rawType: 'RECEIPT',
            color: 'text-teal-400 bg-teal-500/10 border-teal-500/20'
          });
        }
      });

      allPayments.forEach(py => {
        if (py.voucherDate === targetDate) {
          dayList.push({
            id: py.id,
            time: py.createdAt ? new Date(py.createdAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'N/A',
            voucherNo: py.voucherNo,
            voucherType: 'Payment Voucher',
            particulars: py.supplierName,
            paymentMode: py.paymentMode,
            amount: py.amountPaid,
            rawType: 'PAYMENT',
            color: 'text-rose-400 bg-rose-500/10 border-rose-500/20'
          });
        }
      });

      // Sort by chronological time
      dayList.sort((a, b) => a.time.localeCompare(b.time));
      setEntries(dayList);
    };

    loadDayEntries();
    return dbService.subscribe(loadDayEntries);
  }, [selectedDate]);

  // Compute filtered items
  const filteredEntries = entries.filter(e => {
    if (filterType === 'ALL') return true;
    return e.rawType === filterType;
  });

  // Calculate day totals
  const salesEntries = entries.filter(e => e.rawType === 'SALE');
  const totalSales = salesEntries.reduce((sum, e) => sum + e.amount, 0);
  const cashSales = salesEntries
    .filter(e => (e.paymentMode || '').toUpperCase().includes('CASH'))
    .reduce((sum, e) => sum + e.amount, 0);
  const creditSales = salesEntries
    .filter(e => (e.paymentMode || '').toUpperCase().includes('CREDIT'))
    .reduce((sum, e) => sum + e.amount, 0);

  // Total Sales Exchange Net Amount
  const totalSalesExchangeAmount = exchangeDeskEntries.reduce((sum, ed) => sum + (Number(ed.netAmount) || 0), 0);

  // Net Day Collection = Today Day Sales + Total Sales Exchange Amount
  const netDayCollection = totalSales + totalSalesExchangeAmount;

  const totalPurchases = entries.filter(e => e.rawType === 'PURCHASE').reduce((sum, e) => sum + e.amount, 0);
  const totalReceipts = entries.filter(e => e.rawType === 'RECEIPT').reduce((sum, e) => sum + e.amount, 0);
  const totalPayments = entries.filter(e => e.rawType === 'PAYMENT').reduce((sum, e) => sum + e.amount, 0);

  // Total Credit amount for filtered list
  const filteredCreditTotal = filteredEntries
    .filter(e => (e.paymentMode || '').toUpperCase().includes('CREDIT'))
    .reduce((sum, e) => sum + e.amount, 0);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">Day Book Register</h2>
            <p className="text-xs text-slate-400 mt-0.5">Chronological log of operational vouchers, bills, inward receipts and payments.</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Date Picker */}
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs text-slate-300">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input 
              type="date" 
              value={selectedDate} 
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-slate-200 focus:outline-none cursor-pointer font-bold"
            />
          </div>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold border border-slate-700 rounded-xl transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Ledger
          </button>
        </div>
      </div>

      {/* Grid Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Card 1: Total Cash/Bank Receipts */}
        <div className="bg-slate-950/40 border border-slate-850 p-3.5 rounded-xl" id="card-total-receipts">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Cash/Bank Receipts</div>
          <div className="text-lg font-black text-teal-400 mt-1">₹{totalReceipts.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
        </div>

        {/* Card 2: Total Party Payments */}
        <div className="bg-slate-950/40 border border-slate-850 p-3.5 rounded-xl" id="card-total-payments">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Party Payments</div>
          <div className="text-lg font-black text-rose-400 mt-1">₹{totalPayments.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
        </div>

        {/* Card 3: Total Day Purchases */}
        <div className="bg-slate-950/40 border border-slate-850 p-3.5 rounded-xl" id="card-total-purchases">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Day Purchases</div>
          <div className="text-lg font-black text-indigo-400 mt-1">₹{totalPurchases.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
        </div>

        {/* Card 4: TODAY DAY SALES */}
        <div className="bg-slate-950/40 border border-slate-850 p-3.5 rounded-xl space-y-1.5" id="card-today-day-sales">
          <div className="flex items-center justify-between">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Today Day Sales</div>
            <div className="text-base font-black text-emerald-400">
              ₹{totalSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/60">
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Cash Sales</span>
              <span className="font-extrabold text-emerald-300 font-mono text-xs">
                ₹{cashSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Credit Sales</span>
              <span className="font-extrabold text-amber-300 font-mono text-xs">
                ₹{creditSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        {/* Card 5: TOTAL SALES EXCHANGE AMOUNT */}
        <div className="bg-slate-950/40 border border-slate-850 p-3.5 rounded-xl space-y-1.5" id="card-total-sales-exchange-amount">
          <div className="flex items-center justify-between">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Sales Exchange Amount</div>
            <div className={`text-base font-black ${totalSalesExchangeAmount >= 0 ? 'text-purple-400' : 'text-rose-400'}`}>
              ₹{totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/60">
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Exchanges</span>
              <span className="font-extrabold text-purple-300 font-mono text-xs">
                {exchangeDeskEntries.length} {exchangeDeskEntries.length === 1 ? 'Record' : 'Records'}
              </span>
            </div>
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Net Diff</span>
              <span className={`font-extrabold font-mono text-xs ${totalSalesExchangeAmount >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                {totalSalesExchangeAmount > 0 ? `+₹${totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : `₹${totalSalesExchangeAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`}
              </span>
            </div>
          </div>
        </div>

        {/* Card 6: NET DAY COLLECTION */}
        <div className="bg-slate-950/40 border border-amber-500/30 p-3.5 rounded-xl space-y-1.5 shadow-sm" id="card-net-day-collection">
          <div className="flex items-center justify-between">
            <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">Net Day Collection</div>
            <div className="text-base font-black text-amber-300">
              ₹{netDayCollection.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/60">
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Sales + Exch</span>
              <span className="font-bold text-slate-200 font-mono text-[11px] truncate block" title={`₹${totalSales.toFixed(2)} + ₹${totalSalesExchangeAmount.toFixed(2)}`}>
                ₹{netDayCollection.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </span>
            </div>
            <div className="bg-slate-900/80 px-2 py-1 rounded border border-slate-800/80">
              <span className="text-[9px] text-slate-400 uppercase font-bold block">Status</span>
              <span className="font-extrabold text-amber-300 font-mono text-xs">
                Active
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-slate-900/30 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-bold text-slate-300">Filter Voucher Classes:</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {['ALL', 'SALE', 'SALES_EXCHANGE_DESK', 'SALES_EXCHANGE', 'SALES_RETURN', 'PURCHASE', 'PURCHASE_RETURN', 'RECEIPT', 'PAYMENT'].map((type) => (
              <button
                key={type}
                id={`daybook-filter-${type.toLowerCase()}`}
                onClick={() => setFilterType(type)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                  filterType === type
                    ? 'bg-amber-500/25 text-amber-300 border-amber-500/40 shadow-inner'
                    : 'text-slate-400 bg-transparent border-transparent hover:bg-slate-800/30'
                }`}
              >
                {type === 'SALES_EXCHANGE_DESK' ? 'EXCHANGE DESK' : type.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Entries Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <th className="py-3 px-3 w-20">Time</th>
                <th className="py-3 px-3">Voucher Class</th>
                <th className="py-3 px-3">Voucher No</th>
                <th className="py-3 px-3">Ledger / Particulars</th>
                <th className="py-3 px-3 w-28">Method</th>
                <th className="py-3 px-3 text-right w-36">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-500 font-medium">
                    No transactions recorded on {new Date(selectedDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })} matching the selected filter.
                  </td>
                </tr>
              ) : (
                filteredEntries.map((e, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/20 transition-colors">
                    <td className="py-3.5 px-3 font-mono font-bold text-slate-400">{e.time}</td>
                    <td className="py-3.5 px-3">
                      <span className={`px-2.5 py-1 rounded-full text-[9px] font-bold uppercase border tracking-wider ${e.color}`}>
                        {e.voucherType}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 font-mono font-bold text-slate-200">{e.voucherNo}</td>
                    <td className="py-3.5 px-3 font-bold text-slate-300">{e.particulars}</td>
                    <td className="py-3.5 px-3">
                      <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-400 font-bold uppercase">
                        {e.paymentMode || 'N/A'}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right font-black text-slate-100 text-sm">
                      ₹{e.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredEntries.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-slate-700 bg-slate-950/50 font-black text-slate-200">
                  <td colSpan={4} className="py-3.5 px-3 text-right text-xs uppercase tracking-wider text-slate-400 font-bold">
                    Filtered Book Total ({filteredEntries.length} entries):
                  </td>
                  <td className="py-3.5 px-3">
                    <div className="text-[11px] bg-amber-950/40 border border-amber-500/40 text-amber-300 px-2 py-1 rounded-md flex flex-col font-mono font-bold">
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 font-sans font-semibold">Total Credit:</span>
                      <span>₹{filteredCreditTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3 text-right text-base text-amber-400 font-black">
                    ₹{filteredEntries.reduce((sum, e) => sum + e.amount, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
