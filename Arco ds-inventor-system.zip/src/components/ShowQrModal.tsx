import React, { useState, useEffect } from 'react';
import { QrCode, X, Copy, Check, Printer, Building2, CreditCard, ShieldCheck, AlertCircle } from 'lucide-react';
import QRCode from 'qrcode';
import { CompanyInfo, QrCodeOption } from '../types';

interface ShowQrModalProps {
  company: CompanyInfo;
  amount?: number;
  onClose: () => void;
}

export const ShowQrModal: React.FC<ShowQrModalProps> = ({ company, amount, onClose }) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Find active QR option
  const activeQrTitle = company.activeQrTitle || 'GPay / PhonePe UPI';
  const qrCodes = company.qrCodes || [];
  const activeQr = qrCodes.find((q) => q.title === activeQrTitle) || qrCodes[0] || {
    id: 'default',
    title: activeQrTitle,
    upiId: '',
    qrDataUrl: '',
  };

  // Strictly use UPI Address saved in Settings page (company.upiAddress or company.upiId), fallback to activeQr.upiId
  const upiToDisplay = (company.upiAddress || company.upiId || activeQr.upiId || '').trim();

  useEffect(() => {
    // If there is no amount specified and a custom static QR image is uploaded, use it.
    if (!amount && activeQr.qrDataUrl) {
      setQrDataUrl(activeQr.qrDataUrl);
      return;
    }

    if (upiToDisplay) {
      const businessName = (company.companyName || 'ARCO SHOES').trim();
      let upiUrl = `upi://pay?pa=${encodeURIComponent(upiToDisplay)}&pn=${encodeURIComponent(businessName)}&cu=INR`;
      if (amount && amount > 0) {
        upiUrl += `&am=${amount.toFixed(2)}`;
      }
      QRCode.toDataURL(upiUrl, { margin: 1, width: 280, errorCorrectionLevel: 'M' })
        .then((url) => setQrDataUrl(url))
        .catch(() => setQrDataUrl(''));
    } else {
      setQrDataUrl('');
    }
  }, [activeQr, company, upiToDisplay, amount]);

  const handleCopyUpi = () => {
    if (upiToDisplay) {
      navigator.clipboard.writeText(upiToDisplay);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePrintQr = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-md animate-fade-in select-none">
      <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-sm w-full shadow-2xl overflow-hidden text-slate-100 font-sans">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 px-3.5 py-2.5 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shadow-inner">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-1.5 leading-tight">
                <span>{activeQr.title}</span>
              </h3>
              <p className="text-[10px] text-amber-300 font-mono leading-tight">
                {company.companyName || 'ARCO SHOES CO.'} Store Counter QR
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-3.5 space-y-2.5 text-center">
          {/* QR Code Canvas / Image Display */}
          <div className="inline-block p-2 bg-white rounded-xl shadow-lg border-2 border-amber-400/40 mx-auto">
            {!upiToDisplay ? (
              <div className="w-44 h-44 bg-amber-50 rounded-lg border border-amber-300 p-3 flex flex-col items-center justify-center text-center">
                <AlertCircle className="w-6 h-6 text-amber-600 mb-1 animate-bounce" />
                <p className="text-[11px] font-bold text-amber-900 leading-tight">
                  Please configure UPI Address in Settings to enable payments.
                </p>
              </div>
            ) : qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={activeQr.title}
                className="w-44 h-44 object-contain rounded-md"
              />
            ) : (
              <div className="w-44 h-44 bg-slate-100 flex items-center justify-center text-slate-400 font-mono text-xs">
                Generating QR...
              </div>
            )}
            <div className="mt-1 text-center">
              {amount && amount > 0 && (
                <div className="bg-blue-50 text-blue-900 px-2 py-1 rounded-md border border-blue-200 mb-1 flex items-center justify-between gap-2">
                  <span className="text-[9px] uppercase font-bold text-blue-600 tracking-wider">Amount to Pay</span>
                  <span className="text-base font-black font-mono text-blue-900">₹{amount.toFixed(2)}</span>
                </div>
              )}
              <span className="text-[10px] font-extrabold text-slate-900 block font-mono uppercase tracking-wider">
                SCAN & PAY VIA {activeQr.title}
              </span>
            </div>
          </div>

          {/* UPI ID Copy Box */}
          <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between gap-2">
            <div className="text-left">
              <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block">
                Official UPI ID
              </span>
              <span className="font-mono font-bold text-xs text-amber-400 select-all">
                {upiToDisplay || 'Not Configured (Go to Settings)'}
              </span>
            </div>
            <button
              onClick={handleCopyUpi}
              disabled={!upiToDisplay}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 transition ${
                !upiToDisplay
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : copied
                  ? 'bg-emerald-600 text-white border border-emerald-500'
                  : 'bg-amber-600 hover:bg-amber-500 text-white border border-amber-500/40'
              }`}
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>

          {/* Store Bank Details */}
          <div className="p-2 bg-slate-950/60 rounded-lg border border-slate-800/80 text-left space-y-0.5 text-[11px]">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold border-b border-slate-800/80 pb-0.5 mb-1 text-[10px]">
              <Building2 className="w-3 h-3 text-amber-400" />
              <span>Direct Bank Account Details</span>
            </div>
            <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[10px] text-slate-400">
              <div>Bank: <strong className="text-slate-200">{company.bankName || 'SBI'}</strong></div>
              <div>A/C: <strong className="text-slate-200 font-mono">{company.bankAccountNo || '309876543210'}</strong></div>
              <div>IFSC: <strong className="text-slate-200 font-mono">{company.bankIfsc || 'SBIN0000300'}</strong></div>
              <div>Branch: <strong className="text-slate-200">{company.bankBranch || 'Fort Branch'}</strong></div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-1 text-[10px] text-slate-400 pt-0.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Encrypted GST Compliant Payment Terminal</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-3 py-2 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-2">
          <button
            onClick={handlePrintQr}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-md text-[11px] border border-slate-700 transition"
          >
            <Printer className="w-3 h-3 text-amber-400" />
            <span>Print QR</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
