import React, { useState, useEffect } from 'react';
import { Printer, X, Download, FileText, CheckCircle2 } from 'lucide-react';
import QRCode from 'qrcode';
import { CompanyInfo, SalesInvoice } from '../types';
import { formatCurrency, numberToWords, roundTo2 } from '../services/gstCalculations';
import arcoPosLogo from '../assets/images/arco_pos_logo.png';

interface InvoicePrintModalProps {
  invoice: SalesInvoice;
  company: CompanyInfo;
  autoPrint?: boolean;
  onClose: () => void;
  isTabMode?: boolean;
  onAttachToNav?: () => void;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  invoice,
  company,
  autoPrint,
  onClose,
  isTabMode = false,
  onAttachToNav,
}) => {
  const [printCopyType, setPrintCopyType] = useState<string>('ORIGINAL FOR RECIPIENT');
  const [printFormat, setPrintFormat] = useState<'A4' | 'Thermal80' | 'Thermal70'>('Thermal70');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const upiAddress = (company.upiAddress || company.upiId || '').trim();

  useEffect(() => {
    if (upiAddress) {
      const businessName = (company.companyName || '').trim();
      const amountStr = invoice.grandTotal.toFixed(2);
      const invoiceNoStr = (invoice.invoiceNo || '').trim();

      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiAddress)}&pn=${encodeURIComponent(businessName)}&am=${amountStr}&cu=INR&tn=${encodeURIComponent(invoiceNoStr)}`;

      QRCode.toDataURL(upiUrl, { margin: 1, width: 220, errorCorrectionLevel: 'M' })
        .then((url) => setQrDataUrl(url))
        .catch((err) => {
          console.error('Failed to generate UPI QR code:', err);
          setQrDataUrl('');
        });
    } else {
      setQrDataUrl('');
    }
  }, [company, invoice, upiAddress]);

  // Handle auto-print or Ctrl+P key listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handlePrint();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    let timer: any = null;
    if (autoPrint) {
      timer = setTimeout(() => {
        handlePrint();
      }, 400);
    }

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (timer) clearTimeout(timer);
    };
  }, [autoPrint, printFormat, printCopyType, qrDataUrl]);

  const handlePrint = () => {
    const printableEl = document.getElementById('printable-invoice-content');
    if (!printableEl) {
      window.print();
      return;
    }

    try {
      // Remove any existing print iframe
      const oldFrame = document.getElementById('tax-invoice-print-frame');
      if (oldFrame) {
        oldFrame.remove();
      }

      // Create a clean hidden iframe
      const iframe = document.createElement('iframe');
      iframe.id = 'tax-invoice-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0px';
      iframe.style.height = '0px';
      iframe.style.border = 'none';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!doc) {
        window.print();
        return;
      }

      // Extract all head styles / CSS links
      const headLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
        .map((el) => el.outerHTML)
        .join('\n');

      const widthCss =
        printFormat === 'Thermal70'
          ? `@page { size: 70mm auto; margin: 2mm 0mm 0mm 0mm; }
             html, body {
               width: 70mm !important;
               max-width: 70mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding: 2mm 0 0 0 !important;
               overflow-x: hidden !important;
               text-align: left !important;
               font-family: monospace, 'Courier New', Courier, monospace !important;
               font-weight: 700 !important;
               font-size: 13px !important;
               background: #ffffff !important;
               color: #000000 !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
             }
             * {
               box-sizing: border-box !important;
             }
             .print-container,
             .thermal-70mm-slip,
             #thermal-70mm-print-slip,
             .thermal-75mm-slip,
             #thermal-75mm-print-slip {
               width: 70mm !important;
               max-width: 70mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding-top: 2mm !important;
               padding-right: 0mm !important;
               padding-bottom: 0 !important;
               padding-left: 0 !important;
               overflow: hidden !important;
               box-sizing: border-box !important;
               border: none !important;
               box-shadow: none !important;
               background-color: #ffffff !important;
               color: #000000 !important;
             }
             .thermal-70mm-slip,
             .thermal-70mm-slip * {
               background-color: #ffffff !important;
               color: #000000 !important;
               font-weight: 700 !important;
             }
             div, table, tr, td, th, p, span {
               box-sizing: border-box !important;
               max-width: 100% !important;
             }
             table {
               width: 100% !important;
               max-width: 100% !important;
               table-layout: fixed !important;
               border-collapse: collapse !important;
               margin: 4px 0 !important;
             }
             td, th {
               box-sizing: border-box !important;
               overflow-wrap: break-word !important;
               word-break: break-word !important;
             }`
          : printFormat === 'Thermal80'
          ? `@page { size: 80mm auto; margin: 2mm 0mm 0mm 0mm; }
             html, body {
               width: 80mm !important;
               max-width: 80mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding: 2mm 0 0 0 !important;
               overflow-x: hidden !important;
               text-align: left !important;
               font-family: monospace, 'Courier New', Courier, monospace !important;
               font-weight: 700 !important;
               font-size: 13px !important;
               background: #ffffff !important;
               color: #000000 !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
             }
             * {
               box-sizing: border-box !important;
             }
             .print-container,
             .thermal-80mm-slip,
             #thermal-80mm-print-slip {
               width: 80mm !important;
               max-width: 80mm !important;
               margin: 0 !important;
               margin-top: 2mm !important;
               margin-right: 0mm !important;
               padding-top: 2mm !important;
               padding-right: 0mm !important;
               padding-bottom: 0 !important;
               padding-left: 0 !important;
               overflow: hidden !important;
               box-sizing: border-box !important;
               border: none !important;
               box-shadow: none !important;
             }
             div, table, tr, td, th, p, span {
               box-sizing: border-box !important;
               max-width: 100% !important;
             }
             table {
               width: 100% !important;
               max-width: 100% !important;
               table-layout: fixed !important;
               border-collapse: collapse !important;
               margin: 4px 0 !important;
             }
             td, th {
               box-sizing: border-box !important;
               overflow-wrap: break-word !important;
               word-break: break-word !important;
             }`
          : '@page { size: A4 portrait; margin: 6mm; } body { width: 100%; margin: 0; padding: 0; font-family: sans-serif; }';

      const htmlContent = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <title>Tax Invoice - ${invoice.invoiceNo}</title>
            ${headLinks}
            <style>
              ${widthCss}
              * {
                box-sizing: border-box;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              body {
                background: #ffffff !important;
                color: #000000 !important;
                visibility: visible !important;
              }
              .no-print, .print\\:hidden {
                display: none !important;
              }
            </style>
          </head>
          <body>
            ${printableEl.innerHTML}
          </body>
        </html>
      `;

      doc.open();
      doc.write(htmlContent);
      doc.close();

      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch (err) {
          console.error('Iframe print error, falling back to window.print():', err);
          window.print();
        }
      }, 300);
    } catch (e) {
      console.error('Print trigger error:', e);
      window.print();
    }
  };

  const amountInWords = numberToWords(invoice.grandTotal);

  const containerClass = isTabMode
    ? 'w-full max-w-5xl mx-auto flex flex-col my-2 bg-slate-900/95 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl overflow-hidden print:border-none print:shadow-none print:max-w-none print:w-full print:bg-white print:rounded-none'
    : 'bg-slate-900/95 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden print:border-none print:shadow-none print:max-h-none print:max-w-none print:w-full print:bg-white print:rounded-none';

  const content = (
    <div className={containerClass}>
      {/* Action Header - Hidden on print */}
      <div className="p-3 bg-slate-950/80 text-white flex items-center justify-between gap-3 border-b border-slate-700/50 print:hidden backdrop-blur-sm no-print">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shadow-inner">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-sm sm:text-base text-slate-100 flex items-center gap-2">
              <span>Tax Invoice Preview: {invoice.invoiceNo}</span>
              {isTabMode && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2 py-0.5 rounded border border-emerald-500/30">
                  Attached to Nav Bar
                </span>
              )}
            </span>
          </div>
        </div>

          <div className="flex items-center gap-2 text-xs">
            <select
              value={printCopyType}
              onChange={(e) => setPrintCopyType(e.target.value)}
              className="bg-slate-900/90 text-slate-200 border border-slate-700/60 rounded-lg px-2 py-1.5 focus:outline-none focus:border-emerald-500"
            >
              <option value="ORIGINAL FOR RECIPIENT">Original for Recipient</option>
              <option value="DUPLICATE FOR TRANSPORTER">Duplicate for Transporter</option>
              <option value="TRIPLICATE FOR SUPPLIER">Triplicate for Supplier</option>
            </select>

            <div className="flex items-center bg-slate-900/80 rounded-lg p-0.5 border border-slate-700/60">
              <button
                type="button"
                id="btn-format-thermal70"
                onClick={() => setPrintFormat('Thermal70')}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition ${
                  printFormat === 'Thermal70' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
                title="70mm POS Slip (70mm Paper Roll)"
              >
                70mm POS Slip
              </button>
              <button
                type="button"
                id="btn-format-thermal80"
                onClick={() => setPrintFormat('Thermal80')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition ${
                  printFormat === 'Thermal80' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                80mm POS Slip
              </button>
              <button
                type="button"
                id="btn-format-a4"
                onClick={() => setPrintFormat('A4')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition ${
                  printFormat === 'A4' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Standard A4
              </button>
            </div>

            <button
              id="btn-trigger-print"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-md shadow-emerald-900/30 border border-emerald-500/30 transition cursor-pointer"
              title="Print Invoice"
            >
              <Printer className="w-4 h-4" />
              <span>Print [Ctrl+P]</span>
            </button>

            <button
              id="btn-close-print-modal"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition cursor-pointer"
              title={isTabMode ? 'Close Tab' : 'Close Preview'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content Body */}
        <div id="printable-invoice-content" className="p-4 sm:p-6 overflow-y-auto flex-1 bg-white text-slate-900 font-sans print:p-0 printable-invoice">
          {printFormat === 'A4' ? (
            /* Standard A4 Tax Invoice */
            <div className="border border-slate-900 text-[11px] leading-tight text-black max-w-full">
              {/* Header Box */}
              <div className="border-b border-slate-900 p-3 text-center relative bg-slate-50/50">
                <span className="absolute top-2 right-3 text-[10px] font-bold uppercase tracking-wider border border-slate-800 px-2 py-0.5 rounded bg-white">
                  {printCopyType}
                </span>
                <span className="absolute top-2 left-3 text-[10px] font-semibold text-slate-600">
                  GST REGULAR INVOICE
                </span>

                <h2 className="text-xl font-black tracking-tight text-slate-950 uppercase mt-1">
                  {company.companyName}
                </h2>
                <p className="text-xs text-slate-800 font-medium italic">{company.tagline}</p>
                <p className="mt-1 text-slate-800">
                  {company.addressLine1}, {company.addressLine2}, {company.city} - {company.pincode}, {company.state} (State Code: {company.stateCode})
                </p>
                <p className="mt-0.5 text-slate-900 font-semibold">
                  <span>Phone: {company.phone} / {company.mobile}</span>
                  <span className="mx-2">|</span>
                  <span>Email: {company.email}</span>
                </p>
                <div className="mt-1 font-bold text-xs flex justify-center gap-6">
                  <span>GSTIN: <span className="font-mono">{company.gstin}</span></span>
                  <span>PAN: <span className="font-mono">{company.pan}</span></span>
                </div>
              </div>

              {/* Title Strip */}
              <div className="bg-slate-900 text-white text-center py-1 font-bold text-xs uppercase tracking-widest print:bg-black">
                TAX INVOICE
              </div>

              {/* Invoice Meta Grid */}
              <div className="grid grid-cols-2 border-b border-slate-900">
                {/* Left: Buyer Details */}
                <div className="p-2.5 border-r border-slate-900">
                  <p className="font-bold text-[10px] uppercase text-slate-600 mb-1">Details of Receiver / Billed To:</p>
                  <p className="text-xs font-bold text-slate-950">{invoice.customerName}</p>
                  <p className="text-slate-800">{invoice.customerAddress || 'Local Address'}</p>
                  <p className="mt-1">
                    <span className="font-semibold">State: </span>{invoice.customerStateCode ? `State Code: ${invoice.customerStateCode}` : 'Maharashtra (27)'}
                    {invoice.customerMobile && <span className="ml-3 font-semibold">Mobile: {invoice.customerMobile}</span>}
                  </p>
                  <p className="mt-0.5">
                    <span className="font-semibold">GSTIN / UIN: </span>
                    <span className="font-mono font-bold">{invoice.customerGstin || 'Unregistered / Retail Consumer'}</span>
                  </p>
                </div>

                {/* Right: Invoice Info */}
                <div className="p-2.5 grid grid-cols-2 gap-y-1.5 text-[11px]">
                  <div>
                    <span className="text-slate-600">Invoice No:</span>
                    <p className="font-mono font-bold text-slate-950 text-xs">{invoice.invoiceNo}</p>
                  </div>
                  <div>
                    <span className="text-slate-600">Invoice Date:</span>
                    <p className="font-bold text-slate-950">{invoice.invoiceDate}</p>
                  </div>
                  <div>
                    <span className="text-slate-600">Payment Mode:</span>
                    <p className="font-semibold text-slate-900">{invoice.paymentMode}</p>
                  </div>
                  <div>
                    <span className="text-slate-600">Place of Supply:</span>
                    <p className="font-semibold text-slate-900">
                      {invoice.isInterState ? 'Inter-State (IGST)' : `Intra-State (${company.state})`}
                    </p>
                  </div>
                  {invoice.salesmanName && (
                    <div className="col-span-2">
                      <span className="text-slate-600">Salesman:</span>
                      <span className="font-medium ml-1">{invoice.salesmanName}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Items Table */}
              <table className="w-full border-collapse text-[10px]">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-900 text-slate-900 font-bold text-left">
                    <th className="py-1 px-1.5 border-r border-slate-900 w-6 text-center">#</th>
                    <th className="py-1 px-2 border-r border-slate-900">Item Description</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-center w-12">HSN</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-right w-10">Qty</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-center w-10">Unit</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-right w-14">Rate (₹)</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-right w-10">Disc%</th>
                    <th className="py-1 px-1.5 border-r border-slate-900 text-right w-16">Taxable (₹)</th>
                    {!invoice.isInterState ? (
                      <>
                        <th className="py-1 px-1 border-r border-slate-900 text-right w-14">CGST</th>
                        <th className="py-1 px-1 border-r border-slate-900 text-right w-14">SGST</th>
                      </>
                    ) : (
                      <th className="py-1 px-1 border-r border-slate-900 text-right w-20">IGST</th>
                    )}
                    <th className="py-1 px-2 text-right w-20">Total (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  {(invoice.items || []).length === 0 ? (
                    <tr>
                      <td colSpan={invoice.isInterState ? 9 : 10} className="py-4 text-center text-slate-500 italic bg-slate-50/50">
                        All items returned & refunded (Bill Total: ₹0.00)
                      </td>
                    </tr>
                  ) : (
                    (invoice.items || []).map((it, idx) => (
                      <tr key={it.id || idx} className="border-b border-slate-300">
                        <td className="py-1 px-1.5 border-r border-slate-900 text-center font-mono">{idx + 1}</td>
                        <td className="py-1 px-2 border-r border-slate-900 font-medium">
                          <div>{it.itemName}</div>
                          <span className="text-[9px] text-slate-500 font-mono">Code: {it.itemCode}</span>
                        </td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-center font-mono">{it.hsnCode}</td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-right font-bold">{it.quantity}</td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-center">{it.unit}</td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-right font-mono">{it.rate.toFixed(2)}</td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-right font-mono">
                          {it.discountPercent > 0 ? `${it.discountPercent}%` : '-'}
                        </td>
                        <td className="py-1 px-1.5 border-r border-slate-900 text-right font-mono font-semibold">
                          {it.taxableAmount.toFixed(2)}
                        </td>
                        {!invoice.isInterState ? (
                          <>
                            <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                              <div>{it.cgstAmount.toFixed(2)}</div>
                              <span className="text-[8px] text-slate-500">@{it.cgstRate}%</span>
                            </td>
                            <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                              <div>{it.sgstAmount.toFixed(2)}</div>
                              <span className="text-[8px] text-slate-500">@{it.sgstRate}%</span>
                            </td>
                          </>
                        ) : (
                          <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                            <div>{it.igstAmount.toFixed(2)}</div>
                            <span className="text-[8px] text-slate-500">@{it.igstRate}%</span>
                          </td>
                        )}
                        <td className="py-1 px-2 text-right font-mono font-bold text-slate-950">
                          {it.netAmount.toFixed(2)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 font-bold border-b border-slate-900 text-slate-950">
                    <td colSpan={3} className="py-1 px-2 border-r border-slate-900 text-right uppercase">
                      Total Items ({invoice.items.length})
                    </td>
                    <td className="py-1 px-1.5 border-r border-slate-900 text-right">{invoice.totalQuantity}</td>
                    <td colSpan={3} className="py-1 px-2 border-r border-slate-900 text-right">
                      Taxable Total
                    </td>
                    <td className="py-1 px-1.5 border-r border-slate-900 text-right font-mono">
                      ₹{invoice.totalTaxable.toFixed(2)}
                    </td>
                    {!invoice.isInterState ? (
                      <>
                        <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                          ₹{invoice.totalCgst.toFixed(2)}
                        </td>
                        <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                          ₹{invoice.totalSgst.toFixed(2)}
                        </td>
                      </>
                    ) : (
                      <td className="py-1 px-1 border-r border-slate-900 text-right font-mono">
                        ₹{invoice.totalIgst.toFixed(2)}
                      </td>
                    )}
                    <td className="py-1 px-2 text-right font-mono font-black text-slate-950">
                      ₹{(invoice.totalTaxable + invoice.totalTax).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* Amount In Words & Bottom Calculations */}
              <div className="grid grid-cols-12 border-b border-slate-900">
                <div className="col-span-7 p-2.5 border-r border-slate-900 flex flex-col justify-between">
                  <div>
                    <span className="font-semibold text-slate-700 block text-[10px] uppercase">Invoice Amount in Words:</span>
                    <p className="font-bold text-xs text-slate-950 italic mt-0.5">
                      {amountInWords}
                    </p>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-200 grid grid-cols-12 gap-2 text-[10px]">
                    <div className="col-span-7">
                      <span className="font-bold uppercase text-slate-700 block mb-0.5">Bank Transfer Details:</span>
                      <div className="grid grid-cols-1 gap-y-0.5 text-slate-800 text-[10px]">
                        <div>Bank: <strong className="font-medium">{company.bankName}</strong></div>
                        <div>A/C No: <strong className="font-mono font-bold">{company.bankAccountNo}</strong></div>
                        <div>IFSC: <strong className="font-mono font-bold">{company.bankIfsc}</strong></div>
                        <div>Branch: <span>{company.bankBranch}</span></div>
                      </div>
                    </div>

                    <div className="col-span-5 border-l border-slate-300 pl-2 flex flex-col items-center justify-center text-center">
                      <span className="font-black uppercase text-slate-900 text-[10px] tracking-tight block">Scan & Pay via UPI</span>
                      <span className="font-bold text-[9px] text-emerald-800 block mt-0.5">
                        Amount Payable: ₹{invoice.grandTotal.toFixed(2)}
                      </span>
                      {upiAddress ? (
                        qrDataUrl ? (
                          <img src={qrDataUrl} alt="UPI Payment QR Code" className="w-20 h-20 my-1 object-contain border border-slate-300 p-0.5 rounded bg-white shadow-sm" />
                        ) : (
                          <div className="w-20 h-20 my-1 bg-slate-100 border border-slate-200 flex items-center justify-center text-[8px] text-slate-400 rounded">Generating...</div>
                        )
                      ) : (
                        <p className="text-[8px] text-amber-900 leading-tight italic bg-amber-50 p-1.5 mt-1 rounded text-center border border-amber-300">
                          Please configure the UPI Address in Settings to enable UPI payments.
                        </p>
                      )}
                      {upiAddress && (
                        <span className="font-mono text-[8px] text-slate-700 block truncate max-w-full font-semibold">{upiAddress}</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="col-span-5 p-2 text-xs divide-y divide-slate-200">
                  <div className="flex justify-between py-0.5">
                    <span className="text-slate-600">Subtotal (Gross):</span>
                    <span className="font-mono">₹{invoice.grossSubtotal.toFixed(2)}</span>
                  </div>
                  {invoice.totalDiscount > 0 && (
                    <div className="flex justify-between py-0.5 text-emerald-700">
                      <span>Total Discount:</span>
                      <span className="font-mono">-₹{invoice.totalDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-0.5 font-medium">
                    <span>Taxable Amount:</span>
                    <span className="font-mono">₹{invoice.totalTaxable.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between py-0.5 text-slate-700">
                    <span>Total GST:</span>
                    <span className="font-mono">₹{invoice.totalTax.toFixed(2)}</span>
                  </div>
                  {invoice.roundOff !== 0 && (
                    <div className="flex justify-between py-0.5 text-slate-600">
                      <span>Round Off:</span>
                      <span className="font-mono">{invoice.roundOff > 0 ? `+${invoice.roundOff.toFixed(2)}` : invoice.roundOff.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-1 font-black text-sm text-slate-950 bg-slate-100 px-1.5 rounded">
                    <span>GRAND TOTAL:</span>
                    <span className="font-mono">₹{invoice.grandTotal.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between py-0.5 text-[11px]">
                    <span className="text-slate-600">Amount Received:</span>
                    <span className="font-mono font-semibold text-emerald-800">₹{invoice.amountReceived.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between py-0.5 text-[11px]">
                    <span className="text-slate-600">Balance Due:</span>
                    <span className="font-mono font-bold text-rose-800">₹{invoice.balanceDue.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Terms & Signatures */}
              <div className="grid grid-cols-2 p-3 text-[10px]">
                <div className="pr-3">
                  <span className="font-bold uppercase text-slate-800 block mb-1">Terms & Conditions:</span>
                  <pre className="font-sans text-[9px] text-slate-600 whitespace-pre-wrap leading-relaxed">
                    {company.invoiceTerms}
                  </pre>
                  <p className="mt-2 text-[8px] text-slate-500 italic">
                    {company.declaration}
                  </p>
                </div>

                <div className="flex flex-col justify-between items-end pl-3 pt-2 text-center">
                  <span className="font-bold text-[10px] uppercase text-slate-900">
                    For {company.companyName}
                  </span>

                  <div className="w-40 border-t border-slate-900 pt-1 mt-12">
                    <span className="text-[10px] font-semibold text-slate-800">Authorized Signatory</span>
                  </div>
                </div>
              </div>
            </div>
          ) : printFormat === 'Thermal80' ? (
            /* 80mm POS Thermal Slip Format (Exact 80mm Width, matching 70mm styling & typography) */
            <div
              id="thermal-80mm-print-slip"
              className="thermal-80mm-slip print-container w-full max-w-[80mm] mx-auto border-2 border-dashed border-slate-900 pt-[2mm] pr-[0mm] pb-2 pl-1.5 my-2 text-black font-mono font-bold text-[13px] leading-snug bg-white shadow-md print:border-none print:shadow-none print:pt-[2mm] print:pr-[0mm] print:pl-0 print:pb-0 print:m-0 print:w-[80mm] print:max-w-[80mm] print:overflow-hidden text-left shrink-0 box-border"
              style={{ boxSizing: 'border-box' }}
            >
              <div className="text-center border-b-2 border-dashed border-black pb-2 w-full max-w-full overflow-hidden">
                <h3 className="font-black font-bold text-[30px] uppercase leading-tight tracking-tight text-black break-words">{company.companyName}</h3>
                <div className="flex justify-center my-1.5 w-full">
                  <img
                    src={arcoPosLogo}
                    alt="ARCO Logo"
                    referrerPolicy="no-referrer"
                    className="h-12 max-w-[160px] object-contain mx-auto block print:block"
                  />
                </div>
                {company.tagline && <p className="text-[14px] font-bold text-black italic mt-0.5 break-words">{company.tagline}</p>}
                <p className="text-[14px] font-bold leading-tight text-black mt-1 break-words">{company.addressLine1}{company.city ? `, ${company.city}` : ''}</p>
                <p className="text-[14px] font-bold leading-tight text-black">Ph: {company.phone}</p>
                <p className="text-[14px] font-black mt-0.5 text-black">GSTIN: {company.gstin}</p>
                <p className="text-[14px] font-black mt-1 bg-black text-white py-0.5 uppercase tracking-wider text-center w-full">RETAIL TAX INVOICE</p>
              </div>

              <div className="py-2 border-b-2 border-dashed border-black text-[13px] font-bold text-black space-y-1 w-full max-w-full overflow-hidden">
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="truncate mr-1">Bill No: <strong className="font-black text-black">{invoice.invoiceNo}</strong></span>
                  <span className="shrink-0 font-black">{invoice.invoiceDate}</span>
                </div>
                <div className="w-full max-w-full break-words">
                  <span>Customer: <strong className="font-black text-black">{invoice.customerName}</strong></span>
                </div>
                {invoice.customerMobile && <div className="w-full max-w-full">Ph: <strong className="font-black">{invoice.customerMobile}</strong></div>}
                {invoice.customerGstin && <div className="w-full max-w-full break-all">Cust GST: <strong className="font-black">{invoice.customerGstin}</strong></div>}
              </div>

              <table className="w-full max-w-full my-1.5 text-[13px] font-bold text-black border-collapse table-fixed">
                <colgroup>
                  <col className="w-[42%]" />
                  <col className="w-[14%]" />
                  <col className="w-[20%]" />
                  <col className="w-[24%]" />
                </colgroup>
                <thead>
                  <tr className="border-b-2 border-black text-left text-[13px]">
                    <th className="py-1 font-black text-left w-[42%] overflow-hidden">Item</th>
                    <th className="py-1 text-center font-black w-[14%] overflow-hidden">Qty</th>
                    <th className="py-1 text-right font-black w-[20%] overflow-hidden">Rate</th>
                    <th className="py-1 text-right font-black w-[24%] overflow-hidden pr-0.5">Amt</th>
                  </tr>
                </thead>
                <tbody>
                  {(invoice.items || []).length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-2 text-center text-black font-bold italic">
                        All items returned & refunded (₹0.00)
                      </td>
                    </tr>
                  ) : (
                    (invoice.items || []).map((it, idx) => (
                      <tr key={idx} className="border-b border-black/40">
                        <td className="py-1 pr-1 w-[42%] align-top overflow-hidden break-words">
                          <div className="leading-tight font-black text-black text-[13px] break-words">{it.itemName}</div>
                          <span className="text-[11px] font-bold text-black block leading-tight mt-0.5">HSN:{it.hsnCode} G:{it.gstRate}%</span>
                        </td>
                        <td className="py-1 text-center font-black align-top text-[13px] w-[14%] overflow-hidden">{it.quantity}</td>
                        <td className="py-1 text-right font-black align-top text-[13px] w-[20%] overflow-hidden whitespace-nowrap">{it.rate.toFixed(0)}</td>
                        <td className="py-1 text-right font-black align-top text-[13px] w-[24%] overflow-hidden whitespace-nowrap pr-0.5">{it.netAmount.toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              <div className="border-t-2 border-dashed border-black pt-1.5 space-y-1 text-[13px] font-bold text-black w-full max-w-full overflow-hidden">
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0">Total Items Qty:</span>
                  <strong className="font-black text-[13.5px] text-right shrink-0">{invoice.totalQuantity}</strong>
                </div>
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0">Gross Subtotal:</span>
                  <span className="font-black text-right shrink-0">₹{invoice.grossSubtotal.toFixed(2)}</span>
                </div>
                {invoice.totalDiscount > 0 && (
                  <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                    <span className="shrink-0">Discount:</span>
                    <span className="font-black text-right shrink-0">-₹{invoice.totalDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0">Tax (CGST+SGST):</span>
                  <span className="font-black text-right shrink-0">₹{invoice.totalTax.toFixed(2)}</span>
                </div>
                {invoice.roundOff !== 0 && (
                  <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                    <span className="shrink-0">Round Off:</span>
                    <span className="font-black text-right shrink-0">{invoice.roundOff.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center font-black text-[15px] pt-1.5 pb-1 border-t-2 border-b-2 border-black w-full max-w-full pr-0.5">
                  <span className="shrink-0">NET PAYABLE:</span>
                  <span className="font-black text-[17px] text-right shrink-0">₹{invoice.grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-[13px] pt-0.5 w-full max-w-full pr-0.5">
                  <span className="shrink-0">Paid ({invoice.paymentMode}):</span>
                  <span className="font-black text-right shrink-0">₹{invoice.amountReceived.toFixed(2)}</span>
                </div>
                {invoice.balanceDue > 0 && (
                  <div className="flex justify-between items-center text-[13px] font-black text-black w-full max-w-full pr-0.5">
                    <span className="shrink-0">Balance Due:</span>
                    <span className="font-black text-right shrink-0">₹{invoice.balanceDue.toFixed(2)}</span>
                  </div>
                )}
              </div>

              {/* UPI Payment QR Code Block */}
              <div className="text-center py-2 border-t-2 border-dashed border-black my-1.5 w-full max-w-full overflow-hidden">
                <span className="font-black text-[13px] uppercase block text-black">SCAN & PAY VIA UPI</span>
                <span className="font-black text-[13px] text-black block mt-0.5">Amount: ₹{invoice.grandTotal.toFixed(2)}</span>
                {upiAddress ? (
                  qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="UPI Payment QR Code"
                      referrerPolicy="no-referrer"
                      className="w-28 h-28 mx-auto my-1.5 object-contain bg-white p-0.5 border-2 border-black max-w-full block"
                    />
                  ) : (
                    <div className="w-28 h-28 mx-auto my-1.5 bg-slate-100 flex items-center justify-center text-[11px] font-bold text-black border border-black">Generating...</div>
                  )
                ) : (
                  <p className="text-[11px] text-black font-bold leading-tight italic bg-amber-100 p-1.5 my-1 rounded text-center border border-black">
                    Please configure UPI Address in Settings.
                  </p>
                )}
                {upiAddress && (
                  <span className="font-mono font-black text-[11.5px] text-black block break-all w-full max-w-full px-1">{upiAddress}</span>
                )}
              </div>

              <div className="text-center text-[11.5px] pt-1.5 border-t-2 border-dashed border-black mt-1 w-full max-w-full overflow-hidden">
                <p className="font-black text-[14px]">Thank You! Visit Again</p>
                <p className="font-bold text-black mt-0.5">Goods once sold will not be exchanged without bill.</p>
              </div>
            </div>
          ) : (
            /* 70mm POS Thermal Slip Format (Exact 70mm Width, 2mm Top Margin, 0mm Right Margin) */
            <div
              id="thermal-70mm-print-slip"
              className="thermal-70mm-slip print-container w-full max-w-[70mm] mx-auto border-2 border-dashed border-black pt-[2mm] pr-[0mm] pb-2 pl-1.5 my-2 text-black font-mono font-bold text-[13px] leading-snug bg-white shadow-md print:border-none print:shadow-none print:pt-[2mm] print:pr-[0mm] print:pl-0 print:pb-0 print:m-0 print:w-[70mm] print:max-w-[70mm] print:overflow-hidden text-left shrink-0 box-border"
              style={{ boxSizing: 'border-box', backgroundColor: '#ffffff', color: '#000000', fontWeight: 'bold' }}
            >
              <div className="text-center border-b-2 border-dashed border-black pb-2 w-full max-w-full overflow-hidden bg-white">
                <h3 className="font-black font-bold text-[50px] uppercase leading-tight tracking-tight text-black break-words" style={{ fontSize: '50px' }}>{company.companyName}</h3>
                <div className="flex justify-center my-1.5 w-full bg-white">
                  <img
                    src={arcoPosLogo}
                    alt="ARCO Logo"
                    referrerPolicy="no-referrer"
                    className="h-12 max-w-[155px] object-contain mx-auto block print:block bg-white"
                  />
                </div>
                {company.tagline && <p className="text-[14px] font-bold text-black italic mt-0.5 break-words">{company.tagline}</p>}
                <p className="text-[14px] font-bold leading-tight text-black mt-1 break-words">{company.addressLine1}{company.city ? `, ${company.city}` : ''}</p>
                <p className="text-[14px] font-bold leading-tight text-black">Ph: {company.phone}</p>
                <p className="text-[14px] font-black mt-0.5 text-black">GSTIN: {company.gstin}</p>
                <p className="text-[14px] font-black mt-1 bg-white text-black border-y-2 border-black py-0.5 uppercase tracking-wider text-center w-full" style={{ backgroundColor: '#ffffff', color: '#000000', fontWeight: 'bold' }}>RETAIL TAX INVOICE</p>
              </div>

              <div className="py-2 border-b-2 border-dashed border-black text-[15px] font-bold text-black space-y-1 w-full max-w-full overflow-hidden bg-white" style={{ fontSize: '15px' }}>
                <div className="flex justify-between items-center w-full max-w-full pr-0.5 text-[15px]">
                  <span className="truncate mr-1 font-bold text-black">Bill No: <strong className="font-black text-black">{invoice.invoiceNo}</strong></span>
                  <span className="shrink-0 font-black text-black">{invoice.invoiceDate}</span>
                </div>
                <div className="w-full max-w-full break-words text-[15px] font-bold text-black">
                  <span>Customer: <strong className="font-black text-black">{invoice.customerName}</strong></span>
                </div>
                {invoice.customerMobile && <div className="w-full max-w-full text-[15px] font-bold text-black">Ph: <strong className="font-black text-black">{invoice.customerMobile}</strong></div>}
                {invoice.customerGstin && <div className="w-full max-w-full break-all text-[15px] font-bold text-black">Cust GST: <strong className="font-black text-black">{invoice.customerGstin}</strong></div>}
              </div>

              <table className="w-full max-w-full my-1.5 text-[13px] font-bold text-black border-collapse table-fixed bg-white">
                <colgroup>
                  <col className="w-[42%]" />
                  <col className="w-[14%]" />
                  <col className="w-[20%]" />
                  <col className="w-[24%]" />
                </colgroup>
                <thead>
                  <tr className="border-b-2 border-black text-left text-[18px] bg-white text-black font-black" style={{ fontSize: '18px' }}>
                    <th className="py-1 font-black text-left text-[18px] text-black w-[42%] overflow-hidden">Item</th>
                    <th className="py-1 text-center font-black text-[18px] text-black w-[14%] overflow-hidden">Qty</th>
                    <th className="py-1 text-right font-black text-[18px] text-black w-[20%] overflow-hidden">Rate</th>
                    <th className="py-1 text-right font-black text-[18px] text-black w-[24%] overflow-hidden pr-0.5">Amt</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {(invoice.items || []).length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-2 text-center text-black font-bold italic bg-white">
                        All items returned & refunded (₹0.00)
                      </td>
                    </tr>
                  ) : (
                    (invoice.items || []).map((it, idx) => (
                      <tr key={idx} className="border-b border-black bg-white">
                        <td className="py-1 pr-1 w-[42%] align-top overflow-hidden break-words text-black font-bold">
                          <div className="leading-tight font-black text-black text-[13px] break-words">{it.itemName}</div>
                          <span className="text-[11px] font-bold text-black block leading-tight mt-0.5">HSN:{it.hsnCode} G:{it.gstRate}%</span>
                        </td>
                        <td className="py-1 text-center font-black text-black align-top text-[13px] w-[14%] overflow-hidden">{it.quantity}</td>
                        <td className="py-1 text-right font-black text-black align-top text-[13px] w-[20%] overflow-hidden whitespace-nowrap">{it.rate.toFixed(0)}</td>
                        <td className="py-1 text-right font-black text-black align-top text-[13px] w-[24%] overflow-hidden whitespace-nowrap pr-0.5">{it.netAmount.toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              <div className="border-t-2 border-dashed border-black pt-1.5 space-y-1 text-[13px] font-bold text-black w-full max-w-full overflow-hidden bg-white">
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0 font-bold text-black">Total Items Qty:</span>
                  <strong className="font-black text-[13.5px] text-black text-right shrink-0">{invoice.totalQuantity}</strong>
                </div>
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0 font-bold text-black">Gross Subtotal:</span>
                  <span className="font-black text-black text-right shrink-0">₹{invoice.grossSubtotal.toFixed(2)}</span>
                </div>
                {invoice.totalDiscount > 0 && (
                  <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                    <span className="shrink-0 font-bold text-black">Discount:</span>
                    <span className="font-black text-black text-right shrink-0">-₹{invoice.totalDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                  <span className="shrink-0 font-bold text-black">Tax (CGST+SGST):</span>
                  <span className="font-black text-black text-right shrink-0">₹{invoice.totalTax.toFixed(2)}</span>
                </div>
                {invoice.roundOff !== 0 && (
                  <div className="flex justify-between items-center w-full max-w-full pr-0.5">
                    <span className="shrink-0 font-bold text-black">Round Off:</span>
                    <span className="font-black text-black text-right shrink-0">{invoice.roundOff.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center font-black text-[18px] text-black pt-1.5 pb-1 border-t-2 border-b-2 border-black w-full max-w-full pr-0.5" style={{ fontSize: '18px' }}>
                  <span className="shrink-0 text-[18px] text-black font-black">NET PAYABLE:</span>
                  <span className="font-black text-[18px] text-black text-right shrink-0" style={{ fontSize: '18px' }}>₹{invoice.grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-[13px] font-bold text-black pt-0.5 w-full max-w-full pr-0.5">
                  <span className="shrink-0 font-bold text-black">Paid ({invoice.paymentMode}):</span>
                  <span className="font-black text-black text-right shrink-0">₹{invoice.amountReceived.toFixed(2)}</span>
                </div>
                {invoice.balanceDue > 0 && (
                  <div className="flex justify-between items-center text-[13px] font-black text-black w-full max-w-full pr-0.5">
                    <span className="shrink-0 font-black text-black">Balance Due:</span>
                    <span className="font-black text-black text-right shrink-0">₹{invoice.balanceDue.toFixed(2)}</span>
                  </div>
                )}
              </div>

              {/* UPI Payment QR Code Block */}
              <div className="text-center py-2 border-t-2 border-dashed border-black my-1.5 w-full max-w-full overflow-hidden bg-white">
                <span className="font-black text-[13px] uppercase block text-black">SCAN & PAY VIA UPI</span>
                <span className="font-black text-[13px] text-black block mt-0.5">Amount: ₹{invoice.grandTotal.toFixed(2)}</span>
                {upiAddress ? (
                  <div
                    className="w-[220px] h-[220px] mx-auto my-1.5 bg-white p-0.5 border-2 border-black flex items-center justify-center overflow-hidden"
                    style={{ width: '220px', height: '220px', backgroundColor: '#ffffff' }}
                  >
                    {qrDataUrl ? (
                      <img
                        src={qrDataUrl}
                        alt="UPI Payment QR Code"
                        referrerPolicy="no-referrer"
                        className="w-[220px] h-[220px] max-w-full max-h-full object-contain block bg-white"
                        style={{ width: '220px', height: '220px', backgroundColor: '#ffffff' }}
                      />
                    ) : (
                      <div className="w-[220px] h-[220px] bg-white flex items-center justify-center text-[11px] font-bold text-black">Generating...</div>
                    )}
                  </div>
                ) : (
                  <p className="text-[11px] text-black font-bold leading-tight italic bg-white p-1.5 my-1 rounded text-center border-2 border-black">
                    Please configure UPI Address in Settings.
                  </p>
                )}
                {upiAddress && (
                  <span className="font-mono font-black text-[11.5px] text-black block break-all w-full max-w-full px-1">{upiAddress}</span>
                )}
              </div>

              <div className="text-center text-[11.5px] font-bold text-black pt-1.5 border-t-2 border-dashed border-black mt-1 w-full max-w-full overflow-hidden bg-white">
                <p className="font-black text-[14px] text-black">Thank You! Visit Again</p>
                <p className="font-bold text-black mt-0.5">Goods once sold will not be exchanged without bill.</p>
              </div>
            </div>
          )}
        </div>
        {(printFormat === 'Thermal70' || printFormat === 'Thermal80') && (
          <style>{`
            @media print {
              @page {
                size: ${printFormat === 'Thermal70' ? '70mm' : '80mm'} auto !important;
                margin: 2mm 0mm 0mm 0mm !important;
              }
              html, body {
                width: ${printFormat === 'Thermal70' ? '70mm' : '80mm'} !important;
                max-width: ${printFormat === 'Thermal70' ? '70mm' : '80mm'} !important;
                margin: 0 !important;
                margin-top: 2mm !important;
                margin-right: 0mm !important;
                padding: 2mm 0 0 0 !important;
                overflow-x: hidden !important;
              }
              * {
                box-sizing: border-box !important;
              }
              .print-container,
              .thermal-70mm-slip,
              #thermal-70mm-print-slip,
              .thermal-80mm-slip,
              #thermal-80mm-print-slip,
              .thermal-75mm-slip,
              #thermal-75mm-print-slip {
                width: ${printFormat === 'Thermal70' ? '70mm' : '80mm'} !important;
                max-width: ${printFormat === 'Thermal70' ? '70mm' : '80mm'} !important;
                margin: 0 !important;
                margin-top: 2mm !important;
                margin-right: 0mm !important;
                padding-top: 2mm !important;
                padding-right: 0mm !important;
                padding-bottom: 0 !important;
                padding-left: 0 !important;
                overflow: hidden !important;
                box-sizing: border-box !important;
              }
              .thermal-70mm-slip,
              .thermal-70mm-slip * {
                background-color: #ffffff !important;
                color: #000000 !important;
                font-weight: 700 !important;
              }
              table {
                width: 100% !important;
                max-width: 100% !important;
                table-layout: fixed !important;
                border-collapse: collapse !important;
              }
              td, th {
                box-sizing: border-box !important;
                overflow-wrap: break-word !important;
                word-break: break-word !important;
              }
            }
          `}</style>
        )}
      </div>
  );

  if (isTabMode) {
    return content;
  }

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/75 backdrop-blur-md p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      {content}
    </div>
  );
};
