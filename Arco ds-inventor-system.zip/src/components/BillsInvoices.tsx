import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Search, 
  ShoppingCart, 
  Clipboard, 
  Printer, 
  Calendar, 
  CheckCircle2, 
  ExternalLink,
  ChevronRight,
  Filter,
  Hash,
  ShoppingBag,
  RotateCcw,
  RefreshCw,
  Edit3,
  X
} from 'lucide-react';
import { dbService } from '../services/storage';
import { SalesInvoice, PurchaseInvoice, Customer, CompanyInfo } from '../types';
import { InvoicePrintModal } from './InvoicePrintModal';

interface BillsInvoicesProps {
  initialTab?: 'SALES' | 'PURCHASES';
  onNavigateToReturnExchange?: (invoiceId: string) => void;
  company?: CompanyInfo;
  onOpenPrintPreviewTab?: (invoice: SalesInvoice, autoPrint?: boolean) => void;
}

type DateFilterPreset = 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'all' | 'custom';

// Helper to get local YYYY-MM-DD
const getLocalTodayDate = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const BillsInvoicesComponent: React.FC<BillsInvoicesProps> = ({ initialTab = 'SALES', onNavigateToReturnExchange, company, onOpenPrintPreviewTab }) => {
  const [activeSubTab, setActiveSubTab] = useState<'SALES' | 'PURCHASES'>(initialTab);

  useEffect(() => {
    setActiveSubTab(initialTab);
  }, [initialTab]);

  const [sales, setSales] = useState<SalesInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [customersList, setCustomersList] = useState<Customer[]>([]);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo>(company || dbService.getCompanyInfo());

  useEffect(() => {
    if (company) {
      setCompanyInfo(company);
    }
  }, [company]);

  // Filter States - Default to today's date for current date invoices on load
  const todayStr = getLocalTodayDate();
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('today');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedCustomerIdFilter, setSelectedCustomerIdFilter] = useState<string>('ALL');
  const [invoiceNoFilter, setInvoiceNoFilter] = useState<string>('');
  const [itemNameFilter, setItemNameFilter] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<string>(todayStr);

  useEffect(() => {
    const loadBills = () => {
      setSales(dbService.getSales());
      setPurchases(dbService.getPurchases());
      setCustomersList(dbService.getCustomers());
      if (!company) {
        setCompanyInfo(dbService.getCompanyInfo());
      }
    };
    loadBills();
    return dbService.subscribe(loadBills);
  }, [company]);

  const handleDatePresetChange = (preset: DateFilterPreset) => {
    setDatePreset(preset);
    const today = getLocalTodayDate();

    if (preset === 'today') {
      setDateFilter(today);
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yYear = y.getFullYear();
      const yMonth = String(y.getMonth() + 1).padStart(2, '0');
      const yDay = String(y.getDate()).padStart(2, '0');
      const yStr = `${yYear}-${yMonth}-${yDay}`;
      setDateFilter(yStr);
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'last7') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      const d7Year = d7.getFullYear();
      const d7Month = String(d7.getMonth() + 1).padStart(2, '0');
      const d7Day = String(d7.getDate()).padStart(2, '0');
      const d7Str = `${d7Year}-${d7Month}-${d7Day}`;
      setDateFilter('');
      setStartDate(d7Str);
      setEndDate(today);
    } else if (preset === 'thisMonth') {
      const now = new Date();
      const firstDay = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
      setDateFilter('');
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setDateFilter('');
      setStartDate('');
      setEndDate('');
    }
  };

  // Reset all filters and revert active list to current date invoices
  const handleResetFilters = () => {
    const today = getLocalTodayDate();
    setDateFilter(today);
    setDatePreset('today');
    setStartDate(today);
    setEndDate(today);
    setSelectedCustomerIdFilter('ALL');
    setInvoiceNoFilter('');
    setItemNameFilter('');
    setSearchTerm('');
  };

  // Filter Sales Invoices
  const filteredSales = sales.filter(s => {
    // 1. Date Wise single date filter (defaults to today)
    if (dateFilter) {
      if (s.invoiceDate !== dateFilter) return false;
    } else if (datePreset !== 'all') {
      // 2. Date preset & range filtering
      if (startDate && s.invoiceDate < startDate) return false;
      if (endDate && s.invoiceDate > endDate) return false;
    }

    // Customer filter
    if (selectedCustomerIdFilter !== 'ALL') {
      if (selectedCustomerIdFilter === 'CUST-000') {
        if (s.customerId !== 'CUST-000') return false;
      } else {
        if (s.customerId !== selectedCustomerIdFilter) return false;
      }
    }

    // Invoice No filter
    if (invoiceNoFilter.trim()) {
      const q = invoiceNoFilter.trim().toLowerCase();
      if (!s.invoiceNo.toLowerCase().includes(q)) return false;
    }

    // Item Name filter
    if (itemNameFilter.trim()) {
      const q = itemNameFilter.trim().toLowerCase();
      const hasItem = (s.items || []).some(
        (it) =>
          it.itemName.toLowerCase().includes(q) ||
          (it.itemCode && it.itemCode.toLowerCase().includes(q))
      );
      if (!hasItem) return false;
    }

    // General search term
    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const matchSearch = 
        s.invoiceNo.toLowerCase().includes(q) || 
        s.customerName.toLowerCase().includes(q);
      if (!matchSearch) return false;
    }

    return true;
  });

  // Filter Purchase Invoices
  const filteredPurchases = purchases.filter(p => {
    const matchSearch = 
      p.purchaseNo.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (p.supplierBillNo && p.supplierBillNo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      p.supplierName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchDate = dateFilter ? p.purchaseDate === dateFilter : true;
    return matchSearch && matchDate;
  });

  // Calculations
  const salesSubtotal = filteredSales.reduce((acc, s) => acc + s.grossSubtotal, 0);
  const salesTax = filteredSales.reduce((acc, s) => acc + s.totalTax, 0);
  const salesTotal = filteredSales.reduce((acc, s) => acc + s.grandTotal, 0);

  const purchaseSubtotal = filteredPurchases.reduce((acc, p) => acc + p.grossSubtotal, 0);
  const purchaseTax = filteredPurchases.reduce((acc, p) => acc + p.totalTax, 0);
  const purchaseTotal = filteredPurchases.reduce((acc, p) => acc + p.grandTotal, 0);

  const handlePrint = (invoice: SalesInvoice) => {
    setSelectedPrintInvoice(invoice);
  };

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              {activeSubTab === 'SALES' ? 'Sales Invoices Register' : 'Purchase Bill Register'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {activeSubTab === 'SALES'
                ? 'Comprehensive audit register of Sales Billing Invoices.'
                : 'Comprehensive audit register of Purchase Bills.'}
            </p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search bill no, party..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500/60 min-w-[200px]"
            />
          </div>

          {/* Date Picker (Shown on Purchase Tab) */}
          {activeSubTab === 'PURCHASES' && (
            <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs text-slate-300">
              <Calendar className="w-4 h-4 text-slate-400" />
              <input 
                type="date" 
                value={dateFilter} 
                onChange={(e) => setDateFilter(e.target.value)}
                className="bg-transparent text-slate-200 focus:outline-none cursor-pointer font-mono"
              />
              {dateFilter && (
                <button 
                  onClick={() => setDateFilter('')}
                  className="text-[9px] text-slate-400 hover:text-white ml-1 font-bold"
                >
                  Clear
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Calculations Banner */}
      {activeSubTab === 'SALES' ? (
        <div className="grid grid-cols-3 gap-4 bg-slate-950/20 border border-slate-850 p-4 rounded-xl">
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Total Taxable Amount</span>
            <div className="text-base font-black text-slate-200 mt-0.5">₹{salesSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Total GST Calculated</span>
            <div className="text-base font-black text-slate-200 mt-0.5">₹{salesTax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400 text-blue-400">Total Invoice Value ({filteredSales.length} Invoices)</span>
            <div className="text-base font-black text-blue-400 mt-0.5">₹{salesTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-4 bg-slate-950/20 border border-slate-850 p-4 rounded-xl">
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Total Inward Cost</span>
            <div className="text-base font-black text-slate-200 mt-0.5">₹{purchaseSubtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400">Total ITC Earned</span>
            <div className="text-base font-black text-slate-200 mt-0.5">₹{purchaseTax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase text-slate-400 text-indigo-400">Total Purchase Value ({filteredPurchases.length} Bills)</span>
            <div className="text-base font-black text-indigo-400 mt-0.5">₹{purchaseTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
          </div>
        </div>
      )}

      {/* Filter Control Box for Sales Invoices */}
      {activeSubTab === 'SALES' && (
        <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-4 backdrop-blur-sm space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
              <Filter className="w-4 h-4 text-purple-400" />
              <span>Search & Filter Sales Invoices</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['today', 'yesterday', 'last7', 'thisMonth', 'all'] as DateFilterPreset[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => handleDatePresetChange(p)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      datePreset === p
                        ? 'bg-purple-600 text-white shadow-sm font-bold'
                        : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    {p === 'today' && 'Today'}
                    {p === 'yesterday' && 'Yesterday'}
                    {p === 'last7' && 'Last 7 Days'}
                    {p === 'thisMonth' && 'This Month'}
                    {p === 'all' && 'All Dates'}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleResetFilters}
                className="flex items-center gap-1.5 px-3 py-1 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 hover:text-rose-200 border border-rose-500/30 rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-sm"
                title="Reset all filters and revert to today's invoices"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                <span>Reset Filter</span>
              </button>
            </div>
          </div>

          {/* Filter Inputs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
            {/* 1. Date Wise (First Item) */}
            <div>
              <label className="block text-[10px] font-bold text-purple-300 uppercase tracking-wider mb-1">
                Date Wise
              </label>
              <div className="relative">
                <Calendar className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-purple-400 pointer-events-none" />
                <input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => {
                    const val = e.target.value;
                    setDateFilter(val);
                    if (val === getLocalTodayDate()) {
                      setDatePreset('today');
                      setStartDate(val);
                      setEndDate(val);
                    } else if (val) {
                      setDatePreset('custom');
                      setStartDate(val);
                      setEndDate(val);
                    } else {
                      setDatePreset('all');
                      setStartDate('');
                      setEndDate('');
                    }
                  }}
                  className="w-full bg-slate-950/80 border border-purple-500/40 rounded-lg pl-8 pr-2.5 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none cursor-pointer font-mono"
                />
              </div>
            </div>

            {/* 2. Date Range */}
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Date Range
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="date"
                  placeholder="From"
                  value={startDate}
                  onChange={(e) => {
                    setStartDate(e.target.value);
                    setDatePreset('custom');
                    setDateFilter('');
                  }}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none font-mono text-[11px]"
                />
                <input
                  type="date"
                  placeholder="To"
                  value={endDate}
                  onChange={(e) => {
                    setEndDate(e.target.value);
                    setDatePreset('custom');
                    setDateFilter('');
                  }}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none font-mono text-[11px]"
                />
              </div>
            </div>

            {/* 3. Customer Filter */}
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Customer Wise
              </label>
              <select
                value={selectedCustomerIdFilter}
                onChange={(e) => setSelectedCustomerIdFilter(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Customers</option>
                <option value="CUST-000">Cash / Counter Sale</option>
                {customersList
                  .filter((c) => c.id !== 'CUST-000')
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.customerName} {c.mobile ? `(${c.mobile})` : ''}
                    </option>
                  ))}
              </select>
            </div>

            {/* 4. Invoice No Filter */}
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Customer Invoice Number
              </label>
              <div className="relative">
                <Hash className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. CUS-INV-001"
                  value={invoiceNoFilter}
                  onChange={(e) => setInvoiceNoFilter(e.target.value)}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg pl-8 pr-6 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none placeholder-slate-600 font-mono"
                />
                {invoiceNoFilter && (
                  <button
                    type="button"
                    onClick={() => setInvoiceNoFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* 5. Item Name Filter */}
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Contains Item Name
              </label>
              <div className="relative">
                <ShoppingBag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search Item in Bill..."
                  value={itemNameFilter}
                  onChange={(e) => setItemNameFilter(e.target.value)}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-lg pl-8 pr-6 py-1.5 text-slate-200 focus:border-purple-500 focus:outline-none placeholder-slate-600"
                />
                {itemNameFilter && (
                  <button
                    type="button"
                    onClick={() => setItemNameFilter('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Bar with Active Filter Summary & Reset Filter Button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2.5 border-t border-slate-800/60 text-xs">
            <div className="text-slate-400 text-[11px] flex items-center gap-2 flex-wrap">
              <span>Active Filter:</span>
              <span className="font-bold text-purple-300">
                {dateFilter
                  ? `Invoices on ${dateFilter === getLocalTodayDate() ? 'Today (' + dateFilter + ')' : dateFilter}`
                  : datePreset !== 'all'
                  ? `${datePreset === 'today' ? "Today's Invoices" : datePreset === 'yesterday' ? "Yesterday's Invoices" : datePreset === 'last7' ? 'Last 7 Days Invoices' : datePreset === 'thisMonth' ? 'This Month Invoices' : startDate && endDate ? `${startDate} to ${endDate}` : 'Custom Range'}`
                  : 'All Invoices (No Date Filter)'}
              </span>
              {selectedCustomerIdFilter !== 'ALL' && (
                <span className="bg-slate-800 px-2 py-0.5 rounded text-[10px] text-slate-300">
                  Customer: {customersList.find((c) => c.id === selectedCustomerIdFilter)?.customerName || selectedCustomerIdFilter}
                </span>
              )}
              {invoiceNoFilter && (
                <span className="bg-slate-800 px-2 py-0.5 rounded text-[10px] font-mono text-slate-300">
                  Inv: {invoiceNoFilter}
                </span>
              )}
              {itemNameFilter && (
                <span className="bg-slate-800 px-2 py-0.5 rounded text-[10px] text-slate-300">
                  Item: {itemNameFilter}
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleResetFilters}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 hover:border-rose-700 rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-sm self-end sm:self-auto"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
              <span>Reset Filter</span>
            </button>
          </div>
        </div>
      )}

      {/* Table Section */}
      <div className="bg-slate-900/30 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm">
        <div className="overflow-x-auto">
          {activeSubTab === 'SALES' ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3">Invoice No</th>
                  <th className="py-3 px-3">Customer / Client</th>
                  <th className="py-3 px-3">Payment Mode</th>
                  <th className="py-3 px-3 text-right">Taxable</th>
                  <th className="py-3 px-3 text-right">GST Tax</th>
                  <th className="py-3 px-3 text-right">Grand Total</th>
                  <th className="py-3 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                {filteredSales.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-slate-500 font-medium">
                      No sales billing invoices matching criteria found.
                    </td>
                  </tr>
                ) : (
                  filteredSales.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-3 px-3 font-mono text-slate-400">{s.invoiceDate}</td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-100">
                        <button
                          type="button"
                          onClick={() => handlePrint(s)}
                          className="hover:underline text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1 cursor-pointer transition-colors text-left"
                          title="Click to view & print invoice"
                        >
                          <Printer className="w-3 h-3 text-emerald-400" />
                          <span>{s.invoiceNo}</span>
                        </button>
                      </td>
                      <td className="py-3 px-3 font-bold">{s.customerName}</td>
                      <td className="py-3 px-3">
                        <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-400 uppercase font-bold">
                          {s.paymentMode}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono">₹{s.totalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-3 text-right font-mono text-slate-400">₹{s.totalTax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-3 text-right font-black text-slate-100">₹{s.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handlePrint(s)}
                            className="px-2.5 py-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/60 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                            title="Print GST Invoice"
                          >
                            <Printer className="w-3 h-3 text-emerald-400" />
                            <span>Print</span>
                          </button>
                          {onNavigateToReturnExchange && (
                            <button
                              onClick={() => onNavigateToReturnExchange(s.id)}
                              className="px-2.5 py-1 text-[10px] font-bold bg-red-950/60 hover:bg-red-900/70 text-red-300 border border-red-600/40 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                              title="Edit Sales Invoice in Sales Register Desk"
                            >
                              <Edit3 className="w-3 h-3 text-red-400" />
                              <span>Edit</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3">Purchase Bill No</th>
                  <th className="py-3 px-3">Supplier Bill No</th>
                  <th className="py-3 px-3">Supplier Name</th>
                  <th className="py-3 px-3">Mode</th>
                  <th className="py-3 px-3 text-right">Taxable</th>
                  <th className="py-3 px-3 text-right">IGST/CGST/SGST</th>
                  <th className="py-3 px-3 text-right">Grand Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                {filteredPurchases.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-slate-500 font-medium">
                      No purchase billing inward documents found.
                    </td>
                  </tr>
                ) : (
                  filteredPurchases.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-3 px-3 font-mono text-slate-400">{p.purchaseDate}</td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-100">{p.purchaseNo}</td>
                      <td className="py-3 px-3 font-mono text-indigo-400 font-bold">{p.supplierBillNo || 'N/A'}</td>
                      <td className="py-3 px-3 font-bold">{p.supplierName}</td>
                      <td className="py-3 px-3">
                        <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-400 uppercase font-bold">
                          {p.paymentMode}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono">₹{p.totalTaxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-3 text-right font-mono text-slate-400">₹{p.totalTax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-3 text-right font-black text-slate-100">₹{p.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Sales Invoice Print Preview Modal (Exact match to Tax Invoice & Retail Billing page) */}
      {selectedPrintInvoice && (
        <InvoicePrintModal
          invoice={selectedPrintInvoice}
          company={companyInfo}
          onClose={() => setSelectedPrintInvoice(null)}
          onAttachToNav={
            onOpenPrintPreviewTab
              ? () => {
                  const inv = selectedPrintInvoice;
                  setSelectedPrintInvoice(null);
                  onOpenPrintPreviewTab(inv, false);
                }
              : undefined
          }
        />
      )}
    </div>
  );
};
