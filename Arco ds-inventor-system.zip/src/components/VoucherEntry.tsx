import React, { useState, useEffect } from 'react';
import {
  Receipt,
  ArrowDownLeft,
  ArrowUpRight,
  Save,
  RotateCcw,
  History,
  CheckCircle2,
  AlertCircle,
  Building,
  Users,
} from 'lucide-react';
import { Customer, CustomerLedgerEntry, Supplier, SupplierLedgerEntry } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';

interface VoucherEntryProps {
  type: 'RECEIPT' | 'PAYMENT';
}

export const VoucherEntryComponent: React.FC<VoucherEntryProps> = ({ type }) => {
  const isReceipt = type === 'RECEIPT';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  const [partyId, setPartyId] = useState<string>('');
  const [voucherNo, setVoucherNo] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [amount, setAmount] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'Bank / Cheque' | 'UPI / QR' | 'NEFT / RTGS'>('Cash');
  const [refNumber, setRefNumber] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadData = () => {
    const custs = dbService.getCustomers();
    const sups = dbService.getSuppliers();
    setCustomers(custs);
    setSuppliers(sups);

    if (isReceipt && custs.length > 0) {
      setPartyId(custs[1]?.id || custs[0].id);
      const count = dbService.getCustomerLedgers().filter((l) => l.voucherType === 'RECEIPT').length + 1;
      setVoucherNo(`RCT-2026-${String(count).padStart(3, '0')}`);
    } else if (!isReceipt && sups.length > 0) {
      setPartyId(sups[0].id);
      const count = dbService.getSupplierLedgers().filter((l) => l.voucherType === 'PAYMENT').length + 1;
      setVoucherNo(`PMT-2026-${String(count).padStart(3, '0')}`);
    }
  };

  useEffect(() => {
    loadData();
  }, [type]);

  const selectedCustomer = customers.find((c) => c.id === partyId);
  const selectedSupplier = suppliers.find((s) => s.id === partyId);

  const currentPartyBalance = isReceipt
    ? selectedCustomer?.currentBalance || 0
    : selectedSupplier?.currentBalance || 0;

  const newBalance = isReceipt
    ? Math.max(0, roundTo2(currentPartyBalance - amount))
    : Math.max(0, roundTo2(currentPartyBalance - amount));

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyId) {
      setFeedback({ type: 'error', text: 'Select party account.' });
      return;
    }
    if (amount <= 0) {
      setFeedback({ type: 'error', text: 'Amount must be greater than 0.' });
      return;
    }

    if (isReceipt) {
      const cust = customers.find((c) => c.id === partyId);
      if (!cust) return;
      const prevBal = cust.currentBalance;
      const updatedBal = roundTo2(prevBal - amount);

      const entry: CustomerLedgerEntry = {
        id: `CL-${Date.now()}`,
        customerId: cust.id,
        date,
        voucherType: 'RECEIPT',
        voucherNo,
        particulars: `Amount Received by ${paymentMode}${refNumber ? ` (Ref: ${refNumber})` : ''} - ${remarks || 'On Account'}`,
        debit: 0,
        credit: Number(amount),
        balance: updatedBal,
      };

      dbService.saveCustomerLedger(entry);
      dbService.saveCustomer({
        ...cust,
        currentBalance: updatedBal,
      });
      setFeedback({ type: 'success', text: `Receipt of ${formatCurrency(amount)} recorded for ${cust.customerName}.` });
    } else {
      const sup = suppliers.find((s) => s.id === partyId);
      if (!sup) return;
      const prevBal = sup.currentBalance;
      const updatedBal = roundTo2(prevBal - amount);

      const entry: SupplierLedgerEntry = {
        id: `SL-${Date.now()}`,
        supplierId: sup.id,
        date,
        voucherType: 'PAYMENT',
        voucherNo,
        particulars: `Payment Made by ${paymentMode}${refNumber ? ` (Ref: ${refNumber})` : ''} - ${remarks || 'Vendor Clearing'}`,
        debit: Number(amount),
        credit: 0,
        balance: updatedBal,
      };

      dbService.saveSupplierLedger(entry);
      dbService.saveSupplier({
        ...sup,
        currentBalance: updatedBal,
      });
      setFeedback({ type: 'success', text: `Payment of ${formatCurrency(amount)} recorded to ${sup.supplierName}.` });
    }

    loadData();
    setAmount(0);
    setRefNumber('');
    setRemarks('');
  };

  return (
    <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-5 shadow-xl backdrop-blur-md text-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center shadow-inner ${
                isReceipt
                  ? 'bg-teal-600/20 text-teal-400 border border-teal-500/30'
                  : 'bg-rose-600/20 text-rose-400 border border-rose-500/30'
              }`}
            >
              {isReceipt ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>{isReceipt ? 'Customer Payment Receipt Voucher' : 'Supplier Payment Voucher'}</span>
                <span className="text-xs font-mono bg-slate-800/60 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700/50">
                  {isReceipt ? 'frmCustomerReceipt' : 'frmSupplierPayment'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {isReceipt ? 'Credit cash/bank inflow into customer khata' : 'Debit vendor account for bill clearance'}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Voucher Number</label>
              <input
                type="text"
                readOnly
                value={voucherNo}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Transaction Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as any)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-teal-500 focus:outline-none"
              >
                <option value="Cash">Cash In Hand</option>
                <option value="Bank / Cheque">Bank Cheque Deposit</option>
                <option value="UPI / QR">UPI / QR Transfer</option>
                <option value="NEFT / RTGS">NEFT / RTGS</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">
                {isReceipt ? 'Select Customer (Debtor)' : 'Select Supplier (Creditor)'}
              </label>
              <select
                required
                value={partyId}
                onChange={(e) => setPartyId(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-teal-500 focus:outline-none"
              >
                {isReceipt
                  ? customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.customerName} (Due: {formatCurrency(c.currentBalance)} Dr)
                      </option>
                    ))
                  : suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.supplierName} (Payable: {formatCurrency(s.currentBalance)} Cr)
                      </option>
                    ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Cheque / UTR / Transaction Ref #</label>
              <input
                type="text"
                value={refNumber}
                onChange={(e) => setRefNumber(e.target.value)}
                placeholder="e.g. CHQ-449102 / UTR998271"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Amount Box */}
          <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Current Ledger Balance</label>
                <div className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-3 py-2 text-amber-400 font-mono font-bold text-sm">
                  {formatCurrency(currentPartyBalance)}
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  {isReceipt ? 'Amount Received (₹) *' : 'Amount Paid (₹) *'}
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-3 py-2 text-emerald-400 font-mono font-black text-base focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Remaining Balance</label>
                <div className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-3 py-2 text-slate-200 font-mono font-bold text-sm">
                  {formatCurrency(newBalance)}
                </div>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">Particulars / Narration</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Received partial payment against bill #INV-2026-001"
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-700/40">
            <button
              type="submit"
              className={`flex items-center gap-1.5 px-5 py-2 text-white font-bold rounded-lg shadow-lg border transition ${
                isReceipt
                  ? 'bg-teal-600 hover:bg-teal-500 shadow-teal-900/20 border-teal-500/30'
                  : 'bg-rose-600 hover:bg-rose-500 shadow-rose-900/20 border-rose-500/30'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>{isReceipt ? 'Save Customer Receipt' : 'Save Supplier Payment'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
