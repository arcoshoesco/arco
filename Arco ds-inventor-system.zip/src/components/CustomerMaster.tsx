import React, { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Save,
  Trash2,
  Search,
  RotateCcw,
  CreditCard,
  Building,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Customer } from '../types';
import { dbService } from '../services/storage';
import { INDIAN_STATES, formatCurrency } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';

export const CustomerMasterComponent: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState<boolean>(false);

  // Form fields
  const [customerCode, setCustomerCode] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [contactPerson, setContactPerson] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [state, setState] = useState<string>('');
  const [stateCode, setStateCode] = useState<string>('');
  const [gstin, setGstin] = useState<string>('');
  const [pan, setPan] = useState<string>('');
  const [openingBalance, setOpeningBalance] = useState<number>(0);
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [creditLimit, setCreditLimit] = useState<number>(50000);
  const [creditDays, setCreditDays] = useState<number>(30);
  const [customerType, setCustomerType] = useState<'Retail' | 'Wholesale' | 'B2B'>('B2B');
  const [isActive, setIsActive] = useState<boolean>(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadCustomers = () => {
    const list = dbService.getCustomers();
    setCustomers(list);
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const resetForm = () => {
    setSelectedId(null);
    const count = customers.length + 1;
    setCustomerCode(`CUST-${String(count).padStart(3, '0')}`);
    setCustomerName('');
    setContactPerson('');
    setMobile('');
    setPhone('');
    setEmail('');
    setAddress('');
    setCity('');
    setState('');
    setStateCode('');
    setGstin('');
    setPan('');
    setOpeningBalance(0);
    setCurrentBalance(0);
    setCreditLimit(50000);
    setCreditDays(30);
    setCustomerType('B2B');
    setIsActive(true);
    setFeedback(null);
  };

  const handleSelectCustomer = (c: Customer) => {
    setSelectedId(c.id);
    setCustomerCode(c.customerCode);
    setCustomerName(c.customerName);
    setContactPerson(c.contactPerson || '');
    setMobile(c.mobile || '');
    setPhone(c.phone || '');
    setEmail(c.email || '');
    setAddress(c.address || '');
    setCity(c.city || '');
    setState(c.state || '');
    setStateCode(c.stateCode || '');
    setGstin(c.gstin || '');
    setPan(c.pan || '');
    setOpeningBalance(c.openingBalance || 0);
    setCurrentBalance(c.currentBalance || 0);
    setCreditLimit(c.creditLimit || 0);
    setCreditDays(c.creditDays || 0);
    setCustomerType(c.customerType || 'B2B');
    setIsActive(c.isActive);
    setFeedback(null);
  };

  const handleStateChange = (selectedStateName: string) => {
    setState(selectedStateName);
    const st = INDIAN_STATES.find((s) => s.name === selectedStateName);
    if (st) {
      setStateCode(st.code);
    } else {
      setStateCode('');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Customer Name is required.' });
      return;
    }

    const isUpdate = Boolean(selectedId);
    const customer: Customer = {
      id: selectedId || `CUST-${Date.now()}`,
      customerCode: customerCode.trim().toUpperCase() || `CUST-${Date.now()}`,
      customerName: customerName.trim(),
      contactPerson: contactPerson.trim(),
      mobile: mobile.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      city: city.trim(),
      state,
      stateCode,
      gstin: gstin.trim().toUpperCase(),
      pan: pan.trim().toUpperCase(),
      openingBalance: Number(openingBalance) || 0,
      currentBalance: selectedId ? Number(currentBalance) : Number(openingBalance) || 0,
      creditLimit: Number(creditLimit) || 0,
      creditDays: Number(creditDays) || 0,
      customerType,
      isActive,
      createdAt: selectedId ? customers.find((c) => c.id === selectedId)?.createdAt || '' : new Date().toISOString().split('T')[0],
    };

    dbService.saveCustomer(customer);
    loadCustomers();
    setFeedback({
      type: 'success',
      title: isUpdate ? 'Customer Updated Successfully' : 'Customer Saved Successfully',
      text: isUpdate
        ? `Customer "${customer.customerName}" has been updated successfully!`
        : `Customer "${customer.customerName}" has been saved successfully!`,
    });
    if (!selectedId) {
      resetForm();
    }
  };

  const handleDelete = () => {
    if (!selectedId) return;
    setShowConfirmDelete(true);
  };

  const confirmDeleteCustomer = () => {
    if (!selectedId) return;
    const res = dbService.deleteCustomer(selectedId);
    setShowConfirmDelete(false);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Customer Deleted Successfully',
        text: res.message,
      });
      loadCustomers();
      resetForm();
    } else {
      setFeedback({ type: 'error', title: 'Delete Operation Failed', text: res.message });
    }
  };

  const filteredCustomers = customers.filter(
    (c) =>
      c.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.customerCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.mobile && c.mobile.includes(searchQuery)) ||
      (c.gstin && c.gstin.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal */}
      {showConfirmDelete && (
        <ConfirmModal
          title="Delete Customer Account"
          message="Are you sure you want to delete this customer account? This action cannot be undone."
          confirmLabel="Delete Customer"
          onConfirm={confirmDeleteCustomer}
          onCancel={() => setShowConfirmDelete(false)}
        />
      )}

      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Customer Form Panel (frmCustomerMaster) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
          <div className="flex items-center justify-between border-b border-slate-700/40 pb-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shadow-inner">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <span>{selectedId ? 'Edit Customer' : 'Customer Account Master'}</span>
                </h2>
                <p className="text-xs text-slate-400">Buyer KYC, GSTIN, credit limits & account balances</p>
              </div>
            </div>

            <button
              id="btn-new-customer"
              type="button"
              onClick={resetForm}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 text-xs font-medium border border-slate-700/50 backdrop-blur-sm transition"
            >
              <RotateCcw className="w-3.5 h-3.5 text-purple-400" />
              <span>New</span>
            </button>
          </div>

          <form id="form-customer-master" onSubmit={handleSave} className="space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Customer Code</label>
                <input
                  type="text"
                  value={customerCode}
                  onChange={(e) => setCustomerCode(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold uppercase focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-slate-400 font-medium mb-1">Customer / Business Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Royal Footwear & Garments"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="Mr. Rajesh Sharma"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Customer Type</label>
                <select
                  value={customerType}
                  onChange={(e) => setCustomerType(e.target.value as any)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-purple-500 focus:outline-none text-xs"
                >
                  <option value="B2B">B2B (Registered Business)</option>
                  <option value="Wholesale">Wholesale Distributor</option>
                  <option value="Retail">Retail Consumer</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Mobile No.</label>
                <input
                  type="text"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="9820198765"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Email ID</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="client@domain.com"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Billing & Delivery Address</label>
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Shop address / locality"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">State</label>
                <select
                  value={state}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-1.5 py-1.5 text-slate-100 focus:border-purple-500 focus:outline-none text-xs"
                >
                  <option value="">Select State</option>
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.name}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">GST State Code</label>
                <input
                  type="text"
                  readOnly
                  value={stateCode}
                  className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-2 py-1.5 text-purple-400 font-mono font-bold text-center"
                />
              </div>
            </div>

            {/* GSTIN and PAN */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">GSTIN No. (15 Digit)</label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  placeholder="27AAACR4589L1Z5"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">PAN No.</label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={(e) => setPan(e.target.value.toUpperCase())}
                  placeholder="AAACR4589L"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Financials */}
            <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
              <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">
                Khata Balance & Credit Policy
              </span>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Opening Bal (₹)</label>
                  <input
                    type="number"
                    disabled={Boolean(selectedId)}
                    value={openingBalance}
                    onChange={(e) => {
                      setOpeningBalance(Number(e.target.value));
                      if (!selectedId) setCurrentBalance(Number(e.target.value));
                    }}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono disabled:opacity-50 focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Credit Limit (₹)</label>
                  <input
                    type="number"
                    value={creditLimit}
                    onChange={(e) => setCreditLimit(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Credit Days</label>
                  <input
                    type="number"
                    value={creditDays}
                    onChange={(e) => setCreditDays(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              {selectedId && (
                <div className="flex items-center justify-between pt-1.5 border-t border-slate-800 text-[11px]">
                  <span className="text-slate-400">Store Credit Wallet Balance:</span>
                  <span className="font-mono font-bold text-emerald-400">
                    {formatCurrency(customers.find((c) => c.id === selectedId)?.creditBalance || 0)}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/40">
              {selectedId && selectedId !== 'CUST-000' ? (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold backdrop-blur-sm transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              ) : (
                <div />
              )}

              <button
                id="btn-save-customer-master"
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg shadow-lg shadow-purple-900/20 border border-purple-500/30 transition"
              >
                <Save className="w-4 h-4" />
                <span>{selectedId ? 'Update Customer' : 'Save Customer [F9]'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Customer Accounts Directory Table */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3 mb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Customer Directory & Outstanding</span>
                <span className="bg-slate-800/60 text-purple-400 font-mono text-xs px-2 py-0.5 rounded border border-slate-700/50">
                  {filteredCustomers.length} accounts
                </span>
              </h3>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search name/code/GSTIN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 text-xs focus:border-purple-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto flex-1 max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-2.5">Code</th>
                  <th className="py-2.5 px-2">Customer Name</th>
                  <th className="py-2.5 px-2">Mobile / City</th>
                  <th className="py-2.5 px-2 text-center">GSTIN</th>
                  <th className="py-2.5 px-2 text-center">Type</th>
                  <th className="py-2.5 px-2 text-right">Store Credit</th>
                  <th className="py-2.5 px-2 text-right">Outstanding (Dr)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredCustomers.map((c) => {
                  const isSelected = selectedId === c.id;
                  return (
                    <tr
                      key={c.id}
                      onClick={() => handleSelectCustomer(c)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-purple-950/40 border-l-4 border-purple-500 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-mono font-bold text-purple-400">{c.customerCode}</td>
                      <td className="py-2.5 px-2 font-medium">
                        <div className="text-slate-100">{c.customerName}</div>
                        {c.contactPerson && <div className="text-[10px] text-slate-400">Attn: {c.contactPerson}</div>}
                      </td>
                      <td className="py-2.5 px-2">
                        <div className="font-mono">{c.mobile || '-'}</div>
                        <div className="text-[10px] text-slate-400">{c.city}, {c.stateCode}</div>
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-[11px]">
                        {c.gstin ? <span className="text-emerald-400 font-semibold">{c.gstin}</span> : <span className="text-slate-500">Unregistered</span>}
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <span className="bg-slate-800/80 px-1.5 py-0.5 rounded text-[10px] text-slate-300">
                          {c.customerType}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-emerald-400 text-xs">
                        {c.creditBalance && c.creditBalance > 0 ? formatCurrency(c.creditBalance) : '₹0.00'}
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-amber-400 text-sm">
                        {formatCurrency(c.currentBalance)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
