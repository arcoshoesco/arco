import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  AlertCircle,
  Laptop,
  ShieldCheck,
  HelpCircle,
  Info,
  Layers,
  Sparkles,
  ExternalLink,
  AppWindow,
  RefreshCw,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const InstallAppSection: React.FC = () => {
  const {
    isInstalled,
    isInstallable,
    hasPrompt,
    isSecure,
    browserInfo,
    outcome,
    install,
  } = usePWAInstall();

  const [isInstalling, setIsInstalling] = useState(false);
  const [installError, setInstallError] = useState<string | null>(null);
  const [shortcutDownloaded, setShortcutDownloaded] = useState(false);

  const handleDownloadShortcut = () => {
    try {
      const baseUrl = window.location.origin;
      const shortcutContent = `[InternetShortcut]
URL=${baseUrl}/
IconFile=${baseUrl}/favicon.ico
IconIndex=0
HotKey=0
IDList=
[{000214A0-0000-0000-C000-000000000046}]
Prop3=19,11
[ViewState]
Mode=
Vid=
FolderType=Generic
`;
      const blob = new Blob([shortcutContent], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ARCO SHOES.url';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setShortcutDownloaded(true);
      setTimeout(() => setShortcutDownloaded(false), 4000);
    } catch (e: any) {
      console.error('Failed to create shortcut file:', e);
    }
  };

  const handleDownloadIco = () => {
    const a = document.createElement('a');
    a.href = '/favicon.ico';
    a.download = 'ARCO_SHOES.ico';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleOpenStandalone = () => {
    window.open(window.location.origin, '_blank', 'noopener,noreferrer');
  };

  const handleInstallClick = async () => {
    setInstallError(null);
    setIsInstalling(true);
    try {
      const result = await install();
      if (result.outcome === 'dismissed') {
        setInstallError('Installation prompt was dismissed. You can click Install again anytime.');
      } else if (result.outcome === 'unavailable') {
        setInstallError(
          'The browser has not triggered the in-page prompt yet. Use "Open in Full Tab" or the address bar install icon to add to desktop.'
        );
      }
    } catch (err: any) {
      setInstallError(err?.message || 'An error occurred while launching installation prompt.');
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <div className="space-y-6 text-slate-100 max-w-5xl">
      {/* Top Banner Card */}
      <div className="bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-950/90 border border-slate-700/60 rounded-2xl p-6 shadow-2xl backdrop-blur-md relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl p-1 bg-slate-950 border-2 border-amber-400/50 shadow-xl shadow-amber-500/15 flex items-center justify-center shrink-0 overflow-hidden">
              <img
                src="/icon.png"
                alt="ARCO SHOES Desktop Icon"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-xl font-black tracking-tight text-white">
                  Install App
                </h2>
                {isInstalled ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    App is installed
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-800/80 text-amber-300 border border-amber-500/30">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                    Ready to Install on Desktop
                  </span>
                )}
              </div>
              <p className="text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Add ARCO SHOES as a standalone desktop application with this official brand icon directly on your computer desktop, taskbar, and Start menu.
              </p>
            </div>
          </div>

          {/* Action Button Section */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto shrink-0">
            {isInstalled ? (
              <div className="flex items-center gap-3 px-5 py-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-sm font-semibold shadow-lg backdrop-blur-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold text-white">ARCO SHOES is installed on this computer.</div>
                  <div className="text-xs text-emerald-400 font-normal mt-0.5">
                    Launch anytime from Windows Desktop or Start Menu.
                  </div>
                </div>
              </div>
            ) : (
              <>
                <button
                  type="button"
                  id="btn-install-arco-app"
                  disabled={isInstalling}
                  onClick={handleInstallClick}
                  className="flex items-center justify-center gap-2.5 px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/25 border border-amber-300 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer disabled:opacity-50"
                  title="Install ARCO SHOES directly into your Windows desktop and taskbar"
                >
                  {isInstalling ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  ) : (
                    <img
                      src="/pwa-128x128.png"
                      alt="Install"
                      referrerPolicy="no-referrer"
                      className="w-5 h-5 rounded-md object-cover border border-slate-950/40 shadow-sm"
                    />
                  )}
                  <span>Install App</span>
                </button>

                <button
                  type="button"
                  id="btn-download-desktop-shortcut"
                  onClick={handleDownloadShortcut}
                  className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs border border-slate-700 shadow-md hover:border-amber-400/50 transition cursor-pointer"
                  title="Download an instant Windows Desktop Shortcut (.url file) with the ARCO SHOES icon"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download Shortcut (.url)</span>
                </button>

                <button
                  type="button"
                  id="btn-open-full-tab"
                  onClick={handleOpenStandalone}
                  className="flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white text-xs border border-slate-800 transition cursor-pointer"
                  title="Open in full browser window to access native Chrome/Edge address bar install prompt"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
                  <span className="hidden sm:inline">Open Full Tab</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Feedback / Error / Success Notice */}
        {shortcutDownloaded && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong>ARCO SHOES.url</strong> downloaded! Drag or copy it to your Windows Desktop to launch ARCO SHOES anytime with the official desktop icon.
            </span>
          </div>
        )}

        {/* Feedback / Error Notice */}
        {installError && (
          <div className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{installError}</span>
          </div>
        )}

        {outcome === 'accepted' && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Installation accepted! ARCO SHOES is now installed on your computer.</span>
          </div>
        )}
      </div>

      {/* Grid: Benefits / System Features & Status Details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Windows Desktop Shortcut */}
        <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 shadow-lg backdrop-blur-sm">
          <div className="w-10 h-10 rounded-xl p-0.5 bg-slate-800/90 border border-sky-400/40 flex items-center justify-center mb-3 overflow-hidden shadow-inner">
            <img
              src="/pwa-128x128.png"
              alt="Desktop Shortcut Icon"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <h3 className="font-bold text-sm text-slate-100">1. Windows Desktop Shortcut</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Installs with the official ARCO SHOES 3D emblem directly on your Windows desktop. Launches into an isolated, standalone app window with no browser tabs or address bar clutter.
          </p>
        </div>

        {/* Card 2: Windows Start Menu */}
        <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 shadow-lg backdrop-blur-sm">
          <div className="w-10 h-10 rounded-xl p-0.5 bg-slate-800/90 border border-amber-400/40 flex items-center justify-center mb-3 overflow-hidden shadow-inner">
            <img
              src="/pwa-128x128.png"
              alt="Taskbar & Start Menu Icon"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <h3 className="font-bold text-sm text-slate-100">2. Windows Start Menu &amp; Taskbar</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Search for &ldquo;ARCO SHOES&rdquo; in your Windows Start Menu or pin the branded icon to your Windows Taskbar for 1-click showroom cashier access.
          </p>
        </div>

        {/* Card 3: Enterprise Database Protection */}
        <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-5 shadow-lg backdrop-blur-sm">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mb-3">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-100">3. Live Cloud Database Safety</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            The service worker caches only static application code. Dynamic sales bills, inventory stocks, and customer ledgers always sync live with your secure database.
          </p>
        </div>
      </div>

      {/* Desktop Icon & Shortcut Verification Card */}
      <div className="bg-slate-900/70 border border-amber-500/40 rounded-2xl p-6 shadow-xl backdrop-blur-md space-y-5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 pb-5 border-b border-slate-800">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl p-1 bg-slate-950 border-2 border-amber-400/60 shadow-lg shadow-amber-500/20 flex items-center justify-center shrink-0 overflow-hidden">
              <img
                src="/pwa-512x512.png"
                alt="Desktop Icon"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="font-black text-base text-white">Official Desktop Shortcut Icon</h4>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Active in Manifest
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40">
                  Windows 10 / 11 Ready
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                This exact icon is registered in the Web App Manifest and Windows icon resources. When you install ARCO SHOES, Windows places this branded shortcut directly on your desktop.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto shrink-0">
            <button
              type="button"
              id="btn-download-ico"
              onClick={handleDownloadIco}
              className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 hover:border-amber-400/50 transition cursor-pointer"
              title="Download the official multi-resolution Windows .ICO file (16px to 256px)"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Download .ICO File</span>
            </button>
            <button
              type="button"
              id="btn-download-shortcut-card"
              onClick={handleDownloadShortcut}
              className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold border border-amber-500/40 transition cursor-pointer"
              title="Download ready-to-use Windows Internet Shortcut"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              <span>Download .URL Shortcut</span>
            </button>
          </div>
        </div>

        {/* 3 Visual Previews: Windows Desktop, Taskbar, and Start Menu */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-1">
          {/* Preview 1: Windows Desktop */}
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col items-center text-center">
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
              Windows Desktop
            </span>
            <div className="relative group my-1">
              <div className="w-14 h-14 rounded-2xl p-0.5 bg-slate-900 border border-slate-700 shadow-xl flex items-center justify-center overflow-hidden">
                <img
                  src="/pwa-256x256.png"
                  alt="Desktop Icon Preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-xl"
                />
              </div>
              {/* Little Windows shortcut curved arrow overlay */}
              <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-white/95 rounded-sm border border-slate-400 shadow flex items-center justify-center text-[9px] font-black text-blue-600 select-none">
                ↗
              </div>
            </div>
            <span className="text-xs font-bold text-white mt-2">ARCO SHOES</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Desktop Shortcut (.lnk)</span>
          </div>

          {/* Preview 2: Windows Taskbar */}
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col items-center text-center">
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
              Windows Taskbar
            </span>
            <div className="p-1 px-4 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-center my-2 shadow-inner">
              <div className="w-10 h-10 rounded-lg p-0.5 bg-slate-950 border border-amber-400/40 flex items-center justify-center overflow-hidden">
                <img
                  src="/pwa-128x128.png"
                  alt="Taskbar Icon Preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-md"
                />
              </div>
            </div>
            <span className="text-xs font-bold text-white mt-1">Pinned to Taskbar</span>
            <span className="text-[10px] text-slate-400 mt-0.5">1-click Quick Launch</span>
          </div>

          {/* Preview 3: Windows Start Menu */}
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col items-center text-center">
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
              Start Menu Tile
            </span>
            <div className="w-14 h-14 rounded-xl p-1 bg-slate-900 border border-slate-700 flex flex-col items-center justify-center my-1 shadow-md">
              <img
                src="/pwa-128x128.png"
                alt="Start Menu Icon Preview"
                referrerPolicy="no-referrer"
                className="w-8 h-8 object-cover rounded-md"
              />
              <span className="text-[8px] font-semibold text-slate-300 mt-0.5 truncate max-w-full">ARCO</span>
            </div>
            <span className="text-xs font-bold text-white mt-1">Windows Start Menu</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Search &amp; All Apps List</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Automatic Windows Integration:</strong> When installing through Google Chrome or Microsoft Edge, Chromium reads the manifest icons and automatically generates the Windows Desktop shortcut (<code className="text-amber-300 font-mono">ARCO SHOES.lnk</code>) and Start Menu item with this exact emblem.
          </div>
        </div>
      </div>

      {/* Browser Compatibility Notice */}
      {!browserInfo.isChromeOrEdge && (
        <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-sm text-white">Browser Compatibility Notice</div>
            <p className="mt-1 text-slate-300 leading-relaxed">
              Installation is currently unavailable in this browser ({browserInfo.name}). Please open ARCO SHOES in <strong>Google Chrome</strong> or <strong>Microsoft Edge</strong> and try again.
            </p>
          </div>
        </div>
      )}

      {/* How to Install Guide (Section 11) */}
      <div className="bg-slate-900/60 border border-slate-700/60 rounded-2xl p-6 shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-700/50 mb-4">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">How to install ARCO SHOES</h3>
            <p className="text-xs text-slate-400">Step-by-step instructions for Windows 10 & 11</p>
          </div>
        </div>

        <ol className="space-y-3.5 text-xs text-slate-300">
          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              1
            </span>
            <div>
              <strong className="text-white">Open ARCO SHOES in Google Chrome or Microsoft Edge.</strong>
              <div className="text-slate-400 mt-0.5">
                Modern Chromium engines provide native Windows integration and desktop shortcut generation.
              </div>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              2
            </span>
            <div>
              <strong className="text-white">Go to Settings.</strong>
              <div className="text-slate-400 mt-0.5">
                Navigate to Company Settings from the top navigation bar or menu.
              </div>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              3
            </span>
            <div>
              <strong className="text-white">Open &ldquo;Install App&rdquo;.</strong>
              <div className="text-slate-400 mt-0.5">
                Select this tab to access the installation engine and status monitor.
              </div>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              4
            </span>
            <div>
              <strong className="text-white">Click &ldquo;Install App&rdquo;.</strong>
              <div className="text-slate-400 mt-0.5">
                This safely prompts your browser&apos;s standard Progressive Web App installer dialog.
              </div>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              5
            </span>
            <div>
              <strong className="text-white">Confirm the installation.</strong>
              <div className="text-slate-400 mt-0.5">
                In the browser dialog, click &ldquo;Install&rdquo;. Windows will automatically register the application icon, desktop shortcut, and Start Menu entry.
              </div>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
              6
            </span>
            <div>
              <strong className="text-white">
                ARCO SHOES will become available as a Windows application and can be launched from the Desktop/Start Menu.
              </strong>
              <div className="text-slate-400 mt-0.5">
                The application opens in its own clean window, isolated from regular browser tabs.
              </div>
            </div>
          </li>
        </ol>

        {/* Alternative Address Bar Install Tip */}
        <div className="mt-5 p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-slate-200 font-medium">Alternative Browser Address Bar Method:</span>{' '}
            You can also install ARCO SHOES by clicking the <strong className="text-sky-300">&ldquo;Install ARCO SHOES&rdquo;</strong> icon (computer screen with a down arrow) located in the right corner of your browser&apos;s address bar in Google Chrome or Microsoft Edge, or via the browser menu (&hellip;) &rarr; <span className="text-slate-200">Apps &rarr; Install ARCO SHOES</span>.
          </div>
        </div>
      </div>

      {/* Technical & Security Details (HTTPS, Windows Security, Database Architecture) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* HTTPS Requirement */}
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-slate-200 font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>HTTPS & Secure Context Requirement</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Modern browsers require a secure origin (<code className="text-amber-300 font-mono">https://</code> or{' '}
            <code className="text-amber-300 font-mono">localhost</code>) to permit Progressive Web App installation and service workers. If accessed via an unencrypted plain HTTP local LAN IP, the browser will restrict installation until served through HTTPS or trusted loopback.
          </p>
        </div>

        {/* Windows Security Standards */}
        <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-slate-200 font-bold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Standard Windows PWA Security</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            The installation uses the official Chromium/Edge PWA standard. In accordance with Windows security guidelines, browser JavaScript does not execute arbitrary shell commands or write raw <code className="text-amber-300 font-mono">.lnk</code> files. Instead, the browser itself registers the desktop shortcut, Start Menu entry, and Windows uninstaller.
          </p>
        </div>
      </div>
    </div>
  );
};
