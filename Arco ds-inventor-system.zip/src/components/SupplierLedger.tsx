import React, { useState } from 'react';
import {
  Building2,
  Search,
  Calendar,
  Printer,
  Download,
  Receipt,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
  FileSpreadsheet,
  Building,
  Phone,
  MapPin,
  CreditCard,
} from 'lucide-react';
import { CompanyInfo, Supplier, LedgerEntry } from '../types';
import { dbService } from '../services/storage';
import { formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SupplierLedgerPrintModal } from './SupplierLedgerPrintModal';

interface SupplierLedgerProps {
  company: CompanyInfo;
  onNavigateToPayment?: (supplierId?: string) => void;
}

export const SupplierLedgerComponent: React.FC<SupplierLedgerProps> = ({
  company,
  onNavigateToPayment,
}) => {
  const suppliers = dbService.getSuppliers();
  const allLedgers = dbService.getLedgers();

  const [selectedSupplierId, setSelectedSupplierId] = useState<string>(
    suppliers.length > 0 ? suppliers[0].id : 'SUP-001'
  );
  const [supplierSearch, setSupplierSearch] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>('2026-08-01');
  const [toDate, setToDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [voucherFilter, setVoucherFilter] = useState<string>('ALL');
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  const selectedSupplier = suppliers.find((s) => s.id === selectedSupplierId) || suppliers[0];

  // Filtered supplier list for selector
  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.supplierName.toLowerCase().includes(supplierSearch.toLowerCase()) ||
      (s.mobile && s.mobile.includes(supplierSearch)) ||
      (s.city && s.city.toLowerCase().includes(supplierSearch.toLowerCase())) ||
      (s.gstin && s.gstin.toLowerCase().includes(supplierSearch.toLowerCase()))
  );

  // Raw ledgers for this supplier
  const supplierLedgers = allLedgers.filter(
    (l) => l.partyType === 'Supplier' && l.partyId === selectedSupplierId
  );

  // Calculate Opening Balance prior to fromDate
  // For suppliers: Credit = Inward purchases, Debit = Outward payments
  const preDateEntries = supplierLedgers.filter((l) => l.date < fromDate);
  const preDebit = preDateEntries.reduce((sum, l) => sum + (l.debit || 0), 0);
  const preCredit = preDateEntries.reduce((sum, l) => sum + (l.credit || 0), 0);
  const openingBalance = roundTo2(
    (selectedSupplier ? selectedSupplier.openingBalance || 0 : 0) + preCredit - preDebit
  );

  // Period entries
  const periodEntries = supplierLedgers
    .filter((l) => l.date >= fromDate && l.date <= toDate)
    .filter((l) => (voucherFilter === 'ALL' ? true : l.voucherType === voucherFilter))
    .sort((a, b) => a.date.localeCompare(b.date));

  // Compute running balance for each row
  let running = openingBalance;
  const rowsWithBalance = periodEntries.map((entry) => {
    running = roundTo2(running + (entry.credit || 0) - (entry.debit || 0));
    return {
      ...entry,
      calculatedBalance: running,
    };
  });

  const periodTotalDebit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.debit || 0), 0));
  const periodTotalCredit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.credit || 0), 0));
  const closingBalance = rowsWithBalance.length > 0
    ? rowsWithBalance[rowsWithBalance.length - 1].calculatedBalance
    : openingBalance;

  // Export CSV
  const handleExportCSV = () => {
    if (!selectedSupplier) return;
    const headers = ['Date', 'Voucher Type', 'Voucher No', 'Particulars', 'Debit (Rs)', 'Credit (Rs)', 'Balance (Rs)'];
    const rows = [
      [`Opening Balance as on ${fromDate}`, '', '', '', '', '', `${openingBalance.toFixed(2)} ${openingBalance >= 0 ? 'Cr' : 'Dr'}`],
      ...rowsWithBalance.map((r) => [
        r.date,
        r.voucherType,
        r.voucherNo,
        `"${(r.narration || '').replace(/"/g, '""')}"`,
        r.debit > 0 ? r.debit.toFixed(2) : '',
        r.credit > 0 ? r.credit.toFixed(2) : '',
        `${Math.abs(r.calculatedBalance).toFixed(2)} ${r.calculatedBalance >= 0 ? 'Cr' : 'Dr'}`,
      ]),
      ['TOTALS', '', '', '', periodTotalDebit.toFixed(2), periodTotalCredit.toFixed(2), `${Math.abs(closingBalance).toFixed(2)} ${closingBalance >= 0 ? 'Cr' : 'Dr'}`],
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Supplier_Ledger_${selectedSupplier.supplierName.replace(/\s+/g, '_')}_${fromDate}_to_${toDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none text-slate-100">
      {/* Top Header Card */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shadow-inner">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-base sm:text-lg text-slate-100">Supplier Account Ledger</h2>
              <span className="text-xs font-mono bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded border border-indigo-800/60">
                Vendor Khata
              </span>
            </div>
            <p className="text-xs text-slate-400">Statement of Purchases, Stock Inward Bills, Payments & Vendor Balance</p>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToPayment && (
            <button
              onClick={() => onNavigateToPayment(selectedSupplierId)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-lg shadow-sm border border-rose-500/30 text-xs transition cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
          )}

          <button
            onClick={() => setShowPrintModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-indigo-400" />
            <span>Print Statement</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 rounded-lg text-xs font-semibold backdrop-blur-sm transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Selection Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Supplier Select / Search Card */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md space-y-2.5">
          <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Select Supplier / Manufacturer
          </label>
          <div className="flex items-center gap-2">
            <select
              value={selectedSupplierId}
              onChange={(e) => setSelectedSupplierId(e.target.value)}
              className="flex-1 bg-slate-950/80 border border-slate-700/60 rounded-lg px-2.5 py-2 text-slate-100 font-semibold focus:border-indigo-500 focus:outline-none text-xs"
            >
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.supplierName} {s.city ? `(${s.city})` : ''} - Bal: ₹{s.currentBalance.toFixed(2)}
                </option>
              ))}
            </select>
          </div>

          {/* Search filter for fast locating */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search by supplier name, phone or GSTIN..."
              value={supplierSearch}
              onChange={(e) => setSupplierSearch(e.target.value)}
              className="w-full bg-slate-950/60 border border-slate-700/50 rounded-lg pl-8 pr-2.5 py-1.5 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {supplierSearch.trim() && (
            <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
              {filteredSuppliers.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedSupplierId(s.id);
                    setSupplierSearch('');
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition ${
                    selectedSupplierId === s.id
                      ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                      : 'bg-slate-950/40 text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <span className="font-semibold truncate">{s.supplierName}</span>
                  <span className="font-mono text-[11px] text-amber-400">₹{s.currentBalance.toFixed(2)}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Date Filter & Voucher Type Filter */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-xl backdrop-blur-md flex flex-col justify-between gap-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Date & Voucher Filter
            </span>
            <div className="flex items-center gap-1.5 text-[10px]">
              <button
                onClick={() => {
                  const now = new Date();
                  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
                  const today = now.toISOString().split('T')[0];
                  setFromDate(firstDay);
                  setToDate(today);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                This Month
              </button>
              <button
                onClick={() => {
                  setFromDate('2026-04-01');
                  setToDate(new Date().toISOString().split('T')[0]);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                FY 2026-27
              </button>
              <button
                onClick={() => {
                  setFromDate('2026-01-01');
                  setToDate(new Date().toISOString().split('T')[0]);
                }}
                className="px-2 py-0.5 rounded bg-slate-800/60 hover:bg-slate-700 text-slate-300 border border-slate-700/50 transition"
              >
                All Time
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400">From:</span>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400">To:</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full bg-transparent text-slate-200 font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/70 px-2 py-1 rounded-lg border border-slate-700/60">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={voucherFilter}
                onChange={(e) => setVoucherFilter(e.target.value)}
                className="w-full bg-transparent text-slate-200 focus:outline-none text-xs font-semibold"
              >
                <option value="ALL">All Vouchers</option>
                <option value="Purchase">Purchases Only</option>
                <option value="Payment">Payments Only</option>
                <option value="Purchase Return">Returns Only</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Supplier Info Card & Metric Summary */}
      {selectedSupplier && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Party Snapshot */}
          <div className="md:col-span-4 bg-slate-900/30 border border-slate-700/50 rounded-xl p-3.5 backdrop-blur-sm space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-slate-100">{selectedSupplier.supplierName}</span>
              <span className="font-mono text-[11px] text-slate-400 bg-slate-800/80 px-1.5 py-0.2 rounded border border-slate-700/50">
                {selectedSupplier.id}
              </span>
            </div>
            <p className="text-slate-400 flex items-center gap-1.5">
              <Phone className="w-3 h-3 text-slate-500" />
              <span>Phone: <strong className="text-slate-200 font-mono">{selectedSupplier.mobile || selectedSupplier.phone || 'N/A'}</strong></span>
            </p>
            <p className="text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3 h-3 text-slate-500" />
              <span>Address: <strong className="text-slate-200">{selectedSupplier.address || ''} {selectedSupplier.city || ''}</strong></span>
            </p>
            <p className="text-slate-400 flex items-center gap-1.5">
              <Building className="w-3 h-3 text-slate-500" />
              <span>GSTIN: <strong className="text-slate-200 font-mono">{selectedSupplier.gstin || 'Unregistered'}</strong></span>
            </p>
          </div>

          {/* Metric KPI cards */}
          <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Opening Balance</span>
              <span className="text-base font-bold text-slate-200 mt-1 block">
                ₹{Math.abs(openingBalance).toFixed(2)}
                <span className="text-[10px] ml-1 text-slate-400">{openingBalance >= 0 ? 'Cr' : 'Dr'}</span>
              </span>
            </div>

            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[10px] uppercase tracking-wider flex items-center gap-1 text-indigo-400">
                <ArrowDownLeft className="w-3 h-3" />
                <span>Period Credits (Purchases)</span>
              </span>
              <span className="text-base font-bold text-indigo-400 mt-1 block">
                ₹{periodTotalCredit.toFixed(2)}
              </span>
            </div>

            <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3 shadow-xl backdrop-blur-md">
              <span className="text-slate-400 block text-[10px] uppercase tracking-wider flex items-center gap-1 text-rose-400">
                <ArrowUpRight className="w-3 h-3" />
                <span>Period Debits (Paid)</span>
              </span>
              <span className="text-base font-bold text-rose-400 mt-1 block">
                ₹{periodTotalDebit.toFixed(2)}
              </span>
            </div>

            <div className={`border rounded-xl p-3 shadow-xl backdrop-blur-md ${
              closingBalance > 0
                ? 'bg-rose-950/30 border-rose-800/50'
                : 'bg-emerald-950/30 border-emerald-800/50'
            }`}>
              <span className="block text-[10px] uppercase tracking-wider font-bold text-amber-400">
                Closing Payable Due
              </span>
              <span className={`text-lg font-black mt-1 block ${
                closingBalance > 0 ? 'text-rose-300' : 'text-emerald-300'
              }`}>
                ₹{Math.abs(closingBalance).toFixed(2)}
                <span className="text-xs ml-1 font-bold">{closingBalance >= 0 ? 'Cr (Payable)' : 'Dr (Advance Paid)'}</span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Ledger Statement Table */}
      <div className="bg-slate-900/30 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden">
        <div className="p-3 bg-slate-800/40 border-b border-slate-700/50 flex items-center justify-between text-xs backdrop-blur-sm">
          <span className="font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <span>Supplier Transaction Ledger Entries</span>
            <span className="text-slate-400 font-mono font-normal">({rowsWithBalance.length} records)</span>
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            Period: {fromDate} to {toDate}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/60 border-b border-slate-700/60 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="p-2.5">Date</th>
                <th className="p-2.5">Voucher Type</th>
                <th className="p-2.5">Vch No / Bill Ref</th>
                <th className="p-2.5">Particulars / Narration</th>
                <th className="p-2.5 text-right text-rose-400">Debit / Paid (₹)</th>
                <th className="p-2.5 text-right text-indigo-400">Credit / Purchase (₹)</th>
                <th className="p-2.5 text-right text-amber-300">Balance (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {/* Opening Balance Row */}
              <tr className="bg-slate-900/50 font-semibold text-slate-300">
                <td className="p-2.5 font-mono text-slate-400">{fromDate}</td>
                <td className="p-2.5">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-slate-300 border border-slate-700">
                    B/F
                  </span>
                </td>
                <td className="p-2.5 font-mono text-slate-500">-</td>
                <td className="p-2.5 text-slate-300">Opening Balance Brought Forward</td>
                <td className="p-2.5 text-right font-mono">-</td>
                <td className="p-2.5 text-right font-mono">-</td>
                <td className="p-2.5 text-right font-mono font-bold text-amber-300">
                  ₹{Math.abs(openingBalance).toFixed(2)} {openingBalance >= 0 ? 'Cr' : 'Dr'}
                </td>
              </tr>

              {rowsWithBalance.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    No transactions recorded for this supplier in the selected date range.
                  </td>
                </tr>
              ) : (
                rowsWithBalance.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-2.5 font-mono text-slate-400 whitespace-nowrap">{row.date}</td>
                    <td className="p-2.5 whitespace-nowrap">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold uppercase tracking-wider border ${
                          row.voucherType === 'Purchase'
                            ? 'bg-indigo-950/80 text-indigo-300 border-indigo-800/60'
                            : row.voucherType === 'Payment'
                            ? 'bg-rose-950/80 text-rose-300 border-rose-800/60'
                            : row.voucherType === 'Purchase Return'
                            ? 'bg-purple-950/80 text-purple-300 border-purple-800/60'
                            : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}
                      >
                        {row.voucherType}
                      </span>
                    </td>
                    <td className="p-2.5 font-mono font-semibold text-slate-200 whitespace-nowrap">{row.voucherNo}</td>
                    <td className="p-2.5 text-slate-300 max-w-xs sm:max-w-md truncate">{row.narration || '-'}</td>
                    <td className="p-2.5 text-right font-mono font-semibold text-rose-400 whitespace-nowrap">
                      {row.debit > 0 ? `₹${row.debit.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-2.5 text-right font-mono font-semibold text-indigo-400 whitespace-nowrap">
                      {row.credit > 0 ? `₹${row.credit.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-2.5 text-right font-mono font-bold text-amber-300 whitespace-nowrap">
                      ₹{Math.abs(row.calculatedBalance).toFixed(2)} {row.calculatedBalance >= 0 ? 'Cr' : 'Dr'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot>
              <tr className="bg-slate-950/80 font-bold border-t-2 border-slate-700 text-slate-200">
                <td colSpan={4} className="p-3 text-right uppercase tracking-wider text-[11px] text-slate-400">
                  Total for Period:
                </td>
                <td className="p-3 text-right font-mono text-rose-400">₹{periodTotalDebit.toFixed(2)}</td>
                <td className="p-3 text-right font-mono text-indigo-400">₹{periodTotalCredit.toFixed(2)}</td>
                <td className="p-3 text-right font-mono text-amber-300">
                  ₹{Math.abs(closingBalance).toFixed(2)} {closingBalance >= 0 ? 'Cr' : 'Dr'}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      {/* Supplier Ledger Print Modal */}
      {showPrintModal && selectedSupplier && (
        <SupplierLedgerPrintModal
          company={company}
          supplier={selectedSupplier}
          fromDate={fromDate}
          toDate={toDate}
          openingBalance={openingBalance}
          rows={rowsWithBalance}
          periodTotalDebit={periodTotalDebit}
          periodTotalCredit={periodTotalCredit}
          closingBalance={closingBalance}
          onClose={() => setShowPrintModal(false)}
        />
      )}
    </div>
  );
};
