import React from 'react';
import { Clock, RefreshCw, LogOut, AlertTriangle } from 'lucide-react';

interface SessionTimeoutModalProps {
  isOpen: boolean;
  remainingSeconds: number;
  onContinueSession: () => void;
  onLogoutNow: () => void;
}

export const SessionTimeoutModal: React.FC<SessionTimeoutModalProps> = ({
  isOpen,
  remainingSeconds,
  onContinueSession,
  onLogoutNow,
}) => {
  if (!isOpen) return null;

  const minutes = Math.floor(Math.max(0, remainingSeconds) / 60);
  const seconds = Math.max(0, remainingSeconds) % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="session-timeout-title"
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in select-none"
    >
      <div className="bg-slate-900 border-2 border-amber-500/50 rounded-2xl max-w-md w-full shadow-2xl p-6 sm:p-7 text-center text-slate-100 font-sans transform scale-100 transition-all">
        {/* Pulsing Warning Icon */}
        <div className="mx-auto w-16 h-16 bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-amber-500/10">
          <Clock className="w-8 h-8 stroke-[2.2] animate-pulse" />
        </div>

        {/* Title */}
        <h3
          id="session-timeout-title"
          className="text-xl font-bold text-slate-100 mb-2 tracking-tight"
        >
          Session Expiring
        </h3>

        {/* Informational Message */}
        <p className="text-sm text-slate-300 mb-5 leading-relaxed font-normal">
          You have been inactive for a while. For security reasons, your authenticated session will automatically close unless you choose to continue.
        </p>

        {/* Countdown Badge */}
        <div className="mb-6 p-3.5 bg-slate-800/80 border border-amber-500/30 rounded-xl flex items-center justify-center gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs sm:text-sm text-slate-200 font-medium">
            Session expires in{' '}
            <span className="font-mono font-bold text-amber-400 text-base sm:text-lg tracking-wider">
              {formattedTime}
            </span>
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            type="button"
            onClick={onLogoutNow}
            className="w-full sm:w-auto sm:flex-1 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 active:bg-slate-800 text-slate-300 hover:text-white font-semibold rounded-xl text-sm border border-slate-700 shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-slate-500/50"
          >
            <LogOut className="w-4 h-4 text-slate-400" />
            <span>Logout Now</span>
          </button>

          <button
            type="button"
            onClick={onContinueSession}
            className="w-full sm:w-auto sm:flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-lg shadow-emerald-900/30 border border-emerald-400/40 transition-all cursor-pointer flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Continue Session</span>
          </button>
        </div>
      </div>
    </div>
  );
};
