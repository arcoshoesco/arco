import React, { useState, useEffect } from 'react';
import {
  RotateCcw,
  Search,
  Package,
  Calendar,
  User,
  CreditCard,
  Printer,
  CheckCircle,
  AlertCircle,
  Clock,
  ChevronRight,
  Info,
  DollarSign,
  Receipt,
  FileText,
  Wallet,
  Check,
  X,
  ArrowLeft,
  ArrowRightLeft,
  Plus,
  Trash2
} from 'lucide-react';
import {
  CompanyInfo,
  Customer,
  InvoiceItem,
  Item,
  ReturnedItemLine,
  SalesExchange,
  SalesInvoice,
  SalesReturn
} from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2 } from '../services/gstCalculations';

interface ReturnDeskProps {
  company: CompanyInfo;
  preselectedInvoiceId?: string;
  onNavigateBack?: () => void;
  onOpenQrModal?: (amount?: number) => void;
}

type DeskTab = 'RETURN' | 'EXCHANGE' | 'HISTORY';

export const ReturnExchangeComponent: React.FC<ReturnDeskProps> = ({
  company,
  preselectedInvoiceId,
  onNavigateBack,
}) => {
  // Master data
  const [sales, setSales] = useState<SalesInvoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [masterItems, setMasterItems] = useState<Item[]>([]);

  // Selection & Search
  const [invoiceSearchQuery, setInvoiceSearchQuery] = useState<string>('');
  const [selectedInvoice, setSelectedInvoice] = useState<SalesInvoice | null>(null);
  const [activeTab, setActiveTab] = useState<DeskTab>('RETURN');

  // Return Transaction Form State
  const [transactionDate, setTransactionDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [transactionTime, setTransactionTime] = useState<string>(() =>
    new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
  );

  // Returned Items state: Map of itemId -> { returnQty, reason, selected }
  const [returnedItemsState, setReturnedItemsState] = useState<{
    [itemId: string]: {
      returnQty: number;
      reason: string;
      selected: boolean;
    };
  }>({});

  // Exchange Specific States: Replacement items to add
  const [exchangeNewItems, setExchangeNewItems] = useState<InvoiceItem[]>([]);
  const [exchangeSelectedItemId, setExchangeSelectedItemId] = useState<string>('');
  const [exchangeQty, setExchangeQty] = useState<string>('');
  const [exchangeRate, setExchangeRate] = useState<string>('');
  const [exchangeDisc, setExchangeDisc] = useState<string>('');
  const [exchangeGstRate, setExchangeGstRate] = useState<number>(18);
  const [exchangePaymentMethod, setExchangePaymentMethod] = useState<'Cash' | 'UPI' | 'Card' | 'Bank Transfer' | 'Customer Credit'>('Cash');
  const [exchangeRefundMethod, setExchangeRefundMethod] = useState<'Cash' | 'UPI' | 'Card' | 'Bank Transfer'>('Cash');
  const [exchangeSearchQuery, setExchangeSearchQuery] = useState<string>('');

  const [isInterState, setIsInterState] = useState<boolean>(false);
  const [refundMode, setRefundMode] = useState<'Store Credit' | 'Cash' | 'UPI' | 'Card' | 'Credit Note' | 'Bank Transfer'>('Store Credit');
  const [creditAmountStatus, setCreditAmountStatus] = useState<'Credit Amount Pending' | 'Credit Amount Taken'>('Credit Amount Pending');
  const [remarks, setRemarks] = useState<string>('');

  // Modals & Feedback
  const [completedReturn, setCompletedReturn] = useState<SalesReturn | null>(null);
  const [completedExchange, setCompletedExchange] = useState<SalesExchange | null>(null);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Load Data
  const loadData = () => {
    const allSales = dbService.getSales();
    setSales(allSales);
    setCustomers(dbService.getCustomers());
    setMasterItems(dbService.getItems());

    // Update currently selected invoice with fresh data if present
    setSelectedInvoice((prev) => {
      if (!prev) return null;
      const updated = allSales.find((s) => s.id === prev.id || s.invoiceNo === prev.invoiceNo);
      return updated || null;
    });

    // Preselect invoice if requested
    if (preselectedInvoiceId) {
      const match = allSales.find((s) => s.id === preselectedInvoiceId || s.invoiceNo === preselectedInvoiceId);
      if (match) {
        handleSelectInvoice(match);
      }
    }
  };

  useEffect(() => {
    loadData();
    return dbService.subscribe(loadData);
  }, [preselectedInvoiceId]);

  // When an invoice is selected, reset inputs
  const handleSelectInvoice = (inv: SalesInvoice) => {
    setSelectedInvoice(inv);
    setInvoiceSearchQuery('');
    setFeedback(null);
    setRemarks('');
    setCreditAmountStatus('Credit Amount Pending');
    setActiveTab('RETURN');

    // Determine state taxes
    const isInter = Boolean(inv.customerStateCode && company.stateCode && inv.customerStateCode !== company.stateCode);
    setIsInterState(isInter);

    // Initialize return quantities and select status
    const initialState: { [lineId: string]: { returnQty: number; reason: string; selected: boolean } } = {};
    inv.items.forEach((it) => {
      initialState[it.id || it.itemId] = {
        returnQty: 0,
        reason: 'Size Mismatch',
        selected: false,
      };
    });
    setReturnedItemsState(initialState);
  };

  // Get returnable quantities breakdown for the selected invoice
  const returnableLines = selectedInvoice ? dbService.getReturnableItemQuantities(selectedInvoice.id) : [];
  const returnHistory = selectedInvoice ? dbService.getInvoiceReturnHistory(selectedInvoice.id) : { returns: [], exchanges: [], totalReturnedAmount: 0, totalExchangedAmount: 0 };
  const currentReturnStatus = selectedInvoice ? dbService.calculateInvoiceReturnStatus(selectedInvoice) : 'NO_RETURN';

  // Customer Wallet Credit Balance
  const customerCreditBalance = selectedInvoice
    ? dbService.getCustomerCreditBalance(selectedInvoice.customerId, selectedInvoice.customerName, selectedInvoice.customerMobile)
    : 0;

  // Compute list of returned items based on state > 0
  const activeReturnedLines: ReturnedItemLine[] = [];
  let totalReturnedTaxable = 0;
  let totalReturnedTax = 0;
  let totalReturnedCgst = 0;
  let totalReturnedSgst = 0;
  let totalReturnedIgst = 0;
  let totalReturnedGrand = 0;
  let totalReturnedQty = 0;

  if (selectedInvoice) {
    returnableLines.forEach((line) => {
      const itemState = returnedItemsState[line.id];
      const isSelected = itemState ? itemState.selected : false;
      const qty = itemState && isSelected ? itemState.returnQty : 0;
      if (qty > 0) {
        const gstCalc = calculateLineGST(
          qty,
          line.rate,
          line.discountPercent ? `${line.discountPercent}%` : line.discountAmount / (line.soldQuantity || 1),
          line.gstRate,
          isInterState,
          company.defaultTaxCalculation || 'Exclusive'
        );

        const retLine: ReturnedItemLine = {
          id: line.id,
          itemId: line.itemId,
          itemCode: line.itemCode,
          itemName: line.itemName,
          hsnCode: line.hsnCode,
          unit: line.unit,
          originalQuantity: line.soldQuantity,
          previouslyReturnedQty: line.previouslyReturnedQty,
          returnQuantity: qty,
          remainingQuantity: line.remainingReturnableQty - qty,
          rate: line.rate,
          grossAmount: gstCalc.grossAmount,
          discountPercent: line.discountPercent || 0,
          discountAmount: gstCalc.discountAmount,
          taxableAmount: gstCalc.taxableAmount,
          gstRate: line.gstRate,
          cgstRate: gstCalc.cgstRate,
          cgstAmount: gstCalc.cgstAmount,
          sgstRate: gstCalc.sgstRate,
          sgstAmount: gstCalc.sgstAmount,
          igstRate: gstCalc.igstRate,
          igstAmount: gstCalc.igstAmount,
          netAmount: gstCalc.netAmount,
          reason: itemState.reason,
        };

        activeReturnedLines.push(retLine);
        totalReturnedQty += qty;
        totalReturnedTaxable += gstCalc.taxableAmount;
        totalReturnedTax += gstCalc.cgstAmount + gstCalc.sgstAmount + gstCalc.igstAmount;
        totalReturnedCgst += gstCalc.cgstAmount;
        totalReturnedSgst += gstCalc.sgstAmount;
        totalReturnedIgst += gstCalc.igstAmount;
        totalReturnedGrand += gstCalc.netAmount;
      }
    });
  }

  // Handle Save / Process Return
  const handleProcessReturn = () => {
    if (!selectedInvoice) {
      setFeedback({ type: 'error', message: 'No original sales bill selected.' });
      return;
    }

    if (activeReturnedLines.length === 0) {
      setFeedback({ type: 'error', message: 'Please specify a return quantity of at least 1 item.' });
      return;
    }

    const returnNo = dbService.getNextReturnNo();
    const returnDoc: SalesReturn = {
      id: `SR-${Date.now()}`,
      returnNo,
      returnDate: transactionDate,
      returnTime: transactionTime,
      originalInvoiceId: selectedInvoice.id,
      originalInvoiceNo: selectedInvoice.invoiceNo,
      originalInvoiceDate: selectedInvoice.invoiceDate,
      customerId: selectedInvoice.customerId,
      customerName: selectedInvoice.customerName,
      customerMobile: selectedInvoice.customerMobile,
      customerAddress: selectedInvoice.customerAddress,
      customerGstin: selectedInvoice.customerGstin,
      customerStateCode: selectedInvoice.customerStateCode,
      isInterState,
      items: activeReturnedLines,
      totalQuantity: totalReturnedQty,
      totalTaxable: roundTo2(totalReturnedTaxable),
      totalCgst: roundTo2(totalReturnedCgst),
      totalSgst: roundTo2(totalReturnedSgst),
      totalIgst: roundTo2(totalReturnedIgst),
      totalTax: roundTo2(totalReturnedTax),
      roundOff: 0,
      grandTotal: roundTo2(totalReturnedGrand),
      refundMode: 'Store Credit',
      amountRefunded: 0,
      storeCreditAmount: roundTo2(totalReturnedGrand),
      creditAmountStatus,
      reason: activeReturnedLines.map((i) => i.reason).filter(Boolean).join(', ') || remarks || 'Customer Return',
      createdAt: new Date().toISOString(),
    };

    const result = dbService.saveSalesReturn(returnDoc);
    if (result.success) {
      setCompletedReturn(returnDoc);
      setShowPrintModal(true);
      setFeedback({
        type: 'success',
        message: `Sales Return ${returnNo} recorded successfully! Returned item(s) deleted from bill, stock restored, and ₹${totalReturnedGrand.toFixed(2)} saved directly into ${selectedInvoice.customerName}'s Store Credit wallet.`,
      });
      setReturnedItemsState({});
      loadData();
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  // Add Replacement Item to Exchange List
  const handleAddExchangeItem = () => {
    if (!exchangeSelectedItemId) {
      setFeedback({ type: 'error', message: 'Please select a replacement item from the catalogue.' });
      return;
    }
    const found = masterItems.find((i) => i.id === exchangeSelectedItemId);
    if (!found) return;

    const qty = Math.max(1, parseFloat(exchangeQty) || 1);
    const rate = parseFloat(exchangeRate) || found.sellingRate || 0;
    const discStr = exchangeDisc.trim();
    const gstRate = exchangeGstRate || found.gstRate || 0;

    const gstCalc = calculateLineGST(
      qty,
      rate,
      discStr,
      gstRate,
      isInterState,
      company.defaultTaxCalculation || 'Exclusive'
    );

    const newLine: InvoiceItem = {
      id: `EXC-ITEM-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      itemId: found.id,
      itemCode: found.itemCode,
      itemName: found.itemName,
      hsnCode: found.hsnCode || '6403',
      quantity: qty,
      unit: found.unit || 'PCS',
      rate: rate,
      grossAmount: gstCalc.grossAmount,
      discountPercent: gstCalc.discountPercent,
      discountAmount: gstCalc.discountAmount,
      taxableAmount: gstCalc.taxableAmount,
      gstRate: gstRate,
      cgstRate: gstCalc.cgstRate,
      cgstAmount: gstCalc.cgstAmount,
      sgstRate: gstCalc.sgstRate,
      sgstAmount: gstCalc.sgstAmount,
      igstRate: gstCalc.igstRate,
      igstAmount: gstCalc.igstAmount,
      netAmount: gstCalc.netAmount,
    };

    setExchangeNewItems((prev) => [...prev, newLine]);
    setExchangeSelectedItemId('');
    setExchangeQty('1');
    setExchangeRate('');
    setExchangeDisc('0');
    setExchangeSearchQuery('');
  };

  const handleRemoveExchangeItem = (index: number) => {
    setExchangeNewItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Handle Process Exchange
  const handleProcessExchange = () => {
    if (!selectedInvoice) {
      setFeedback({ type: 'error', message: 'No sales bill selected.' });
      return;
    }
    if (activeReturnedLines.length === 0) {
      setFeedback({ type: 'error', message: 'Please select at least 1 item from the bill to return/exchange.' });
      return;
    }
    if (exchangeNewItems.length === 0) {
      setFeedback({ type: 'error', message: 'Please add at least 1 replacement item for the exchange.' });
      return;
    }

    const newTotalValue = roundTo2(exchangeNewItems.reduce((sum, it) => sum + it.netAmount, 0));
    const returnedTotalValue = roundTo2(totalReturnedGrand);
    const diff = roundTo2(newTotalValue - returnedTotalValue);

    const exchangeNo = dbService.getNextExchangeNo();
    const exchangeDoc: SalesExchange = {
      id: `EXC-${Date.now()}`,
      exchangeNo,
      exchangeDate: transactionDate,
      exchangeTime: transactionTime,
      originalInvoiceId: selectedInvoice.id,
      originalInvoiceNo: selectedInvoice.invoiceNo,
      originalInvoiceDate: selectedInvoice.invoiceDate,
      customerId: selectedInvoice.customerId,
      customerName: selectedInvoice.customerName,
      customerGstin: selectedInvoice.customerGstin,
      customerMobile: selectedInvoice.customerMobile,
      customerAddress: selectedInvoice.customerAddress,
      customerStateCode: selectedInvoice.customerStateCode || company.stateCode,
      isInterState,
      returnedItems: activeReturnedLines,
      returnedTotalQuantity: totalReturnedQty,
      returnedTaxable: roundTo2(totalReturnedTaxable),
      returnedTax: roundTo2(totalReturnedTax),
      returnedTotalValue: returnedTotalValue,
      newItems: exchangeNewItems,
      newTotalQuantity: roundTo2(exchangeNewItems.reduce((acc, i) => acc + i.quantity, 0)),
      newTaxable: roundTo2(exchangeNewItems.reduce((acc, i) => acc + i.taxableAmount, 0)),
      newTax: roundTo2(exchangeNewItems.reduce((acc, i) => acc + (i.cgstAmount + i.sgstAmount + i.igstAmount), 0)),
      newTotalValue: newTotalValue,
      differenceAmount: diff,
      settlementType: diff > 0 ? 'CUSTOMER_PAID' : diff < 0 ? 'REFUND_PAID' : 'EQUAL',
      additionalAmountPaid: diff > 0 ? diff : 0,
      paymentMethod: diff > 0 ? exchangePaymentMethod : undefined,
      refundAmount: diff < 0 ? Math.abs(diff) : 0,
      refundMethod: diff < 0 ? exchangeRefundMethod : undefined,
      storeCreditAmount: 0,
      reason: remarks || activeReturnedLines.map((i) => i.reason).filter(Boolean).join(', ') || 'Item Exchange & Replacement',
      createdAt: new Date().toISOString(),
    };

    const res = dbService.saveSalesExchange(exchangeDoc);
    if (res.success) {
      setCompletedExchange(exchangeDoc);
      setShowPrintModal(true);
      setFeedback({
        type: 'success',
        message: `Exchange ${exchangeNo} completed successfully!`,
      });
      setReturnedItemsState({});
      setExchangeNewItems([]);
      loadData();
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const handleUpdateCreditStatus = (returnId: string, newStatus: 'Credit Amount Pending' | 'Credit Amount Taken') => {
    const res = dbService.updateSalesReturnCreditStatus(returnId, newStatus);
    if (res.success) {
      setFeedback({ type: 'success', message: `Credit status updated to "${newStatus}".` });
      loadData();
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  // Filter available sales bills for invoice search
  const filteredSalesInvoices = sales.filter((s) => {
    if (!invoiceSearchQuery.trim()) return true;
    const q = invoiceSearchQuery.toLowerCase().trim();
    return (
      s.invoiceNo.toLowerCase().includes(q) ||
      s.customerName.toLowerCase().includes(q) ||
      (s.customerMobile && s.customerMobile.includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Invoice Selector Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">Sales Return Desk</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Process customer returns, issue store credit or refunds, and automatically restore item stock.
              </p>
            </div>
          </div>

          {/* Quick Select Bill Search Field */}
          <div className="flex items-center gap-3">
            <div className="relative min-w-[280px] sm:min-w-[340px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search Bill #, Customer Name, Mobile..."
                value={invoiceSearchQuery}
                onChange={(e) => setInvoiceSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500 font-medium"
              />
              {invoiceSearchQuery && (
                <div className="absolute left-0 right-0 top-full mt-1.5 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-h-60 overflow-y-auto z-50 divide-y divide-slate-800">
                  {filteredSalesInvoices.length === 0 ? (
                    <div className="p-3 text-center text-xs text-slate-400">No matching sales bills found</div>
                  ) : (
                    filteredSalesInvoices.map((inv) => (
                      <button
                        key={inv.id}
                        onClick={() => handleSelectInvoice(inv)}
                        className="w-full text-left p-2.5 hover:bg-slate-800 transition-colors flex items-center justify-between group cursor-pointer"
                      >
                        <div>
                          <div className="flex items-center gap-2 font-mono font-bold text-xs text-slate-200 group-hover:text-purple-300">
                            <span>{inv.invoiceNo}</span>
                            <span className="text-[10px] font-sans text-slate-400">({inv.invoiceDate})</span>
                          </div>
                          <div className="text-[11px] text-slate-400">{inv.customerName} {inv.customerMobile ? `• ${inv.customerMobile}` : ''}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-xs text-emerald-400">₹{inv.grandTotal.toFixed(2)}</div>
                          <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                            {inv.paymentMode}
                          </span>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {onNavigateBack && (
              <button
                onClick={onNavigateBack}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}
          </div>
        </div>

        {/* Selected Bill Overview Bar */}
        {selectedInvoice ? (
          <div className="mt-5 pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Original Bill No</span>
              <span className="font-mono font-black text-sm text-purple-300">{selectedInvoice.invoiceNo}</span>
              <span className="text-[10px] text-slate-500 block">Date: {selectedInvoice.invoiceDate}</span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Customer Party</span>
              <span className="font-bold text-xs text-slate-200 truncate block">{selectedInvoice.customerName}</span>
              <span className="text-[10px] text-slate-400 font-mono">{selectedInvoice.customerMobile || 'Counter Sale'}</span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Original Total</span>
              <span className="font-mono font-black text-sm text-emerald-400">₹{selectedInvoice.grandTotal.toFixed(2)}</span>
              <span className="text-[10px] text-slate-500 block">Paid via {selectedInvoice.paymentMode}</span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Store Credit Wallet</span>
              <div className="flex items-center gap-1.5">
                <Wallet className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-mono font-black text-sm text-amber-300">₹{customerCreditBalance.toFixed(2)}</span>
              </div>
              <span className="text-[10px] text-slate-500 block">
                {totalReturnedGrand > 0 && refundMode === 'Store Credit'
                  ? `+ ₹${totalReturnedGrand.toFixed(2)} on Save`
                  : returnHistory.totalReturnedAmount > 0
                  ? `₹${returnHistory.totalReturnedAmount.toFixed(2)} returned on bill`
                  : 'Customer Balance'}
              </span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex flex-col justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Return Status</span>
              <div>
                <span
                  className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider border inline-block ${
                    currentReturnStatus === 'NO_RETURN'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : currentReturnStatus === 'FULLY_RETURNED'
                      ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                      : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                  }`}
                >
                  {currentReturnStatus.replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-4 p-4 rounded-xl bg-purple-950/20 border border-purple-800/30 flex items-center gap-3">
            <Info className="w-5 h-5 text-purple-400 shrink-0" />
            <span className="text-xs text-purple-200">
              Please search and select an original sales bill above to begin processing returned items.
            </span>
          </div>
        )}
      </div>

      {/* Tabs & Date Config */}
      {selectedInvoice && (
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-900/40 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setActiveTab('RETURN')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'RETURN'
                  ? 'bg-purple-600/30 text-purple-200 border-purple-500/50 shadow-inner'
                  : 'text-slate-400 hover:text-white border-transparent'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5 text-purple-400" />
              <span>Process Sales Return</span>
            </button>

            <button
              onClick={() => setActiveTab('EXCHANGE')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'EXCHANGE'
                  ? 'bg-cyan-600/30 text-cyan-200 border-cyan-500/50 shadow-inner'
                  : 'text-slate-400 hover:text-white border-transparent'
              }`}
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-cyan-400" />
              <span>Item Exchange / Replacement</span>
            </button>

            <button
              onClick={() => setActiveTab('HISTORY')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'HISTORY'
                  ? 'bg-amber-600/30 text-amber-200 border-amber-500/50 shadow-inner'
                  : 'text-slate-400 hover:text-white border-transparent'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Bill History ({returnHistory.returns.length + (returnHistory.exchanges?.length || 0)})</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[11px] text-slate-400 font-bold">Action Date:</span>
              <input
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
                className="bg-slate-950 border border-slate-700 px-2 py-1 rounded text-xs font-bold font-mono text-purple-300 focus:outline-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* Feedback Toast */}
      {feedback && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between text-xs font-medium animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/40'
              : 'bg-rose-950/40 text-rose-300 border-rose-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {feedback.type === 'success' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* View: Bill Return & Exchange History */}
      {selectedInvoice && activeTab === 'HISTORY' && (
        <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200">Activity History for {selectedInvoice.invoiceNo}</h3>
            <div className="text-xs text-slate-400 space-x-3">
              <span>Total Returns: <strong className="text-emerald-400 font-mono">₹{returnHistory.totalReturnedAmount.toFixed(2)}</strong></span>
              <span>•</span>
              <span>Total Exchanges: <strong className="text-cyan-400 font-mono">₹{(returnHistory.totalExchangedAmount || 0).toFixed(2)}</strong></span>
            </div>
          </div>

          {returnHistory.returns.length === 0 && (!returnHistory.exchanges || returnHistory.exchanges.length === 0) ? (
            <div className="text-center py-10 text-slate-500 text-xs">
              No previous returns or exchanges have been processed for this bill.
            </div>
          ) : (
            <div className="space-y-3">
              {/* Exchanges History */}
              {returnHistory.exchanges?.map((exc) => (
                <div key={exc.id} className="p-4 bg-slate-950/60 border border-cyan-800/40 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-cyan-400">{exc.exchangeNo}</span>
                      <span className="px-2 py-0.5 rounded-full text-[9px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold uppercase">
                        Item Exchange
                      </span>
                      <span className="text-slate-400">• {exc.exchangeDate} at {exc.exchangeTime || 'N/A'}</span>
                    </div>
                    <div className="text-slate-300 mt-1">
                      Returned: <span className="font-mono text-purple-300">₹{exc.returnedTotalValue.toFixed(2)}</span> ({exc.returnedItems.map(i => `${i.returnQuantity}x ${i.itemName}`).join(', ')}) 
                      &nbsp;→&nbsp; Replaced with: <span className="font-mono text-cyan-300">₹{exc.newTotalValue.toFixed(2)}</span> ({exc.newItems.map(i => `${i.quantity}x ${i.itemName}`).join(', ')})
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400 uppercase">Difference Amount</div>
                    <div className={`text-sm font-bold font-mono ${exc.differenceAmount > 0 ? 'text-emerald-400' : exc.differenceAmount < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                      {exc.differenceAmount > 0 ? `+₹${exc.differenceAmount.toFixed(2)}` : exc.differenceAmount < 0 ? `-₹${Math.abs(exc.differenceAmount).toFixed(2)}` : '₹0.00 (Even)'}
                    </div>
                  </div>
                </div>
              ))}

              {/* Returns History */}
              {returnHistory.returns.map((ret) => (
                <div key={ret.id} className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-purple-400">{ret.returnNo}</span>
                      <span className="px-2 py-0.5 rounded-full text-[9px] bg-purple-500/10 text-purple-400 border border-purple-500/20 font-bold uppercase">
                        Sales Return
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                        (ret.creditAmountStatus || 'Credit Amount Pending') === 'Credit Amount Pending'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}>
                        {ret.creditAmountStatus || 'Credit Amount Pending'}
                      </span>
                      <button
                        onClick={() => handleUpdateCreditStatus(ret.id, (ret.creditAmountStatus || 'Credit Amount Pending') === 'Credit Amount Pending' ? 'Credit Amount Taken' : 'Credit Amount Pending')}
                        className={`px-2 py-0.5 text-[9px] font-bold rounded-md border transition cursor-pointer flex items-center gap-1 ${
                          (ret.creditAmountStatus || 'Credit Amount Pending') === 'Credit Amount Pending'
                            ? 'bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 border-emerald-500/30'
                            : 'bg-amber-600/20 hover:bg-amber-600/40 text-amber-300 border-amber-500/30'
                        }`}
                        title="Click to toggle credit amount status"
                      >
                        {(ret.creditAmountStatus || 'Credit Amount Pending') === 'Credit Amount Pending' ? '✓ Process to Taken' : '🔄 Set Pending'}
                      </button>
                      <span className="text-slate-400">• {ret.returnDate} at {ret.returnTime || 'N/A'}</span>
                    </div>
                    <div className="text-slate-400 mt-1">
                      Returned {ret.totalQuantity} items. Refund Mode: <strong className="text-slate-300">{ret.refundMode}</strong>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-emerald-400 font-mono">₹{ret.grandTotal.toFixed(2)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* View: Item Exchange / Replacement */}
      {selectedInvoice && activeTab === 'EXCHANGE' && (
        <div className="space-y-6">
          {/* Step 1: Select Item to Return */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-bold text-slate-200">Step 1: Select Original Item(s) to Exchange/Return</h3>
              </div>
              <span className="text-xs text-purple-300 font-bold font-mono">
                Returned Value: ₹{totalReturnedGrand.toFixed(2)}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {returnableLines.map((line) => {
                const state = returnedItemsState[line.id] || { returnQty: 0, reason: 'Size Mismatch', selected: false };
                const isFullyReturned = line.remainingReturnableQty <= 0;

                return (
                  <div
                    key={line.id}
                    className={`p-4 rounded-xl border transition-all ${
                      isFullyReturned
                        ? 'bg-slate-950/30 border-slate-800/50 opacity-60'
                        : state.selected
                        ? 'bg-purple-950/20 border-purple-500/40 shadow-sm ring-1 ring-purple-500/20'
                        : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-3">
                        {!isFullyReturned && (
                          <input
                            type="checkbox"
                            checked={state.selected || false}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              setReturnedItemsState((prev) => ({
                                ...prev,
                                [line.id]: {
                                  ...state,
                                  selected: checked,
                                  returnQty: checked ? (state.returnQty || line.remainingReturnableQty || 1) : 0,
                                },
                              }));
                            }}
                            className="mt-1 w-4.5 h-4.5 rounded border-slate-700 text-purple-600 focus:ring-purple-500 bg-slate-900 cursor-pointer"
                          />
                        )}
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[11px] font-bold text-purple-400">{line.itemCode}</span>
                            <h4 className="font-bold text-xs text-slate-100">{line.itemName}</h4>
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-3">
                            <span>Rate: <strong className="font-mono text-purple-300 font-bold">₹{line.rate.toFixed(2)}</strong></span>
                            <span>GST: <strong className="text-slate-300">{line.gstRate}%</strong></span>
                          </div>
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isFullyReturned
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                        }`}
                      >
                        {isFullyReturned ? 'Unavailable' : `${line.remainingReturnableQty} ${line.unit} in Bill`}
                      </span>
                    </div>

                    {!isFullyReturned && (
                      <div className="mt-3 pt-3 border-t border-slate-800/60 grid grid-cols-2 gap-2 items-center">
                        <div>
                          <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                            Exchange Qty (Max: {line.remainingReturnableQty})
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            value={state.returnQty || ''}
                            onChange={(e) => {
                              const rawVal = e.target.value;
                              const numVal = parseInt(rawVal) || 0;
                              const val = Math.min(line.remainingReturnableQty, Math.max(0, numVal));
                              setReturnedItemsState((prev) => ({
                                ...prev,
                                [line.id]: {
                                  ...state,
                                  returnQty: val,
                                  selected: val > 0,
                                },
                              }));
                            }}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-100 font-mono focus:border-purple-500 focus:outline-none"
                            placeholder="0"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                            Exchange Reason
                          </label>
                          <select
                            value={state.reason}
                            onChange={(e) => {
                              setReturnedItemsState((prev) => ({
                                ...prev,
                                [line.id]: {
                                  ...state,
                                  reason: e.target.value,
                                },
                              }));
                            }}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-[11px] font-medium text-slate-200 focus:border-purple-500 focus:outline-none cursor-pointer"
                          >
                            <option value="Size Replacement">Size Replacement</option>
                            <option value="Model / Article Exchange">Model / Article Exchange</option>
                            <option value="Color Choice">Color Choice</option>
                            <option value="Defective / Damaged">Defective / Damaged</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Step 2: Add Replacement Item(s) */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-slate-200">Step 2: Select Replacement Item(s)</h3>
              </div>
              <span className="text-xs text-cyan-300 font-bold font-mono">
                Replacement Total: ₹{exchangeNewItems.reduce((acc, i) => acc + i.netAmount, 0).toFixed(2)}
              </span>
            </div>

            {/* Item Add Row Form */}
            <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                <div className="sm:col-span-5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Select Replacement Product
                  </label>
                  <select
                    value={exchangeSelectedItemId}
                    onChange={(e) => {
                      const id = e.target.value;
                      setExchangeSelectedItemId(id);
                      const it = masterItems.find((m) => m.id === id);
                      if (it) {
                        setExchangeRate(it.sellingRate.toString());
                        setExchangeGstRate(it.gstRate || 18);
                      }
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-semibold text-slate-200 focus:border-cyan-500 focus:outline-none cursor-pointer"
                  >
                    <option value="">-- Choose Item from Inventory --</option>
                    {masterItems.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.itemCode} - {m.itemName} (Stock: {m.currentStock} {m.unit || 'PCS'} | ₹{m.sellingRate})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Qty
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={exchangeQty}
                    onChange={(e) => setExchangeQty(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-bold font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
                    placeholder="1"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Rate (₹)
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={exchangeRate}
                    onChange={(e) => setExchangeRate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-bold font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
                    placeholder="Rate"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Disc (₹/%)
                  </label>
                  <input
                    type="text"
                    value={exchangeDisc}
                    onChange={(e) => setExchangeDisc(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
                    placeholder="0"
                  />
                </div>

                <div className="sm:col-span-1">
                  <button
                    type="button"
                    onClick={handleAddExchangeItem}
                    disabled={!exchangeSelectedItemId}
                    className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-lg font-bold flex items-center justify-center transition cursor-pointer"
                    title="Add Item"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* List of Added Replacement Items */}
            {exchangeNewItems.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-[10px] font-bold uppercase text-slate-400">
                      <th className="py-2 px-3">Item Name</th>
                      <th className="py-2 px-3 text-center">Qty</th>
                      <th className="py-2 px-3 text-right">Rate</th>
                      <th className="py-2 px-3 text-right">Taxable</th>
                      <th className="py-2 px-3 text-right">GST</th>
                      <th className="py-2 px-3 text-right">Net Amount</th>
                      <th className="py-2 px-3 text-center w-12">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {exchangeNewItems.map((it, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="py-2.5 px-3 font-semibold text-slate-200">
                          {it.itemName} <span className="text-[10px] text-slate-400 font-mono">({it.itemCode})</span>
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono font-bold text-cyan-300">
                          {it.quantity} {it.unit}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-300">₹{it.rate.toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-300">₹{it.taxableAmount.toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-400">{it.gstRate}%</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-cyan-400">₹{it.netAmount.toFixed(2)}</td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveExchangeItem(idx)}
                            className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Step 3: Financial Settlement & Bill Adjustment Amount Calculation */}
          {(() => {
            const returnedVal = roundTo2(totalReturnedGrand);
            const replacementVal = roundTo2(exchangeNewItems.reduce((acc, i) => acc + i.netAmount, 0));
            const adjDiff = roundTo2(replacementVal - returnedVal);

            return (
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-2xl space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-amber-400" />
                    <h3 className="text-sm font-bold text-slate-100">Step 3: Bill Adjustment & Settlement</h3>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-mono">
                    <span>Returned: <strong className="text-purple-300">₹{returnedVal.toFixed(2)}</strong></span>
                    <span>•</span>
                    <span>Replacement: <strong className="text-cyan-300">₹{replacementVal.toFixed(2)}</strong></span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  {/* Summary Box */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bill Adjustment Amount</span>
                    <div className={`text-2xl font-black font-mono ${adjDiff > 0 ? 'text-emerald-400' : adjDiff < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                      {adjDiff > 0 ? `+₹${adjDiff.toFixed(2)}` : adjDiff < 0 ? `-₹${Math.abs(adjDiff).toFixed(2)}` : '₹0.00'}
                    </div>
                    <p className="text-[10px] text-slate-400">
                      {adjDiff > 0
                        ? `Additional payment required from ${selectedInvoice.customerName}.`
                        : adjDiff < 0
                        ? `Refund or store credit to return to ${selectedInvoice.customerName}.`
                        : 'Exact value exchange. No balance adjustment.'}
                    </p>
                  </div>

                  {/* Payment / Refund Method Selection */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    {adjDiff > 0 ? (
                      <div>
                        <label className="block text-[10px] font-bold text-emerald-400 uppercase tracking-wider mb-1">
                          Receive Additional Amount Via
                        </label>
                        <select
                          value={exchangePaymentMethod}
                          onChange={(e) => setExchangePaymentMethod(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-200 focus:border-emerald-500 focus:outline-none cursor-pointer"
                        >
                          <option value="Cash">Cash</option>
                          <option value="UPI">UPI</option>
                          <option value="Card">Card</option>
                          <option value="Bank Transfer">Bank Transfer</option>
                          <option value="Customer Credit">Customer Khata (Credit)</option>
                        </select>
                      </div>
                    ) : adjDiff < 0 ? (
                      <div>
                        <label className="block text-[10px] font-bold text-rose-400 uppercase tracking-wider mb-1">
                          Refund Balance Amount Via
                        </label>
                        <select
                          value={exchangeRefundMethod}
                          onChange={(e) => setExchangeRefundMethod(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-200 focus:border-rose-500 focus:outline-none cursor-pointer"
                        >
                          <option value="Cash">Cash Refund</option>
                          <option value="UPI">UPI Refund</option>
                          <option value="Store Credit">Store Credit Wallet</option>
                          <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                      </div>
                    ) : (
                      <div className="text-center py-2 text-xs text-slate-400 font-medium">
                        ✓ Balanced Exchange (₹0 Difference)
                      </div>
                    )}
                  </div>

                  {/* Confirm & Process Exchange Button */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <input
                      type="text"
                      placeholder="Exchange note (e.g. Size 8 to Size 9)..."
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />

                    <button
                      onClick={handleProcessExchange}
                      disabled={activeReturnedLines.length === 0 || exchangeNewItems.length === 0}
                      className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs rounded-xl shadow-lg shadow-cyan-900/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                      <span>Confirm & Save Item Exchange</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Main Return Form: Select Items & Refund Settlement */}
      {selectedInvoice && activeTab === 'RETURN' && (
        <div className="space-y-6">
          {/* Original Bill Items to Return */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-bold text-slate-200">1. Select Items to Return</h3>
              </div>
              <span className="text-xs text-slate-400">
                Total Line Items: <strong className="text-slate-200">{returnableLines.length}</strong>
              </span>
            </div>

            {/* Items Return Table */}
            {returnableLines.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
                <CheckCircle className="w-8 h-8 text-purple-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-200">All Items Returned & Refunded</h4>
                <p className="text-xs text-slate-400">
                  All items originally associated with invoice <strong className="font-mono text-purple-300">{selectedInvoice.invoiceNo}</strong> have been returned, refunded, and removed from the bill.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {returnableLines.map((line) => {
                  const state = returnedItemsState[line.id] || { returnQty: 0, reason: 'Size Mismatch', selected: false };
                  const isFullyReturned = line.remainingReturnableQty <= 0;

                  return (
                    <div
                      key={line.id}
                      className={`p-4 rounded-xl border transition-all ${
                        isFullyReturned
                          ? 'bg-slate-950/30 border-slate-800/50 opacity-60'
                          : state.selected
                          ? 'bg-purple-950/20 border-purple-500/40 shadow-sm ring-1 ring-purple-500/20'
                          : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-3">
                          {!isFullyReturned && (
                            <input
                              type="checkbox"
                              checked={state.selected || false}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                setReturnedItemsState((prev) => ({
                                  ...prev,
                                  [line.id]: {
                                    ...state,
                                    selected: checked,
                                    returnQty: checked ? (state.returnQty || line.remainingReturnableQty || 1) : 0,
                                  },
                                }));
                              }}
                              className="mt-1 w-4.5 h-4.5 rounded border-slate-700 text-purple-600 focus:ring-purple-500 bg-slate-900 cursor-pointer"
                            />
                          )}
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[11px] font-bold text-purple-400">{line.itemCode}</span>
                              <h4 className="font-bold text-xs text-slate-100">{line.itemName}</h4>
                            </div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-3">
                              <span>HSN: <strong className="font-mono text-slate-300">{line.hsnCode}</strong></span>
                              <span>Rate: <strong className="font-mono text-slate-300 font-bold text-purple-300">₹{line.rate.toFixed(2)}</strong></span>
                              <span>GST: <strong className="text-slate-300">{line.gstRate}%</strong></span>
                            </div>
                          </div>
                        </div>

                        {/* Sold & Remaining Qty Pills */}
                        <div className="text-right flex flex-col items-end">
                          <div className="flex items-center gap-1.5 text-[10px]">
                            <span className="text-slate-500 font-medium">Sold: {line.soldQuantity}</span>
                            <span className="text-slate-600">|</span>
                            <span className="text-slate-500 font-medium">Prev. Ret: {line.previouslyReturnedQty}</span>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold mt-1 ${
                              isFullyReturned
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                            }`}
                          >
                            {isFullyReturned ? 'Fully Returned' : `${line.remainingReturnableQty} ${line.unit} Returnable`}
                          </span>
                        </div>
                      </div>

                      {/* Return Controls if Available */}
                      {!isFullyReturned && (
                        <div className="mt-3 pt-3 border-t border-slate-800/60 grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center transition-all">
                          {/* Qty Input */}
                          <div>
                            <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                              Return Qty (Max: {line.remainingReturnableQty})
                            </label>
                            <input
                              type="text"
                              inputMode="numeric"
                              value={state.returnQty || ''}
                              onChange={(e) => {
                                const rawVal = e.target.value;
                                const numVal = parseInt(rawVal) || 0;
                                const val = Math.min(line.remainingReturnableQty, Math.max(0, numVal));
                                setReturnedItemsState((prev) => ({
                                  ...prev,
                                  [line.id]: {
                                    ...state,
                                    returnQty: val,
                                    selected: val > 0,
                                  },
                                }));
                              }}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-100 font-mono focus:border-purple-500 focus:outline-none"
                              placeholder="0"
                            />
                          </div>

                          {/* Reason Selector */}
                          <div>
                            <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                              Reason
                            </label>
                            <select
                              value={state.reason}
                              onChange={(e) => {
                                setReturnedItemsState((prev) => ({
                                  ...prev,
                                  [line.id]: {
                                    ...state,
                                    reason: e.target.value,
                                  },
                                }));
                              }}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-[11px] font-medium text-slate-200 focus:border-purple-500 focus:outline-none cursor-pointer"
                            >
                              <option value="Size Mismatch">Size Mismatch</option>
                              <option value="Defective / Damaged">Defective / Damaged</option>
                              <option value="Customer Choice">Customer Choice</option>
                              <option value="Wrong Item Shipped">Wrong Item Shipped</option>
                              <option value="Color / Style Change">Color / Style Change</option>
                            </select>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Returned Items Summary Footer */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Total Returned Qty: <strong className="text-slate-200 font-mono">{totalReturnedQty} items</strong></span>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase block">Total Return Value</span>
                <span className="text-base font-black text-purple-400 font-mono">₹{totalReturnedGrand.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Refund & Financial Settlement Footer Panel */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-100">2. Store Credit Wallet & Status</h3>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <span>Taxable: <strong className="text-slate-300 font-mono">₹{totalReturnedTaxable.toFixed(2)}</strong></span>
                <span>•</span>
                <span>GST: <strong className="text-slate-300 font-mono">₹{totalReturnedTax.toFixed(2)}</strong></span>
                <span>•</span>
                <span>Total Refund: <strong className="text-purple-400 font-mono font-bold">₹{totalReturnedGrand.toFixed(2)}</strong></span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
              {/* Box 1: Store Credit Refund Summary */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Store Credit Refund</span>
                <div className="text-2xl font-black font-mono text-purple-400">
                  ₹{totalReturnedGrand.toFixed(2)}
                </div>
                <p className="text-[10px] text-amber-300 font-medium flex items-center gap-1">
                  ✓ Amount saved directly into {selectedInvoice.customerName}&apos;s Store Credit wallet.
                </p>
              </div>

              {/* Box 2: Credit Amount Status & Process Button */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Credit Amount Status
                </label>
                <select
                  value={creditAmountStatus}
                  onChange={(e) => setCreditAmountStatus(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-200 focus:border-purple-500 focus:outline-none cursor-pointer"
                >
                  <option value="Credit Amount Pending">Credit Amount Pending</option>
                  <option value="Credit Amount Taken">Credit Amount Taken</option>
                </select>

                <button
                  type="button"
                  onClick={() => setCreditAmountStatus(creditAmountStatus === 'Credit Amount Pending' ? 'Credit Amount Taken' : 'Credit Amount Pending')}
                  className={`w-full py-1.5 px-3 rounded-lg text-xs font-bold border transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    creditAmountStatus === 'Credit Amount Pending'
                      ? 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border-emerald-500/40'
                      : 'bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border-amber-500/40'
                  }`}
                >
                  {creditAmountStatus === 'Credit Amount Pending' ? '⚡ Process: Change to Credit Taken' : '🔄 Process: Set Back to Pending'}
                </button>
              </div>

              {/* Box 3: Remarks & Final Process Action */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <input
                  type="text"
                  placeholder="Optional remarks / return note..."
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />

                <button
                  onClick={handleProcessReturn}
                  disabled={activeReturnedLines.length === 0}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl shadow-lg shadow-purple-900/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirm & Save Sales Return</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Completed Print Modal */}
      {showPrintModal && (completedReturn || completedExchange) && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-emerald-400">
                <CheckCircle className="w-5 h-5" />
                <h3 className="text-base font-bold text-slate-100">
                  {completedExchange ? 'Item Exchange Note & Invoice Adjustment' : 'Sales Return Note'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setShowPrintModal(false);
                  setCompletedReturn(null);
                  setCompletedExchange(null);
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Receipt Content */}
            <div id="printable-return-receipt" className="bg-white text-black p-6 rounded-xl space-y-4 font-sans text-xs">
              {/* Receipt Header */}
              <div className="text-center border-b pb-3 space-y-1">
                <h2 className="text-lg font-black tracking-tight uppercase">{company.companyName || 'ARCO SHOES CO.'}</h2>
                <p className="text-[11px] text-gray-700">{company.addressLine1}, {company.city} - {company.pincode}</p>
                <p className="text-[11px] font-mono">GSTIN: {company.gstin} | Phone: {company.phone}</p>
                <div className="inline-block px-3 py-0.5 bg-gray-200 text-gray-900 font-bold rounded-full text-[10px] uppercase tracking-wider mt-1">
                  {completedExchange ? 'ITEM EXCHANGE VOUCHER' : 'CREDIT NOTE / SALES RETURN'}
                </div>
              </div>

              {/* Doc Details */}
              {completedReturn && (
                <>
                  <div className="grid grid-cols-2 gap-2 text-[11px] border-b pb-2">
                    <div>
                      <p><strong>Voucher No:</strong> <span className="font-mono">{completedReturn.returnNo}</span></p>
                      <p><strong>Date & Time:</strong> {completedReturn.returnDate} {completedReturn.returnTime}</p>
                      <p><strong>Original Bill:</strong> <span className="font-mono">{completedReturn.originalInvoiceNo}</span> ({completedReturn.originalInvoiceDate})</p>
                    </div>
                    <div className="text-right">
                      <p><strong>Customer:</strong> {completedReturn.customerName}</p>
                      <p><strong>Phone:</strong> {completedReturn.customerMobile || 'N/A'}</p>
                    </div>
                  </div>

                  {/* Returned Items Table */}
                  <div className="space-y-1">
                    <h4 className="font-bold text-[11px] uppercase tracking-wider text-gray-800">Returned Items:</h4>
                    <table className="w-full text-left border-collapse text-[10px]">
                      <thead>
                        <tr className="border-b border-gray-300 font-bold">
                          <th className="py-1">Item Description</th>
                          <th className="py-1 text-center">Qty</th>
                          <th className="py-1 text-right">Rate</th>
                          <th className="py-1 text-right">Taxable</th>
                          <th className="py-1 text-right">Net</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {completedReturn.items.map((it, idx) => (
                          <tr key={idx}>
                            <td className="py-1">{it.itemName} ({it.itemCode})</td>
                            <td className="py-1 text-center">{it.returnQuantity} {it.unit}</td>
                            <td className="py-1 text-right">₹{it.rate.toFixed(2)}</td>
                            <td className="py-1 text-right">₹{it.taxableAmount.toFixed(2)}</td>
                            <td className="py-1 text-right font-bold">₹{it.netAmount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Settlement Summary */}
                  <div className="border-t pt-2 space-y-1 text-right text-[11px]">
                    <p>Taxable Amount: <strong>₹{completedReturn.totalTaxable.toFixed(2)}</strong></p>
                    <p>GST Total: <strong>₹{completedReturn.totalTax.toFixed(2)}</strong></p>
                    <p className="text-sm font-black text-gray-900">
                      Total Refund / Credit: ₹{completedReturn.grandTotal.toFixed(2)} ({completedReturn.refundMode})
                    </p>
                  </div>
                </>
              )}

              {/* Exchange Doc Details */}
              {completedExchange && (
                <>
                  <div className="grid grid-cols-2 gap-2 text-[11px] border-b pb-2">
                    <div>
                      <p><strong>Exchange Voucher:</strong> <span className="font-mono">{completedExchange.exchangeNo}</span></p>
                      <p><strong>Date & Time:</strong> {completedExchange.exchangeDate} {completedExchange.exchangeTime}</p>
                      <p><strong>Original Bill:</strong> <span className="font-mono">{completedExchange.originalInvoiceNo}</span> ({completedExchange.originalInvoiceDate})</p>
                    </div>
                    <div className="text-right">
                      <p><strong>Customer:</strong> {completedExchange.customerName}</p>
                      <p><strong>Phone:</strong> {completedExchange.customerMobile || 'N/A'}</p>
                    </div>
                  </div>

                  {/* Returned Items */}
                  <div className="space-y-1">
                    <h4 className="font-bold text-[11px] uppercase tracking-wider text-rose-700">1. Returned Item(s):</h4>
                    <table className="w-full text-left border-collapse text-[10px]">
                      <thead>
                        <tr className="border-b border-gray-300 font-bold">
                          <th className="py-1">Item</th>
                          <th className="py-1 text-center">Qty</th>
                          <th className="py-1 text-right">Rate</th>
                          <th className="py-1 text-right">Net Return Value</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {completedExchange.returnedItems.map((it, idx) => (
                          <tr key={idx}>
                            <td className="py-1">{it.itemName} ({it.itemCode})</td>
                            <td className="py-1 text-center">{it.returnQuantity} {it.unit}</td>
                            <td className="py-1 text-right">₹{it.rate.toFixed(2)}</td>
                            <td className="py-1 text-right font-bold text-rose-700">₹{it.netAmount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Replacement Items */}
                  <div className="space-y-1 mt-2">
                    <h4 className="font-bold text-[11px] uppercase tracking-wider text-cyan-700">2. Replacement Item(s) Delivered:</h4>
                    <table className="w-full text-left border-collapse text-[10px]">
                      <thead>
                        <tr className="border-b border-gray-300 font-bold">
                          <th className="py-1">Item</th>
                          <th className="py-1 text-center">Qty</th>
                          <th className="py-1 text-right">Rate</th>
                          <th className="py-1 text-right">Net Value</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {completedExchange.newItems.map((it, idx) => (
                          <tr key={idx}>
                            <td className="py-1">{it.itemName} ({it.itemCode})</td>
                            <td className="py-1 text-center">{it.quantity} {it.unit}</td>
                            <td className="py-1 text-right">₹{it.rate.toFixed(2)}</td>
                            <td className="py-1 text-right font-bold text-cyan-700">₹{it.netAmount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Exchange Settlement Math */}
                  <div className="border-t pt-2 space-y-1 text-right text-[11px]">
                    <p>Returned Total: <strong>₹{completedExchange.returnedTotalValue.toFixed(2)}</strong></p>
                    <p>Replacement Total: <strong>₹{completedExchange.newTotalValue.toFixed(2)}</strong></p>
                    <div className="text-sm font-black text-gray-900 pt-1 border-t">
                      Difference Amount: {completedExchange.differenceAmount >= 0 ? '+' : '-'}₹{Math.abs(completedExchange.differenceAmount).toFixed(2)}
                      <span className="text-[10px] font-normal block text-gray-600">
                        {completedExchange.differenceAmount > 0
                          ? `(Additional Amount Received via ${completedExchange.paymentMethod || 'Cash'})`
                          : completedExchange.differenceAmount < 0
                          ? `(Refunded via ${completedExchange.refundMethod || 'Cash'})`
                          : '(Even Exchange - ₹0 Difference)'}
                      </span>
                    </div>
                  </div>
                </>
              )}

              {/* Signatures */}
              <div className="pt-6 flex justify-between text-[10px] text-gray-600">
                <span>Customer Signature</span>
                <span>Authorized Signatory for {company.companyName}</span>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Document</span>
              </button>
              <button
                onClick={() => {
                  setShowPrintModal(false);
                  setCompletedReturn(null);
                  setCompletedExchange(null);
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
