/**
 * Precise GST and Currency calculation service
 * Preserves legacy Access / VB6 rounding and financial rules.
 */

export function roundTo2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function formatCurrency(value: number | undefined | null, symbol = '₹'): string {
  const num = Number(value) || 0;
  return `${symbol} ${num.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatNumber(value: number | undefined | null): string {
  const num = Number(value) || 0;
  return num.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export interface GSTLineCalculation {
  grossAmount: number;
  discountPercent: number;
  discountAmount: number;
  taxableAmount: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  igstRate: number;
  igstAmount: number;
  netAmount: number;
}

export function calculateLineGST(
  qty: number,
  rate: number,
  discountInput: number | string,
  gstRate: number,
  isInterState: boolean,
  taxType: 'Inclusive' | 'Exclusive' = 'Exclusive'
): GSTLineCalculation {
  const safeQty = Math.max(0, Number(qty) || 0);
  const safeRate = Math.max(0, Number(rate) || 0);
  const safeGstRate = Math.max(0, Number(gstRate) || 0);

  let safeDiscPercent = 0;
  let fixedDiscAmount: number | null = null;

  if (typeof discountInput === 'string') {
    const trimmed = discountInput.trim();
    if (trimmed.includes('%')) {
      const parsedPct = parseFloat(trimmed.replace('%', ''));
      safeDiscPercent = Math.max(0, Math.min(100, isNaN(parsedPct) ? 0 : parsedPct));
    } else if (trimmed !== '') {
      const parsedAmt = parseFloat(trimmed);
      if (!isNaN(parsedAmt) && parsedAmt >= 0) {
        fixedDiscAmount = parsedAmt;
      }
    }
  } else if (typeof discountInput === 'number') {
    const num = Number(discountInput);
    if (!isNaN(num) && num >= 0) {
      fixedDiscAmount = num;
    }
  }

  if (taxType === 'Inclusive' && safeGstRate > 0) {
    // If rate is inclusive of GST:
    const totalInclusive = safeQty * safeRate;
    let discAmt = 0;
    if (fixedDiscAmount !== null) {
      discAmt = roundTo2(Math.min(totalInclusive, fixedDiscAmount));
      safeDiscPercent = totalInclusive > 0 ? roundTo2((discAmt / totalInclusive) * 100) : 0;
    } else {
      discAmt = roundTo2((totalInclusive * safeDiscPercent) / 100);
    }

    const netInclusive = totalInclusive - discAmt;
    const taxableAmount = roundTo2(netInclusive / (1 + safeGstRate / 100));
    const totalTax = roundTo2(netInclusive - taxableAmount);

    let cgstRate = 0;
    let cgstAmount = 0;
    let sgstRate = 0;
    let sgstAmount = 0;
    let igstRate = 0;
    let igstAmount = 0;

    if (isInterState) {
      igstRate = safeGstRate;
      igstAmount = totalTax;
    } else {
      cgstRate = roundTo2(safeGstRate / 2);
      sgstRate = roundTo2(safeGstRate / 2);
      cgstAmount = roundTo2(totalTax / 2);
      sgstAmount = roundTo2(totalTax - cgstAmount); // avoids 1 paisa rounding diff
    }

    return {
      grossAmount: roundTo2(totalInclusive),
      discountPercent: safeDiscPercent,
      discountAmount: discAmt,
      taxableAmount,
      cgstRate,
      cgstAmount,
      sgstRate,
      sgstAmount,
      igstRate,
      igstAmount,
      netAmount: roundTo2(netInclusive),
    };
  }

  // Standard Exclusive calculation (VB6 Default)
  const grossAmount = roundTo2(safeQty * safeRate);
  let discountAmount = 0;
  if (fixedDiscAmount !== null) {
    discountAmount = roundTo2(Math.min(grossAmount, fixedDiscAmount));
    safeDiscPercent = grossAmount > 0 ? roundTo2((discountAmount / grossAmount) * 100) : 0;
  } else {
    discountAmount = roundTo2((grossAmount * safeDiscPercent) / 100);
  }

  const taxableAmount = roundTo2(grossAmount - discountAmount);

  let cgstRate = 0;
  let cgstAmount = 0;
  let sgstRate = 0;
  let sgstAmount = 0;
  let igstRate = 0;
  let igstAmount = 0;

  if (isInterState) {
    igstRate = safeGstRate;
    igstAmount = roundTo2((taxableAmount * safeGstRate) / 100);
  } else {
    cgstRate = roundTo2(safeGstRate / 2);
    sgstRate = roundTo2(safeGstRate / 2);
    cgstAmount = roundTo2((taxableAmount * cgstRate) / 100);
    sgstAmount = roundTo2((taxableAmount * sgstRate) / 100);
  }

  const netAmount = roundTo2(taxableAmount + cgstAmount + sgstAmount + igstAmount);

  return {
    grossAmount,
    discountPercent: safeDiscPercent,
    discountAmount,
    taxableAmount,
    cgstRate,
    cgstAmount,
    sgstRate,
    sgstAmount,
    igstRate,
    igstAmount,
    netAmount,
  };
}

/**
 * Convert numeric amount into English Words (Indian numbering format: Lakhs, Crores)
 */
export function numberToWords(amount: number): string {
  const num = Math.floor(Math.abs(amount));
  const paisa = Math.round((Math.abs(amount) - num) * 100);

  if (num === 0 && paisa === 0) return 'Rupees Zero Only';

  const ones = [
    '',
    'One',
    'Two',
    'Three',
    'Four',
    'Five',
    'Six',
    'Seven',
    'Eight',
    'Nine',
    'Ten',
    'Eleven',
    'Twelve',
    'Thirteen',
    'Fourteen',
    'Fifteen',
    'Sixteen',
    'Seventeen',
    'Eighteen',
    'Nineteen',
  ];

  const tens = [
    '',
    '',
    'Twenty',
    'Thirty',
    'Forty',
    'Fifty',
    'Sixty',
    'Seventy',
    'Eighty',
    'Ninety',
  ];

  function convertTwoDigits(n: number): string {
    if (n < 20) return ones[n];
    const t = Math.floor(n / 10);
    const o = n % 10;
    return `${tens[t]}${o > 0 ? ' ' + ones[o] : ''}`;
  }

  function convertThreeDigits(n: number): string {
    const h = Math.floor(n / 100);
    const rem = n % 100;
    let res = '';
    if (h > 0) {
      res += `${ones[h]} Hundred`;
      if (rem > 0) res += ' and ';
    }
    if (rem > 0) {
      res += convertTwoDigits(rem);
    }
    return res;
  }

  let words = '';
  let crore = Math.floor(num / 10000000);
  let remainder = num % 10000000;

  let lakh = Math.floor(remainder / 100000);
  remainder = remainder % 100000;

  let thousand = Math.floor(remainder / 1000);
  remainder = remainder % 1000;

  let hundreds = remainder;

  if (crore > 0) {
    words += `${convertTwoDigits(crore)} Crore `;
  }
  if (lakh > 0) {
    words += `${convertTwoDigits(lakh)} Lakh `;
  }
  if (thousand > 0) {
    words += `${convertTwoDigits(thousand)} Thousand `;
  }
  if (hundreds > 0) {
    words += convertThreeDigits(hundreds);
  }

  words = words.trim();
  let result = `Rupees ${words}`;
  if (paisa > 0) {
    result += ` and ${convertTwoDigits(paisa)} Paise`;
  }
  return result + ' Only';
}

export const INDIAN_STATES = [
  { code: '01', name: 'Jammu & Kashmir' },
  { code: '02', name: 'Himachal Pradesh' },
  { code: '03', name: 'Punjab' },
  { code: '04', name: 'Chandigarh' },
  { code: '05', name: 'Uttarakhand' },
  { code: '06', name: 'Haryana' },
  { code: '07', name: 'Delhi' },
  { code: '08', name: 'Rajasthan' },
  { code: '09', name: 'Uttar Pradesh' },
  { code: '10', name: 'Bihar' },
  { code: '11', name: 'Sikkim' },
  { code: '12', name: 'Arunachal Pradesh' },
  { code: '13', name: 'Nagaland' },
  { code: '14', name: 'Manipur' },
  { code: '15', name: 'Mizoram' },
  { code: '16', name: 'Tripura' },
  { code: '17', name: 'Meghalaya' },
  { code: '18', name: 'Assam' },
  { code: '19', name: 'West Bengal' },
  { code: '20', name: 'Jharkhand' },
  { code: '21', name: 'Odisha' },
  { code: '22', name: 'Chhattisgarh' },
  { code: '23', name: 'Madhya Pradesh' },
  { code: '24', name: 'Gujarat' },
  { code: '26', name: 'Dadra and Nagar Haveli and Daman and Diu' },
  { code: '27', name: 'Maharashtra' },
  { code: '28', name: 'Andhra Pradesh' },
  { code: '29', name: 'Karnataka' },
  { code: '30', name: 'Goa' },
  { code: '31', name: 'Lakshadweep' },
  { code: '32', name: 'Kerala' },
  { code: '33', name: 'Tamil Nadu' },
  { code: '34', name: 'Puducherry' },
  { code: '35', name: 'Andaman & Nicobar' },
  { code: '36', name: 'Telangana' },
  { code: '37', name: 'Andhra Pradesh (New)' },
  { code: '38', name: 'Ladakh' },
];
