import { SalesInvoice, CompanyInfo } from '../types';
import { dbService } from './storage';
import { getApiUrl, checkBackendHealth } from './apiConfig';

export interface DayBookStatus {
  todayDaySales: number;
  totalSalesExchangeAmount: number;
  netDayCollection: number;
}

export interface EmailSendResult {
  success: boolean;
  message?: string;
  error?: string;
  isConfigIncomplete?: boolean;
  skipped?: boolean;
  recipientEmail?: string;
}

/**
 * Calculates Day Book figures matching the Day Book page logic
 */
export function getUpdatedDayBookStatus(targetDate: string): DayBookStatus {
  try {
    const allSales = dbService.getSales();
    const allSalesExchangeDesk = dbService.getSalesExchangeDeskRecords();

    // 1. Today Day Sales (all sales for targetDate)
    const todaySales = allSales
      .filter((s) => s.invoiceDate === targetDate)
      .reduce((sum, s) => sum + (Number(s.grandTotal) || 0), 0);

    // 2. Total Sales Exchange Amount (exchange desk records for targetDate)
    const dayDeskList = allSalesExchangeDesk.filter(
      (ed) =>
        (ed.billModifiedDate === targetDate ||
          ed.invoiceDate === targetDate ||
          (ed.createdAt && ed.createdAt.startsWith(targetDate))) &&
        !(ed.invoiceDate && ed.billModifiedDate && ed.invoiceDate === ed.billModifiedDate)
    );

    const totalSalesExchangeAmount = dayDeskList.reduce(
      (sum, ed) => sum + (Number(ed.netAmount) || 0),
      0
    );

    // 3. Net Day Collection = Today Day Sales + Total Sales Exchange Amount
    const netDayCollection = todaySales + totalSalesExchangeAmount;

    return {
      todayDaySales: Math.round(todaySales * 100) / 100,
      totalSalesExchangeAmount: Math.round(totalSalesExchangeAmount * 100) / 100,
      netDayCollection: Math.round(netDayCollection * 100) / 100,
    };
  } catch (err) {
    console.error('[DayBookStatus Error]:', err);
    return {
      todayDaySales: 0,
      totalSalesExchangeAmount: 0,
      netDayCollection: 0,
    };
  }
}

/**
 * Sends an email for the saved invoice via secure server-side endpoint
 */
export async function sendInvoiceEmail(
  invoice: SalesInvoice,
  company: CompanyInfo,
  options?: {
    isModified?: boolean;
    targetDate?: string;
  }
): Promise<EmailSendResult> {
  // Check if "Send E-Mail" option is disabled
  if (company.sendEmail === false) {
    return {
      success: false,
      skipped: true,
      message: 'Send E-Mail checkbox is disabled in Settings.',
    };
  }

  // Pre-validate client configuration to warn user if fields are blank
  const hasSender = Boolean(company.smtpEmail?.trim());
  const hasReceiver = Boolean(company.receivingEmail?.trim());

  if (!hasSender || !hasReceiver) {
    return {
      success: false,
      isConfigIncomplete: true,
      error: 'Email settings are incomplete. Please specify Email and Receiving Email in Settings.',
    };
  }

  // Retrieve latest Day Book status for target date AFTER the bill has been saved
  const effectiveDate = options?.targetDate || invoice.billModifiedDate || invoice.invoiceDate || new Date().toISOString().split('T')[0];
  const dayBookStatus = getUpdatedDayBookStatus(effectiveDate);

  try {
    const response = await fetch(getApiUrl('/api/send-invoice-email'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        invoice,
        isModified: options?.isModified ?? Boolean(invoice.billModifiedDate),
        dayBookStatus,
        companyInfo: {
          companyName: company.companyName,
          address: [company.addressLine1, company.addressLine2, company.city, company.state, company.pincode]
            .filter(Boolean)
            .join(', '),
          gstin: company.gstin,
          phone: company.phone || company.mobile,
        },
        emailConfig: {
          smtpEmail: company.smtpEmail,
          smtpPassword: company.smtpPassword,
          receivingEmail: company.receivingEmail,
          sendEmail: company.sendEmail ?? true,
        },
      }),
    });

    const responseText = await response.text();
    let data: any = {};

    const isHtmlResponse =
      responseText.trim().startsWith('<') ||
      responseText.includes('<!DOCTYPE') ||
      responseText.includes('<!doctype') ||
      responseText.includes('<html');

    if (isHtmlResponse) {
      return {
        success: false,
        error: `SMTP backend server is unavailable or incorrectly configured. Received an HTML response instead of JSON (${response.status}). In Firebase production, make sure Cloud Function "api" is deployed. In local dev, verify that the Node.js Express backend is running.`,
      };
    }

    try {
      data = JSON.parse(responseText);
    } catch (parseErr) {
      console.warn('[EmailService] Response is not valid JSON:', responseText);
      return {
        success: false,
        error: `Email server endpoint returned an invalid response (${response.status}).`,
      };
    }

    if (!response.ok) {
      return {
        success: false,
        error: data.error || data.message || `Server responded with status ${response.status}`,
        isConfigIncomplete: Boolean(data.isConfigIncomplete),
      };
    }

    return {
      success: Boolean(data.success),
      message: data.message,
      error: data.error,
      isConfigIncomplete: Boolean(data.isConfigIncomplete),
      skipped: Boolean(data.skipped),
      recipientEmail: (data.recipientEmail || company.receivingEmail || '').trim(),
    };
  } catch (err: any) {
    console.error('[EmailService Error]:', err);
    return {
      success: false,
      error: 'SMTP backend server is unavailable. Could not connect to API server.',
    };
  }
}

/**
 * Tests the email SMTP connection and sends a test email
 */
export async function testEmailConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  try {
    const effectiveSmtpEmail = (company.smtpEmail || company.email || '').trim();
    const effectiveReceivingEmail = (company.receivingEmail || company.email || company.smtpEmail || '').trim();
    const effectivePassword = (company.smtpPassword || '').trim();

    const companyToSync: CompanyInfo = {
      ...company,
      smtpEmail: effectiveSmtpEmail,
      receivingEmail: effectiveReceivingEmail,
      smtpPassword: effectivePassword || company.smtpPassword,
    };

    // First sync credentials to server
    await syncEmailConfigToServer(companyToSync);

    const response = await fetch(getApiUrl('/api/test-email'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        smtpEmail: effectiveSmtpEmail,
        smtpPassword: effectivePassword,
        receivingEmail: effectiveReceivingEmail,
        email: company.email,
      }),
    });

    const responseText = await response.text();
    let data: any = {};

    const isHtmlResponse =
      responseText.trim().startsWith('<') ||
      responseText.includes('<!DOCTYPE') ||
      responseText.includes('<!doctype') ||
      responseText.includes('<html');

    if (isHtmlResponse) {
      return {
        success: false,
        message:
          'SMTP backend server is unavailable or incorrectly configured. Received an HTML webpage instead of an API response (200). In Firebase production, ensure Cloud Functions ("api") is deployed and firebase.json routes /api/** to function "api". In local development, ensure the Node.js Express backend is running on port 3000.',
      };
    }

    try {
      data = JSON.parse(responseText);
    } catch (e) {
      return {
        success: false,
        message: 'Could not communicate with email test service (invalid response).',
      };
    }

    if (!data.success) {
      return {
        success: false,
        message: data.error || data.message || 'SMTP authentication or connection test failed.',
      };
    }

    return {
      success: true,
      message: data.message || 'Email test succeeded! Test email sent successfully.',
    };
  } catch (err: any) {
    return {
      success: false,
      message: 'SMTP backend server is unavailable. Could not connect to email test service.',
    };
  }
}

/**
 * Saves email configuration securely to server-side memory & storage
 */
export async function syncEmailConfigToServer(company: Partial<CompanyInfo>): Promise<void> {
  try {
    await fetch(getApiUrl('/api/email-config'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        smtpEmail: company.smtpEmail,
        smtpPassword: company.smtpPassword,
        receivingEmail: company.receivingEmail,
        sendEmail: company.sendEmail ?? true,
      }),
    });
  } catch (err) {
    console.warn('[SyncEmailConfigToServer] Error:', err);
  }
}
