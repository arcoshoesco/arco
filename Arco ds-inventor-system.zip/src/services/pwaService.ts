export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

type PWAInstallListener = () => void;

class PWAService {
  private deferredPrompt: BeforeInstallPromptEvent | null = null;
  private isInstalled: boolean = false;
  private listeners: Set<PWAInstallListener> = new Set();
  private userChoiceOutcome: 'accepted' | 'dismissed' | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.checkInstalledStatus();

      window.addEventListener('beforeinstallprompt', (e: Event) => {
        // Prevent default mini-infobar from appearing on mobile
        e.preventDefault();
        // Stash the event so it can be triggered later.
        this.deferredPrompt = e as BeforeInstallPromptEvent;
        this.notify();
      });

      window.addEventListener('appinstalled', () => {
        this.isInstalled = true;
        this.deferredPrompt = null;
        this.notify();
        console.log('[PWA] ARCO SHOES has been installed as a desktop/mobile app.');
      });

      // Watch for display mode changes (e.g. user opens in standalone window)
      try {
        const mediaQuery = window.matchMedia('(display-mode: standalone)');
        mediaQuery.addEventListener?.('change', (e) => {
          this.isInstalled = e.matches;
          this.notify();
        });
      } catch (err) {}
    }
  }

  public checkInstalledStatus(): boolean {
    if (typeof window === 'undefined') return false;
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
      document.referrer.includes('android-app://');
    this.isInstalled = isStandalone;
    return isStandalone;
  }

  public getIsInstallable(): boolean {
    return !!this.deferredPrompt && !this.isInstalled;
  }

  public getIsInstalled(): boolean {
    return this.isInstalled || this.checkInstalledStatus();
  }

  public getDeferredPrompt(): BeforeInstallPromptEvent | null {
    return this.deferredPrompt;
  }

  public getUserChoiceOutcome(): 'accepted' | 'dismissed' | null {
    return this.userChoiceOutcome;
  }

  public isSecureContext(): boolean {
    if (typeof window === 'undefined') return true;
    return (
      window.isSecureContext ||
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1'
    );
  }

  public isSupportedBrowser(): { isChromeOrEdge: boolean; name: string } {
    if (typeof navigator === 'undefined') return { isChromeOrEdge: true, name: 'Modern Browser' };
    const ua = navigator.userAgent;
    const isEdge = /Edg\//.test(ua);
    const isChrome = /Chrome\//.test(ua) && !/Edg\//.test(ua) && !/OPR\//.test(ua);
    if (isEdge) return { isChromeOrEdge: true, name: 'Microsoft Edge' };
    if (isChrome) return { isChromeOrEdge: true, name: 'Google Chrome' };
    return { isChromeOrEdge: false, name: 'Other Browser' };
  }

  public async promptInstall(): Promise<{ outcome: 'accepted' | 'dismissed' | 'unavailable' }> {
    if (!this.deferredPrompt) {
      return { outcome: 'unavailable' };
    }
    try {
      await this.deferredPrompt.prompt();
      const choice = await this.deferredPrompt.userChoice;
      this.userChoiceOutcome = choice.outcome;
      if (choice.outcome === 'accepted') {
        this.isInstalled = true;
        this.deferredPrompt = null;
      }
      this.notify();
      return { outcome: choice.outcome };
    } catch (err) {
      console.error('[PWA] Error displaying install prompt:', err);
      return { outcome: 'unavailable' };
    }
  }

  public subscribe(listener: PWAInstallListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => {
      try {
        fn();
      } catch (e) {}
    });
  }
}

export const pwaService = new PWAService();
