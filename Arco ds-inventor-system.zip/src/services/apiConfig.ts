/**
 * Centralized API URL and health configuration helper.
 * Supports development, production, custom VITE_API_URL, same-origin, and IIS reverse proxy environments.
 */

export function getApiUrl(endpoint: string): string {
  let customUrl = '';
  try {
    const storedComp = localStorage.getItem('arco_company_info');
    if (storedComp) {
      const parsed = JSON.parse(storedComp);
      if (parsed.customBackendUrl && typeof parsed.customBackendUrl === 'string') {
        customUrl = parsed.customBackendUrl.trim();
      }
    }
    if (!customUrl) {
      customUrl = (localStorage.getItem('arco_backend_api_url') || '').trim();
    }
  } catch (e) {}

  let baseUrl = (customUrl || import.meta.env.VITE_API_URL || '').trim().replace(/\/+$/, '');

  // Guard: If it's a dummy placeholder (e.g. 'your-backend-app.onrender.com' or 'example.com'), ignore it
  if (baseUrl.includes('your-backend-app') || baseUrl.includes('example.com') || baseUrl === 'https://' || baseUrl === 'http://') {
    baseUrl = '';
  }

  // Guard: If running in production browser on a remote domain (e.g., Firebase Hosting *.web.app, *.firebaseapp.com, etc.),
  // do NOT let a stale or accidentally baked 'localhost:3000' break production API calls unless explicitly set in customUrl.
  if (!customUrl && typeof window !== 'undefined' && window.location && window.location.hostname) {
    const isLocalhostBrowser =
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1' ||
      window.location.hostname === '0.0.0.0';
    if (!isLocalhostBrowser && (baseUrl.includes('localhost') || baseUrl.includes('127.0.0.1'))) {
      baseUrl = '';
    }
  }

  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return baseUrl ? `${baseUrl}${cleanEndpoint}` : cleanEndpoint;
}

export interface BackendHealthResponse {
  success: boolean;
  service?: string;
  status?: string;
  port?: number;
  timestamp?: string;
  message?: string;
  isHtmlResponse?: boolean;
}

export async function checkBackendHealth(): Promise<BackendHealthResponse> {
  try {
    const url = getApiUrl('/api/health');
    const response = await fetch(url, { method: 'GET' });
    const responseText = await response.text();

    const isHtml =
      responseText.trim().startsWith('<') ||
      responseText.includes('<!DOCTYPE') ||
      responseText.includes('<!doctype') ||
      responseText.includes('<html');

    if (isHtml) {
      return {
        success: false,
        isHtmlResponse: true,
        message:
          'Backend API server unreachable: Received an HTML webpage instead of an API response (200). In Firebase production, ensure Cloud Functions ("api") is deployed and firebase.json routes /api/** to function "api". In local development, ensure Node.js Express server is started and listening on port 3000.',
      };
    }

    try {
      const data = JSON.parse(responseText);
      if (response.ok && (data.success || data.status === 'ok' || data.status === 'running')) {
        return {
          success: true,
          service: data.service || 'SMTP Backend',
          status: data.status || 'running',
          port: data.port,
          timestamp: data.timestamp,
          message: 'Node.js Express backend is running and reachable.',
        };
      }
      return {
        success: false,
        message: data.error || data.message || `Backend health check failed with status ${response.status}`,
      };
    } catch (parseErr) {
      return {
        success: false,
        message: `Backend returned non-JSON response (${response.status}).`,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: `SMTP backend server is unavailable: ${err.message || 'Could not connect to API server'}.`,
    };
  }
}
