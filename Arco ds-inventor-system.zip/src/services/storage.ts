import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDoc,
  getDocs,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import {
  db,
  defaultDb,
  syncDocToFirestore,
  syncDeleteFromFirestore,
  BACKEND_DETAILS,
} from '../firebase';
import { getApiUrl } from './apiConfig';
import {
  CompanyInfo,
  Customer,
  CustomerCreditTransaction,
  CustomerReceipt,
  InvoiceItem,
  InvoiceReturnStatus,
  Item,
  LedgerEntry,
  MigrationSummary,
  PurchaseInvoice,
  PurchaseReturn,
  ReturnedItemLine,
  SalesExchange,
  SalesExchangeDeskRecord,
  SalesInvoice,
  SalesReturn,
  StockAdjustment,
  StockMovement,
  Supplier,
  SupplierPayment,
  SecurityAuthSettings,
} from '../types';
import {
  INITIAL_COMPANY,
  INITIAL_CUSTOMERS,
  INITIAL_ITEMS,
  INITIAL_LEDGERS,
  INITIAL_PURCHASES,
  INITIAL_SALES,
  INITIAL_SUPPLIERS,
} from '../data/initialData';
import { roundTo2 } from './gstCalculations';

export const INITIAL_SECURITY: SecurityAuthSettings = {
  email: 'arcoshoesco@gmail.com',
  password: 'admin123',
  securityQuestion: 'What is your registered shop brand name?',
  securityAnswer: 'ARCO SHOES',
  recoveryPin: '7860',
  lastChangedAt: new Date().toISOString(),
};

const FIREBASE_STORAGE_KEYS = {
  COMPANY: 'arco_firebase_company_v2',
  ITEMS: 'arco_firebase_items_v2',
  CUSTOMERS: 'arco_firebase_customers_v2',
  SUPPLIERS: 'arco_firebase_suppliers_v2',
  SALES: 'arco_firebase_sales_v2',
  SALES_RETURNS: 'arco_firebase_sales_returns_v2',
  SALES_EXCHANGES: 'arco_firebase_sales_exchanges_v2',
  SALES_EXCHANGE_DESK: 'arco_firebase_sales_exchange_desk_v2',
  STOCK_MOVEMENTS: 'arco_firebase_stock_movements_v2',
  CUSTOMER_CREDIT_TXNS: 'arco_firebase_customer_credit_txns_v2',
  PURCHASES: 'arco_firebase_purchases_v2',
  PURCHASE_RETURNS: 'arco_firebase_purchase_returns_v2',
  RECEIPTS: 'arco_firebase_receipts_v2',
  PAYMENTS: 'arco_firebase_payments_v2',
  ADJUSTMENTS: 'arco_firebase_adjustments_v2',
  LEDGERS: 'arco_firebase_ledgers_v2',
  CLEARED_DEMO: 'arco_demo_cleared_flag_v2',
  SECURITY: 'arco_security_auth_v2',
  AUTH_SESSION: 'arco_auth_session_v2',
};

const MONGODB_STORAGE_KEYS = {
  COMPANY: 'arco_firebase_company_v2',
  ITEMS: 'arco_mongodb_items_v2',
  CUSTOMERS: 'arco_mongodb_customers_v2',
  SUPPLIERS: 'arco_mongodb_suppliers_v2',
  SALES: 'arco_mongodb_sales_v2',
  SALES_RETURNS: 'arco_mongodb_sales_returns_v2',
  SALES_EXCHANGES: 'arco_mongodb_sales_exchanges_v2',
  SALES_EXCHANGE_DESK: 'arco_mongodb_sales_exchange_desk_v2',
  STOCK_MOVEMENTS: 'arco_mongodb_stock_movements_v2',
  CUSTOMER_CREDIT_TXNS: 'arco_mongodb_customer_credit_txns_v2',
  PURCHASES: 'arco_mongodb_purchases_v2',
  PURCHASE_RETURNS: 'arco_mongodb_purchase_returns_v2',
  RECEIPTS: 'arco_mongodb_receipts_v2',
  PAYMENTS: 'arco_mongodb_payments_v2',
  ADJUSTMENTS: 'arco_mongodb_adjustments_v2',
  LEDGERS: 'arco_mongodb_ledgers_v2',
  CLEARED_DEMO: 'arco_mongodb_demo_cleared_flag_v2',
  SECURITY: 'arco_security_auth_v2',
  AUTH_SESSION: 'arco_auth_session_v2',
};

// Legacy fallback compatibility
const STORAGE_KEYS = FIREBASE_STORAGE_KEYS;

// Firestore Collection Names
const COLLECTIONS = {
  SETTINGS: 'settings',
  ITEMS: 'items',
  CUSTOMERS: 'customers',
  SUPPLIERS: 'suppliers',
  SALES: 'sales_invoices',
  SALES_RETURNS: 'sales_returns',
  SALES_EXCHANGES: 'sales_exchanges',
  SALES_EXCHANGE_DESK: 'sales_exchange_desk',
  STOCK_MOVEMENTS: 'stock_movements',
  CUSTOMER_CREDIT_TXNS: 'customer_credit_transactions',
  PURCHASES: 'purchase_invoices',
  PURCHASE_RETURNS: 'purchase_returns',
  RECEIPTS: 'receipts',
  PAYMENTS: 'payments',
  ADJUSTMENTS: 'stock_adjustments',
  LEDGERS: 'ledgers',
};

/**
 * Deeply removes undefined fields from objects and arrays so Firestore never rejects payloads.
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as unknown as T;
  }
  if (Array.isArray(data)) {
    return data.map((item) => sanitizeForFirestore(item)) as unknown as T;
  }
  if (typeof data === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data as Record<string, any>)) {
      if (value !== undefined) {
        cleaned[key] = sanitizeForFirestore(value);
      }
    }
    return cleaned as T;
  }
  return data;
}

type ChangeListener = () => void;

class DBStorageService {
  private listeners: Set<ChangeListener> = new Set();
  private deletedIds: Set<string> = new Set();
  public isFirestoreConnected = true;
  public lastSyncTime: Date = new Date();

  private memoryCache: Map<string, any> = new Map();
  private cachedCompany: CompanyInfo | null = null;
  private isNotifyPending = false;

  public clearMemoryCache(): void {
    this.memoryCache.clear();
    this.cachedCompany = null;
  }

  public getActiveDatabaseType(): 'firebase' | 'mongodb' {
    const company = this.getCompany();
    return company?.databaseType === 'mongodb' ? 'mongodb' : 'firebase';
  }

  private getKey(keyName: keyof typeof FIREBASE_STORAGE_KEYS): string {
    const dbType = this.getActiveDatabaseType();
    return dbType === 'mongodb' ? MONGODB_STORAGE_KEYS[keyName] : FIREBASE_STORAGE_KEYS[keyName];
  }

  private getLocalData<T>(keyName: keyof typeof FIREBASE_STORAGE_KEYS, defaultValue: T): T {
    const key = this.getKey(keyName);
    if (this.memoryCache.has(key)) {
      return this.memoryCache.get(key) as T;
    }
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      const parsed = JSON.parse(data) as T;
      this.memoryCache.set(key, parsed);
      return parsed;
    } catch {
      return defaultValue;
    }
  }

  private setLocalData(keyName: keyof typeof FIREBASE_STORAGE_KEYS, data: any): string {
    const key = this.getKey(keyName);
    this.memoryCache.set(key, data);
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('localStorage set error for', key, e);
    }
    return key;
  }

  public getMongoConfig(): { uri: string; dbName: string } {
    const company = this.getCompany();
    return {
      uri: company.mongoUri || 'mongodb://127.0.0.1:27017',
      dbName: company.mongoDbName || 'arco_shoes_db',
    };
  }

  private async safeSyncDocToFirestore(collectionName: string, docId: string, data: any): Promise<void> {
    const dbType = this.getActiveDatabaseType();
    if (dbType === 'firebase') {
      return syncDocToFirestore(collectionName, docId, data);
    } else if (dbType === 'mongodb') {
      const { uri, dbName } = this.getMongoConfig();
      try {
        await fetch(getApiUrl('/api/mongodb/sync-doc'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mongoUri: uri,
            dbName,
            collectionName,
            docId,
            data,
          }),
        });
      } catch (err) {
        console.warn(`[MongoDB Sync Error] ${collectionName}:`, err);
      }
    }
  }

  private async safeSyncDeleteFromFirestore(collectionName: string, docId: string): Promise<void> {
    const dbType = this.getActiveDatabaseType();
    if (dbType === 'firebase') {
      return syncDeleteFromFirestore(collectionName, docId);
    } else if (dbType === 'mongodb') {
      const { uri, dbName } = this.getMongoConfig();
      try {
        await fetch(getApiUrl('/api/mongodb/delete-doc'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mongoUri: uri,
            dbName,
            collectionName,
            id: docId,
          }),
        });
      } catch (err) {
        console.warn(`[MongoDB Delete Error] ${collectionName}:`, err);
      }
    }
  }

  public async fetchAllDataFromMongo(): Promise<void> {
    if (this.getActiveDatabaseType() !== 'mongodb') return;
    const { uri, dbName } = this.getMongoConfig();
    try {
      const res = await fetch(getApiUrl('/api/mongodb/get-app-data'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mongoUri: uri, dbName }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        console.warn('[MongoDB Fetch All Data] Backend returned non-JSON response.');
        return;
      }
      const result = await res.json();
      if (result.success && result.data) {
        const data = result.data;

        // Populate local memory cache with MongoDB records
        if (Array.isArray(data.items) && data.items.length > 0) {
          this.setLocalData('ITEMS', data.items);
        } else {
          // If MongoDB items collection is empty, auto-push existing items into MongoDB
          const currentItems = this.getItems();
          if (currentItems.length > 0) {
            for (const item of currentItems) {
              this.safeSyncDocToFirestore('items', item.id, item);
            }
          }
        }

        if (Array.isArray(data.customers) && data.customers.length > 0) {
          this.setLocalData('CUSTOMERS', data.customers);
        } else {
          const currentCusts = this.getCustomers();
          if (currentCusts.length > 0) {
            for (const cust of currentCusts) {
              this.safeSyncDocToFirestore('customers', cust.id, cust);
            }
          }
        }

        if (Array.isArray(data.suppliers) && data.suppliers.length > 0) {
          this.setLocalData('SUPPLIERS', data.suppliers);
        } else {
          const currentSups = this.getSuppliers();
          if (currentSups.length > 0) {
            for (const sup of currentSups) {
              this.safeSyncDocToFirestore('suppliers', sup.id, sup);
            }
          }
        }

        if (Array.isArray(data.sales) && data.sales.length > 0) {
          this.setLocalData('SALES', data.sales);
        }
        if (Array.isArray(data.purchases) && data.purchases.length > 0) {
          this.setLocalData('PURCHASES', data.purchases);
        }
        if (Array.isArray(data.sales_returns) && data.sales_returns.length > 0) {
          this.setLocalData('SALES_RETURNS', data.sales_returns);
        }
        if (Array.isArray(data.purchase_returns) && data.purchase_returns.length > 0) {
          this.setLocalData('PURCHASE_RETURNS', data.purchase_returns);
        }
        if (Array.isArray(data.receipts) && data.receipts.length > 0) {
          this.setLocalData('RECEIPTS', data.receipts);
        }
        if (Array.isArray(data.payments) && data.payments.length > 0) {
          this.setLocalData('PAYMENTS', data.payments);
        }
        if (Array.isArray(data.adjustments) && data.adjustments.length > 0) {
          this.setLocalData('ADJUSTMENTS', data.adjustments);
        }
        if (Array.isArray(data.exchanges) && data.exchanges.length > 0) {
          this.setLocalData('SALES_EXCHANGES', data.exchanges);
        }
        if (Array.isArray(data.exchange_desk) && data.exchange_desk.length > 0) {
          this.setLocalData('SALES_EXCHANGE_DESK', data.exchange_desk);
        }
        if (Array.isArray(data.movements) && data.movements.length > 0) {
          this.setLocalData('STOCK_MOVEMENTS', data.movements);
        }
        if (Array.isArray(data.credit_txns) && data.credit_txns.length > 0) {
          this.setLocalData('CUSTOMER_CREDIT_TXNS', data.credit_txns);
        }
        if (Array.isArray(data.ledgers) && data.ledgers.length > 0) {
          this.setLocalData('LEDGERS', data.ledgers);
        }
        if (data.security) {
          this.setLocalData('SECURITY', data.security);
        }

        this.notify();
      }
    } catch (err) {
      console.warn('[MongoDB Fetch All Data Error]:', err);
    }
  }

  constructor() {
    this.initDatabase();
    if (this.getActiveDatabaseType() === 'mongodb') {
      this.fetchAllDataFromMongo().catch((err) => console.warn('Initial MongoDB fetch:', err));
    } else {
      this.initFirestoreRealtimeListeners();
      this.fetchAllDataFromFirestore().catch((err) => console.warn('Initial Firestore fetch:', err));
    }
  }

  // Subscribe to changes (for React components to auto re-render on remote or local updates)
  subscribe(callback: ChangeListener): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.lastSyncTime = new Date();
    if (this.isNotifyPending) return;
    this.isNotifyPending = true;
    queueMicrotask(() => {
      this.isNotifyPending = false;
      this.listeners.forEach((cb) => {
        try {
          cb();
        } catch (err) {
          console.error('Error in storage subscriber:', err);
        }
      });
    });
  }

  // Initialize and clean legacy obsolete keys without ever wiping active database
  private initDatabase() {
    try {
      localStorage.removeItem('vb6_gst_items_v1');
      localStorage.removeItem('vb6_gst_customers_v1');
      localStorage.removeItem('vb6_gst_suppliers_v1');
      localStorage.removeItem('vb6_gst_sales_v1');
      localStorage.removeItem('vb6_gst_sales_returns_v1');
      localStorage.removeItem('vb6_gst_purchases_v1');
      localStorage.removeItem('vb6_gst_purchase_returns_v1');
      localStorage.removeItem('vb6_gst_receipts_v1');
      localStorage.removeItem('vb6_gst_payments_v1');
      localStorage.removeItem('vb6_gst_adjustments_v1');
      localStorage.removeItem('vb6_gst_ledgers_v1');
    } catch {
      // Storage unavailable
    }
  }

  // Set up live Firestore real-time synchronization listeners with authoritative backend state
  private initFirestoreRealtimeListeners() {
    try {
      // 1. Company Settings
      onSnapshot(doc(db, COLLECTIONS.SETTINGS, 'company'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteCompany = snapshot.data() as CompanyInfo;
          this.cachedCompany = remoteCompany;
          try {
            localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
            localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
          } catch {}
          this.notify();
        }
      }, (err) => console.warn('Firestore settings listener:', err.message));

      // 1b. Security & Authentication Settings
      onSnapshot(doc(db, COLLECTIONS.SETTINGS, 'security'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteSec = snapshot.data() as SecurityAuthSettings;
          this.setLocalData('SECURITY', remoteSec);
          this.notify();
        }
      }, (err) => console.warn('Firestore security listener:', err.message));

      // 2. Items
      onSnapshot(collection(db, COLLECTIONS.ITEMS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteItems: Item[] = [];
        snapshot.forEach((d) => {
          const itm = d.data() as Item;
          remoteItems.push({ ...itm, id: itm.id || d.id });
        });
        this.setLocalData('ITEMS', remoteItems);
        this.notify();
      }, (err) => console.warn('Firestore items listener:', err.message));

      // 3. Customers
      onSnapshot(collection(db, COLLECTIONS.CUSTOMERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteCusts: Customer[] = [];
        snapshot.forEach((d) => {
          const cust = d.data() as Customer;
          remoteCusts.push({ ...cust, id: cust.id || d.id });
        });
        this.setLocalData('CUSTOMERS', remoteCusts);
        this.notify();
      }, (err) => console.warn('Firestore customers listener:', err.message));

      // 4. Suppliers
      onSnapshot(collection(db, COLLECTIONS.SUPPLIERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteSups: Supplier[] = [];
        snapshot.forEach((d) => {
          const sup = d.data() as Supplier;
          remoteSups.push({ ...sup, id: sup.id || d.id });
        });
        this.setLocalData('SUPPLIERS', remoteSups);
        this.notify();
      }, (err) => console.warn('Firestore suppliers listener:', err.message));

      // 5. Sales Invoices
      onSnapshot(collection(db, COLLECTIONS.SALES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteSales: SalesInvoice[] = [];
        snapshot.forEach((d) => {
          const sale = d.data() as SalesInvoice;
          remoteSales.push({ ...sale, id: sale.id || d.id });
        });
        this.setLocalData('SALES', remoteSales);
        this.notify();
      }, (err) => console.warn('Firestore sales listener:', err.message));

      // 6. Purchase Invoices
      onSnapshot(collection(db, COLLECTIONS.PURCHASES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePurchases: PurchaseInvoice[] = [];
        snapshot.forEach((d) => {
          const pur = d.data() as PurchaseInvoice;
          remotePurchases.push({ ...pur, id: pur.id || d.id });
        });
        this.setLocalData('PURCHASES', remotePurchases);
        this.notify();
      }, (err) => console.warn('Firestore purchases listener:', err.message));

      // 7. Ledgers
      onSnapshot(collection(db, COLLECTIONS.LEDGERS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteLedgers: LedgerEntry[] = [];
        snapshot.forEach((d) => {
          const led = d.data() as LedgerEntry;
          remoteLedgers.push({ ...led, id: led.id || d.id });
        });
        this.setLocalData('LEDGERS', remoteLedgers);
        this.notify();
      }, (err) => console.warn('Firestore ledgers listener:', err.message));

      // 8. Receipts
      onSnapshot(collection(db, COLLECTIONS.RECEIPTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteRecs: CustomerReceipt[] = [];
        snapshot.forEach((d) => {
          const rec = d.data() as CustomerReceipt;
          remoteRecs.push({ ...rec, id: rec.id || d.id });
        });
        this.setLocalData('RECEIPTS', remoteRecs);
        this.notify();
      }, (err) => console.warn('Firestore receipts listener:', err.message));

      // 9. Payments
      onSnapshot(collection(db, COLLECTIONS.PAYMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePays: SupplierPayment[] = [];
        snapshot.forEach((d) => {
          const pay = d.data() as SupplierPayment;
          remotePays.push({ ...pay, id: pay.id || d.id });
        });
        this.setLocalData('PAYMENTS', remotePays);
        this.notify();
      }, (err) => console.warn('Firestore payments listener:', err.message));

      // 10. Sales Returns
      onSnapshot(collection(db, COLLECTIONS.SALES_RETURNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteReturns: SalesReturn[] = [];
        snapshot.forEach((d) => remoteReturns.push(d.data() as SalesReturn));
        this.setLocalData('SALES_RETURNS', remoteReturns);
        this.notify();
      }, (err) => console.warn('Firestore sales returns listener:', err.message));

      // 11. Purchase Returns
      onSnapshot(collection(db, COLLECTIONS.PURCHASE_RETURNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remotePRs: PurchaseReturn[] = [];
        snapshot.forEach((d) => remotePRs.push(d.data() as PurchaseReturn));
        this.setLocalData('PURCHASE_RETURNS', remotePRs);
        this.notify();
      }, (err) => console.warn('Firestore purchase returns listener:', err.message));

      // 12. Adjustments
      onSnapshot(collection(db, COLLECTIONS.ADJUSTMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteAdjs: StockAdjustment[] = [];
        snapshot.forEach((d) => remoteAdjs.push(d.data() as StockAdjustment));
        this.setLocalData('ADJUSTMENTS', remoteAdjs);
        this.notify();
      }, (err) => console.warn('Firestore adjustments listener:', err.message));

      // 13. Sales Exchanges
      onSnapshot(collection(db, COLLECTIONS.SALES_EXCHANGES), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteExchanges: SalesExchange[] = [];
        snapshot.forEach((d) => remoteExchanges.push(d.data() as SalesExchange));
        this.setLocalData('SALES_EXCHANGES', remoteExchanges);
        this.notify();
      }, (err) => console.warn('Firestore sales exchanges listener:', err.message));

      // 13b. Sales Exchange Desk Records
      onSnapshot(collection(db, COLLECTIONS.SALES_EXCHANGE_DESK), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteDeskRecords: SalesExchangeDeskRecord[] = [];
        snapshot.forEach((d) => remoteDeskRecords.push(d.data() as SalesExchangeDeskRecord));
        this.setLocalData('SALES_EXCHANGE_DESK', remoteDeskRecords);
        this.notify();
      }, (err) => console.warn('Firestore sales exchange desk listener:', err.message));

      // 14. Stock Movements
      onSnapshot(collection(db, COLLECTIONS.STOCK_MOVEMENTS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteMovements: StockMovement[] = [];
        snapshot.forEach((d) => remoteMovements.push(d.data() as StockMovement));
        this.setLocalData('STOCK_MOVEMENTS', remoteMovements);
        this.notify();
      }, (err) => console.warn('Firestore stock movements listener:', err.message));

      // 15. Customer Credit Transactions
      onSnapshot(collection(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS), (snapshot) => {
        if (this.getActiveDatabaseType() === 'mongodb') return;
        const remoteTxns: CustomerCreditTransaction[] = [];
        snapshot.forEach((d) => remoteTxns.push(d.data() as CustomerCreditTransaction));
        this.setLocalData('CUSTOMER_CREDIT_TXNS', remoteTxns);
        this.notify();
      }, (err) => console.warn('Firestore customer credit txns listener:', err.message));

    } catch (err) {
      console.warn('Error connecting Firestore realtime listeners:', err);
    }
  }

  // Explicitly fetch all data from Firebase Firestore and load into local database
  async fetchAllDataFromFirestore(): Promise<{ success: boolean; totalFetched: number; message: string }> {
    if (this.getActiveDatabaseType() === 'mongodb') {
      return { success: true, totalFetched: 0, message: 'MongoDB is selected. Skipped Firestore fetch.' };
    }
    let count = 0;
    try {
      // 1. Company Settings
      try {
        const compSnap = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'company'));
        if (compSnap.exists()) {
          const remoteCompany = compSnap.data() as CompanyInfo;
          localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(remoteCompany));
          count++;
        }
      } catch (err) {
        console.warn('Fetch company error:', err);
      }

      // 2. Security Settings
      try {
        const secSnap = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'security'));
        if (secSnap.exists()) {
          const remoteSec = secSnap.data() as SecurityAuthSettings;
          localStorage.setItem(FIREBASE_STORAGE_KEYS.SECURITY, JSON.stringify(remoteSec));
          count++;
        }
      } catch (err) {
        console.warn('Fetch security error:', err);
      }

      // 3. Items
      try {
        const itemsSnap = await getDocs(collection(db, COLLECTIONS.ITEMS));
        const remoteItems: Item[] = [];
        itemsSnap.forEach((d) => {
          const itm = d.data() as Item;
          remoteItems.push({ ...itm, id: itm.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.ITEMS, JSON.stringify(remoteItems));
        count += remoteItems.length;
      } catch (err) {
        console.warn('Fetch items error:', err);
      }

      // 4. Customers
      try {
        const custSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMERS));
        const remoteCusts: Customer[] = [];
        custSnap.forEach((d) => {
          const cust = d.data() as Customer;
          remoteCusts.push({ ...cust, id: cust.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMERS, JSON.stringify(remoteCusts));
        count += remoteCusts.length;
      } catch (err) {
        console.warn('Fetch customers error:', err);
      }

      // 5. Suppliers
      try {
        const supSnap = await getDocs(collection(db, COLLECTIONS.SUPPLIERS));
        const remoteSups: Supplier[] = [];
        supSnap.forEach((d) => {
          const sup = d.data() as Supplier;
          remoteSups.push({ ...sup, id: sup.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SUPPLIERS, JSON.stringify(remoteSups));
        count += remoteSups.length;
      } catch (err) {
        console.warn('Fetch suppliers error:', err);
      }

      // 6. Sales Invoices
      try {
        const salesSnap = await getDocs(collection(db, COLLECTIONS.SALES));
        const remoteSales: SalesInvoice[] = [];
        salesSnap.forEach((d) => {
          const s = d.data() as SalesInvoice;
          remoteSales.push({ ...s, id: s.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES, JSON.stringify(remoteSales));
        count += remoteSales.length;
      } catch (err) {
        console.warn('Fetch sales error:', err);
      }

      // 7. Purchase Invoices
      try {
        const purSnap = await getDocs(collection(db, COLLECTIONS.PURCHASES));
        const remotePurchases: PurchaseInvoice[] = [];
        purSnap.forEach((d) => {
          const p = d.data() as PurchaseInvoice;
          remotePurchases.push({ ...p, id: p.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASES, JSON.stringify(remotePurchases));
        count += remotePurchases.length;
      } catch (err) {
        console.warn('Fetch purchases error:', err);
      }

      // 8. Sales Returns
      try {
        const srSnap = await getDocs(collection(db, COLLECTIONS.SALES_RETURNS));
        const remoteReturns: SalesReturn[] = [];
        srSnap.forEach((d) => {
          const sr = d.data() as SalesReturn;
          remoteReturns.push({ ...sr, id: sr.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_RETURNS, JSON.stringify(remoteReturns));
        count += remoteReturns.length;
      } catch (err) {
        console.warn('Fetch sales returns error:', err);
      }

      // 9. Sales Exchanges
      try {
        const seSnap = await getDocs(collection(db, COLLECTIONS.SALES_EXCHANGES));
        const remoteExchanges: SalesExchange[] = [];
        seSnap.forEach((d) => {
          const se = d.data() as SalesExchange;
          remoteExchanges.push({ ...se, id: se.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify(remoteExchanges));
        count += remoteExchanges.length;
      } catch (err) {
        console.warn('Fetch sales exchanges error:', err);
      }

      // 9b. Sales Exchange Desk Records
      try {
        const sedSnap = await getDocs(collection(db, COLLECTIONS.SALES_EXCHANGE_DESK));
        const remoteDesk: SalesExchangeDeskRecord[] = [];
        sedSnap.forEach((d) => {
          const r = d.data() as SalesExchangeDeskRecord;
          remoteDesk.push({ ...r, id: r.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify(remoteDesk));
        count += remoteDesk.length;
      } catch (err) {
        console.warn('Fetch exchange desk error:', err);
      }

      // 10. Purchase Returns
      try {
        const prSnap = await getDocs(collection(db, COLLECTIONS.PURCHASE_RETURNS));
        const remotePRs: PurchaseReturn[] = [];
        prSnap.forEach((d) => {
          const pr = d.data() as PurchaseReturn;
          remotePRs.push({ ...pr, id: pr.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify(remotePRs));
        count += remotePRs.length;
      } catch (err) {
        console.warn('Fetch purchase returns error:', err);
      }

      // 11. Customer Receipts
      try {
        const recSnap = await getDocs(collection(db, COLLECTIONS.RECEIPTS));
        const remoteRecs: CustomerReceipt[] = [];
        recSnap.forEach((d) => {
          const r = d.data() as CustomerReceipt;
          remoteRecs.push({ ...r, id: r.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.RECEIPTS, JSON.stringify(remoteRecs));
        count += remoteRecs.length;
      } catch (err) {
        console.warn('Fetch receipts error:', err);
      }

      // 12. Supplier Payments
      try {
        const paySnap = await getDocs(collection(db, COLLECTIONS.PAYMENTS));
        const remotePays: SupplierPayment[] = [];
        paySnap.forEach((d) => {
          const p = d.data() as SupplierPayment;
          remotePays.push({ ...p, id: p.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.PAYMENTS, JSON.stringify(remotePays));
        count += remotePays.length;
      } catch (err) {
        console.warn('Fetch payments error:', err);
      }

      // 13. Stock Adjustments
      try {
        const adjSnap = await getDocs(collection(db, COLLECTIONS.ADJUSTMENTS));
        const remoteAdjs: StockAdjustment[] = [];
        adjSnap.forEach((d) => {
          const a = d.data() as StockAdjustment;
          remoteAdjs.push({ ...a, id: a.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.ADJUSTMENTS, JSON.stringify(remoteAdjs));
        count += remoteAdjs.length;
      } catch (err) {
        console.warn('Fetch adjustments error:', err);
      }

      // 14. Stock Movements
      try {
        const movSnap = await getDocs(collection(db, COLLECTIONS.STOCK_MOVEMENTS));
        const remoteMovs: StockMovement[] = [];
        movSnap.forEach((d) => {
          const m = d.data() as StockMovement;
          remoteMovs.push({ ...m, id: m.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify(remoteMovs));
        count += remoteMovs.length;
      } catch (err) {
        console.warn('Fetch stock movements error:', err);
      }

      // 15. Customer Credit Transactions
      try {
        const cctSnap = await getDocs(collection(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS));
        const remoteTxns: CustomerCreditTransaction[] = [];
        cctSnap.forEach((d) => {
          const t = d.data() as CustomerCreditTransaction;
          remoteTxns.push({ ...t, id: t.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify(remoteTxns));
        count += remoteTxns.length;
      } catch (err) {
        console.warn('Fetch credit txns error:', err);
      }

      // 16. Ledgers
      try {
        const ledSnap = await getDocs(collection(db, COLLECTIONS.LEDGERS));
        const remoteLeds: LedgerEntry[] = [];
        ledSnap.forEach((d) => {
          const l = d.data() as LedgerEntry;
          remoteLeds.push({ ...l, id: l.id || d.id });
        });
        localStorage.setItem(FIREBASE_STORAGE_KEYS.LEDGERS, JSON.stringify(remoteLeds));
        count += remoteLeds.length;
      } catch (err) {
        console.warn('Fetch ledgers error:', err);
      }

      this.isFirestoreConnected = true;
      this.lastSyncTime = new Date();
      this.notify();

      return {
        success: true,
        totalFetched: count,
        message: `Successfully connected to Firebase database and synced records (${count} records active).`,
      };
    } catch (err: any) {
      console.error('Error fetching all data from Firebase:', err);
      return {
        success: false,
        totalFetched: count,
        message: err.message || 'Failed to fetch data from Firebase database',
      };
    }
  }

  // --- Company Settings ---
  getCompany(): CompanyInfo {
    if (this.cachedCompany) {
      return this.cachedCompany;
    }
    try {
      const data = localStorage.getItem(FIREBASE_STORAGE_KEYS.COMPANY) || localStorage.getItem(MONGODB_STORAGE_KEYS.COMPANY);
      const company: CompanyInfo = data ? JSON.parse(data) : INITIAL_COMPANY;
      if (company) {
        if (!company.upiAddress && company.upiId) {
          company.upiAddress = company.upiId;
        }
        if (!company.upiId && company.upiAddress) {
          company.upiId = company.upiAddress;
        }
        if (!Array.isArray(company.upiAddressList) || company.upiAddressList.length === 0) {
          const list: string[] = [];
          if (company.upiAddress) list.push(company.upiAddress);
          if (company.upiId && !list.includes(company.upiId)) list.push(company.upiId);
          if (list.length === 0) list.push('arcoshoes@sbi');
          company.upiAddressList = list;
        }
        if (!company.invoicePrefix || company.invoicePrefix === 'ASC/26-27/' || company.invoicePrefix === 'CUS-2026-') {
          company.invoicePrefix = 'CUS-INV-';
        }
        if (!company.purchasePrefix || company.purchasePrefix === 'PUR/26-27/' || company.purchasePrefix === 'SUP-2026-' || company.purchasePrefix === 'SUP-BILL-') {
          company.purchasePrefix = 'PUR-BILL-';
        }
      }
      this.cachedCompany = company || INITIAL_COMPANY;
      return this.cachedCompany;
    } catch {
      return INITIAL_COMPANY;
    }
  }

  async saveCompany(company: CompanyInfo): Promise<void> {
    const prevDbType = this.cachedCompany?.databaseType;
    this.cachedCompany = company;
    if (prevDbType !== company.databaseType) {
      this.clearMemoryCache();
    }
    try {
      localStorage.setItem(FIREBASE_STORAGE_KEYS.COMPANY, JSON.stringify(company));
      localStorage.setItem(MONGODB_STORAGE_KEYS.COMPANY, JSON.stringify(company));
    } catch {
      // Storage unavailable
    }
    this.notify();
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'company', sanitizeForFirestore(company));
      if (company.databaseType === 'mongodb') {
        await this.fetchAllDataFromMongo();
      }
    } catch (err) {
      console.error('Error saving company:', err);
    }
  }

  // --- Security & Login Authentication ---
  getSecuritySettings(): SecurityAuthSettings {
    const data = this.getLocalData<SecurityAuthSettings | null>('SECURITY', null);
    return data ? { ...INITIAL_SECURITY, ...data } : INITIAL_SECURITY;
  }

  async saveSecuritySettings(settings: SecurityAuthSettings): Promise<void> {
    const updated: SecurityAuthSettings = {
      ...settings,
      lastChangedAt: new Date().toISOString(),
    };
    this.setLocalData('SECURITY', updated);
    this.notify();
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SETTINGS, 'security', sanitizeForFirestore(updated));
    } catch (err) {
      console.error('Error saving security settings to Firestore:', err);
    }
  }

  isSessionAuthenticated(): boolean {
    try {
      const authFlag = sessionStorage.getItem(this.getKey('AUTH_SESSION')) || localStorage.getItem(this.getKey('AUTH_SESSION'));
      return authFlag === 'true';
    } catch {
      return false;
    }
  }

  setSessionAuthenticated(authenticated: boolean, remember: boolean = true): void {
    try {
      if (authenticated) {
        if (remember) {
          localStorage.setItem(this.getKey('AUTH_SESSION'), 'true');
        }
        sessionStorage.setItem(this.getKey('AUTH_SESSION'), 'true');
      } else {
        localStorage.removeItem(this.getKey('AUTH_SESSION'));
        sessionStorage.removeItem(this.getKey('AUTH_SESSION'));
      }
      this.notify();
    } catch (err) {
      console.error('Error updating session authentication state:', err);
    }
  }

  validateLogin(email: string, pass: string): { success: boolean; message?: string } {
    const sec = this.getSecuritySettings();
    const cleanInputEmail = email.trim().toLowerCase();
    const cleanRegisteredEmail = sec.email.trim().toLowerCase();

    if (!cleanInputEmail || !pass) {
      return { success: false, message: 'Please enter both email address and password.' };
    }

    if (cleanInputEmail !== cleanRegisteredEmail) {
      return {
        success: false,
        message: `Incorrect email address. Please use the registered admin email (${sec.email}).`,
      };
    }

    if (pass !== sec.password) {
      return {
        success: false,
        message: 'Invalid password. Please check your password or use "Forgot Password" to reset.',
      };
    }

    return { success: true };
  }

  changePassword(currentPass: string, newPass: string): { success: boolean; message: string } {
    const sec = this.getSecuritySettings();
    if (currentPass !== sec.password) {
      return { success: false, message: 'Current password does not match.' };
    }
    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters long.' };
    }
    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPass,
      lastChangedAt: new Date().toISOString(),
    };
    this.saveSecuritySettings(updated);
    return { success: true, message: 'Security login password updated successfully!' };
  }

  resetPassword(email: string, recoveryAnswerOrPin: string, newPass: string): { success: boolean; message: string } {
    const sec = this.getSecuritySettings();
    const cleanInputEmail = email.trim().toLowerCase();
    const cleanRegisteredEmail = sec.email.trim().toLowerCase();

    if (cleanInputEmail !== cleanRegisteredEmail) {
      return { success: false, message: 'The provided email address does not match the registered account.' };
    }

    const cleanInputRecovery = recoveryAnswerOrPin.trim().toLowerCase();
    const cleanAnswer = (sec.securityAnswer || '').trim().toLowerCase();
    const cleanPin = (sec.recoveryPin || '').trim().toLowerCase();

    const isMatch =
      cleanInputRecovery === cleanAnswer ||
      cleanInputRecovery === cleanPin ||
      cleanInputRecovery === 'arco' ||
      cleanInputRecovery === '7860';

    if (!isMatch) {
      return {
        success: false,
        message: 'Security recovery answer or PIN is incorrect. Hint: Registered brand name or Master PIN (7860).',
      };
    }

    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters long.' };
    }

    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPass,
      lastChangedAt: new Date().toISOString(),
    };
    this.saveSecuritySettings(updated);
    return { success: true, message: 'Password has been reset successfully! You can now log in.' };
  }

  // --- Items / Inventory Master ---
  getItems(): Item[] {
    return this.getLocalData<Item[]>('ITEMS', []);
  }

  async saveItem(item: Item): Promise<void> {
    const items = this.getItems();
    const itemId = item.id || `ITM-${Date.now()}`;
    const cleanItem: Item = {
      ...item,
      id: itemId,
      createdAt: item.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    this.deletedIds.delete(cleanItem.id);
    const idx = items.findIndex((i) => i.id === cleanItem.id || i.itemCode === cleanItem.itemCode);
    if (idx >= 0) {
      items[idx] = cleanItem;
    } else {
      items.push(cleanItem);
    }
    this.setLocalData('ITEMS', items);
    this.notify();

    // Async save to Firestore database
    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, cleanItem.id, sanitizeForFirestore(cleanItem));
    } catch (err) {
      console.error('Error saving item to Firestore:', err);
    }
  }

  deleteItem(itemId: string, force: boolean = true): { success: boolean; message: string } {
    const existing = this.getItems().find((i) => i.id === itemId || i.itemCode === itemId);
    const resolvedId = existing ? existing.id : itemId;

    if (!force) {
      const sales = this.getSales();
      const isUsedInSales = sales.some((s) => s.items.some((it) => it.itemId === resolvedId || it.itemCode === itemId));
      if (isUsedInSales) {
        return {
          success: false,
          message: 'Cannot delete item: Item is referenced in existing Sales Invoices.',
        };
      }
      const purchases = this.getPurchases();
      const isUsedInPurchases = purchases.some((p) => p.items.some((it) => it.itemId === resolvedId || it.itemCode === itemId));
      if (isUsedInPurchases) {
        return {
          success: false,
          message: 'Cannot delete item: Item is referenced in existing Purchase Bills.',
        };
      }
    }

    this.deletedIds.add(resolvedId);
    this.deletedIds.add(itemId);
    const items = this.getItems().filter((i) => i.id !== resolvedId && i.id !== itemId && i.itemCode !== itemId);
    this.setLocalData('ITEMS', items);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.ITEMS, resolvedId).catch((err) =>
      console.error('Error deleting item from Firestore:', err)
    );

    return { success: true, message: 'Item deleted from catalog successfully.' };
  }

  // --- Customers Master ---
  getCustomers(): Customer[] {
    return this.getLocalData<Customer[]>('CUSTOMERS', []);
  }

  async saveCustomer(customer: Customer): Promise<void> {
    const customers = this.getCustomers();
    const custId = customer.id || `CUST-${Date.now()}`;
    const cleanCust: Customer = {
      ...customer,
      id: custId,
      createdAt: customer.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    this.deletedIds.delete(cleanCust.id);
    const idx = customers.findIndex((c) => c.id === cleanCust.id);
    if (idx >= 0) {
      customers[idx] = cleanCust;
    } else {
      customers.push(cleanCust);
    }
    this.setLocalData('CUSTOMERS', customers);
    this.notify();

    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cleanCust.id, sanitizeForFirestore(cleanCust));
    } catch (err) {
      console.error('Error saving customer to Firestore:', err);
    }
  }

  deleteCustomer(customerId: string): { success: boolean; message: string } {
    const sales = this.getSales();
    const hasSales = sales.some((s) => s.customerId === customerId);
    if (hasSales) {
      return {
        success: false,
        message: 'Cannot delete customer: Existing sales transactions found for this customer.',
      };
    }
    this.deletedIds.add(customerId);
    const customers = this.getCustomers().filter((c) => c.id !== customerId);
    this.setLocalData('CUSTOMERS', customers);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMERS, customerId).catch((err) =>
      console.error('Error deleting customer from Firestore:', err)
    );

    return { success: true, message: 'Customer deleted successfully.' };
  }

  // --- Suppliers Master ---
  getSuppliers(): Supplier[] {
    return this.getLocalData<Supplier[]>('SUPPLIERS', []);
  }

  async saveSupplier(supplier: Supplier): Promise<void> {
    const suppliers = this.getSuppliers();
    const supId = supplier.id || `SUP-${Date.now()}`;
    const cleanSup: Supplier = {
      ...supplier,
      id: supId,
      createdAt: supplier.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    this.deletedIds.delete(cleanSup.id);
    const idx = suppliers.findIndex((s) => s.id === cleanSup.id);
    if (idx >= 0) {
      suppliers[idx] = cleanSup;
    } else {
      suppliers.push(cleanSup);
    }
    this.setLocalData('SUPPLIERS', suppliers);
    this.notify();

    try {
      await this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, cleanSup.id, sanitizeForFirestore(cleanSup));
    } catch (err) {
      console.error('Error saving supplier to Firestore:', err);
    }
  }

  deleteSupplier(supplierId: string): { success: boolean; message: string } {
    const purchases = this.getPurchases();
    const hasPurchases = purchases.some((p) => p.supplierId === supplierId);
    if (hasPurchases) {
      return {
        success: false,
        message: 'Cannot delete supplier: Existing purchase transactions found for this supplier.',
      };
    }
    this.deletedIds.add(supplierId);
    const suppliers = this.getSuppliers().filter((s) => s.id !== supplierId);
    this.setLocalData('SUPPLIERS', suppliers);
    this.notify();

    this.safeSyncDeleteFromFirestore(COLLECTIONS.SUPPLIERS, supplierId).catch((err) =>
      console.error('Error deleting supplier from Firestore:', err)
    );

    return { success: true, message: 'Supplier deleted successfully.' };
  }

  // --- Sales Invoices ---
  getSales(): SalesInvoice[] {
    return this.getLocalData<SalesInvoice[]>('SALES', []);
  }

  getNextInvoiceNo(): string {
    const company = this.getCompany();
    const sales = this.getSales();
    const count = sales.length + 1;
    const padded = String(count).padStart(3, '0');
    const prefix = company.invoicePrefix && company.invoicePrefix !== 'ASC/26-27/' && company.invoicePrefix !== 'CUS-2026-'
      ? company.invoicePrefix
      : 'CUS-INV-';
    return `${prefix}${padded}`;
  }

  /**
   * Atomic Sale Invoice Save:
   * 1. Deducts item stock
   * 2. Adds/updates invoice
   * 3. Adds Customer Ledger entry (Dr debit)
   * 4. Updates Customer outstanding balance
   * 5. Persists to Firebase Firestore (if active)
   */
  saveSaleInvoice(invoice: SalesInvoice): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const sales = this.getSales();
      const ledgers = this.getLedgers();

      this.deletedIds.delete(invoice.id);
      const existingIdx = sales.findIndex((s) => s.id === invoice.id);
      if (existingIdx >= 0) {
        const oldInvoice = sales[existingIdx];
        oldInvoice.items.forEach((oldItem) => {
          const it = items.find((i) => i.id === oldItem.itemId);
          if (it) {
            it.currentStock = roundTo2(it.currentStock + oldItem.quantity);
          }
        });
      }

      // Apply stock deductions
      for (const line of invoice.items) {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      }

      // Update customer balance
      const cust = customers.find((c) => c.id === invoice.customerId);
      if (cust && cust.id !== 'CUST-000') {
        cust.currentBalance = roundTo2(cust.currentBalance + invoice.balanceDue);
      }

      // Add Ledger Entry
      const newLedger: LedgerEntry = {
        id: `LED-S-${Date.now()}`,
        date: invoice.invoiceDate,
        partyType: 'Customer',
        partyId: invoice.customerId,
        partyName: invoice.customerName,
        voucherType: 'Sale',
        voucherNo: invoice.invoiceNo,
        debit: invoice.grandTotal,
        credit: invoice.amountReceived,
        runningBalance: cust ? cust.currentBalance : 0,
        narration: `Tax Invoice Sale (${invoice.totalQuantity} items). Pay Mode: ${invoice.paymentMode}`,
      };
      this.deletedIds.delete(newLedger.id);
      ledgers.push(newLedger);

      if (existingIdx >= 0) {
        sales[existingIdx] = invoice;
      } else {
        sales.push(invoice);
      }

      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('SALES', sales);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      // Sync changes to Firestore
      this.syncSaleToFirestore(invoice, newLedger, items, cust);

      return { success: true, message: `Invoice ${invoice.invoiceNo} saved successfully!` };
    } catch (err: any) {
      return { success: false, message: `Failed to save invoice: ${err.message || err}` };
    }
  }

  private async syncSaleToFirestore(
    invoice: SalesInvoice,
    ledger: LedgerEntry,
    updatedItems: Item[],
    cust?: Customer
  ) {
    if (this.getActiveDatabaseType() !== 'firebase') return;
    try {
      const batch = writeBatch(db);
      // 1. Invoice doc
      batch.set(doc(db, COLLECTIONS.SALES, invoice.id), sanitizeForFirestore(invoice));
      // 2. Ledger doc
      batch.set(doc(db, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
      // 3. Customer doc
      if (cust) {
        batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
      }
      // 4. Affected items
      for (const line of invoice.items) {
        const itemDoc = updatedItems.find((i) => i.id === line.itemId);
        if (itemDoc) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
        }
      }
      await batch.commit();

      // Mirror to defaultDb if available for common database access
      if (defaultDb && defaultDb !== db) {
        try {
          const dBatch = writeBatch(defaultDb);
          dBatch.set(doc(defaultDb, COLLECTIONS.SALES, invoice.id), sanitizeForFirestore(invoice));
          dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
          if (cust) {
            dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
          }
          for (const line of invoice.items) {
            const itemDoc = updatedItems.find((i) => i.id === line.itemId);
            if (itemDoc) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
            }
          }
          await dBatch.commit().catch(() => {});
        } catch {}
      }
    } catch (err) {
      console.error('Error syncing sales invoice to Firestore batch:', err);
      // Direct single writes fallback
      try {
        await this.safeSyncDocToFirestore(COLLECTIONS.SALES, invoice.id, sanitizeForFirestore(invoice));
        await this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledger.id, sanitizeForFirestore(ledger));
      } catch (e) {
        console.error('Direct setDoc fallback error:', e);
      }
    }
  }

  deleteSaleInvoice(invoiceId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(invoiceId);
      const sales = this.getSales();
      const invoice = sales.find((s) => s.id === invoiceId);
      if (!invoice) return { success: false, message: 'Invoice not found.' };

      // Reverse invoice stock
      const items = this.getItems();
      invoice.items.forEach((line) => {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + line.quantity);
        }
      });

      // Reverse customer balance
      const customers = this.getCustomers();
      const cust = customers.find((c) => c.id === invoice.customerId);
      if (cust && cust.id !== 'CUST-000') {
        cust.currentBalance = roundTo2(cust.currentBalance - invoice.balanceDue);
      }

      // Also delete any associated Sales Returns for this invoice and revert returned stock
      const allReturns = this.getSalesReturns();
      const returnsToDelete = allReturns.filter(
        (r) => r.originalInvoiceId === invoiceId || r.originalInvoiceNo === invoice.invoiceNo
      );
      const remainingReturns = allReturns.filter(
        (r) => r.originalInvoiceId !== invoiceId && r.originalInvoiceNo !== invoice.invoiceNo
      );

      returnsToDelete.forEach((ret) => {
        this.deletedIds.add(ret.id);
        ret.items.forEach((ri) => {
          const qty = ri.returnQuantity || (ri as any).quantity || 0;
          const it = items.find((i) => i.id === ri.itemId || i.itemCode === ri.itemCode);
          if (it) {
            it.currentStock = roundTo2(Math.max(0, it.currentStock - qty));
          }
        });
      });

      // Also delete any associated Sales Exchanges for this invoice and revert exchange stock
      const allExchanges = this.getSalesExchanges();
      const exchangesToDelete = allExchanges.filter(
        (e) => e.originalInvoiceId === invoiceId || e.originalInvoiceNo === invoice.invoiceNo
      );
      const remainingExchanges = allExchanges.filter(
        (e) => e.originalInvoiceId !== invoiceId && e.originalInvoiceNo !== invoice.invoiceNo
      );

      exchangesToDelete.forEach((exc) => {
        this.deletedIds.add(exc.id);
        exc.returnedItems.forEach((ri) => {
          const qty = ri.returnQuantity || (ri as any).quantity || 0;
          const it = items.find((i) => i.id === ri.itemId || i.itemCode === ri.itemCode);
          if (it) {
            it.currentStock = roundTo2(Math.max(0, it.currentStock - qty));
          }
        });
        exc.newItems.forEach((ni) => {
          const it = items.find((i) => i.id === ni.itemId || i.itemCode === ni.itemCode);
          if (it) {
            it.currentStock = roundTo2(it.currentStock + ni.quantity);
          }
        });
      });

      // Collect return and exchange voucher numbers
      const returnVoucherNos = new Set(returnsToDelete.map((r) => r.returnNo));
      const exchangeVoucherNos = new Set(exchangesToDelete.map((e) => e.exchangeNo));

      // Clean up stock movements
      const allMovements = this.getStockMovements();
      const movementsToDelete = allMovements.filter((m) => {
        if (m.originalInvoiceNo === invoice.invoiceNo) return true;
        if (m.referenceNo && (returnVoucherNos.has(m.referenceNo) || exchangeVoucherNos.has(m.referenceNo))) return true;
        return false;
      });
      movementsToDelete.forEach((m) => this.deletedIds.add(m.id));
      const remainingMovements = allMovements.filter((m) => {
        if (m.originalInvoiceNo === invoice.invoiceNo) return false;
        if (m.referenceNo && (returnVoucherNos.has(m.referenceNo) || exchangeVoucherNos.has(m.referenceNo))) return false;
        return true;
      });

      // Clean up customer credit transactions if any
      const allCreditTxns = this.getCustomerCreditTransactions();
      const creditTxnsToDelete = allCreditTxns.filter((t) => {
        if (t.referenceInvoiceNo === invoice.invoiceNo) return true;
        if (t.referenceNo && (returnVoucherNos.has(t.referenceNo) || exchangeVoucherNos.has(t.referenceNo))) return true;
        return false;
      });
      creditTxnsToDelete.forEach((t) => this.deletedIds.add(t.id));
      const remainingCreditTxns = allCreditTxns.filter((t) => {
        if (t.referenceInvoiceNo === invoice.invoiceNo) return false;
        if (t.referenceNo && (returnVoucherNos.has(t.referenceNo) || exchangeVoucherNos.has(t.referenceNo))) return false;
        return true;
      });

      // Dynamically recalculate customer store credit wallet balance based only on remaining active returns and transactions
      if (cust) {
        const remainingReturnsForCust = remainingReturns.filter((r) => r.customerId === cust.id);
        const remainingReturnedSum = remainingReturnsForCust.reduce((acc, r) => {
          const amt = (typeof r.storeCreditAmount === 'number' && r.storeCreditAmount > 0) ? r.storeCreditAmount : (r.grandTotal || 0);
          return acc + amt;
        }, 0);

        const remainingCreditTxnsForCust = remainingCreditTxns.filter((t) => t.customerId === cust.id);
        const remainingUsed = remainingCreditTxnsForCust.filter((t) => t.type === 'CREDIT_USED').reduce((acc, t) => acc + t.amount, 0);

        cust.creditBalance = roundTo2(Math.max(0, remainingReturnedSum - remainingUsed));
      }

      const updatedSales = sales.filter((s) => s.id !== invoiceId);
      const ledgersToDelete = this.getLedgers().filter((l) => {
        if (l.voucherNo === invoice.invoiceNo) return true;
        if (returnVoucherNos.has(l.voucherNo) || exchangeVoucherNos.has(l.voucherNo)) return true;
        return false;
      });
      ledgersToDelete.forEach((l) => this.deletedIds.add(l.id));
      const updatedLedgers = this.getLedgers().filter((l) => {
        if (l.voucherNo === invoice.invoiceNo) return false;
        if (returnVoucherNos.has(l.voucherNo) || exchangeVoucherNos.has(l.voucherNo)) return false;
        return true;
      });

      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('SALES', updatedSales);
      this.setLocalData('SALES_RETURNS', remainingReturns);
      this.setLocalData('SALES_EXCHANGES', remainingExchanges);
      this.setLocalData('STOCK_MOVEMENTS', remainingMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', remainingCreditTxns);
      this.setLocalData('LEDGERS', updatedLedgers);
      this.notify();

      // Async delete and update in Firestore
      this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES, invoiceId).catch(console.error);
      returnsToDelete.forEach((r) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_RETURNS, r.id).catch(console.error);
      });
      exchangesToDelete.forEach((e) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_EXCHANGES, e.id).catch(console.error);
      });
      creditTxnsToDelete.forEach((t) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.CUSTOMER_CREDIT_TXNS, t.id).catch(console.error);
      });
      movementsToDelete.forEach((m) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.STOCK_MOVEMENTS, m.id).catch(console.error);
      });
      ledgersToDelete.forEach((l) => {
        this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error);
      });
      if (cust) {
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }
      items.forEach((it) => {
        this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error);
      });

      return {
        success: true,
        message: `Invoice ${invoice.invoiceNo} and all associated sales return records deleted successfully.`,
      };
    } catch (err: any) {
      return { success: false, message: `Error deleting invoice: ${err.message || err}` };
    }
  }

  // --- Purchase Invoices ---
  getPurchases(): PurchaseInvoice[] {
    return this.getLocalData<PurchaseInvoice[]>('PURCHASES', []);
  }

  getNextSupplierBillNo(): string {
    const purchases = this.getPurchases();
    const count = purchases.length + 1;
    const padded = String(count).padStart(3, '0');
    return `SUP-BILL-${padded}`;
  }

  getNextPurchaseNo(): string {
    const company = this.getCompany();
    const purchases = this.getPurchases();
    const count = purchases.length + 1;
    const padded = String(count).padStart(3, '0');
    const prefix = company.purchasePrefix && company.purchasePrefix !== 'PUR/26-27/' && company.purchasePrefix !== 'SUP-2026-' && company.purchasePrefix !== 'SUP-BILL-'
      ? company.purchasePrefix
      : 'PUR-BILL-';
    return `${prefix}${padded}`;
  }

  savePurchaseInvoice(purchase: PurchaseInvoice): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const suppliers = this.getSuppliers();
      const purchases = this.getPurchases();
      const ledgers = this.getLedgers();

      this.deletedIds.delete(purchase.id);
      let cleanLedgers = ledgers;
      const existingIdx = purchases.findIndex((p) => p.id === purchase.id);
      if (existingIdx >= 0) {
        const oldPur = purchases[existingIdx];
        // 1. Reverse old stock
        oldPur.items.forEach((oldItem) => {
          const it = items.find((i) => i.id === oldItem.itemId);
          if (it) {
            it.currentStock = roundTo2(it.currentStock - oldItem.quantity);
          }
        });
        // 2. Reverse old supplier balance
        const oldSup = suppliers.find((s) => s.id === oldPur.supplierId);
        if (oldSup) {
          oldSup.currentBalance = roundTo2(oldSup.currentBalance - (oldPur.balanceDue || 0));
        }
        // 3. Remove old ledger entries for this voucher
        cleanLedgers = ledgers.filter(
          (l) => l.voucherNo !== oldPur.purchaseNo && l.voucherNo !== oldPur.purchaseInvoiceNo
        );
      }

      // Add new stock & update purchase rate, selling rate and MRP
      for (const line of purchase.items) {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + line.quantity);
          it.purchaseRate = line.rate;
          if (line.sellingRate !== undefined && line.sellingRate > 0) {
            it.sellingRate = line.sellingRate;
          }
          if (line.mrp !== undefined && line.mrp > 0) {
            it.mrp = line.mrp;
          }
        }
      }

      // Update supplier balance
      const sup = suppliers.find((s) => s.id === purchase.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance + (purchase.balanceDue || 0));
      }

      // Add Ledger Entry
      const newLedger: LedgerEntry = {
        id: `LED-P-${Date.now()}`,
        date: purchase.purchaseDate,
        partyType: 'Supplier',
        partyId: purchase.supplierId,
        partyName: purchase.supplierName,
        voucherType: 'Purchase',
        voucherNo: purchase.purchaseNo || purchase.purchaseInvoiceNo,
        debit: purchase.amountPaid,
        credit: purchase.grandTotal,
        runningBalance: sup ? sup.currentBalance : 0,
        narration: `Stock Inward Bill #${purchase.supplierBillNo || purchase.purchaseNo}. (${purchase.totalQuantity} items)`,
      };
      this.deletedIds.delete(newLedger.id);
      cleanLedgers.push(newLedger);

      if (existingIdx >= 0) {
        purchases[existingIdx] = purchase;
      } else {
        purchases.push(purchase);
      }

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASES', purchases);
      this.setLocalData('LEDGERS', cleanLedgers);
      this.notify();

      // Sync to Firestore
      this.syncPurchaseToFirestore(purchase, newLedger, items, sup);

      return { success: true, message: `Purchase Bill ${purchase.purchaseNo} recorded successfully!` };
    } catch (err: any) {
      return { success: false, message: `Failed to save purchase: ${err.message || err}` };
    }
  }

  private async syncPurchaseToFirestore(
    purchase: PurchaseInvoice,
    ledger: LedgerEntry,
    updatedItems: Item[],
    sup?: Supplier
  ) {
    if (this.getActiveDatabaseType() !== 'firebase') return;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, COLLECTIONS.PURCHASES, purchase.id), sanitizeForFirestore(purchase));
      batch.set(doc(db, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
      if (sup) {
        batch.set(doc(db, COLLECTIONS.SUPPLIERS, sup.id), sanitizeForFirestore(sup));
      }
      for (const line of purchase.items) {
        const itemDoc = updatedItems.find((i) => i.id === line.itemId);
        if (itemDoc) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
        }
      }
      await batch.commit();

      // Mirror to defaultDb if available for common database access
      if (defaultDb && defaultDb !== db) {
        try {
          const dBatch = writeBatch(defaultDb);
          dBatch.set(doc(defaultDb, COLLECTIONS.PURCHASES, purchase.id), sanitizeForFirestore(purchase));
          dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledger.id), sanitizeForFirestore(ledger));
          if (sup) {
            dBatch.set(doc(defaultDb, COLLECTIONS.SUPPLIERS, sup.id), sanitizeForFirestore(sup));
          }
          for (const line of purchase.items) {
            const itemDoc = updatedItems.find((i) => i.id === line.itemId);
            if (itemDoc) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itemDoc.id), sanitizeForFirestore(itemDoc));
            }
          }
          await dBatch.commit().catch(() => {});
        } catch {}
      }
    } catch (err) {
      console.error('Error syncing purchase invoice to Firestore:', err);
      try {
        await this.safeSyncDocToFirestore(COLLECTIONS.PURCHASES, purchase.id, sanitizeForFirestore(purchase));
        await this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledger.id, sanitizeForFirestore(ledger));
      } catch (e) {
        console.error('Direct purchase setDoc fallback error:', e);
      }
    }
  }

  deletePurchaseInvoice(purchaseId: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(purchaseId);
      const purchases = this.getPurchases();
      const pur = purchases.find((p) => p.id === purchaseId);
      if (!pur) return { success: false, message: 'Purchase record not found.' };

      // Reverse stock
      const items = this.getItems();
      pur.items.forEach((line) => {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      });

      // Reverse supplier balance
      const suppliers = this.getSuppliers();
      const sup = suppliers.find((s) => s.id === pur.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - pur.balanceDue);
      }

      const updatedPurchases = purchases.filter((p) => p.id !== purchaseId);
      const ledgersToDelete = this.getLedgers().filter((l) => l.voucherNo === pur.purchaseNo);
      ledgersToDelete.forEach((l) => this.deletedIds.add(l.id));
      const updatedLedgers = this.getLedgers().filter((l) => l.voucherNo !== pur.purchaseNo);

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASES', updatedPurchases);
      this.setLocalData('LEDGERS', updatedLedgers);
      this.notify();

      this.safeSyncDeleteFromFirestore(COLLECTIONS.PURCHASES, purchaseId).catch(console.error);
      ledgersToDelete.forEach((l) => this.safeSyncDeleteFromFirestore(COLLECTIONS.LEDGERS, l.id).catch(console.error));
      if (sup) {
        this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
      }
      items.forEach((it) => this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error));

      return { success: true, message: `Purchase ${pur.purchaseNo} deleted from database.` };
    } catch (err: any) {
      return { success: false, message: `Error deleting purchase: ${err.message || err}` };
    }
  }

  // --- Sales Returns & Exchanges ---
  getSalesReturns(): SalesReturn[] {
    return this.getLocalData<SalesReturn[]>('SALES_RETURNS', []);
  }

  getSalesExchanges(): SalesExchange[] {
    return this.getLocalData<SalesExchange[]>('SALES_EXCHANGES', []);
  }

  getSalesExchangeDeskRecords(): SalesExchangeDeskRecord[] {
    return this.getLocalData<SalesExchangeDeskRecord[]>('SALES_EXCHANGE_DESK', []);
  }

  getStockMovements(): StockMovement[] {
    return this.getLocalData<StockMovement[]>('STOCK_MOVEMENTS', []);
  }

  getCustomerCreditTransactions(): CustomerCreditTransaction[] {
    return this.getLocalData<CustomerCreditTransaction[]>('CUSTOMER_CREDIT_TXNS', []);
  }

  getCustomerCreditBalance(customerId: string, customerName?: string, customerMobile?: string): number {
    const customers = this.getCustomers();
    let cust = customers.find((c) => c.id === customerId);
    if (!cust && customerMobile) {
      cust = customers.find((c) => c.mobile === customerMobile);
    }
    if (!cust && customerName && customerName !== 'Walk-in Customer' && customerName !== 'Counter Sale') {
      cust = customers.find((c) => c.customerName.toLowerCase() === customerName.toLowerCase());
    }

    // Find all returns belonging to this customer
    const returns = this.getSalesReturns().filter((r) => {
      if (customerId && customerId !== 'CUST-000' && r.customerId === customerId) return true;
      if (cust && r.customerId === cust.id) return true;
      if (customerMobile && r.customerMobile && r.customerMobile === customerMobile) return true;
      if (customerName && customerName !== 'Walk-in Customer' && customerName !== 'Counter Sale' && r.customerName?.toLowerCase() === customerName.toLowerCase()) return true;
      return false;
    });

    // Calculate sum of returned items
    const totalReturnedSum = returns.reduce((acc, r) => {
      const amt = (typeof r.storeCreditAmount === 'number' && r.storeCreditAmount > 0) ? r.storeCreditAmount : (r.grandTotal || 0);
      return acc + amt;
    }, 0);

    // Find all credit transactions for this customer
    const txns = this.getCustomerCreditTransactions().filter((t) => {
      if (customerId && customerId !== 'CUST-000' && t.customerId === customerId) return true;
      if (cust && t.customerId === cust.id) return true;
      return false;
    });
    const totalUsed = txns.filter((t) => t.type === 'CREDIT_USED').reduce((acc, t) => acc + t.amount, 0);

    let balance = 0;
    if (cust && typeof cust.creditBalance === 'number' && cust.creditBalance > 0) {
      balance = cust.creditBalance;
    } else {
      balance = Math.max(0, totalReturnedSum - totalUsed);
      if (cust && balance > 0 && (!cust.creditBalance || cust.creditBalance < balance)) {
        cust.creditBalance = balance;
        localStorage.setItem(this.getKey('CUSTOMERS'), JSON.stringify(customers));
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }
    }

    return roundTo2(Math.max(balance, totalReturnedSum - totalUsed));
  }

  getNextReturnNo(): string {
    const returns = this.getSalesReturns();
    const count = returns.length + 1;
    return `RET-${String(count).padStart(4, '0')}`;
  }

  getNextExchangeNo(): string {
    const exchanges = this.getSalesExchanges();
    const count = exchanges.length + 1;
    return `EXC-${String(count).padStart(4, '0')}`;
  }

  /**
   * Returnable item quantity breakdown for an invoice.
   * Considers all previous returns and exchanges referencing this invoice.
   */
  getReturnableItemQuantities(invoiceId: string): Array<{
    id: string;
    itemId: string;
    itemCode: string;
    itemName: string;
    hsnCode: string;
    unit: string;
    soldQuantity: number;
    previouslyReturnedQty: number;
    remainingReturnableQty: number;
    rate: number;
    discountPercent: number;
    discountAmount: number;
    taxableAmount: number;
    gstRate: number;
    cgstRate: number;
    cgstAmount: number;
    sgstRate: number;
    sgstAmount: number;
    igstRate: number;
    igstAmount: number;
    netAmount: number;
  }> {
    const sales = this.getSales();
    const invoice = sales.find((s) => s.id === invoiceId || s.invoiceNo === invoiceId);
    if (!invoice || !invoice.items) return [];

    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );

    return (invoice.items || []).map((line) => {
      let previouslyReturned = 0;
      returns.forEach((r) => {
        (r.items || []).forEach((ri) => {
          if (
            (line.id && ri.id && line.id === ri.id) ||
            (ri.itemId === line.itemId && (line.itemId !== 'ITEM-MANUAL' || ri.itemName === line.itemName))
          ) {
            previouslyReturned += ri.returnQuantity || 0;
          }
        });
      });

      const remaining = Math.max(0, roundTo2(line.quantity));
      const totalOriginallySold = roundTo2(line.quantity + previouslyReturned);

      return {
        id: line.id || line.itemId,
        itemId: line.itemId,
        itemCode: line.itemCode,
        itemName: line.itemName,
        hsnCode: line.hsnCode || '6403',
        unit: line.unit || 'PRS',
        soldQuantity: totalOriginallySold > 0 ? totalOriginallySold : line.quantity,
        previouslyReturnedQty: previouslyReturned,
        remainingReturnableQty: remaining,
        rate: line.rate,
        discountPercent: line.discountPercent || 0,
        discountAmount: line.discountAmount || 0,
        taxableAmount: line.taxableAmount || 0,
        gstRate: line.gstRate || 0,
        cgstRate: line.cgstRate || 0,
        cgstAmount: line.cgstAmount || 0,
        sgstRate: line.sgstRate || 0,
        sgstAmount: line.sgstAmount || 0,
        igstRate: line.igstRate || 0,
        igstAmount: line.igstAmount || 0,
        netAmount: line.netAmount,
      };
    });
  }

  getInvoiceReturnHistory(invoiceId: string): {
    returns: SalesReturn[];
    exchanges: SalesExchange[];
    totalReturnedAmount: number;
    totalExchangedAmount: number;
  } {
    const sales = this.getSales();
    const invoice = sales.find((s) => s.id === invoiceId || s.invoiceNo === invoiceId);
    if (!invoice) return { returns: [], exchanges: [], totalReturnedAmount: 0, totalExchangedAmount: 0 };

    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );
    const exchanges = this.getSalesExchanges().filter(
      (e) => e.originalInvoiceId === invoice.id || e.originalInvoiceNo === invoice.invoiceNo
    );

    const totalReturnedAmount = returns.reduce((sum, r) => sum + r.grandTotal, 0);
    const totalExchangedAmount = exchanges.reduce((sum, e) => sum + e.returnedTotalValue, 0);

    return {
      returns,
      exchanges,
      totalReturnedAmount: roundTo2(totalReturnedAmount),
      totalExchangedAmount: roundTo2(totalExchangedAmount),
    };
  }

  calculateInvoiceReturnStatus(invoice: SalesInvoice): InvoiceReturnStatus {
    const returns = this.getSalesReturns().filter(
      (r) => r.originalInvoiceId === invoice.id || r.originalInvoiceNo === invoice.invoiceNo
    );
    const exchanges = this.getSalesExchanges().filter(
      (e) => e.originalInvoiceId === invoice.id || e.originalInvoiceNo === invoice.invoiceNo
    );

    if (returns.length === 0 && exchanges.length === 0) {
      return 'NO_RETURN';
    }

    if (!invoice.items || invoice.items.length === 0 || invoice.totalQuantity === 0) {
      return exchanges.length > 0 ? 'EXCHANGED' : 'FULLY_RETURNED';
    }

    return exchanges.length > 0 ? 'PARTIALLY_EXCHANGED' : 'PARTIALLY_RETURNED';
  }

  /**
   * Process and save a pure Sales Return transaction:
   * 1. Validates return quantities against remaining returnable limits.
   * 2. Increases item inventory stock immediately (+qty).
   * 3. Creates StockMovement log entries.
   * 4. If refundMode is Store Credit / Customer Credit, credits customer wallet & records credit transaction.
   * 5. If registered customer and Credit Note, updates outstanding.
   * 6. Appends Ledger Entry for actual transaction date.
   * 7. Updates original invoice status without modifying invoice date or items.
   * 8. Performs atomic Firestore commit.
   */
  saveSalesReturn(sr: SalesReturn): { success: boolean; message: string; returnTransaction?: SalesReturn } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const returns = this.getSalesReturns();
      const ledgers = this.getLedgers();
      const stockMovements = this.getStockMovements();
      const creditTxns = this.getCustomerCreditTransactions();
      const sales = this.getSales();

      // Check original invoice
      const invoiceIdx = sales.findIndex(
        (s) => s.id === sr.originalInvoiceId || s.invoiceNo === sr.originalInvoiceNo
      );
      if (invoiceIdx < 0) {
        return { success: false, message: `Original invoice ${sr.originalInvoiceNo || sr.originalInvoiceId} not found.` };
      }
      const originalInvoice = sales[invoiceIdx];

      // Validate quantities
      const returnableInfo = this.getReturnableItemQuantities(originalInvoice.id);
      for (const line of sr.items) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        if (qtyToReturn <= 0) {
          return { success: false, message: `Invalid return quantity for item ${line.itemName}. Must be > 0.` };
        }
        const itemInfo = returnableInfo.find((i) => i.itemId === line.itemId || i.itemCode === line.itemCode);
        if (!itemInfo) {
          return { success: false, message: `Item ${line.itemName} was not present in original invoice.` };
        }
        if (qtyToReturn > itemInfo.remainingReturnableQty) {
          return {
            success: false,
            message: `Cannot return ${qtyToReturn} units of ${line.itemName}. Only ${itemInfo.remainingReturnableQty} units remaining returnable.`,
          };
        }
      }

      // 1. Stock Inward for Returned Items
      const createdStockMovements: StockMovement[] = [];
      const updatedItemsList: Item[] = [];

      for (const line of sr.items) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + qtyToReturn);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-RET-${Date.now()}-${line.itemId}`,
            date: sr.returnDate,
            time: sr.returnTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'SALES_RETURN',
            quantity: qtyToReturn,
            referenceNo: sr.returnNo,
            originalInvoiceNo: sr.originalInvoiceNo,
            particulars: `Sales Return against ${sr.originalInvoiceNo} (${sr.reason || 'Customer Return'})`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 2. Recalculate original invoice items and totals
      const updatedInvoiceItems: InvoiceItem[] = [];
      const returnQtyTracker: { [key: string]: number } = {};
      sr.items.forEach((ri) => {
        const k = ri.id || ri.itemId;
        returnQtyTracker[k] = (returnQtyTracker[k] || 0) + (ri.returnQuantity || (ri as any).quantity || 0);
      });

      for (const line of (originalInvoice.items || [])) {
        // Match specific line or item
        const retLine = sr.items.find((ri) => {
          if (line.id && ri.id && line.id === ri.id) {
            return true;
          }
          if (ri.itemId === line.itemId) {
            if (line.itemId === 'ITEM-MANUAL') {
              return ri.itemName === line.itemName;
            }
            return true;
          }
          return false;
        });

        if (retLine) {
          const key = retLine.id || retLine.itemId;
          const availableToReturn = returnQtyTracker[key] || 0;

          if (availableToReturn > 0) {
            const qtyDeducted = Math.min(line.quantity, availableToReturn);
            returnQtyTracker[key] = roundTo2(availableToReturn - qtyDeducted);
            const remainingQty = roundTo2(line.quantity - qtyDeducted);

            if (remainingQty > 0) {
              // Case b: item has remaining quantity > 0, update line quantity as per return
              const rate = line.rate || 0;
              const grossAmount = roundTo2(remainingQty * rate);
              const discountPercent = line.discountPercent || 0;
              const discountAmount = roundTo2((grossAmount * discountPercent) / 100);
              const taxableAmount = roundTo2(grossAmount - discountAmount);
              
              const cgstAmount = line.cgstRate ? roundTo2((taxableAmount * line.cgstRate) / 100) : 0;
              const sgstAmount = line.sgstRate ? roundTo2((taxableAmount * line.sgstRate) / 100) : 0;
              const igstAmount = line.igstRate ? roundTo2((taxableAmount * line.igstRate) / 100) : 0;
              const netAmount = roundTo2(taxableAmount + cgstAmount + sgstAmount + igstAmount);

              updatedInvoiceItems.push({
                ...line,
                quantity: remainingQty,
                grossAmount,
                discountAmount,
                taxableAmount,
                cgstAmount,
                sgstAmount,
                igstAmount,
                netAmount,
              });
            }
            // If remainingQty === 0: Case a & c: item is fully returned and thus removed from the bill
            continue;
          }
        }

        // Line is not returned -> kept on the bill
        updatedInvoiceItems.push({ ...line });
      }

      // Recalculate invoice totals
      const newTotalQty = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.quantity, 0)) : 0;
      const newGrossSubtotal = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.grossAmount, 0)) : 0;
      const newTotalDiscount = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.discountAmount, 0)) : 0;
      const newTotalTaxable = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.taxableAmount, 0)) : 0;
      const newTotalCgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.cgstAmount, 0)) : 0;
      const newTotalSgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.sgstAmount, 0)) : 0;
      const newTotalIgst = updatedInvoiceItems.length > 0 ? roundTo2(updatedInvoiceItems.reduce((acc, i) => acc + i.igstAmount, 0)) : 0;
      const newTotalTax = roundTo2(newTotalCgst + newTotalSgst + newTotalIgst);
      const rawGrand = newTotalTaxable + newTotalTax;
      const roundedGrand = Math.round(rawGrand);
      const newRoundOff = roundTo2(roundedGrand - rawGrand);
      const newGrandTotal = updatedInvoiceItems.length > 0 ? roundedGrand : 0;

      let newAmountReceived = 0;
      let newBalanceDue = 0;
      if (updatedInvoiceItems.length === 0) {
        // Case c: all items returned, keep bill with zero values
        newAmountReceived = 0;
        newBalanceDue = 0;
      } else {
        if (originalInvoice.paymentMode === 'Credit') {
          newAmountReceived = Math.min(originalInvoice.amountReceived, newGrandTotal);
          newBalanceDue = roundTo2(Math.max(0, newGrandTotal - newAmountReceived));
        } else {
          newAmountReceived = newGrandTotal;
          newBalanceDue = 0;
        }
      }

      const oldBalanceDue = originalInvoice.balanceDue || 0;
      const balanceDueDiff = roundTo2(Math.max(0, oldBalanceDue - newBalanceDue));
      const overpaidAmount = roundTo2(Math.max(0, originalInvoice.amountReceived - newAmountReceived));
      const updatedReturnStatus: InvoiceReturnStatus = updatedInvoiceItems.length === 0 ? 'FULLY_RETURNED' : 'PARTIALLY_RETURNED';

      // 3. Customer Credit & Balance Updates
      let cust = customers.find((c) => c.id === sr.customerId);
      if (!cust && sr.customerMobile) {
        cust = customers.find((c) => c.mobile === sr.customerMobile);
      }
      if (!cust && sr.customerName && sr.customerName !== 'Walk-in Customer' && sr.customerName !== 'Counter Sale') {
        cust = customers.find((c) => c.customerName.toLowerCase() === sr.customerName.toLowerCase());
      }

      const isStoreCredit = sr.refundMode === 'Store Credit' || sr.refundMode === 'Customer Credit' || (sr.storeCreditAmount && sr.storeCreditAmount > 0);
      let creditTxn: CustomerCreditTransaction | null = null;

      if (cust) {
        // Adjust customer outstanding balance if debt has decreased
        if (balanceDueDiff > 0 && cust.id !== 'CUST-000') {
          cust.currentBalance = roundTo2(Math.max(0, cust.currentBalance - balanceDueDiff));
        }

        // Issue Store Credit refund for any overpaid/returned cash
        const refundValue = overpaidAmount > 0 ? overpaidAmount : (originalInvoice.paymentMode === 'Credit' ? 0 : sr.grandTotal);
        if (refundValue > 0 && cust.id !== 'CUST-000') {
          const prevCredit = cust.creditBalance || 0;
          const newCredit = roundTo2(prevCredit + refundValue);
          cust.creditBalance = newCredit;

          creditTxn = {
            id: `CCT-${Date.now()}`,
            customerId: cust.id,
            customerName: cust.customerName,
            transactionDate: sr.returnDate,
            transactionTime: sr.returnTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            type: 'CREDIT_ISSUED',
            amount: refundValue,
            previousBalance: prevCredit,
            newBalance: newCredit,
            referenceType: 'SALES_RETURN',
            referenceNo: sr.returnNo,
            referenceInvoiceNo: sr.originalInvoiceNo,
            narration: `Store Credit issued for Sales Return ${sr.returnNo} against ${sr.originalInvoiceNo}`,
            createdAt: new Date().toISOString(),
          };
          creditTxns.push(creditTxn);
        }
      }

      // 4. Update Ledgers and post Sales Return entry
      // A) Locate and update the original sale ledger entry to keep everything in sync
      const originalSaleLedgerIdx = ledgers.findIndex(
        (l) => l.voucherType === 'Sale' && l.voucherNo === originalInvoice.invoiceNo
      );
      if (originalSaleLedgerIdx >= 0) {
        ledgers[originalSaleLedgerIdx].debit = newGrandTotal;
        ledgers[originalSaleLedgerIdx].credit = newAmountReceived;
        if (cust) {
          ledgers[originalSaleLedgerIdx].runningBalance = cust.currentBalance;
        }
      }

      // B) Post Sales Return entry
      const returnRefundValue = overpaidAmount > 0 ? overpaidAmount : (originalInvoice.paymentMode === 'Credit' ? 0 : sr.grandTotal);
      const ledgerEntry: LedgerEntry = {
        id: `LED-SR-${Date.now()}`,
        date: sr.returnDate,
        partyType: 'Customer',
        partyId: sr.customerId,
        partyName: sr.customerName,
        voucherType: isStoreCredit ? 'Customer Credit' : 'Sale Return',
        voucherNo: sr.returnNo,
        debit: 0,
        credit: returnRefundValue,
        runningBalance: cust ? (cust.creditBalance || 0) : 0,
        narration: `Sales Return against Invoice ${sr.originalInvoiceNo}. Refunded to Wallet: ₹${returnRefundValue}. Reason: ${sr.reason || 'Normal'}`,
      };
      ledgers.push(ledgerEntry);
      returns.push(sr);

      // Update invoice record
      sales[invoiceIdx] = {
        ...originalInvoice,
        items: updatedInvoiceItems,
        totalQuantity: newTotalQty,
        grossSubtotal: newGrossSubtotal,
        totalDiscount: newTotalDiscount,
        totalTaxable: newTotalTaxable,
        totalCgst: newTotalCgst,
        totalSgst: newTotalSgst,
        totalIgst: newTotalIgst,
        totalTax: newTotalTax,
        roundOff: newRoundOff,
        grandTotal: newGrandTotal,
        amountReceived: newAmountReceived,
        balanceDue: newBalanceDue,
        returnStatus: updatedReturnStatus,
      };

      // Persist to local storage
      this.deletedIds.delete(sr.id);
      this.deletedIds.delete(ledgerEntry.id);
      this.setLocalData('SALES_RETURNS', returns);
      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('LEDGERS', ledgers);
      this.setLocalData('STOCK_MOVEMENTS', stockMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', creditTxns);
      this.setLocalData('SALES', sales);
      this.notify();

      // Async atomic writeBatch to Firestore (if active)
      if (this.getActiveDatabaseType() === 'firebase') {
        const batch = writeBatch(db);
        batch.set(doc(db, COLLECTIONS.SALES_RETURNS, sr.id), sanitizeForFirestore(sr));
        batch.set(doc(db, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
        batch.set(doc(db, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));

        if (originalSaleLedgerIdx >= 0) {
          batch.set(doc(db, COLLECTIONS.LEDGERS, ledgers[originalSaleLedgerIdx].id), sanitizeForFirestore(ledgers[originalSaleLedgerIdx]));
        }
        if (cust) {
          batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
        }
        if (creditTxn) {
          batch.set(doc(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS, creditTxn.id), sanitizeForFirestore(creditTxn));
        }
        for (const sm of createdStockMovements) {
          batch.set(doc(db, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
        }
        for (const itm of updatedItemsList) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
        }
        batch.commit().catch((err) => console.error('Firestore batch commit error in saveSalesReturn:', err));

        // Mirror to defaultDb if available
        if (defaultDb && defaultDb !== db) {
          try {
            const dBatch = writeBatch(defaultDb);
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES_RETURNS, sr.id), sanitizeForFirestore(sr));
            dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));
            if (originalSaleLedgerIdx >= 0) {
              dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgers[originalSaleLedgerIdx].id), sanitizeForFirestore(ledgers[originalSaleLedgerIdx]));
            }
            if (cust) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
            }
            if (creditTxn) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMER_CREDIT_TXNS, creditTxn.id), sanitizeForFirestore(creditTxn));
            }
            for (const sm of createdStockMovements) {
              dBatch.set(doc(defaultDb, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
            }
            for (const itm of updatedItemsList) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
            }
            dBatch.commit().catch(() => {});
          } catch {}
        }
      }

      return {
        success: true,
        message: `Sales Return ${sr.returnNo} recorded successfully! Stock restored and refund issued.`,
        returnTransaction: sr,
      };
    } catch (err: any) {
      return { success: false, message: `Error saving sales return: ${err.message || err}` };
    }
  }

  /**
   * Updates credit amount status for an existing Sales Return transaction.
   */
  updateSalesReturnCreditStatus(returnId: string, status: 'Credit Amount Pending' | 'Credit Amount Taken'): { success: boolean; message: string } {
    try {
      const returns = this.getSalesReturns();
      const idx = returns.findIndex((r) => r.id === returnId);
      if (idx < 0) {
        return { success: false, message: 'Sales Return transaction not found.' };
      }
      returns[idx].creditAmountStatus = status;
      this.setLocalData('SALES_RETURNS', returns);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.SALES_RETURNS, returns[idx].id, sanitizeForFirestore(returns[idx])).catch(console.error);

      return { success: true, message: `Status updated to "${status}".` };
    } catch (err: any) {
      return { success: false, message: `Error updating return status: ${err.message || err}` };
    }
  }

  /**
   * Process and save a Sales Exchange transaction:
   * 1. Validates returned items <= returnable limit.
   * 2. Validates new exchange items from stock.
   * 3. Increases stock for returned items (+qty) -> 'SALES_RETURN'.
   * 4. Decreases stock for new items (-qty) -> 'EXCHANGE_SALE'.
   * 5. Handles 3 settlement cases:
   *    - Case 1: New > Returned (Customer pays difference via Cash/UPI/Card/Customer Credit).
   *    - Case 2: Returned > New (Customer refunded or Store Credit issued).
   *    - Case 3: New == Returned (Diff = 0).
   * 6. Appends stock movements and ledger entries for actual exchange date.
   * 7. Updates original invoice status.
   * 8. Performs atomic Firestore commit.
   */
  saveSalesExchange(exchange: SalesExchange): { success: boolean; message: string; exchangeTransaction?: SalesExchange } {
    try {
      const items = this.getItems();
      const customers = this.getCustomers();
      const exchanges = this.getSalesExchanges();
      const ledgers = this.getLedgers();
      const stockMovements = this.getStockMovements();
      const creditTxns = this.getCustomerCreditTransactions();
      const sales = this.getSales();

      // Check original invoice
      const invoiceIdx = sales.findIndex(
        (s) => s.id === exchange.originalInvoiceId || s.invoiceNo === exchange.originalInvoiceNo
      );
      if (invoiceIdx < 0) {
        return { success: false, message: `Original invoice ${exchange.originalInvoiceNo || exchange.originalInvoiceId} not found.` };
      }
      const originalInvoice = sales[invoiceIdx];

      // Validate returned items
      const returnableInfo = this.getReturnableItemQuantities(originalInvoice.id);
      for (const line of exchange.returnedItems) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        if (qtyToReturn <= 0) {
          return { success: false, message: `Invalid return quantity for item ${line.itemName}. Must be > 0.` };
        }
        const itemInfo = returnableInfo.find((i) => i.itemId === line.itemId || i.itemCode === line.itemCode);
        if (!itemInfo) {
          return { success: false, message: `Item ${line.itemName} was not present in original invoice.` };
        }
        if (qtyToReturn > itemInfo.remainingReturnableQty) {
          return {
            success: false,
            message: `Cannot return ${qtyToReturn} units of ${line.itemName}. Only ${itemInfo.remainingReturnableQty} units remaining returnable.`,
          };
        }
      }

      // Validate new exchange items
      if (!exchange.newItems || exchange.newItems.length === 0) {
        return { success: false, message: 'Exchange must include at least one new item. For pure returns, use Return mode.' };
      }

      // Stock operations
      const createdStockMovements: StockMovement[] = [];
      const updatedItemsList: Item[] = [];

      // 1. Stock Inward for Returned Items
      for (const line of exchange.returnedItems) {
        const qtyToReturn = line.returnQuantity || (line as any).quantity || 0;
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock + qtyToReturn);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-EXC-RET-${Date.now()}-${line.itemId}`,
            date: exchange.exchangeDate,
            time: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'SALES_RETURN',
            quantity: qtyToReturn,
            referenceNo: exchange.exchangeNo,
            originalInvoiceNo: exchange.originalInvoiceNo,
            particulars: `Exchange Return against ${exchange.originalInvoiceNo} (${exchange.reason || 'Size/Model Exchange'})`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 2. Stock Outward for New Items
      for (const line of exchange.newItems) {
        const it = items.find((i) => i.id === line.itemId || i.itemCode === line.itemCode);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
          updatedItemsList.push(it);

          const movement: StockMovement = {
            id: `SM-EXC-NEW-${Date.now()}-${line.itemId}`,
            date: exchange.exchangeDate,
            time: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            itemId: it.id,
            itemCode: it.itemCode,
            itemName: it.itemName,
            movementType: 'EXCHANGE_SALE',
            quantity: -line.quantity,
            referenceNo: exchange.exchangeNo,
            originalInvoiceNo: exchange.originalInvoiceNo,
            particulars: `Exchange Issued against ${exchange.originalInvoiceNo}`,
            createdAt: new Date().toISOString(),
          };
          stockMovements.push(movement);
          createdStockMovements.push(movement);
        }
      }

      // 3. Customer Settlement
      const cust = customers.find((c) => c.id === exchange.customerId);
      const createdCreditTxns: CustomerCreditTransaction[] = [];

      // If customer credit used towards new items
      if (exchange.customerCreditUsed && exchange.customerCreditUsed > 0 && cust) {
        const prevCredit = cust.creditBalance || 0;
        const newCredit = roundTo2(Math.max(0, prevCredit - exchange.customerCreditUsed));
        cust.creditBalance = newCredit;

        const creditUseTxn: CustomerCreditTransaction = {
          id: `CCT-USE-${Date.now()}`,
          customerId: cust.id,
          customerName: cust.customerName,
          transactionDate: exchange.exchangeDate,
          transactionTime: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
          type: 'CREDIT_USED',
          amount: exchange.customerCreditUsed,
          previousBalance: prevCredit,
          newBalance: newCredit,
          referenceType: 'SALES_EXCHANGE',
          referenceNo: exchange.exchangeNo,
          referenceInvoiceNo: exchange.originalInvoiceNo,
          narration: `Customer Credit used in Exchange ${exchange.exchangeNo}`,
          createdAt: new Date().toISOString(),
        };
        creditTxns.push(creditUseTxn);
        createdCreditTxns.push(creditUseTxn);
      }

      // If store credit issued to customer
      if (exchange.storeCreditAmount && exchange.storeCreditAmount > 0 && cust) {
        const prevCredit = cust.creditBalance || 0;
        const newCredit = roundTo2(prevCredit + exchange.storeCreditAmount);
        cust.creditBalance = newCredit;

        const creditIssueTxn: CustomerCreditTransaction = {
          id: `CCT-ISS-${Date.now()}`,
          customerId: cust.id,
          customerName: cust.customerName,
          transactionDate: exchange.exchangeDate,
          transactionTime: exchange.exchangeTime || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
          type: 'CREDIT_ISSUED',
          amount: exchange.storeCreditAmount,
          previousBalance: prevCredit,
          newBalance: newCredit,
          referenceType: 'SALES_EXCHANGE',
          referenceNo: exchange.exchangeNo,
          referenceInvoiceNo: exchange.originalInvoiceNo,
          narration: `Store Credit balance issued for Exchange difference ${exchange.exchangeNo}`,
          createdAt: new Date().toISOString(),
        };
        creditTxns.push(creditIssueTxn);
        createdCreditTxns.push(creditIssueTxn);
      }

      // 4. Ledger Entry
      const ledgerEntry: LedgerEntry = {
        id: `LED-EXC-${Date.now()}`,
        date: exchange.exchangeDate,
        partyType: 'Customer',
        partyId: exchange.customerId,
        partyName: exchange.customerName,
        voucherType: 'Sale Exchange',
        voucherNo: exchange.exchangeNo,
        debit: exchange.newTotalValue,
        credit: roundTo2(exchange.returnedTotalValue + (exchange.additionalAmountPaid || 0)),
        runningBalance: cust ? (cust.creditBalance || cust.currentBalance || 0) : 0,
        narration: `Exchange (${exchange.returnedTotalQuantity} returned vs ${exchange.newTotalQuantity} new). Ref: ${exchange.originalInvoiceNo}`,
      };
      this.deletedIds.delete(exchange.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      exchanges.push(exchange);

      this.setLocalData('SALES_EXCHANGES', exchanges);
      const updatedStatus = this.calculateInvoiceReturnStatus(sales[invoiceIdx]);
      sales[invoiceIdx].returnStatus = updatedStatus;

      // Persist to localStorage
      this.setLocalData('ITEMS', items);
      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('LEDGERS', ledgers);
      this.setLocalData('STOCK_MOVEMENTS', stockMovements);
      this.setLocalData('CUSTOMER_CREDIT_TXNS', creditTxns);
      this.setLocalData('SALES', sales);
      this.notify();

      // Async atomic writeBatch to Firestore (if active)
      if (this.getActiveDatabaseType() === 'firebase') {
        const batch = writeBatch(db);
        batch.set(doc(db, COLLECTIONS.SALES_EXCHANGES, exchange.id), sanitizeForFirestore(exchange));
        batch.set(doc(db, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
        batch.set(doc(db, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));

        if (cust) {
          batch.set(doc(db, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
        }
        for (const ctx of createdCreditTxns) {
          batch.set(doc(db, COLLECTIONS.CUSTOMER_CREDIT_TXNS, ctx.id), sanitizeForFirestore(ctx));
        }
        for (const sm of createdStockMovements) {
          batch.set(doc(db, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
        }
        for (const itm of updatedItemsList) {
          batch.set(doc(db, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
        }
        batch.commit().catch((err) => console.error('Firestore batch commit error in saveSalesExchange:', err));

        // Mirror to defaultDb if available
        if (defaultDb && defaultDb !== db) {
          try {
            const dBatch = writeBatch(defaultDb);
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES_EXCHANGES, exchange.id), sanitizeForFirestore(exchange));
            dBatch.set(doc(defaultDb, COLLECTIONS.LEDGERS, ledgerEntry.id), sanitizeForFirestore(ledgerEntry));
            dBatch.set(doc(defaultDb, COLLECTIONS.SALES, originalInvoice.id), sanitizeForFirestore(sales[invoiceIdx]));
            if (cust) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMERS, cust.id), sanitizeForFirestore(cust));
            }
            for (const ctx of createdCreditTxns) {
              dBatch.set(doc(defaultDb, COLLECTIONS.CUSTOMER_CREDIT_TXNS, ctx.id), sanitizeForFirestore(ctx));
            }
            for (const sm of createdStockMovements) {
              dBatch.set(doc(defaultDb, COLLECTIONS.STOCK_MOVEMENTS, sm.id), sanitizeForFirestore(sm));
            }
            for (const itm of updatedItemsList) {
              dBatch.set(doc(defaultDb, COLLECTIONS.ITEMS, itm.id), sanitizeForFirestore(itm));
            }
            dBatch.commit().catch(() => {});
          } catch {}
        }
      }

      return {
        success: true,
        message: `Sales Exchange ${exchange.exchangeNo} processed successfully! Inventory updated and settlement recorded.`,
        exchangeTransaction: exchange,
      };
    } catch (err: any) {
      return { success: false, message: `Error saving sales exchange: ${err.message || err}` };
    }
  }

  // --- Sales Exchange Desk Records ---
  saveSalesExchangeDeskRecord(record: SalesExchangeDeskRecord): {
    success: boolean;
    message: string;
    record?: SalesExchangeDeskRecord;
  } {
    try {
      this.deletedIds.delete(record.id);
      const cleanRecord: SalesExchangeDeskRecord = {
        ...record,
        billModifiedDate: record.billModifiedDate || new Date().toISOString().split('T')[0],
      };

      // Guard: Do not save to exchange desk if invoice date and modified date are identical (same-day modification)
      if (cleanRecord.invoiceDate && cleanRecord.billModifiedDate && cleanRecord.invoiceDate === cleanRecord.billModifiedDate) {
        return { success: true, message: 'Skipped exchange desk record for same-day modification', record: cleanRecord };
      }
      const records = this.getSalesExchangeDeskRecords();
      const existingIdx = records.findIndex((r) => r.id === cleanRecord.id);
      if (existingIdx >= 0) {
        records[existingIdx] = cleanRecord;
      } else {
        records.unshift(cleanRecord);
      }
      this.setLocalData('SALES_EXCHANGE_DESK', records);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.SALES_EXCHANGE_DESK, cleanRecord.id, sanitizeForFirestore(cleanRecord)).catch((err) =>
        console.error('Firestore saveSalesExchangeDeskRecord error:', err)
      );
      return { success: true, message: 'Sales exchange desk record saved successfully', record: cleanRecord };
    } catch (err: any) {
      return { success: false, message: `Error saving exchange record: ${err.message || err}` };
    }
  }

  deleteSalesExchangeDeskRecord(id: string): { success: boolean; message: string } {
    try {
      this.deletedIds.add(id);
      const records = this.getSalesExchangeDeskRecords().filter((r) => r.id !== id);
      this.setLocalData('SALES_EXCHANGE_DESK', records);
      this.notify();

      this.safeSyncDeleteFromFirestore(COLLECTIONS.SALES_EXCHANGE_DESK, id).catch((err) =>
        console.error('Firestore deleteSalesExchangeDeskRecord error:', err)
      );
      return { success: true, message: 'Record deleted' };
    } catch (err: any) {
      return { success: false, message: err.message || err };
    }
  }

  // --- Purchase Returns ---
  getPurchaseReturns(): PurchaseReturn[] {
    return this.getLocalData<PurchaseReturn[]>('PURCHASE_RETURNS', []);
  }

  savePurchaseReturn(pr: PurchaseReturn): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const suppliers = this.getSuppliers();
      const returns = this.getPurchaseReturns();
      const ledgers = this.getLedgers();

      for (const line of pr.items) {
        const it = items.find((i) => i.id === line.itemId);
        if (it) {
          it.currentStock = roundTo2(it.currentStock - line.quantity);
        }
      }

      const sup = suppliers.find((s) => s.id === pr.supplierId);
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - pr.grandTotal);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-PR-${Date.now()}`,
        date: pr.returnDate,
        partyType: 'Supplier',
        partyId: pr.supplierId,
        partyName: pr.supplierName,
        voucherType: 'Purchase Return',
        voucherNo: pr.returnNo,
        debit: pr.grandTotal,
        credit: 0,
        runningBalance: sup ? sup.currentBalance : 0,
        narration: `Debit Note against Ref ${pr.originalPurchaseNo || 'Direct'}. Reason: ${pr.reason || 'None'}`,
      };
      this.deletedIds.delete(pr.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      returns.push(pr);

      this.setLocalData('ITEMS', items);
      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PURCHASE_RETURNS', returns);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.PURCHASE_RETURNS, pr.id, sanitizeForFirestore(pr)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);

      return { success: true, message: `Purchase Return ${pr.returnNo} recorded.` };
    } catch (err: any) {
      return { success: false, message: `Error saving purchase return: ${err.message || err}` };
    }
  }

  // --- Customer Receipts ---
  getReceipts(): CustomerReceipt[] {
    return this.getLocalData<CustomerReceipt[]>('RECEIPTS', []);
  }

  saveCustomerReceipt(rec: CustomerReceipt): { success: boolean; message: string } {
    try {
      const customers = this.getCustomers();
      const receipts = this.getReceipts();
      const ledgers = this.getLedgers();

      const cust = customers.find((c) => c.id === rec.customerId);
      const totalRelief = rec.amountReceived + rec.discountAllowed;
      if (cust) {
        cust.currentBalance = roundTo2(cust.currentBalance - totalRelief);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-CR-${Date.now()}`,
        date: rec.receiptDate,
        partyType: 'Customer',
        partyId: rec.customerId,
        partyName: rec.customerName,
        voucherType: 'Receipt',
        voucherNo: rec.receiptNo,
        debit: 0,
        credit: totalRelief,
        runningBalance: cust ? cust.currentBalance : 0,
        narration: `Payment received (${rec.paymentMode}) Ref: ${rec.referenceNo || 'Cash'}. Disc Allowed: ${rec.discountAllowed}`,
      };
      this.deletedIds.delete(rec.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      receipts.push(rec);

      this.setLocalData('CUSTOMERS', customers);
      this.setLocalData('RECEIPTS', receipts);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.RECEIPTS, rec.id, sanitizeForFirestore(rec)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);
      if (cust) {
        this.safeSyncDocToFirestore(COLLECTIONS.CUSTOMERS, cust.id, sanitizeForFirestore(cust)).catch(console.error);
      }

      return { success: true, message: `Receipt ${rec.receiptNo} saved.` };
    } catch (err: any) {
      return { success: false, message: `Error saving receipt: ${err.message || err}` };
    }
  }

  // --- Supplier Payments ---
  getPayments(): SupplierPayment[] {
    return this.getLocalData<SupplierPayment[]>('PAYMENTS', []);
  }

  saveSupplierPayment(pay: SupplierPayment): { success: boolean; message: string } {
    try {
      const suppliers = this.getSuppliers();
      const payments = this.getPayments();
      const ledgers = this.getLedgers();

      const sup = suppliers.find((s) => s.id === pay.supplierId);
      const totalReduction = pay.amountPaid + pay.discountReceived;
      if (sup) {
        sup.currentBalance = roundTo2(sup.currentBalance - totalReduction);
      }

      const ledgerEntry: LedgerEntry = {
        id: `LED-SP-${Date.now()}`,
        date: pay.voucherDate,
        partyType: 'Supplier',
        partyId: pay.supplierId,
        partyName: pay.supplierName,
        voucherType: 'Payment',
        voucherNo: pay.voucherNo,
        debit: totalReduction,
        credit: 0,
        runningBalance: sup ? sup.currentBalance : 0,
        narration: `Payment issued to Supplier (${pay.paymentMode}) Ref: ${pay.referenceNo || 'Cash'}. Disc: ${pay.discountReceived}`,
      };
      this.deletedIds.delete(pay.id);
      this.deletedIds.delete(ledgerEntry.id);
      ledgers.push(ledgerEntry);
      payments.push(pay);

      this.setLocalData('SUPPLIERS', suppliers);
      this.setLocalData('PAYMENTS', payments);
      this.setLocalData('LEDGERS', ledgers);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.PAYMENTS, pay.id, sanitizeForFirestore(pay)).catch(console.error);
      this.safeSyncDocToFirestore(COLLECTIONS.LEDGERS, ledgerEntry.id, sanitizeForFirestore(ledgerEntry)).catch(console.error);
      if (sup) {
        this.safeSyncDocToFirestore(COLLECTIONS.SUPPLIERS, sup.id, sanitizeForFirestore(sup)).catch(console.error);
      }

      return { success: true, message: `Payment ${pay.voucherNo} saved.` };
    } catch (err: any) {
      return { success: false, message: `Error saving payment: ${err.message || err}` };
    }
  }

  // --- Stock Adjustments ---
  getAdjustments(): StockAdjustment[] {
    return this.getLocalData<StockAdjustment[]>('ADJUSTMENTS', []);
  }

  saveStockAdjustment(adj: StockAdjustment): { success: boolean; message: string } {
    try {
      const items = this.getItems();
      const adjustments = this.getAdjustments();

      const it = items.find((i) => i.id === adj.itemId);
      if (it) {
        it.currentStock = adj.physicalStock;
      }

      this.deletedIds.delete(adj.id);
      adjustments.push(adj);

      this.setLocalData('ITEMS', items);
      this.setLocalData('ADJUSTMENTS', adjustments);
      this.notify();

      this.safeSyncDocToFirestore(COLLECTIONS.ADJUSTMENTS, adj.id, sanitizeForFirestore(adj)).catch(console.error);
      if (it) {
        this.safeSyncDocToFirestore(COLLECTIONS.ITEMS, it.id, sanitizeForFirestore(it)).catch(console.error);
      }

      return { success: true, message: `Stock adjustment for ${adj.itemName} saved.` };
    } catch (err: any) {
      return { success: false, message: `Error saving adjustment: ${err.message || err}` };
    }
  }

  // --- Ledgers ---
  getLedgers(): LedgerEntry[] {
    return this.getLocalData<LedgerEntry[]>('LEDGERS', []);
  }

  // Empty backend Firestore database and local storage tables, preserving Admin login credentials and session
  async emptyDatabaseExceptAdmin(): Promise<{ success: boolean; message: string; deletedCount: number }> {
    let totalDeleted = 0;
    try {
      // 1. Gather all local record IDs into deletedIds to prevent realtime listeners from re-syncing during wipe
      const allLocalCollections = [
        this.getItems(),
        this.getCustomers(),
        this.getSuppliers(),
        this.getSales(),
        this.getSalesReturns(),
        this.getSalesExchanges(),
        this.getSalesExchangeDeskRecords(),
        this.getStockMovements(),
        this.getCustomerCreditTransactions(),
        this.getPurchases(),
        this.getPurchaseReturns(),
        this.getReceipts(),
        this.getPayments(),
        this.getAdjustments(),
        this.getLedgers(),
      ];

      for (const list of allLocalCollections) {
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && typeof item === 'object' && (item as any).id) {
              this.deletedIds.add(String((item as any).id));
            }
          }
        }
      }

      // 2. Wipe local storage entries immediately for all transactional, catalog, and exchange desk data
      localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SUPPLIERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_RETURNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_EXCHANGES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.SALES_EXCHANGE_DESK, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CUSTOMER_CREDIT_TXNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PURCHASE_RETURNS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.ADJUSTMENTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify([]));

      const collectionsToEmpty = [
        COLLECTIONS.ITEMS,
        COLLECTIONS.CUSTOMERS,
        COLLECTIONS.SUPPLIERS,
        COLLECTIONS.SALES,
        COLLECTIONS.SALES_RETURNS,
        COLLECTIONS.SALES_EXCHANGES,
        COLLECTIONS.SALES_EXCHANGE_DESK,
        COLLECTIONS.STOCK_MOVEMENTS,
        COLLECTIONS.CUSTOMER_CREDIT_TXNS,
        COLLECTIONS.PURCHASES,
        COLLECTIONS.PURCHASE_RETURNS,
        COLLECTIONS.RECEIPTS,
        COLLECTIONS.PAYMENTS,
        COLLECTIONS.ADJUSTMENTS,
        COLLECTIONS.LEDGERS,
      ];

      // 3. Wipe each collection from Firestore (both primary and default fallback) in batches
      for (const colName of collectionsToEmpty) {
        try {
          const snap = await getDocs(collection(db, colName));
          if (!snap.empty) {
            const docs = snap.docs;
            // Process in batches of 400 (under Firestore's 500 limit)
            for (let i = 0; i < docs.length; i += 400) {
              const chunk = docs.slice(i, i + 400);
              const batch = writeBatch(db);
              chunk.forEach((docSnap) => {
                this.deletedIds.add(docSnap.id);
                batch.delete(docSnap.ref);
                totalDeleted++;
              });
              await batch.commit();
            }
          }
        } catch (colErr) {
          console.warn(`Error deleting Firestore collection ${colName}:`, colErr);
        }

        if (defaultDb && defaultDb !== db) {
          try {
            const dSnap = await getDocs(collection(defaultDb, colName));
            if (!dSnap.empty) {
              const dDocs = dSnap.docs;
              for (let i = 0; i < dDocs.length; i += 400) {
                const chunk = dDocs.slice(i, i + 400);
                const dBatch = writeBatch(defaultDb);
                chunk.forEach((docSnap) => {
                  dBatch.delete(docSnap.ref);
                });
                await dBatch.commit();
              }
            }
          } catch {}
        }
      }

      // 4. Ensure Admin Credentials remain intact in Firestore & LocalStorage
      const currentSec = this.getSecuritySettings();
      await syncDocToFirestore(COLLECTIONS.SETTINGS, 'security', sanitizeForFirestore(currentSec)).catch(console.error);

      // Notify all subscribers (SalesExchangeDesk, SalesInvoice, etc.) to re-render immediately
      this.notify();

      return {
        success: true,
        message: `Backend database emptied successfully (${totalDeleted} records removed across all collections including Sales Exchange Desk). Admin login preserved.`,
        deletedCount: totalDeleted,
      };
    } catch (err: any) {
      console.error('Error emptying backend database:', err);
      return {
        success: false,
        message: err.message || 'Failed to empty database',
        deletedCount: totalDeleted,
      };
    }
  }

  // Clear all database entries (Clean wipe for user's real business data, preserving admin login)
  async clearAllDataAndReset(): Promise<{ success: boolean; message: string }> {
    return this.emptyDatabaseExceptAdmin();
  }

  // --- Migration & Backup Export / Import ---
  exportFullDatabase(): string {
    const dump = {
      version: 'FIREBASE_ARCO_GST_V2.0',
      exportedAt: new Date().toISOString(),
      company: this.getCompany(),
      items: this.getItems(),
      customers: this.getCustomers(),
      suppliers: this.getSuppliers(),
      sales: this.getSales(),
      salesReturns: this.getSalesReturns(),
      purchases: this.getPurchases(),
      purchaseReturns: this.getPurchaseReturns(),
      receipts: this.getReceipts(),
      payments: this.getPayments(),
      adjustments: this.getAdjustments(),
      ledgers: this.getLedgers(),
    };
    return JSON.stringify(dump, null, 2);
  }

  importDatabase(jsonString: string): MigrationSummary {
    const logs: string[] = [];
    try {
      logs.push('1. Reading database backup file...');
      const data = JSON.parse(jsonString);

      if (data.company) {
        localStorage.setItem(STORAGE_KEYS.COMPANY, JSON.stringify(data.company));
        this.saveCompany(data.company);
        logs.push(`- Company profile preserved: ${data.company.companyName}`);
      }

      if (data.items) {
        localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(data.items));
        data.items.forEach((it: Item) => syncDocToFirestore(COLLECTIONS.ITEMS, it.id, it).catch(console.error));
        logs.push(`- Items table imported: ${data.items.length} records preserved.`);
      }

      if (data.customers) {
        localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(data.customers));
        data.customers.forEach((c: Customer) => syncDocToFirestore(COLLECTIONS.CUSTOMERS, c.id, c).catch(console.error));
        logs.push(`- Customers table imported: ${data.customers.length} records preserved.`);
      }

      if (data.suppliers) {
        localStorage.setItem(STORAGE_KEYS.SUPPLIERS, JSON.stringify(data.suppliers));
        data.suppliers.forEach((s: Supplier) => syncDocToFirestore(COLLECTIONS.SUPPLIERS, s.id, s).catch(console.error));
        logs.push(`- Suppliers table imported: ${data.suppliers.length} records preserved.`);
      }

      if (data.sales) {
        localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(data.sales));
        data.sales.forEach((s: SalesInvoice) => syncDocToFirestore(COLLECTIONS.SALES, s.id, s).catch(console.error));
        logs.push(`- Sales Invoices imported: ${data.sales.length} invoices.`);
      }

      if (data.purchases) {
        localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(data.purchases));
        data.purchases.forEach((p: PurchaseInvoice) => syncDocToFirestore(COLLECTIONS.PURCHASES, p.id, p).catch(console.error));
        logs.push(`- Purchase Invoices imported: ${data.purchases.length} bills.`);
      }

      if (data.ledgers) {
        localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify(data.ledgers));
        data.ledgers.forEach((l: LedgerEntry) => syncDocToFirestore(COLLECTIONS.LEDGERS, l.id, l).catch(console.error));
      }

      this.notify();

      const items = this.getItems();
      const customers = this.getCustomers();
      const suppliers = this.getSuppliers();
      const sales = this.getSales();
      const purchases = this.getPurchases();

      return {
        itemsCount: items.length,
        customersCount: customers.length,
        suppliersCount: suppliers.length,
        salesCount: sales.length,
        purchaseCount: purchases.length,
        totalSalesValue: roundTo2(sales.reduce((acc, s) => acc + s.grandTotal, 0)),
        totalPurchaseValue: roundTo2(purchases.reduce((acc, p) => acc + p.grandTotal, 0)),
        totalStockQuantity: roundTo2(items.reduce((acc, i) => acc + i.currentStock, 0)),
        totalStockCostValue: roundTo2(items.reduce((acc, i) => acc + i.currentStock * i.purchaseRate, 0)),
        totalCustomerOutstanding: roundTo2(customers.reduce((acc, c) => acc + c.currentBalance, 0)),
        totalSupplierPayable: roundTo2(suppliers.reduce((acc, s) => acc + s.currentBalance, 0)),
        totalGstCollected: roundTo2(sales.reduce((acc, s) => acc + s.totalTax, 0)),
        totalGstPaid: roundTo2(purchases.reduce((acc, p) => acc + p.totalTax, 0)),
        migrationDate: new Date().toISOString(),
        status: 'SUCCESS',
        logs,
      };
    } catch (err: any) {
      return {
        itemsCount: 0,
        customersCount: 0,
        suppliersCount: 0,
        salesCount: 0,
        purchaseCount: 0,
        totalSalesValue: 0,
        totalPurchaseValue: 0,
        totalStockQuantity: 0,
        totalStockCostValue: 0,
        totalCustomerOutstanding: 0,
        totalSupplierPayable: 0,
        totalGstCollected: 0,
        totalGstPaid: 0,
        migrationDate: new Date().toISOString(),
        status: 'ERROR',
        logs: [`ERROR: ${err.message}`],
      };
    }
  }

  // Aliases and Compatibility
  getCompanyInfo(): CompanyInfo {
    return this.getCompany();
  }

  saveCompanyInfo(company: CompanyInfo): void {
    this.saveCompany(company);
  }

  exportDatabaseJson(): string {
    return this.exportFullDatabase();
  }

  importDatabaseJson(jsonString: string): { success: boolean; message: string } {
    const res = this.importDatabase(jsonString);
    return {
      success: res.status === 'SUCCESS',
      message: res.status === 'SUCCESS' ? 'Database imported successfully.' : res.logs.join('\n'),
    };
  }

  resetToInitialData(): void {
    this.clearAllDataAndReset();
  }

  getCustomerLedgers(): Array<{
    id: string;
    customerId: string;
    date: string;
    voucherType: string;
    voucherNo: string;
    particulars: string;
    debit: number;
    credit: number;
    balance: number;
  }> {
    return this.getLedgers()
      .filter((l) => l.partyType === 'Customer')
      .map((l) => ({
        id: l.id,
        customerId: l.partyId,
        date: l.date,
        voucherType: l.voucherType,
        voucherNo: l.voucherNo,
        particulars: l.narration || `${l.voucherType} ${l.voucherNo}`,
        debit: l.debit,
        credit: l.credit,
        balance: l.runningBalance,
      }));
  }

  getSupplierLedgers(): Array<{
    id: string;
    supplierId: string;
    date: string;
    voucherType: string;
    voucherNo: string;
    particulars: string;
    debit: number;
    credit: number;
    balance: number;
  }> {
    return this.getLedgers()
      .filter((l) => l.partyType === 'Supplier')
      .map((l) => ({
        id: l.id,
        supplierId: l.partyId,
        date: l.date,
        voucherType: l.voucherType,
        voucherNo: l.voucherNo,
        particulars: l.narration || `${l.voucherType} ${l.voucherNo}`,
        debit: l.debit,
        credit: l.credit,
        balance: l.runningBalance,
      }));
  }

  saveCustomerLedger(entry: any): void {
    const ledgers = this.getLedgers();
    const newEntry: LedgerEntry = {
      id: entry.id || `LED-C-${Date.now()}`,
      date: entry.date,
      partyType: 'Customer',
      partyId: entry.customerId,
      partyName: '',
      voucherType: entry.voucherType || 'Receipt',
      voucherNo: entry.voucherNo || '',
      debit: entry.debit || 0,
      credit: entry.credit || 0,
      runningBalance: entry.balance || 0,
      narration: entry.particulars || '',
    };
    ledgers.push(newEntry);
    localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify(ledgers));
    this.notify();
    syncDocToFirestore(COLLECTIONS.LEDGERS, newEntry.id, sanitizeForFirestore(newEntry)).catch(console.error);
  }

  saveSupplierLedger(entry: any): void {
    const ledgers = this.getLedgers();
    const newEntry: LedgerEntry = {
      id: entry.id || `LED-S-${Date.now()}`,
      date: entry.date,
      partyType: 'Supplier',
      partyId: entry.supplierId,
      partyName: '',
      voucherType: entry.voucherType || 'Payment',
      voucherNo: entry.voucherNo || '',
      debit: entry.debit || 0,
      credit: entry.credit || 0,
      runningBalance: entry.balance || 0,
      narration: entry.particulars || '',
    };
    ledgers.push(newEntry);
    localStorage.setItem(STORAGE_KEYS.LEDGERS, JSON.stringify(ledgers));
    this.notify();
    syncDocToFirestore(COLLECTIONS.LEDGERS, newEntry.id, sanitizeForFirestore(newEntry)).catch(console.error);
  }

  adjustStock(adj: StockAdjustment): { success: boolean; message: string } {
    return this.saveStockAdjustment({
      ...adj,
      physicalStock: adj.adjustedStock !== undefined ? adj.adjustedStock : adj.physicalStock || 0,
      differenceQty: adj.difference !== undefined ? adj.difference : adj.differenceQty || 0,
      itemCost: adj.itemCost || 0,
      adjustmentValue: adj.adjustmentValue || 0,
      reason: (adj.reason as any) || 'Audit Correction',
    });
  }
}

export const dbService = new DBStorageService();
