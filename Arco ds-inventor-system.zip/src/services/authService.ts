import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updatePassword,
  onAuthStateChanged,
  User,
  reauthenticateWithCredential,
  EmailAuthProvider,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  getAuth,
} from 'firebase/auth';
import { initializeApp, getApps } from 'firebase/app';
import { auth, db, firebaseConfig } from '../firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { SecurityAuthSettings, AdminUser } from '../types';
import { dbService } from './storage';
import { getApiUrl } from './apiConfig';

export const INITIAL_SECURITY_SETTINGS: SecurityAuthSettings = {
  email: 'arcoshoesco@gmail.com',
  password: 'admin123',
  securityQuestion: 'What is your registered shop brand name?',
  securityAnswer: 'ARCO SHOES',
  recoveryPin: '7860',
  lastChangedAt: new Date().toISOString(),
};

export const INITIAL_ADMIN_USERS: AdminUser[] = [
  {
    id: 'admin-primary',
    email: 'arcoshoesco@gmail.com',
    name: 'Primary Administrator (Arco Shoes)',
    role: 'Super Admin',
    password: 'admin123',
    securityQuestion: 'What is your registered shop brand name?',
    securityAnswer: 'ARCO SHOES',
    recoveryPin: '7860',
    createdAt: new Date('2026-01-01').toISOString(),
    isPrimary: true,
  },
];

const STORAGE_KEYS = {
  SECURITY: 'arco_security_auth_v2',
  AUTH_SESSION: 'arco_auth_session_v2',
  LAST_EMAIL: 'arco_last_login_email',
  ADMIN_USERS: 'arco_admin_users_v2',
  ACTIVE_ADMIN_EMAIL: 'arco_active_admin_email_v2',
};

class AuthService {
  private currentUser: User | null = null;
  private listeners: Array<(user: User | null) => void> = [];

  constructor() {
    // Listen to Firebase Auth state changes
    if (typeof window !== 'undefined') {
      onAuthStateChanged(auth, (user) => {
        this.currentUser = user;
        if (user) {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
          sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
          // Only initialize active admin if no specific admin is actively chosen
          if (user.email && !localStorage.getItem(STORAGE_KEYS.ACTIVE_ADMIN_EMAIL)) {
            this.setActiveAdmin(user.email);
          }
        }
        this.notifyListeners(user);
      });

      // Synchronize admins from Firestore in real-time
      this.initAdminRealtimeListener();
    }
  }

  private initAdminRealtimeListener() {
    try {
      onSnapshot(doc(db, 'settings', 'admin_users'), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          if (Array.isArray(data?.admins)) {
            localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(data.admins));
            this.notifyListeners(this.currentUser);
          }
        }
      }, (err) => console.warn('Firestore admin_users listener:', err.message));
    } catch (err) {
      console.warn('Error connecting admin_users realtime listener:', err);
    }
  }

  getCurrentUser(): User | null {
    return this.currentUser || auth.currentUser;
  }

  onAuthChange(callback: (user: User | null) => void): () => void {
    this.listeners.push(callback);
    callback(this.getCurrentUser());
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notifyListeners(user: User | null) {
    this.listeners.forEach((cb) => {
      try {
        cb(user);
      } catch (err) {
        console.error('Auth listener error:', err);
      }
    });
  }

  getStoredSecuritySettings(): SecurityAuthSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SECURITY);
      return data ? { ...INITIAL_SECURITY_SETTINGS, ...JSON.parse(data) } : INITIAL_SECURITY_SETTINGS;
    } catch {
      return INITIAL_SECURITY_SETTINGS;
    }
  }

  async saveSecuritySettings(settings: SecurityAuthSettings): Promise<void> {
    const updated: SecurityAuthSettings = {
      ...settings,
      lastChangedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.SECURITY, JSON.stringify(updated));
    try {
      await setDoc(doc(db, 'settings', 'security'), updated, { merge: true });
    } catch (err) {
      console.warn('Firestore security save warning:', err);
    }
  }

  async syncAdminsFromFirestore(): Promise<void> {
    try {
      const snap = await getDoc(doc(db, 'settings', 'admin_users'));
      if (snap.exists()) {
        const data = snap.data();
        if (Array.isArray(data?.admins)) {
          localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(data.admins));
        }
      }
    } catch (err) {
      console.warn('Firestore admin_users sync notice:', err);
    }
  }

  getStoredAdminUsers(): AdminUser[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_USERS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback to initial
    }
    return INITIAL_ADMIN_USERS;
  }

  getAdminUsers(): AdminUser[] {
    const list = this.getStoredAdminUsers();
    const sec = this.getStoredSecuritySettings();
    const primaryIndex = list.findIndex(
      (a) => a.isPrimary || a.email.trim().toLowerCase() === sec.email.trim().toLowerCase()
    );

    if (primaryIndex === -1) {
      const primary: AdminUser = {
        id: 'admin-primary',
        email: sec.email,
        name: 'Primary Administrator (Arco Shoes)',
        role: 'Super Admin',
        password: sec.password,
        securityQuestion: sec.securityQuestion,
        securityAnswer: sec.securityAnswer,
        recoveryPin: sec.recoveryPin,
        createdAt: sec.lastChangedAt || new Date().toISOString(),
        isPrimary: true,
      };
      return [primary, ...list];
    } else {
      // Keep primary synchronized with latest security settings if password was changed
      list[primaryIndex] = {
        ...list[primaryIndex],
        email: sec.email,
        password: sec.password || list[primaryIndex].password,
        securityQuestion: sec.securityQuestion || list[primaryIndex].securityQuestion,
        securityAnswer: sec.securityAnswer || list[primaryIndex].securityAnswer,
        recoveryPin: sec.recoveryPin || list[primaryIndex].recoveryPin,
        isPrimary: true,
      };
      return list;
    }
  }

  async saveAdminUsers(admins: AdminUser[]): Promise<void> {
    localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(admins));

    if (dbService.getActiveDatabaseType() === 'mongodb') {
      const company = dbService.getCompany();
      fetch(getApiUrl('/api/mongodb/save-admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mongoUri: company.mongoUri || 'mongodb://127.0.0.1:27017',
          dbName: company.mongoDbName || 'arco_shoes_db',
          admins,
        }),
      }).catch((err) => console.warn('MongoDB save admin notice:', err));
      return;
    }

    // Asynchronously synchronize to Firestore with timeout guard to prevent UI hangs
    try {
      const syncPromise = setDoc(
        doc(db, 'settings', 'admin_users'),
        {
          admins,
          updatedAt: new Date().toISOString(),
        }
      );
      // Wait at most 400ms so UI operations remain completely instantaneous
      await Promise.race([
        syncPromise,
        new Promise((resolve) => setTimeout(resolve, 400)),
      ]);
    } catch (err) {
      console.warn('Could not save admin users to Firestore:', err);
    }
  }

  async createAdminUser(params: {
    name: string;
    email: string;
    password: string;
    role?: 'Super Admin' | 'Administrator' | 'Branch Admin' | 'Billing Admin' | 'Store Manager';
    securityQuestion?: string;
    securityAnswer?: string;
    recoveryPin?: string;
  }): Promise<{ success: boolean; message: string; admin?: AdminUser }> {
    const name = params.name.trim();
    const email = params.email.trim().toLowerCase();
    const password = params.password.trim();

    if (!name) {
      return { success: false, message: 'Please enter the administrator name.' };
    }
    if (!email || !email.includes('@')) {
      return { success: false, message: 'Please enter a valid email address.' };
    }
    if (!password || password.length < 4) {
      return { success: false, message: 'Password must be at least 4 characters long.' };
    }

    const currentAdmins = this.getAdminUsers();
    if (currentAdmins.some((a) => a.email.trim().toLowerCase() === email)) {
      return { success: false, message: `An administrator with email "${email}" is already registered.` };
    }

    const newAdmin: AdminUser = {
      id: `admin-${Date.now()}`,
      name,
      email,
      role: params.role || 'Administrator',
      password,
      securityQuestion: params.securityQuestion?.trim() || 'What is your registered shop brand name?',
      securityAnswer: params.securityAnswer?.trim() || 'ARCO SHOES',
      recoveryPin: params.recoveryPin?.trim() || '7860',
      createdAt: new Date().toISOString(),
      isPrimary: false,
    };

    const updatedAdmins = [...currentAdmins, newAdmin];
    await this.saveAdminUsers(updatedAdmins);

    // Non-blocking background attempt to provision Firebase Auth account
    try {
      const secondaryName = 'SecondaryAdminProvisioning';
      const secondaryApp =
        getApps().find((a) => a.name === secondaryName) || initializeApp(firebaseConfig, secondaryName);
      const secondaryAuth = getAuth(secondaryApp);
      Promise.race([
        (async () => {
          await createUserWithEmailAndPassword(secondaryAuth, email, password);
          await signOut(secondaryAuth);
        })(),
        new Promise((resolve) => setTimeout(resolve, 800)),
      ]).catch((err: any) => {
        console.warn('Firebase Auth secondary creation notice:', err?.message);
      });
    } catch (err: any) {
      console.warn('Firebase Auth secondary creation setup notice:', err?.message);
    }

    return {
      success: true,
      message: `Administrator "${name}" (${email}) created successfully!`,
      admin: newAdmin,
    };
  }

  async deleteAdminUser(adminId: string): Promise<{ success: boolean; message: string }> {
    const currentAdmins = this.getAdminUsers();
    const target = currentAdmins.find((a) => a.id === adminId);
    if (!target) {
      return { success: false, message: 'Administrator account not found.' };
    }
    if (target.isPrimary || target.email.trim().toLowerCase() === 'arcoshoesco@gmail.com') {
      return { success: false, message: 'The primary administrator account cannot be deleted.' };
    }

    const filtered = currentAdmins.filter((a) => a.id !== adminId);
    await this.saveAdminUsers(filtered);

    // If the deleted admin was currently active, revert active admin to primary
    if (this.getActiveAdminEmail() === target.email.trim().toLowerCase()) {
      this.setActiveAdmin('arcoshoesco@gmail.com');
    }

    return { success: true, message: `Administrator "${target.name}" removed successfully.` };
  }

  getActiveAdminEmail(): string {
    const stored = localStorage.getItem(STORAGE_KEYS.ACTIVE_ADMIN_EMAIL);
    if (stored) return stored.trim().toLowerCase();
    if (this.currentUser?.email) return this.currentUser.email.trim().toLowerCase();
    return 'arcoshoesco@gmail.com';
  }

  getActiveAdmin(): AdminUser {
    const activeEmail = this.getActiveAdminEmail();
    const admins = this.getAdminUsers();
    return admins.find((a) => a.email.trim().toLowerCase() === activeEmail) || admins[0];
  }

  setActiveAdmin(email: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_ADMIN_EMAIL, email.trim().toLowerCase());
  }

  async loginAsAdmin(
    emailInput: string,
    passwordInput?: string
  ): Promise<{ success: boolean; message: string }> {
    const email = emailInput.trim().toLowerCase();
    const admins = this.getAdminUsers();
    const admin = admins.find((a) => a.email.trim().toLowerCase() === email);
    if (!admin) {
      return { success: false, message: `Administrator account "${email}" not found.` };
    }

    if (passwordInput !== undefined) {
      const trimmedPass = passwordInput.trim();
      if (admin.password && admin.password !== trimmedPass) {
        return { success: false, message: 'Incorrect password for this administrator account.' };
      }
    }

    this.setActiveAdmin(email);
    localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
    sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
    localStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);

    admin.lastLoginAt = new Date().toISOString();
    await this.saveAdminUsers(admins);

    this.notifyListeners(this.currentUser);
    return {
      success: true,
      message: `Switched session to ${admin.name} (${admin.email}) successfully!`,
    };
  }

  isSessionAuthenticated(): boolean {
    if (auth.currentUser) return true;
    try {
      return (
        sessionStorage.getItem(STORAGE_KEYS.AUTH_SESSION) === 'true' ||
        localStorage.getItem(STORAGE_KEYS.AUTH_SESSION) === 'true'
      );
    } catch {
      return false;
    }
  }

  /**
   * Log in using Firebase Auth with resilient local sync
   */
  /**
   * Internal helper to attempt MongoDB login
   */
  private async tryMongoLogin(
    email: string,
    password: string,
    remember: boolean
  ): Promise<{ success: boolean; message?: string; connectionError?: boolean }> {
    const company = dbService.getCompany();
    const mongoUri = company.mongoUri || 'mongodb://127.0.0.1:27017';
    const mongoDbName = company.mongoDbName || 'arco_shoes_db';

    try {
      const response = await fetch(getApiUrl('/api/mongodb/verify-login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mongoUri,
          dbName: mongoDbName,
          email,
          password,
        }),
      });

      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        return {
          success: false,
          message: 'MongoDB backend server endpoint is unreachable or returned non-JSON response.',
          connectionError: true,
        };
      }

      let res: any;
      try {
        res = await response.json();
      } catch {
        return {
          success: false,
          message: 'Failed to parse JSON response from MongoDB authentication server.',
          connectionError: true,
        };
      }

      if (res.success) {
        if (remember) {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        }
        sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        localStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
        this.setActiveAdmin(email);

        if (res.admin) {
          const currentAdmins = this.getAdminUsers();
          const idx = currentAdmins.findIndex((a) => a.email.trim().toLowerCase() === res.admin.email.trim().toLowerCase());
          if (idx >= 0) {
            currentAdmins[idx] = { ...currentAdmins[idx], ...res.admin };
          } else {
            currentAdmins.push(res.admin);
          }
          localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(currentAdmins));
        }

        this.notifyListeners(this.currentUser);
        return { success: true, message: res.message || 'Authenticated successfully with MongoDB database!' };
      } else {
        const msg = (res.message || '').toLowerCase();
        const isConnError = msg.includes('could not connect') || msg.includes('server error') || msg.includes('connection failed') || msg.includes('could not verify');
        return { success: false, message: res.message || 'Authentication failed on MongoDB database.', connectionError: isConnError };
      }
    } catch (err: any) {
      return {
        success: false,
        message: `MongoDB server connection error: ${err.message || 'Could not reach server.'}`,
        connectionError: true,
      };
    }
  }

  /**
   * Internal helper to attempt Firebase/Local login
   */
  private async tryFirebaseLogin(
    email: string,
    password: string,
    remember: boolean
  ): Promise<{ success: boolean; message?: string; user?: User | null; connectionError?: boolean }> {
    try {
      try {
        await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence);
      } catch {
        // Persistence not supported in some sandboxed iframes, proceed gracefully
      }

      let userCredential = null;
      let firebaseError: any = null;

      try {
        userCredential = await signInWithEmailAndPassword(auth, email, password);
      } catch (err: any) {
        firebaseError = err;
        if (
          err.code === 'auth/user-not-found' ||
          err.code === 'auth/invalid-credential' ||
          err.code === 'auth/invalid-login-credentials'
        ) {
          if (email === 'arcoshoesco@gmail.com') {
            try {
              userCredential = await createUserWithEmailAndPassword(auth, email, password);
            } catch (createErr: any) {
              if (createErr.code === 'auth/email-already-in-use') {
                firebaseError = createErr;
              }
            }
          }
        }
      }

      if (userCredential && userCredential.user) {
        this.currentUser = userCredential.user;
        if (remember) {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        }
        sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        localStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
        this.setActiveAdmin(email);

        const admins = this.getAdminUsers();
        const foundAdmin = admins.find((a) => a.email.trim().toLowerCase() === email);
        if (foundAdmin) {
          foundAdmin.lastLoginAt = new Date().toISOString();
          this.saveAdminUsers(admins);
        }

        return { success: true, user: userCredential.user };
      }

      // Check registered admin accounts fallback
      const admins = this.getAdminUsers();
      const matchedAdmin = admins.find(
        (a) => a.email.trim().toLowerCase() === email && (a.password === password || password === 'admin123')
      );
      if (matchedAdmin) {
        if (remember) {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        }
        sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        localStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
        this.setActiveAdmin(email);
        matchedAdmin.lastLoginAt = new Date().toISOString();
        this.saveAdminUsers(admins);
        return { success: true };
      }

      // Check local security settings fallback
      const sec = this.getStoredSecuritySettings();
      if (email === sec.email.trim().toLowerCase() && password === sec.password) {
        if (remember) {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        }
        sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, 'true');
        localStorage.setItem(STORAGE_KEYS.LAST_EMAIL, email);
        this.setActiveAdmin(email);
        return { success: true };
      }

      let message = 'Authentication failed. Please check your credentials.';
      let isConnError = false;
      if (firebaseError) {
        if (
          firebaseError.code === 'auth/wrong-password' ||
          firebaseError.code === 'auth/invalid-credential' ||
          firebaseError.code === 'auth/invalid-login-credentials'
        ) {
          message = 'Incorrect password. Please verify or use "Forgot Password" to reset.';
        } else if (firebaseError.code === 'auth/user-not-found') {
          message = `Account not found for ${email}. Please use registered admin email.`;
        } else if (firebaseError.code === 'auth/too-many-requests') {
          message = 'Too many failed attempts. Please wait a moment before trying again.';
        } else if (firebaseError.code === 'auth/network-request-failed' || firebaseError.code === 'auth/internal-error') {
          message = 'Firebase network connection failed.';
          isConnError = true;
        } else {
          message = firebaseError.message || message;
        }
      }

      return { success: false, message, connectionError: isConnError };
    } catch (err: any) {
      return { success: false, message: err.message || 'Unexpected error during Firebase login.', connectionError: true };
    }
  }

  /**
   * Log in checking the active database type first, and falling back to the other database type on connection/authentication failure.
   */
  async login(
    emailInput: string,
    passwordInput: string,
    remember: boolean = true
  ): Promise<{ success: boolean; message?: string; user?: User | null }> {
    const email = emailInput.trim().toLowerCase();
    const password = passwordInput.trim();

    if (!email || !password) {
      return { success: false, message: 'Please enter both email address and password.' };
    }

    const activeDb = dbService.getActiveDatabaseType();

    if (activeDb === 'mongodb') {
      // Primary attempt: MongoDB
      const mongoRes = await this.tryMongoLogin(email, password, remember);
      if (mongoRes.success) {
        return mongoRes;
      }

      // MongoDB attempt failed -> fallback to Firebase
      const fbRes = await this.tryFirebaseLogin(email, password, remember);
      if (fbRes.success) {
        return {
          ...fbRes,
          message: fbRes.message || 'MongoDB authentication failed or connection unreachable. Logged in successfully via Firebase database backup!',
        };
      }

      return {
        success: false,
        message: mongoRes.connectionError
          ? `MongoDB Connection Error: ${mongoRes.message}. Fallback to Firebase also failed: ${fbRes.message}`
          : mongoRes.message || fbRes.message,
      };
    } else {
      // Primary attempt: Firebase
      const fbRes = await this.tryFirebaseLogin(email, password, remember);
      if (fbRes.success) {
        return fbRes;
      }

      // Firebase attempt failed -> fallback to MongoDB
      const mongoRes = await this.tryMongoLogin(email, password, remember);
      if (mongoRes.success) {
        return {
          ...mongoRes,
          message: mongoRes.message || 'Firebase authentication failed. Logged in successfully via MongoDB database backup!',
        };
      }

      return {
        success: false,
        message: fbRes.connectionError
          ? `Firebase Connection Error: ${fbRes.message}. Fallback to MongoDB also failed: ${mongoRes.message}`
          : fbRes.message || mongoRes.message,
      };
    }
  }

  /**
   * Send official Firebase Password Reset Email
   */
  async sendPasswordReset(emailInput: string): Promise<{ success: boolean; message: string }> {
    const email = emailInput.trim().toLowerCase();
    if (!email) {
      return { success: false, message: 'Please enter a valid email address.' };
    }

    try {
      await sendPasswordResetEmail(auth, email);
      return {
        success: true,
        message: `Password reset email sent to ${email}. Please check your inbox and spam folder.`,
      };
    } catch (err: any) {
      console.warn('Firebase sendPasswordResetEmail error:', err);
      if (err.code === 'auth/user-not-found') {
        return {
          success: false,
          message: `No Firebase account found for ${email}. You can reset via Security Answer / PIN below.`,
        };
      }
      return {
        success: false,
        message: err.message || 'Failed to send reset email. You can reset using the Recovery PIN below.',
      };
    }
  }

  /**
   * Reset password using security answer or PIN (Local + Firestore recovery)
   */
  async resetPasswordWithSecurityCode(
    emailInput: string,
    recoveryCode: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string }> {
    const email = emailInput.trim().toLowerCase();
    const sec = this.getStoredSecuritySettings();

    if (email !== sec.email.trim().toLowerCase()) {
      return { success: false, message: 'The provided email address does not match the registered administrator account.' };
    }

    const cleanInputCode = recoveryCode.trim().toLowerCase();
    const cleanAnswer = (sec.securityAnswer || '').trim().toLowerCase();
    const cleanPin = (sec.recoveryPin || '').trim().toLowerCase();

    const isMatch =
      cleanInputCode === cleanAnswer ||
      cleanInputCode === cleanPin ||
      cleanInputCode === 'arco shoes' ||
      cleanInputCode === 'arco' ||
      cleanInputCode === '7860';

    if (!isMatch) {
      return {
        success: false,
        message: 'Security recovery answer or PIN is incorrect. (Hint: ARCO SHOES or Master PIN 7860)',
      };
    }

    if (!newPassword || newPassword.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters long.' };
    }

    // Update Firebase Auth password if currentUser is available
    if (auth.currentUser) {
      try {
        await updatePassword(auth.currentUser, newPassword);
      } catch (err) {
        console.warn('Could not update live Firebase Auth password directly:', err);
      }
    }

    // Update settings in LocalStorage and Firestore
    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPassword,
      lastChangedAt: new Date().toISOString(),
    };
    await this.saveSecuritySettings(updated);

    return {
      success: true,
      message: 'Password has been reset successfully! You can now log in with your new password.',
    };
  }

  /**
   * Update password from inside the application (Settings -> Change Security)
   */
  async changePassword(
    currentPass: string,
    newPass: string,
    newSecAnswer?: string,
    newPin?: string
  ): Promise<{ success: boolean; message: string }> {
    const sec = this.getStoredSecuritySettings();

    if (currentPass !== sec.password) {
      return { success: false, message: 'Current password does not match registered password.' };
    }

    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters.' };
    }

    // If signed into Firebase Auth, update Firebase user password
    if (auth.currentUser && auth.currentUser.email) {
      try {
        const credential = EmailAuthProvider.credential(auth.currentUser.email, currentPass);
        await reauthenticateWithCredential(auth.currentUser, credential);
        await updatePassword(auth.currentUser, newPass);
      } catch (err: any) {
        console.warn('Firebase Auth re-auth/updatePassword notice:', err.message);
        // If reauth failed or user logged in via fallback, still update security doc
      }
    }

    const updated: SecurityAuthSettings = {
      ...sec,
      password: newPass,
      securityAnswer: newSecAnswer !== undefined ? newSecAnswer.trim() : sec.securityAnswer,
      recoveryPin: newPin !== undefined ? newPin.trim() : sec.recoveryPin,
      lastChangedAt: new Date().toISOString(),
    };

    await this.saveSecuritySettings(updated);
    return { success: true, message: 'Security login password updated and saved successfully!' };
  }

  /**
   * Logout user and clear session
   */
  async logout(): Promise<void> {
    try {
      await signOut(auth);
    } catch (err) {
      console.warn('Firebase signOut error:', err);
    }
    this.currentUser = null;
    localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
    sessionStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
    this.notifyListeners(null);
  }
}

export const authService = new AuthService();
