import { useState, useEffect, useRef, useCallback } from 'react';
import { SESSION_CONFIG } from '../config/sessionConfig';

interface UseSessionTimeoutProps {
  isAuthenticated: boolean;
  onLogout: () => void | Promise<void>;
}

export function useSessionTimeout({ isAuthenticated, onLogout }: UseSessionTimeoutProps) {
  const [showWarning, setShowWarning] = useState<boolean>(false);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(
    Math.floor(SESSION_CONFIG.WARNING_TIME_MS / 1000)
  );

  const lastActivityRef = useRef<number>(Date.now());
  const isLoggedOutRef = useRef<boolean>(!isAuthenticated);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);

  // Keep isLoggedOutRef in sync with isAuthenticated
  useEffect(() => {
    isLoggedOutRef.current = !isAuthenticated;
    if (!isAuthenticated) {
      setShowWarning(false);
    }
  }, [isAuthenticated]);

  // Synchronized logout that triggers the app's existing logout & informs other tabs
  const performLogout = useCallback(() => {
    if (isLoggedOutRef.current) return;
    isLoggedOutRef.current = true;
    setShowWarning(false);

    try {
      localStorage.removeItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY);
      localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LOGOUT_BROADCAST, String(Date.now()));
    } catch {
      // Storage unavailable or disabled
    }

    if (broadcastChannelRef.current) {
      try {
        broadcastChannelRef.current.postMessage({ type: 'LOGOUT' });
      } catch (err) {
        console.warn('BroadcastChannel postMessage error:', err);
      }
    }

    onLogout();
  }, [onLogout]);

  // Reset/extend the user session when active or when "Continue Session" is clicked
  const extendSession = useCallback(() => {
    if (isLoggedOutRef.current || !isAuthenticated) return;

    const now = Date.now();
    lastActivityRef.current = now;
    setShowWarning(false);
    setRemainingSeconds(Math.floor(SESSION_CONFIG.WARNING_TIME_MS / 1000));

    try {
      localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY, String(now));
      localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.EXTEND_BROADCAST, String(now));
    } catch {
      // Storage unavailable or disabled
    }

    if (broadcastChannelRef.current) {
      try {
        broadcastChannelRef.current.postMessage({ type: 'EXTEND_SESSION', timestamp: now });
      } catch (err) {
        console.warn('BroadcastChannel postMessage error:', err);
      }
    }
  }, [isAuthenticated]);

  // Setup BroadcastChannel and storage event listeners for multi-tab synchronization
  useEffect(() => {
    if (!isAuthenticated) return;

    // 1. Initialize BroadcastChannel if supported
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        const channel = new BroadcastChannel(SESSION_CONFIG.BROADCAST_CHANNEL_NAME);
        broadcastChannelRef.current = channel;

        channel.onmessage = (event) => {
          if (event?.data?.type === 'LOGOUT') {
            performLogout();
          } else if (event?.data?.type === 'EXTEND_SESSION') {
            const remoteTs = Number(event.data.timestamp) || Date.now();
            lastActivityRef.current = Math.max(lastActivityRef.current, remoteTs);
            setShowWarning(false);
          }
        };
      } catch (err) {
        console.warn('BroadcastChannel setup notice:', err);
      }
    }

    // 2. Storage event listener for cross-tab communication fallback
    const handleStorage = (e: StorageEvent) => {
      if (!e.key) return;

      if (e.key === SESSION_CONFIG.STORAGE_KEYS.LOGOUT_BROADCAST) {
        performLogout();
      } else if (
        e.key === SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY ||
        e.key === SESSION_CONFIG.STORAGE_KEYS.EXTEND_BROADCAST
      ) {
        if (e.newValue) {
          const remoteTs = Number(e.newValue);
          if (!isNaN(remoteTs) && remoteTs > lastActivityRef.current) {
            lastActivityRef.current = remoteTs;
            const elapsed = Date.now() - remoteTs;
            const remaining = SESSION_CONFIG.INACTIVITY_TIMEOUT_MS - elapsed;
            if (remaining > SESSION_CONFIG.WARNING_TIME_MS) {
              setShowWarning(false);
            }
          }
        }
      }
    };

    window.addEventListener('storage', handleStorage);

    return () => {
      window.removeEventListener('storage', handleStorage);
      if (broadcastChannelRef.current) {
        try {
          broadcastChannelRef.current.close();
        } catch {
          // Closed
        }
        broadcastChannelRef.current = null;
      }
    };
  }, [isAuthenticated, performLogout]);

  // Activity detection: listen for user interaction and throttle updates
  useEffect(() => {
    if (!isAuthenticated) return;

    // Check stored activity on mount / after refresh
    try {
      const stored = localStorage.getItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY);
      if (stored) {
        const parsed = Number(stored);
        if (!isNaN(parsed) && parsed > 0) {
          const elapsed = Date.now() - parsed;
          if (elapsed >= SESSION_CONFIG.INACTIVITY_TIMEOUT_MS) {
            performLogout();
            return;
          }
          lastActivityRef.current = parsed;
        } else {
          lastActivityRef.current = Date.now();
          localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY, String(Date.now()));
        }
      } else {
        lastActivityRef.current = Date.now();
        localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY, String(Date.now()));
      }
    } catch {
      lastActivityRef.current = Date.now();
    }

    let lastRecordedActivity = Date.now();

    const handleUserActivity = () => {
      if (isLoggedOutRef.current || !isAuthenticated) return;

      // When warning modal is actively displayed, do not automatically dismiss it on passive mousemove;
      // the user should explicitly click "Continue Session" to confirm active presence.
      if (showWarning) return;

      const now = Date.now();
      if (now - lastRecordedActivity >= SESSION_CONFIG.ACTIVITY_THROTTLE_MS) {
        lastRecordedActivity = now;
        lastActivityRef.current = now;
        try {
          localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY, String(now));
        } catch {
          // Storage unavailable
        }
      }
    };

    // User interaction events to monitor
    const events: Array<keyof WindowEventMap> = [
      'mousemove',
      'mousedown',
      'keydown',
      'touchstart',
      'scroll',
      'click',
    ];

    events.forEach((evt) => {
      window.addEventListener(evt, handleUserActivity, { passive: true });
    });

    return () => {
      events.forEach((evt) => {
        window.removeEventListener(evt, handleUserActivity);
      });
    };
  }, [isAuthenticated, showWarning, performLogout]);

  // Periodic heartbeat timer (every 1 second) to inspect elapsed inactivity
  useEffect(() => {
    if (!isAuthenticated) return;

    const intervalId = setInterval(() => {
      if (isLoggedOutRef.current || !isAuthenticated) return;

      // Sync with localStorage timestamp in case another tab recorded user activity
      try {
        const stored = localStorage.getItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY);
        if (stored) {
          const parsed = Number(stored);
          if (!isNaN(parsed) && parsed > lastActivityRef.current) {
            lastActivityRef.current = parsed;
          }
        }
      } catch {
        // Fallback to in-memory timestamp
      }

      const elapsed = Date.now() - lastActivityRef.current;
      const remainingMs = SESSION_CONFIG.INACTIVITY_TIMEOUT_MS - elapsed;

      if (remainingMs <= 0) {
        // Total inactivity timeout elapsed -> Auto Logout
        performLogout();
      } else if (remainingMs <= SESSION_CONFIG.WARNING_TIME_MS) {
        // Within warning window -> Display countdown modal
        setShowWarning(true);
        setRemainingSeconds(Math.ceil(remainingMs / 1000));
      } else {
        // Inactivity is within safe margin -> Ensure warning modal is closed
        if (showWarning) {
          setShowWarning(false);
        }
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [isAuthenticated, showWarning, performLogout]);

  return {
    showWarning,
    remainingSeconds,
    continueSession: extendSession,
    logoutNow: performLogout,
  };
}
