import { useState, useEffect, useCallback } from 'react';
import { pwaService } from '../services/pwaService';

export function usePWAInstall() {
  const [isInstalled, setIsInstalled] = useState<boolean>(() => pwaService.getIsInstalled());
  const [isInstallable, setIsInstallable] = useState<boolean>(() => pwaService.getIsInstallable());
  const [hasPrompt, setHasPrompt] = useState<boolean>(() => !!pwaService.getDeferredPrompt());
  const [isSecure] = useState<boolean>(() => pwaService.isSecureContext());
  const [browserInfo] = useState(() => pwaService.isSupportedBrowser());
  const [outcome, setOutcome] = useState<'accepted' | 'dismissed' | null>(() =>
    pwaService.getUserChoiceOutcome()
  );

  useEffect(() => {
    const update = () => {
      setIsInstalled(pwaService.getIsInstalled());
      setIsInstallable(pwaService.getIsInstallable());
      setHasPrompt(!!pwaService.getDeferredPrompt());
      setOutcome(pwaService.getUserChoiceOutcome());
    };

    update();
    const unsubscribe = pwaService.subscribe(update);
    return () => {
      unsubscribe();
    };
  }, []);

  const install = useCallback(async () => {
    const res = await pwaService.promptInstall();
    setOutcome(res.outcome === 'unavailable' ? null : res.outcome);
    return res;
  }, []);

  return {
    isInstalled,
    isInstallable,
    hasPrompt,
    isSecure,
    browserInfo,
    outcome,
    install,
  };
}
