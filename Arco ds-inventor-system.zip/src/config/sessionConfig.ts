/**
 * Session Inactivity Timeout Configuration
 * 
 * Production defaults:
 * - Inactivity Timeout: 20 minutes (can also be set to 30 minutes: 30 * 60 * 1000)
 * - Warning Display: 5 minutes remaining before expiry
 * 
 * Testing example:
 * - INACTIVITY_TIMEOUT_MS: 2 * 60 * 1000  (2 minutes)
 * - WARNING_TIME_MS: 30 * 1000           (30 seconds)
 */
export const SESSION_CONFIG = {
  /**
   * Total allowed inactivity duration before automatic logout (in milliseconds)
   * Default: 20 minutes (20 * 60 * 1000 = 1,200,000 ms)
   * Set to 30 * 60 * 1000 if 30-minute timeout is desired.
   */
  INACTIVITY_TIMEOUT_MS: 20 * 60 * 1000,

  /**
   * Time remaining before session expiry when the warning modal is shown (in milliseconds)
   * Default: 5 minutes (5 * 60 * 1000 = 300,000 ms)
   */
  WARNING_TIME_MS: 5 * 60 * 1000,

  /**
   * Minimum interval between recording user interaction events (in milliseconds).
   * Prevents high-frequency event spam (e.g. mouse movement).
   */
  ACTIVITY_THROTTLE_MS: 5000,

  /**
   * Browser localStorage keys used for activity timestamp and cross-tab synchronization
   */
  STORAGE_KEYS: {
    LAST_ACTIVITY: 'arco_session_last_activity',
    LOGOUT_BROADCAST: 'arco_session_logout_broadcast',
    EXTEND_BROADCAST: 'arco_session_extend_broadcast',
  },

  /**
   * BroadcastChannel name for multi-tab/multi-window synchronization
   */
  BROADCAST_CHANNEL_NAME: 'arco_session_sync',
} as const;
