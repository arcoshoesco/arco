export type ModuleTab =
  | 'dashboard'
  | 'day_book'
  | 'invoices'
  | 'bills'
  | 'bills_invoices'
  | 'sales_invoice'
  | 'sales_return'
  | 'purchase_entry'
  | 'purchase_return'
  | 'item_master'
  | 'customer_master'
  | 'supplier_master'
  | 'customer_receipt'
  | 'supplier_payment'
  | 'stock_adjustment'
  | 'gst_reports'
  | 'gst_register'
  | 'business_reports'
  | 'customer_ledger'
  | 'supplier_ledger'
  | 'company_settings'
  | 'print_preview'
  | 'database_migration';

export type AppTheme = 'cream' | 'linen' | 'porcelain' | 'cashmere' | 'dark' | 'oxford' | 'institutional';

export interface ThemeOption {
  id: AppTheme;
  name: string;
  category: 'Cream' | 'White' | 'Dark';
  tagline: string;
  description: string;
  bgHex: string;
  cardHex: string;
  accentHex: string;
  textHex: string;
  borderHex: string;
}

export interface QrCodeOption {
  id: string;
  title: string;
  qrDataUrl: string;
  upiId?: string;
  notes?: string;
  createdAt?: string;
}

export interface CompanyInfo {
  companyName: string;
  tagline: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  stateCode: string; // e.g. "27" (Maharashtra), "07" (Delhi)
  pincode: string;
  phone: string;
  mobile: string;
  email: string;
  gstin: string;
  pan: string;
  bankName: string;
  bankAccountNo: string;
  bankIfsc: string;
  bankBranch: string;
  upiId: string;
  upiAddress?: string;
  upiAddressList?: string[];
  invoicePrefix: string;
  purchasePrefix: string;
  invoiceTerms: string;
  declaration: string;
  currencySymbol: string;

  // Email Purpose Settings
  smtpEmail?: string;
  smtpPassword?: string;
  receivingEmail?: string;
  sendEmail?: boolean;
  customBackendUrl?: string;

  // QR Codes & Active Display Selection
  qrCodes?: QrCodeOption[];
  activeQrTitle?: string;

  // New global setting for item tax calculation
  defaultTaxCalculation?: 'Inclusive' | 'Exclusive';

  // Database Connection Choice
  databaseType?: 'firebase' | 'mongodb';
  mongoUri?: string;
  mongoDbName?: string;
}

export interface Item {
  id: string; // e.g. "ITM-001"
  itemCode: string; // e.g. "SH-FOR-01"
  barcode: string;
  itemName: string;
  category: string;
  unit: string; // "Pairs", "Pcs", "Box", "Doz"
  hsnCode: string; // e.g. "6403" for footwear
  purchaseRate: number; // Cost price (excl or incl)
  sellingRate: number; // MRP / Sale price
  mrp: number;
  gstRate: number; // 0, 3, 5, 12, 18, 28
  taxType: 'Inclusive' | 'Exclusive';
  openingStock: number;
  openingStockValue: number;
  currentStock: number;
  minStockLevel: number;
  locationRack?: string;
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string; // "CUST-001"
  customerCode: string;
  customerName: string;
  contactPerson?: string;
  mobile: string;
  phone?: string;
  email?: string;
  address: string;
  city: string;
  state: string;
  stateCode: string;
  gstin?: string;
  pan?: string;
  openingBalance: number; // Positive = Receivable (Dr), Negative = Advance (Cr)
  currentBalance: number;
  creditLimit: number;
  creditDays: number;
  creditBalance?: number; // Active Store Credit / Customer Credit wallet balance
  customerType: 'Retail' | 'Wholesale' | 'B2B';
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface Supplier {
  id: string; // "SUP-001"
  supplierCode: string;
  supplierName: string;
  contactPerson?: string;
  mobile: string;
  phone?: string;
  email?: string;
  address: string;
  city: string;
  state: string;
  stateCode: string;
  gstin?: string;
  pan?: string;
  bankName?: string;
  bankAccountNo?: string;
  bankIfsc?: string;
  openingBalance: number; // Positive = Payable (Cr), Negative = Advance (Dr)
  currentBalance: number;
  paymentTermsDays: number;
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface CustomerLedgerEntry {
  id: string;
  customerId: string;
  date: string;
  voucherType: string;
  voucherNo: string;
  particulars: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface SupplierLedgerEntry {
  id: string;
  supplierId: string;
  date: string;
  voucherType: string;
  voucherNo: string;
  particulars: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface InvoiceItem {
  id: string;
  itemId: string;
  itemCode: string;
  itemName: string;
  hsnCode: string;
  quantity: number;
  unit: string;
  rate: number;
  sellingRate?: number;
  mrp?: number;
  grossAmount: number;
  discountPercent: number;
  discountAmount: number;
  taxableAmount: number;
  gstRate: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  igstRate: number;
  igstAmount: number;
  netAmount: number;
}

export type InvoiceReturnStatus =
  | 'NO_RETURN'
  | 'PARTIALLY_RETURNED'
  | 'FULLY_RETURNED'
  | 'EXCHANGED'
  | 'PARTIALLY_EXCHANGED';

export interface SalesInvoice {
  id: string; // "INV-1001"
  invoiceNo: string;
  invoiceDate: string; // YYYY-MM-DD
  customerId: string;
  customerName: string;
  customerGstin?: string;
  customerAddress?: string;
  customerStateCode: string;
  customerMobile?: string;
  isInterState: boolean;
  paymentMode: 'Cash' | 'Credit' | 'Bank/UPI' | 'Card' | 'Split' | 'Customer Credit';
  items: InvoiceItem[];
  totalQuantity: number;
  grossSubtotal: number;
  totalDiscount: number;
  totalTaxable: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  totalTax: number;
  roundOff: number;
  grandTotal: number;
  amountReceived: number;
  balanceDue: number;
  previousBalance: number;
  newBalance: number;
  customerCreditUsed?: number;
  returnStatus?: InvoiceReturnStatus;
  salesmanName?: string;
  remarks?: string;
  billModifiedDate?: string; // Date when the bill is modified (YYYY-MM-DD)
  createdAt: string;
}

export interface ReturnedItemLine {
  id: string;
  itemId: string;
  itemCode: string;
  itemName: string;
  hsnCode: string;
  unit: string;
  originalQuantity: number;
  previouslyReturnedQty: number;
  returnQuantity: number;
  remainingQuantity: number;
  rate: number;
  grossAmount: number;
  discountPercent: number;
  discountAmount: number;
  taxableAmount: number;
  gstRate: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  igstRate: number;
  igstAmount: number;
  netAmount: number; // Return value for this line
  reason?: string;
}

export interface SalesReturn {
  id: string;
  returnNo: string; // e.g. "RET-0001"
  returnDate: string; // YYYY-MM-DD
  returnTime: string; // HH:MM
  originalInvoiceId: string;
  originalInvoiceNo: string;
  originalInvoiceDate: string;
  customerId: string;
  customerName: string;
  customerGstin?: string;
  customerMobile?: string;
  customerAddress?: string;
  customerStateCode: string;
  isInterState: boolean;
  items: ReturnedItemLine[];
  totalQuantity: number;
  totalTaxable: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  totalTax: number;
  roundOff: number;
  grandTotal: number; // Total Return Value
  refundMode: 'Cash' | 'UPI' | 'Card' | 'Bank Transfer' | 'Store Credit' | 'Customer Credit' | 'Credit Note';
  amountRefunded: number;
  storeCreditAmount?: number;
  creditAmountStatus?: 'Credit Amount Pending' | 'Credit Amount Taken';
  reason?: string;
  createdBy?: string;
  createdAt: string;
}

export interface SalesExchange {
  id: string;
  exchangeNo: string; // e.g. "EXC-0001"
  exchangeDate: string; // YYYY-MM-DD
  exchangeTime: string; // HH:MM
  originalInvoiceId: string;
  originalInvoiceNo: string;
  originalInvoiceDate: string;
  customerId: string;
  customerName: string;
  customerGstin?: string;
  customerMobile?: string;
  customerAddress?: string;
  customerStateCode: string;
  isInterState: boolean;
  returnedItems: ReturnedItemLine[];
  returnedTotalQuantity: number;
  returnedTaxable: number;
  returnedTax: number;
  returnedTotalValue: number; // Total Returned Value
  newItems: InvoiceItem[];
  newTotalQuantity: number;
  newTaxable: number;
  newTax: number;
  newTotalValue: number; // Total New Items Value
  differenceAmount: number; // newTotalValue - returnedTotalValue
  settlementType: 'CUSTOMER_PAID' | 'REFUND_PAID' | 'STORE_CREDIT_ISSUED' | 'EQUAL';
  additionalAmountPaid: number;
  paymentMethod?: 'Cash' | 'UPI' | 'Card' | 'Bank Transfer' | 'Customer Credit' | 'Split';
  refundAmount: number;
  refundMethod?: 'Cash' | 'UPI' | 'Card' | 'Bank Transfer';
  storeCreditAmount: number;
  customerCreditUsed?: number;
  reason?: string;
  createdBy?: string;
  createdAt: string;
}

export interface SalesExchangeDeskRecord {
  id: string;
  invoiceId: string;
  invoiceNo: string; // Customer Invoice Number
  invoiceDate: string; // Invoice Date
  billModifiedDate?: string; // Bill Modified Date (YYYY-MM-DD, date on which bill was modified)
  customerId: string;
  customerName: string; // Customer Name
  customerMobile?: string; // Customer Mobile number
  originalBillAmount: number; // Original Bill Amount
  newBillAmount: number; // New Bill Amount
  netAmount: number; // Net Amount
  reason?: string;
  remarks?: string;
  itemsBefore?: InvoiceItem[];
  itemsAfter?: InvoiceItem[];
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
}

export interface StockMovement {
  id: string;
  date: string;
  time: string;
  itemId: string;
  itemCode: string;
  itemName: string;
  movementType: 'SALES_RETURN' | 'EXCHANGE_SALE' | 'SALE' | 'PURCHASE' | 'PURCHASE_RETURN' | 'ADJUSTMENT';
  quantity: number; // positive = stock in, negative = stock out
  referenceNo: string; // RET-0001, EXC-0001, INV-1001, etc.
  originalInvoiceNo?: string;
  particulars?: string;
  createdAt: string;
}

export interface CustomerCreditTransaction {
  id: string;
  customerId: string;
  customerName: string;
  transactionDate: string;
  transactionTime: string;
  type: 'CREDIT_ISSUED' | 'CREDIT_USED';
  amount: number;
  previousBalance: number;
  newBalance: number;
  referenceType: 'SALES_RETURN' | 'SALES_EXCHANGE' | 'SALE_INVOICE';
  referenceNo: string;
  referenceInvoiceNo?: string;
  narration?: string;
  createdAt: string;
}

export interface PurchaseInvoice {
  id: string; // "PUR-1001"
  purchaseNo: string;
  purchaseInvoiceNo?: string;
  supplierBillNo: string;
  purchaseDate: string; // YYYY-MM-DD
  supplierId: string;
  supplierName: string;
  supplierGstin?: string;
  supplierAddress?: string;
  supplierStateCode: string;
  isInterState: boolean;
  paymentMode: 'Cash' | 'Credit' | 'Bank' | 'Bank/NEFT';
  items: InvoiceItem[];
  totalQuantity: number;
  grossSubtotal: number;
  totalDiscount: number;
  totalTaxable: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  totalTax: number;
  freightOtherCharges: number;
  roundOff: number;
  grandTotal: number;
  amountPaid: number;
  balanceDue: number;
  previousBalance?: number;
  newBalance?: number;
  remarks?: string;
  createdAt: string;
}

export interface PurchaseReturn {
  id: string;
  returnNo: string;
  returnDate: string;
  originalPurchaseNo?: string;
  supplierId: string;
  supplierName: string;
  supplierGstin?: string;
  supplierStateCode: string;
  isInterState: boolean;
  items: InvoiceItem[];
  totalQuantity: number;
  totalTaxable: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  roundOff: number;
  grandTotal: number;
  refundMode: 'Debit Note' | 'Cash' | 'Bank';
  amountAdjusted: number;
  reason?: string;
  createdAt: string;
}

export interface CustomerReceipt {
  id: string;
  receiptNo: string;
  receiptDate: string;
  customerId: string;
  customerName: string;
  paymentMode: 'Cash' | 'Cheque' | 'Bank/UPI' | 'Card';
  referenceNo?: string; // Cheque / Txn No
  previousBalance: number;
  amountReceived: number;
  discountAllowed: number;
  newBalance: number;
  remarks?: string;
  createdAt: string;
}

export interface SupplierPayment {
  id: string;
  voucherNo: string;
  voucherDate: string;
  supplierId: string;
  supplierName: string;
  paymentMode: 'Cash' | 'Cheque' | 'Bank/NEFT' | 'UPI';
  referenceNo?: string; // Cheque / UTR No
  previousBalance: number;
  amountPaid: number;
  discountReceived: number;
  newBalance: number;
  remarks?: string;
  createdAt: string;
}

export interface StockAdjustment {
  id: string;
  adjustmentNo?: string;
  adjustmentDate: string;
  itemId: string;
  itemCode: string;
  itemName: string;
  previousStock: number;
  physicalStock?: number;
  adjustedStock?: number;
  differenceQty?: number; // positive = excess, negative = shortage
  difference?: number;
  itemCost?: number;
  adjustmentValue?: number;
  reason: string;
  remarks?: string;
  createdAt?: string;
}

export interface LedgerEntry {
  id: string;
  date: string;
  partyType: 'Customer' | 'Supplier';
  partyId: string;
  partyName: string;
  voucherType: 'Sale' | 'Sale Return' | 'Sale Exchange' | 'Purchase' | 'Purchase Return' | 'Receipt' | 'Payment' | 'Customer Credit' | 'Opening Balance';
  voucherNo: string;
  debit: number;
  credit: number;
  runningBalance: number;
  narration?: string;
}

export interface SecurityAuthSettings {
  email: string;
  password: string;
  securityQuestion: string;
  securityAnswer: string;
  recoveryPin: string;
  lastChangedAt: string;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'Super Admin' | 'Administrator' | 'Branch Admin' | 'Billing Admin' | 'Store Manager';
  password?: string;
  securityQuestion?: string;
  securityAnswer?: string;
  recoveryPin?: string;
  createdAt: string;
  lastLoginAt?: string;
  isPrimary?: boolean;
}

export interface MigrationSummary {
  itemsCount: number;
  customersCount: number;
  suppliersCount: number;
  salesCount: number;
  purchaseCount: number;
  totalSalesValue: number;
  totalPurchaseValue: number;
  totalStockQuantity: number;
  totalStockCostValue: number;
  totalCustomerOutstanding: number;
  totalSupplierPayable: number;
  totalGstCollected: number;
  totalGstPaid: number;
  migrationDate: string;
  status: 'SUCCESS' | 'WARNING' | 'ERROR';
  logs: string[];
}
