// Import the functions you need from the SDKs you need
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import {
  initializeFirestore,
  getFirestore,
  Firestore,
  doc,
  setDoc,
  deleteDoc,
  getDocFromServer,
} from "firebase/firestore";
import { getAuth } from "firebase/auth";
import firebaseConfig from "../firebase-applet-config.json";

// Initialize Firebase
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Authoritative Firestore database (handles default database or custom named database)
const configuredDbId = (firebaseConfig as any).firestoreDatabaseId;
const isNamedDb = !!(configuredDbId && configuredDbId !== "(default)" && configuredDbId.trim() !== "");

// Initialize Firestore with experimentalForceLongPolling to ensure instant and reliable
// connectivity even in sandboxed iframes, proxies, or restricted network environments,
// preventing the 10-second backend timeout warning.
export const db: Firestore = (() => {
  try {
    return initializeFirestore(
      app,
      {
        experimentalForceLongPolling: true,
      },
      isNamedDb ? configuredDbId : undefined
    );
  } catch {
    return isNamedDb ? getFirestore(app, configuredDbId) : getFirestore(app);
  }
})();

// Validate Connection to Firestore on startup as mandated by Firebase Skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    }
  }
}
testConnection();

// Set defaultDb to point to authoritative db to prevent secondary unreachable connection timeouts
export const defaultDb: Firestore | null = db;

export const auth = getAuth(app);
export { firebaseConfig };

const effectiveDbName = isNamedDb ? configuredDbId : '(default)';

// Backend Details metadata for display in Settings & Diagnostics
export const BACKEND_DETAILS = {
  projectId: firebaseConfig.projectId,
  appId: firebaseConfig.appId,
  firestoreDatabaseId: effectiveDbName,
  storageBucket: firebaseConfig.storageBucket,
  authDomain: firebaseConfig.authDomain,
  messagingSenderId: firebaseConfig.messagingSenderId,
  consoleDirectUrl: isNamedDb
    ? `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/${configuredDbId}/data`
    : `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/-default-/data`,
  consoleDefaultUrl: `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore`,
};

/**
 * Dual-sync write: Writes to primary Firestore database and mirrors to default database if accessible
 */
export async function syncDocToFirestore(collectionName: string, docId: string, data: any): Promise<void> {
  // Write to primary authoritative database
  await setDoc(doc(db, collectionName, docId), data, { merge: true });

  // Non-blocking mirror to default database so Firebase Console default view also has entries
  if (defaultDb && defaultDb !== db) {
    setDoc(doc(defaultDb, collectionName, docId), data, { merge: true }).catch(() => {
      // Ignored if default DB is not provisioned or has different permissions
    });
  }
}

/**
 * Dual-sync delete: Deletes from primary Firestore database and mirrors to default database
 */
export async function syncDeleteFromFirestore(collectionName: string, docId: string): Promise<void> {
  await deleteDoc(doc(db, collectionName, docId));

  if (defaultDb && defaultDb !== db) {
    deleteDoc(doc(defaultDb, collectionName, docId)).catch(() => {});
  }
}

// Initialize Analytics safely
export let analytics: ReturnType<typeof getAnalytics> | null = null;
if (typeof window !== "undefined") {
  isSupported()
    .then((supported) => {
      if (supported) {
        analytics = getAnalytics(app);
      }
    })
    .catch(() => {
      // Analytics not supported in non-browser or restricted context
    });
}

