import React, { useState, useEffect, useRef } from 'react';
import {
  Plus,
  Trash2,
  Save,
  Printer,
  Search,
  RotateCcw,
  History,
  AlertCircle,
  CheckCircle,
  FileText,
  UserPlus,
  ShoppingBag,
  ArrowRight,
  QrCode,
  Loader2,
} from 'lucide-react';
import { CompanyInfo, Customer, InvoiceItem, Item, SalesInvoice } from '../types';
import { dbService } from '../services/storage';
import { calculateLineGST, formatCurrency, roundTo2 } from '../services/gstCalculations';
import { sendInvoiceEmail } from '../services/emailService';
import { InvoicePrintModal } from './InvoicePrintModal';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';

interface SalesInvoiceProps {
  company: CompanyInfo;
  onNavigateToCustomerMaster?: () => void;
  onNavigateToItemMaster?: () => void;
  onOpenQrModal?: (amount?: number) => void;
  onNavigateToSalesReturn?: () => void;
  onOpenPrintPreviewTab?: (invoice: SalesInvoice, autoPrint?: boolean) => void;
}

export const SalesInvoiceComponent: React.FC<SalesInvoiceProps> = ({
  company,
  onNavigateToCustomerMaster,
  onNavigateToItemMaster,
  onOpenQrModal,
  onNavigateToSalesReturn,
  onOpenPrintPreviewTab,
}) => {
  const [itemsList, setItemsList] = useState<Item[]>([]);
  const [customersList, setCustomersList] = useState<Customer[]>([]);
  const [invoiceToDelete, setInvoiceToDelete] = useState<{ id: string; no: string } | null>(null);

  // Form State
  const [invoiceId, setInvoiceId] = useState<string>('');
  const [invoiceNo, setInvoiceNo] = useState<string>('');
  const [invoiceDate, setInvoiceDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('CUST-000');
  const [customerMobile, setCustomerMobile] = useState<string>('');
  const [customerGstin, setCustomerGstin] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [customerStateCode, setCustomerStateCode] = useState<string>('27');
  const [isInterState, setIsInterState] = useState<boolean>(false);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'Credit' | 'Bank/UPI' | 'Card' | 'Split'>('Cash');
  const [salesmanName, setSalesmanName] = useState<string>('Counter');
  const [remarks, setRemarks] = useState<string>('');
  const [amountReceived, setAmountReceived] = useState<number>(0);

  // Manual Customer Mode states (Unchecked by default)
  const [isExistingCustomer, setIsExistingCustomer] = useState<boolean>(false);
  const [manualCustomerName, setManualCustomerName] = useState<string>('NA');
  const [manualCustomerMobile, setManualCustomerMobile] = useState<string>('');

  // Manual Item Mode states (Unchecked by default)
  const [isExistingItem, setIsExistingItem] = useState<boolean>(false);
  const [manualItemName, setManualItemName] = useState<string>('');

  // Line items state
  const [lineItems, setLineItems] = useState<InvoiceItem[]>([]);

  // Item row input buffer (empty strings so no default 1, 0, 0 values appear)
  const [activeItemId, setActiveItemId] = useState<string>('');
  const [rowQty, setRowQty] = useState<string>('');
  const [rowRate, setRowRate] = useState<string>('');
  const [rowDisc, setRowDisc] = useState<string>('');

  // Popups & modals
  const [showItemSearch, setShowItemSearch] = useState<boolean>(false);
  const [itemSearchQuery, setItemSearchQuery] = useState<string>('');
  const [showCustomerSearch, setShowCustomerSearch] = useState<boolean>(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<SalesInvoice | null>(null);
  const [autoPrintModal, setAutoPrintModal] = useState<boolean>(false);

  // Status message and saving states
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'warning' | 'info';
    title?: string;
    text: string;
    onClose?: () => void;
  } | null>(null);
  const [saveStatus, setSaveStatus] = useState<'saving' | 'sending_email' | null>(null);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const rateInputRef = useRef<HTMLInputElement>(null);
  const qtyInputRef = useRef<HTMLInputElement>(null);

  // Load initial data
  const loadMasterData = () => {
    const itms = dbService.getItems();
    const custs = dbService.getCustomers();
    setItemsList(itms);
    setCustomersList(custs);
  };

  const resetForm = () => {
    loadMasterData();
    const newInvNo = dbService.getNextInvoiceNo();
    setInvoiceId(`INV-${Date.now()}`);
    setInvoiceNo(newInvNo);
    setInvoiceDate(new Date().toISOString().split('T')[0]);
    setSelectedCustomerId('CUST-000');
    setCustomerMobile('');
    setCustomerGstin('');
    setCustomerAddress('Local Counter Sales, Mumbai');
    setCustomerStateCode(company.stateCode || '27');
    setIsInterState(false);
    setPaymentMode('Cash');
    setRemarks('');
    setLineItems([]);
    setAmountReceived(0);
    setActiveItemId('');
    setRowQty('');
    setRowRate('');
    setRowDisc('');
    setIsExistingCustomer(false);
    setManualCustomerName('NA');
    setManualCustomerMobile('');
    setIsExistingItem(false);
    setManualItemName('');
  };

  useEffect(() => {
    resetForm();
    return dbService.subscribe(() => {
      setItemsList(dbService.getItems());
      setCustomersList(dbService.getCustomers());
    });
  }, []);

  // Update customer fields when customer selected
  const handleCustomerChange = (custId: string) => {
    setIsExistingCustomer(true);
    setSelectedCustomerId(custId);
    const cust = customersList.find((c) => c.id === custId);
    if (cust) {
      setCustomerMobile(cust.mobile || '');
      setCustomerGstin(cust.gstin || '');
      setCustomerAddress(cust.address || '');
      setCustomerStateCode(cust.stateCode || company.stateCode || '27');
      const isInter = cust.stateCode && cust.stateCode !== company.stateCode;
      setIsInterState(Boolean(isInter));
      setPaymentMode('Credit'); // Existing customer defaults to Credit Line
    }
  };

  const handleExistingCustomerToggle = (checked: boolean) => {
    setIsExistingCustomer(checked);
    if (checked) {
      // Switched to Existing Customer -> Customer Type: Credit Line
      setPaymentMode('Credit');
      setManualCustomerName('NA');
      setManualCustomerMobile('');
      const nonWalkIn = customersList.find((c) => c.id !== 'CUST-000');
      if (nonWalkIn) {
        handleCustomerChange(nonWalkIn.id);
      } else {
        handleCustomerChange('CUST-000');
      }
    } else {
      // Switched to Manual / Walk-in Customer -> Customer Type: Cash(Counter)
      setPaymentMode('Cash');
      setSelectedCustomerId('CUST-000');
      setCustomerMobile('');
      setCustomerGstin('');
      setCustomerAddress('Local Counter Sales, Mumbai');
      setCustomerStateCode(company.stateCode || '27');
      setIsInterState(false);
    }
  };

  const handleExistingItemToggle = (checked: boolean) => {
    setIsExistingItem(checked);
    setActiveItemId('');
    setManualItemName('');
    setRowQty('');
    setRowRate('');
    setRowDisc('');
  };

  // When active item selected in quick entry bar
  const handleItemSelect = (itmId: string) => {
    setIsExistingItem(true);
    setManualItemName('');
    setActiveItemId(itmId);

    if (itmId) {
      const selected = itemsList.find((i) => i.id === itmId);
      if (selected) {
        const rateVal =
          selected.sellingRate !== undefined && selected.sellingRate !== null && selected.sellingRate !== 0
            ? selected.sellingRate
            : (selected.mrp || 0);
        setRowRate(rateVal.toString());
      } else {
        setRowRate('');
      }
    } else {
      setRowRate('');
    }

    if (!rowQty || rowQty === '0') {
      setRowQty('1');
    }
    setRowDisc('');
    setShowItemSearch(false);
    qtyInputRef.current?.focus();
  };

  // Add line item to grid
  const handleAddLineItem = () => {
    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const qtyNum = Number(rowQty);
    const rateNum = Number(rowRate);
    const discInput = rowDisc.trim();

    if (!isExistingItem) {
      if (!manualItemName.trim()) {
        setFeedback({ type: 'error', text: 'Please enter item name.' });
        return;
      }
      if (!rowQty || isNaN(qtyNum) || qtyNum <= 0) {
        setFeedback({ type: 'error', text: 'Please enter a valid quantity.' });
        return;
      }
      if (rowRate === '' || isNaN(rateNum) || rateNum < 0) {
        setFeedback({ type: 'error', text: 'Please enter a valid rate.' });
        return;
      }

      // Calculate manual item GST
      const calc = calculateLineGST(qtyNum, rateNum, discInput, 5, isInterState, activeTaxType);
      const newLine: InvoiceItem = {
        id: `L-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemId: 'ITEM-MANUAL',
        itemCode: 'MANUAL',
        itemName: manualItemName.trim(),
        hsnCode: '6403', // Default shoes HSN
        quantity: qtyNum,
        unit: 'Pairs', // Default shoes unit
        rate: rateNum,
        gstRate: 5,
        ...calc,
      };

      // Check if exact same manual item name is already in grid -> group quantity
      const existingIdx = lineItems.findIndex(
        (l) => l.itemId === 'ITEM-MANUAL' && l.itemName.toLowerCase() === manualItemName.trim().toLowerCase()
      );
      if (existingIdx >= 0) {
        const updated = [...lineItems];
        const newQty = updated[existingIdx].quantity + qtyNum;
        const newCalc = calculateLineGST(newQty, rateNum, discInput, 5, isInterState, activeTaxType);
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: newQty,
          rate: rateNum,
          ...newCalc,
        };
        setLineItems(updated);
      } else {
        setLineItems([...lineItems, newLine]);
      }

      // Reset row buffer
      setManualItemName('');
      setRowQty('');
      setRowRate('');
      setRowDisc('');
      setFeedback(null);
      return;
    }

    if (!activeItemId) {
      setFeedback({ type: 'error', text: 'Please select an item first (or press F2 to search).' });
      return;
    }
    const itm = itemsList.find((i) => i.id === activeItemId);
    if (!itm) return;

    if (!rowQty || isNaN(qtyNum) || qtyNum <= 0) {
      setFeedback({ type: 'error', text: 'Quantity must be greater than 0.' });
      return;
    }
    if (rowRate === '' || isNaN(rateNum) || rateNum < 0) {
      setFeedback({ type: 'error', text: 'Please enter a valid rate.' });
      return;
    }

    // Check if item already in grid -> add qty
    const existingIdx = lineItems.findIndex((l) => l.itemId === itm.id);
    if (existingIdx >= 0) {
      const updated = [...lineItems];
      const newQty = updated[existingIdx].quantity + qtyNum;
      const calc = calculateLineGST(newQty, rateNum, discInput, itm.gstRate, isInterState, activeTaxType);
      updated[existingIdx] = {
        ...updated[existingIdx],
        quantity: newQty,
        rate: rateNum,
        ...calc,
      };
      setLineItems(updated);
    } else {
      const calc = calculateLineGST(qtyNum, rateNum, discInput, itm.gstRate, isInterState, activeTaxType);
      const newLine: InvoiceItem = {
        id: `L-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        itemId: itm.id,
        itemCode: itm.itemCode,
        itemName: itm.itemName,
        hsnCode: itm.hsnCode,
        quantity: qtyNum,
        unit: itm.unit,
        rate: rateNum,
        gstRate: itm.gstRate,
        ...calc,
      };
      setLineItems([...lineItems, newLine]);
    }

    // Reset row buffer
    setActiveItemId('');
    setRowQty('');
    setRowRate('');
    setRowDisc('');
    setFeedback(null);
    barcodeInputRef.current?.focus();
  };

  const handleRemoveLineItem = (index: number) => {
    const updated = lineItems.filter((_, idx) => idx !== index);
    setLineItems(updated);
  };

  const handleUpdateLineItem = (index: number, field: 'quantity' | 'rate' | 'discountPercent', val: number) => {
    const updated = [...lineItems];
    const item = updated[index];
    const qty = field === 'quantity' ? Math.max(0, val) : item.quantity;
    const rate = field === 'rate' ? Math.max(0, val) : item.rate;
    const disc = field === 'discountPercent' ? Math.max(0, Math.min(100, val)) : item.discountPercent;

    const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
    const calc = calculateLineGST(qty, rate, disc, item.gstRate, isInterState, activeTaxType);
    updated[index] = {
      ...item,
      quantity: qty,
      rate,
      discountPercent: disc,
      ...calc,
    };
    setLineItems(updated);
  };

  // Real-time Preview Net Amount calculation for the current input row
  const activeTaxType = company.defaultTaxCalculation || 'Inclusive';
  const rowQtyNum = Number(rowQty) || 0;
  const rowRateNum = Number(rowRate) || 0;
  const activeItemObj = isExistingItem ? itemsList.find((i) => i.id === activeItemId) : null;
  const rowGstRate = activeItemObj ? activeItemObj.gstRate : 5;
  const previewRowCalc =
    rowQtyNum > 0 && rowRateNum >= 0
      ? calculateLineGST(rowQtyNum, rowRateNum, rowDisc.trim(), rowGstRate, isInterState, activeTaxType)
      : null;
  const rowNetAmountDisplay = previewRowCalc
    ? formatCurrency(previewRowCalc.netAmount)
    : rowQtyNum > 0 && rowRateNum > 0
    ? formatCurrency(rowQtyNum * rowRateNum)
    : '';

  // Grand totals recalculations
  const totalQuantity = lineItems.reduce((acc, it) => acc + it.quantity, 0);
  const grossSubtotal = roundTo2(lineItems.reduce((acc, it) => acc + it.grossAmount, 0));
  const totalDiscount = roundTo2(lineItems.reduce((acc, it) => acc + it.discountAmount, 0));
  const totalTaxable = roundTo2(lineItems.reduce((acc, it) => acc + it.taxableAmount, 0));
  const totalCgst = roundTo2(lineItems.reduce((acc, it) => acc + it.cgstAmount, 0));
  const totalSgst = roundTo2(lineItems.reduce((acc, it) => acc + it.sgstAmount, 0));
  const totalIgst = roundTo2(lineItems.reduce((acc, it) => acc + it.igstAmount, 0));
  const totalTax = roundTo2(totalCgst + totalSgst + totalIgst);

  const exactNet = totalTaxable + totalTax;
  const roundedGrand = Math.round(exactNet);
  const roundOff = roundTo2(roundedGrand - exactNet);
  const grandTotal = roundedGrand;

  // Selected customer balance lookup
  const selectedCustomer = isExistingCustomer ? customersList.find((c) => c.id === selectedCustomerId) : null;
  const previousBalance = selectedCustomer ? selectedCustomer.currentBalance : 0;

  // Effective amount received & balance due
  const effectivePaid = paymentMode === 'Cash' || paymentMode === 'Bank/UPI' || paymentMode === 'Card' ? grandTotal : amountReceived;
  const balanceDue = Math.max(0, roundTo2(grandTotal - effectivePaid));
  const newBalance = roundTo2(previousBalance + balanceDue);

  // Save Invoice
  const handleSaveInvoice = async (andPrint = false) => {
    if (saveStatus) return; // Prevent double-clicks / duplicate submissions

    if (lineItems.length === 0) {
      setFeedback({ type: 'error', text: 'Cannot save invoice with 0 line items.' });
      return;
    }

    if (!isExistingCustomer) {
      if (!manualCustomerName.trim()) {
        setManualCustomerName('NA');
      }
      if (manualCustomerMobile.trim() && !/^[0-9]{10}$/.test(manualCustomerMobile.trim())) {
        setFeedback({ type: 'error', text: 'Please enter a valid mobile number.' });
        return;
      }
    }

    // Step 1: Set loading state to "saving"
    setSaveStatus('saving');

    const currentCustomer = isExistingCustomer ? customersList.find((c) => c.id === selectedCustomerId) : null;
    const invoice: SalesInvoice = {
      id: invoiceId,
      invoiceNo,
      invoiceDate,
      customerId: isExistingCustomer ? selectedCustomerId : 'CUST-000',
      customerName: isExistingCustomer
        ? (currentCustomer ? currentCustomer.customerName : 'NA')
        : (manualCustomerName.trim() || 'NA'),
      customerGstin: isExistingCustomer ? customerGstin : '',
      customerAddress: isExistingCustomer ? customerAddress : 'Local Counter Sales, Mumbai',
      customerStateCode: isExistingCustomer ? customerStateCode : (company.stateCode || '27'),
      customerMobile: isExistingCustomer ? customerMobile : manualCustomerMobile.trim(),
      isInterState: isExistingCustomer ? isInterState : false,
      paymentMode,
      items: lineItems,
      totalQuantity,
      grossSubtotal,
      totalDiscount,
      totalTaxable,
      totalCgst,
      totalSgst,
      totalIgst,
      totalTax,
      roundOff,
      grandTotal,
      amountReceived: effectivePaid,
      balanceDue,
      previousBalance: isExistingCustomer ? previousBalance : 0,
      newBalance: isExistingCustomer ? newBalance : 0,
      salesmanName,
      remarks,
      createdAt: new Date().toISOString(),
    };

    // Step 2: Save to database using existing database logic
    const res = dbService.saveSaleInvoice(invoice);

    // If database save failed, do NOT send email and do not proceed
    if (!res.success) {
      setSaveStatus(null);
      setFeedback({ type: 'error', title: 'Save Failed', text: res.message });
      return;
    }

    // Step 3: Check if automatic email should be sent
    const isEmailEnabled = company.sendEmail !== false;

    let finalMessage = res.message;
    let finalPopupType: 'success' | 'warning' = 'success';
    let finalTitle = 'Bill Saved Successfully';

    if (isEmailEnabled) {
      // Transition loading state to "sending_email"
      setSaveStatus('sending_email');

      try {
        const emailRes = await sendInvoiceEmail(invoice, company);
        const recipientEmail = (emailRes.recipientEmail || company.receivingEmail || '').trim();

        if (emailRes.success) {
          finalMessage = recipientEmail
            ? `Bill saved successfully and invoice email was sent to ${recipientEmail}.`
            : 'Bill saved successfully and invoice email was sent.';
          finalTitle = 'Bill Saved & Email Sent';
          finalPopupType = 'success';
        } else if (emailRes.skipped) {
          finalMessage = `Bill saved successfully (Invoice #${invoice.invoiceNo}).`;
          finalTitle = 'Bill Saved Successfully';
          finalPopupType = 'success';
        } else if (emailRes.isConfigIncomplete) {
          finalMessage = `Bill saved successfully, but email was not sent because email settings are incomplete. (${emailRes.error || 'Check Email & E-Password in Settings'})`;
          finalTitle = 'Bill Saved (Email Notice)';
          finalPopupType = 'warning';
        } else {
          finalMessage = `Bill saved successfully, but the email could not be sent. (${emailRes.error || 'SMTP connection failed'})`;
          finalTitle = 'Bill Saved (Email Failed)';
          finalPopupType = 'warning';
        }
      } catch (err: any) {
        finalMessage = `Bill saved successfully, but invoice email could not be sent. (${err.message || 'Error occurred'})`;
        finalTitle = 'Bill Saved (Email Failed)';
        finalPopupType = 'warning';
      }
    } else {
      finalMessage = `Bill saved successfully (Invoice #${invoice.invoiceNo}).`;
      finalTitle = 'Bill Saved Successfully';
      finalPopupType = 'success';
    }

    // Done processing
    setSaveStatus(null);

    // Step 4: Display the success / result dialog ONLY AFTER email sending is finished
    // The dialog does NOT disappear automatically. It stays on screen until the user clicks the OK button.
    setFeedback({
      type: finalPopupType,
      title: finalTitle,
      text: finalMessage,
      onClose: () => {
        resetForm();
        if (andPrint) {
          setAutoPrintModal(true);
          setSelectedPrintInvoice(invoice);
        } else {
          setAutoPrintModal(false);
        }
      },
    });
  };

  // Keyboard Shortcuts Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        barcodeInputRef.current?.focus();
      } else if (e.key === 'F2') {
        e.preventDefault();
        setShowItemSearch(true);
      } else if (e.key === 'F3') {
        e.preventDefault();
        setShowCustomerSearch(true);
      } else if (e.key === 'F5') {
        e.preventDefault();
        if (!saveStatus && !feedback) handleSaveInvoice(false);
      } else if (e.key === 'F7') {
        e.preventDefault();
        if (!saveStatus && !feedback) handleSaveInvoice(true);
      } else if (e.key === 'Escape') {
        setShowItemSearch(false);
        setShowCustomerSearch(false);
        setShowHistoryModal(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lineItems, selectedCustomerId, effectivePaid, grandTotal, invoiceNo, saveStatus, company, feedback]);

  // Filtered items for search
  const filteredSearchItems = itemsList.filter((i) =>
    i.isActive &&
    (i.itemName.toLowerCase().includes(itemSearchQuery.toLowerCase()) ||
      i.itemCode.toLowerCase().includes(itemSearchQuery.toLowerCase()) ||
      i.barcode.includes(itemSearchQuery) ||
      i.category.toLowerCase().includes(itemSearchQuery.toLowerCase()))
  );

  // Filtered customers for search
  const filteredCustomers = customersList.filter((c) =>
    c.customerName.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
    c.customerCode.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
    c.mobile.includes(customerSearchQuery) ||
    (c.gstin && c.gstin.toLowerCase().includes(customerSearchQuery.toLowerCase()))
  );

  const pastSales = dbService.getSales();

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          buttonText="OK"
          onClose={() => {
            const cb = feedback.onClose;
            setFeedback(null);
            if (cb) {
              cb();
            }
          }}
        />
      )}

      {/* Top Invoice Header Form Panel */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/40 pb-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shadow-inner">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <span>Tax Invoice & Retail Billing</span>
              </h2>
              <p className="text-xs text-slate-400">
                High-speed POS counter entry with real-time GST computation and automatic stock reduction.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onNavigateToSalesReturn ? (
              <button
                id="btn-update-return-sale"
                type="button"
                onClick={onNavigateToSalesReturn}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/40 backdrop-blur-sm text-xs font-bold shadow transition-all cursor-pointer"
                title="Navigate to Update & Return Sale page"
              >
                <RotateCcw className="w-4 h-4 text-indigo-400" />
                <span>Update & Return Sale</span>
              </button>
            ) : onOpenQrModal && (
              <button
                id="btn-show-qr-invoice"
                type="button"
                onClick={() => onOpenQrModal(grandTotal)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/40 text-amber-300 border border-amber-500/40 backdrop-blur-sm text-xs font-bold shadow transition-all cursor-pointer"
                title="Display Active Counter Payment QR Code"
              >
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>Show QR</span>
              </button>
            )}

            <button
              id="btn-view-past-sales"
              onClick={() => setShowHistoryModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all"
            >
              <History className="w-4 h-4 text-sky-400" />
              <span>Past Bills ({pastSales.length})</span>
            </button>
            {lineItems.length > 0 && onOpenPrintPreviewTab && (
              <button
                id="btn-nav-print-preview"
                type="button"
                onClick={() => {
                  const currentCustomer = isExistingCustomer ? customersList.find((c) => c.id === selectedCustomerId) : null;
                  const currentInvoicePreview: SalesInvoice = {
                    id: invoiceId,
                    invoiceNo,
                    invoiceDate,
                    customerId: isExistingCustomer ? selectedCustomerId : 'CUST-000',
                    customerName: isExistingCustomer
                      ? (currentCustomer ? currentCustomer.customerName : 'NA')
                      : (manualCustomerName.trim() || 'NA'),
                    customerGstin: isExistingCustomer ? customerGstin : '',
                    customerAddress: isExistingCustomer ? customerAddress : 'Local Counter Sales',
                    customerStateCode: isExistingCustomer ? customerStateCode : (company.stateCode || '27'),
                    customerMobile: isExistingCustomer ? customerMobile : manualCustomerMobile.trim(),
                    isInterState: isExistingCustomer ? isInterState : false,
                    paymentMode,
                    items: lineItems,
                    totalQuantity,
                    grossSubtotal,
                    totalDiscount,
                    totalTaxable,
                    totalCgst,
                    totalSgst,
                    totalIgst,
                    totalTax,
                    roundOff,
                    grandTotal,
                    amountReceived: effectivePaid,
                    balanceDue,
                    previousBalance: isExistingCustomer ? previousBalance : 0,
                    newBalance: isExistingCustomer ? newBalance : 0,
                    salesmanName,
                    remarks,
                    createdAt: new Date().toISOString(),
                  };
                  onOpenPrintPreviewTab(currentInvoicePreview, false);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/40 backdrop-blur-sm text-xs font-bold shadow transition-all cursor-pointer"
                title="Attach Print Preview to Top Navigation Bar as New Tab"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>Print Tab</span>
              </button>
            )}
            <button
              id="btn-new-invoice"
              onClick={resetForm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm text-xs font-medium transition-all"
            >
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span>New Bill [Esc]</span>
            </button>
          </div>
        </div>

        {/* Invoice Parameters Form Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
          {/* Customer Invoice No (Locked) */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
              <span>Customer Invoice Number</span>
              <span className="text-[9px] text-amber-400 font-mono font-normal">🔒 Locked</span>
            </label>
            <input
              type="text"
              value={invoiceNo}
              readOnly
              disabled
              tabIndex={-1}
              className="w-full bg-slate-950/80 border border-slate-700/60 rounded-md px-2 py-1 text-slate-300 font-mono font-bold cursor-not-allowed opacity-85 select-none focus:outline-none"
              title="Customer Invoice Number is auto-generated and locked"
            />
          </div>

          {/* Invoice Date */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Invoice Date</label>
            <input
              type="date"
              value={invoiceDate}
              onChange={(e) => setInvoiceDate(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono focus:border-blue-500 focus:outline-none"
            />
          </div>

          {/* Customer Selection with [F3] search */}
          {isExistingCustomer ? (
            <div className="lg:col-span-2 bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span>Customer Party</span>
                  <span className="text-[10px] bg-slate-800/80 text-purple-300 px-1 rounded font-mono border border-slate-700/50">F3</span>
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1 text-[11px] text-slate-300 cursor-pointer select-none font-semibold">
                    <input
                      type="checkbox"
                      checked={isExistingCustomer}
                      onChange={(e) => handleExistingCustomerToggle(e.target.checked)}
                      className="rounded border-slate-700 bg-slate-950 text-purple-500 focus:ring-purple-500 h-3.5 w-3.5 accent-purple-600 cursor-pointer"
                    />
                    <span>Existing Customer</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowCustomerSearch(true)}
                    className="text-[11px] text-purple-400 hover:underline flex items-center gap-0.5"
                  >
                    <Search className="w-3 h-3" /> Find
                  </button>
                </div>
              </div>
              <select
                value={selectedCustomerId}
                onChange={(e) => handleCustomerChange(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-medium focus:border-purple-500 focus:outline-none text-xs"
              >
                {customersList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.customerName} {c.gstin ? `[GSTIN: ${c.gstin}]` : ''} ({formatCurrency(c.currentBalance)} Dr)
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="lg:col-span-2 grid grid-cols-2 gap-2">
              {/* Customer Name */}
              <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm flex flex-col justify-between">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Customer Name</label>
                  <label className="flex items-center gap-1 text-[11px] text-slate-300 cursor-pointer select-none font-semibold">
                    <input
                      type="checkbox"
                      checked={isExistingCustomer}
                      onChange={(e) => handleExistingCustomerToggle(e.target.checked)}
                      className="rounded border-slate-700 bg-slate-950 text-purple-500 focus:ring-purple-500 h-3.5 w-3.5 accent-purple-600 cursor-pointer"
                    />
                    <span>Existing</span>
                  </label>
                </div>
                <input
                  type="text"
                  placeholder="NA"
                  value={manualCustomerName}
                  onChange={(e) => setManualCustomerName(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 focus:border-blue-500 focus:outline-none text-xs"
                />
              </div>

              {/* Mobile Number */}
              <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm flex flex-col justify-between">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Mobile No.</label>
                <input
                  type="text"
                  placeholder="Enter Mobile"
                  value={manualCustomerMobile}
                  onChange={(e) => setManualCustomerMobile(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono focus:border-blue-500 focus:outline-none text-xs"
                />
              </div>
            </div>
          )}

          {/* Customer GSTIN */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Buyer GSTIN</label>
            <input
              type="text"
              placeholder="Unregistered"
              value={customerGstin}
              onChange={(e) => setCustomerGstin(e.target.value.toUpperCase())}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2 py-1 text-slate-100 font-mono uppercase focus:border-blue-500 focus:outline-none"
            />
          </div>

          {/* Customer Type (Renamed from Payment Mode, displays Credit Line when Existing Customer, otherwise Cash(Counter)) */}
          <div className="bg-slate-900/50 border border-slate-700/40 p-2.5 rounded-lg backdrop-blur-sm">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Customer Type</label>
            <div className="w-full bg-slate-950/70 border border-slate-700/60 rounded-md px-2.5 py-1 text-slate-100 font-semibold text-xs flex items-center justify-between min-h-[30px]">
              <span className={isExistingCustomer ? 'text-purple-300 font-bold' : 'text-emerald-300 font-bold'}>
                {isExistingCustomer ? 'Credit Line' : 'Cash(Counter)'}
              </span>
              <span
                className={`text-[9px] px-1.5 py-0.5 rounded font-mono uppercase tracking-wider ${
                  isExistingCustomer
                    ? 'bg-purple-950/80 text-purple-300 border border-purple-800/60'
                    : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                }`}
              >
                {isExistingCustomer ? 'Khata' : 'Counter'}
              </span>
            </div>
          </div>
        </div>

        {/* Customer Balance Indicator Strip */}
        <div className="mt-3 pt-2.5 border-t border-slate-700/40 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span>
              Prev Balance: <strong className="text-amber-400 font-mono">{formatCurrency(previousBalance)}</strong>
            </span>
            <span>•</span>
            <span>
              Supply Type:{' '}
              <strong className={isInterState ? 'text-amber-300' : 'text-emerald-400'}>
                {isInterState ? 'Inter-State (IGST Applicable)' : `Intra-State (CGST + SGST - State ${customerStateCode})`}
              </strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span>
              Address: <strong className="text-slate-300">{customerAddress || 'Local Walk-in'}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Item Quick Insertion Strip */}
      <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-3.5 shadow-lg backdrop-blur-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                Fast Item Insertion Bar
              </span>
            </div>
            <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer select-none font-semibold bg-slate-800/60 hover:bg-slate-800 border border-slate-700/40 px-2 py-0.5 rounded-md">
              <input
                type="checkbox"
                checked={isExistingItem}
                onChange={(e) => handleExistingItemToggle(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-blue-500 focus:ring-blue-500 h-3.5 w-3.5 accent-blue-600 cursor-pointer"
              />
              <span>Existing Item</span>
            </label>
          </div>
          <span className="text-[11px] text-slate-400">
            Press <strong className="text-amber-400 font-mono bg-slate-800/80 px-1 py-0.5 rounded border border-slate-700/50">F2</strong> to search item catalog
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs items-end">
          {/* Item Selector / Search / Manual input */}
          {isExistingItem ? (
            <div className="sm:col-span-4 lg:col-span-4">
              <label className="block text-slate-400 font-medium mb-1">Select Item / Footwear Code</label>
              <div className="flex gap-1.5">
                <select
                  ref={barcodeInputRef as any}
                  value={activeItemId}
                  onChange={(e) => handleItemSelect(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-medium focus:border-blue-500 focus:outline-none text-xs"
                >
                  <option value="">-- Choose Item or Press F2 --</option>
                  {itemsList
                    .filter((i) => i.isActive)
                    .map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.itemCode} - {i.itemName} (Stock: {i.currentStock} {i.unit} | ₹{i.sellingRate})
                      </option>
                    ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowItemSearch(true)}
                  className="px-2.5 py-1.5 bg-slate-800/70 hover:bg-slate-700/70 text-amber-400 border border-slate-700/50 rounded-lg flex items-center gap-1 backdrop-blur-sm"
                  title="Search Item (F2)"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="sm:col-span-4 lg:col-span-4">
              <label className="block text-slate-400 font-medium mb-1">Item Name</label>
              <input
                type="text"
                placeholder="Enter Item Name"
                value={manualItemName}
                onChange={(e) => setManualItemName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddLineItem();
                }}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-blue-500 focus:outline-none"
              />
            </div>
          )}

          {/* Rate */}
          <div className="sm:col-span-2 lg:col-span-2">
            <label className="block text-slate-400 font-medium mb-1">Rate (₹)</label>
            <input
              ref={rateInputRef}
              type="text"
              inputMode="decimal"
              placeholder=""
              value={rowRate}
              onChange={(e) => setRowRate(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  qtyInputRef.current?.focus();
                }
              }}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-blue-500 focus:outline-none"
            />
          </div>

          {/* Qty */}
          <div className="sm:col-span-1 lg:col-span-1">
            <label className="block text-slate-400 font-medium mb-1">Quantity</label>
            <input
              ref={qtyInputRef}
              type="text"
              inputMode="numeric"
              placeholder=""
              value={rowQty}
              onChange={(e) => setRowQty(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddLineItem();
              }}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-bold font-mono focus:border-blue-500 focus:outline-none"
            />
          </div>

          {/* Disc % */}
          <div className="sm:col-span-1 lg:col-span-1">
            <label className="block text-slate-400 font-medium mb-1">Disc% / Amt</label>
            <input
              type="text"
              placeholder="e.g. 10 or 10%"
              value={rowDisc}
              onChange={(e) => setRowDisc(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddLineItem();
              }}
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 font-mono text-xs focus:border-blue-500 focus:outline-none"
            />
          </div>

          {/* NET AMOUNT Text Box */}
          <div className="sm:col-span-2 lg:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
              <span>Net Amount</span>
              <span className="text-[9px] text-emerald-400 font-mono">Auto</span>
            </label>
            <input
              id="input-row-net-amount"
              type="text"
              readOnly
              tabIndex={-1}
              placeholder="₹0.00"
              value={rowNetAmountDisplay || '₹0.00'}
              className="w-full bg-slate-950/80 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-emerald-400 font-mono font-bold text-xs select-none cursor-not-allowed opacity-90 focus:outline-none"
              title="Net Amount payable for this line item (including GST and discounts)"
            />
          </div>

          {/* Add Row Button */}
          <div className="sm:col-span-2 lg:col-span-2">
            <button
              id="btn-add-line-item"
              type="button"
              onClick={handleAddLineItem}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-lg shadow-blue-900/20 border border-blue-500/30 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Item [Enter]</span>
            </button>
          </div>
        </div>
      </div>

      {/* Line Items Table Grid */}
      <div className="bg-slate-900/20 border border-slate-700/50 rounded-xl shadow-xl backdrop-blur-md overflow-hidden text-slate-200">
        <div className="p-3 bg-slate-800/40 border-b border-slate-700/50 flex items-center justify-between text-xs backdrop-blur-sm">
          <span className="font-bold uppercase tracking-wider text-slate-300">
            Invoice Bill Items Grid ({lineItems.length} items)
          </span>
          <span className="text-slate-400">All prices calculated with exact 2-decimal precision</span>
        </div>

        <div className="overflow-x-auto max-h-80">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 z-10 backdrop-blur-md">
              <tr>
                <th className="py-2.5 px-2.5 w-8 text-center">#</th>
                <th className="py-2.5 px-3">Item Details</th>
                <th className="py-2.5 px-2 text-center w-16">HSN</th>
                <th className="py-2.5 px-2 text-right w-20">Qty</th>
                <th className="py-2.5 px-2 text-right w-24">Rate (₹)</th>
                <th className="py-2.5 px-2 text-right w-16">Disc%</th>
                <th className="py-2.5 px-2 text-right w-24">Taxable</th>
                <th className="py-2.5 px-2 text-center w-14">GST%</th>
                {!isInterState ? (
                  <>
                    <th className="py-2.5 px-2 text-right w-20">CGST</th>
                    <th className="py-2.5 px-2 text-right w-20">SGST</th>
                  </>
                ) : (
                  <th className="py-2.5 px-2 text-right w-24">IGST</th>
                )}
                <th className="py-2.5 px-3 text-right w-28">Net Amount</th>
                <th className="py-2.5 px-2 text-center w-10">Act</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {lineItems.length === 0 ? (
                <tr>
                  <td colSpan={isInterState ? 10 : 11} className="py-8 text-center text-slate-500">
                    <p className="text-sm font-medium">No items added to invoice.</p>
                    <p className="text-xs mt-1">Select an item above or press <strong className="text-amber-400">F2</strong> to search catalog.</p>
                  </td>
                </tr>
              ) : (
                lineItems.map((line, idx) => (
                  <tr key={line.id} className="hover:bg-slate-800/40 transition font-mono border-b border-slate-800/50">
                    <td className="py-2.5 px-2.5 text-center text-slate-400">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-sans">
                      <div className="font-semibold text-slate-100">{line.itemName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">Code: {line.itemCode}</div>
                    </td>
                    <td className="py-2.5 px-2 text-center text-slate-300">{line.hsnCode}</td>
                    <td className="py-2.5 px-2 text-right">
                      <input
                        type="text"
                        inputMode="numeric"
                        value={line.quantity}
                        onChange={(e) => handleUpdateLineItem(idx, 'quantity', Number(e.target.value) || 0)}
                        className="w-16 bg-slate-950/70 border border-slate-700/60 rounded px-1.5 py-0.5 text-right font-bold text-slate-100 focus:border-blue-500 focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2 text-right">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={line.rate}
                        onChange={(e) => handleUpdateLineItem(idx, 'rate', Number(e.target.value) || 0)}
                        className="w-20 bg-slate-950/70 border border-slate-700/60 rounded px-1.5 py-0.5 text-right text-slate-100 focus:border-blue-500 focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2 text-right">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={line.discountPercent}
                        onChange={(e) => handleUpdateLineItem(idx, 'discountPercent', Number(e.target.value) || 0)}
                        className="w-14 bg-slate-950/70 border border-slate-700/60 rounded px-1.5 py-0.5 text-right text-slate-100 focus:border-blue-500 focus:outline-none"
                      />
                    </td>
                    <td className="py-2.5 px-2 text-right text-slate-200 font-semibold">
                      ₹{line.taxableAmount.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-2 text-center text-slate-300">{line.gstRate}%</td>
                    {!isInterState ? (
                      <>
                        <td className="py-2.5 px-2 text-right text-slate-300">
                          <div>₹{line.cgstAmount.toFixed(2)}</div>
                          <span className="text-[10px] text-slate-500">@{line.cgstRate}%</span>
                        </td>
                        <td className="py-2.5 px-2 text-right text-slate-300">
                          <div>₹{line.sgstAmount.toFixed(2)}</div>
                          <span className="text-[10px] text-slate-500">@{line.sgstRate}%</span>
                        </td>
                      </>
                    ) : (
                      <td className="py-2.5 px-2 text-right text-slate-300">
                        <div>₹{line.igstAmount.toFixed(2)}</div>
                        <span className="text-[10px] text-slate-500">@{line.igstRate}%</span>
                      </td>
                    )}
                    <td className="py-2.5 px-3 text-right font-bold text-blue-400 text-sm">
                      ₹{line.netAmount.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveLineItem(idx)}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800/60 transition"
                        title="Delete line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bottom Financial Totals & Action Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Remarks & Salesman */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Bill Remarks / Order Reference</label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Retail sale counter, goods delivered"
              className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">SOLD BY</label>
              <input
                type="text"
                value={salesmanName}
                onChange={(e) => setSalesmanName(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Total Quantity</label>
              <div className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold">
                {totalQuantity} Units ({lineItems.length} Lines)
              </div>
            </div>
          </div>
        </div>

        {/* Right Financial Summary Card */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-xs space-y-3 text-slate-300">
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-700/50 backdrop-blur-sm">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Gross Subtotal</span>
                <span className="font-semibold text-slate-200">₹{grossSubtotal.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Total Discount</span>
                <span className="font-semibold text-rose-400">-₹{totalDiscount.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Taxable Value</span>
                <span className="font-semibold text-slate-200">₹{totalTaxable.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">Total GST Tax</span>
                <span className="font-semibold text-blue-400">₹{totalTax.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between py-0.5 px-1 text-xs">
            <span className="text-slate-400">Round Off Adjustment:</span>
            <span className="font-mono text-slate-300">{roundOff > 0 ? `+${roundOff.toFixed(2)}` : roundOff.toFixed(2)}</span>
          </div>

          {/* Grand Total Bar - Frosted Accent Callout */}
          <div className="bg-blue-600/20 p-4 sm:p-5 rounded-xl border border-blue-500/40 flex flex-col justify-center shadow-inner backdrop-blur-md">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-black text-blue-400 tracking-widest block">
                  Net Amount Payable
                </span>
                <span className="text-[10px] text-blue-300 italic mt-0.5 block">
                  Inclusive of all GST taxes & round-off
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl sm:text-4xl font-mono text-white font-bold leading-tight">
                  ₹{grandTotal.toLocaleString('en-IN')}.00
                </span>
              </div>
            </div>
          </div>

          {/* Payment & Balance */}
          <div className="grid grid-cols-3 gap-2 pt-1 font-mono">
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-700/50">
              <label className="block text-[10px] text-slate-400 font-sans uppercase font-semibold">Amount Paid</label>
              <input
                type="text"
                inputMode="decimal"
                value={effectivePaid}
                onChange={(e) => setAmountReceived(Number(e.target.value) || 0)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-bold focus:border-blue-500 focus:outline-none mt-1"
              />
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-700/50">
              <span className="block text-[10px] text-slate-400 font-sans uppercase font-semibold">Invoice Due</span>
              <div className="w-full bg-slate-950/70 border border-slate-700/60 rounded px-2 py-1 font-bold text-rose-400 mt-1">
                ₹{balanceDue.toFixed(2)}
              </div>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-700/50">
              <span className="block text-[10px] text-slate-400 font-sans uppercase font-semibold">New Party Balance</span>
              <div className="w-full bg-slate-950/70 border border-slate-700/60 rounded px-2 py-1 font-bold text-amber-300 mt-1">
                ₹{newBalance.toFixed(2)} Dr
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-700/40">
            {onOpenQrModal && lineItems.length > 0 && (
              <button
                id="btn-invoice-upi-pay"
                type="button"
                onClick={() => onOpenQrModal(grandTotal)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-600/30 hover:bg-amber-600/40 text-amber-300 font-bold rounded-lg border border-amber-500/40 shadow transition-all cursor-pointer"
                title="Display UPI QR Code for the exact current bill amount"
              >
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>Pay UPI (₹{grandTotal.toFixed(2)})</span>
              </button>
            )}

            <button
              id="btn-save-invoice"
              type="button"
              disabled={Boolean(saveStatus) || lineItems.length === 0}
              onClick={() => handleSaveInvoice(false)}
              className={`flex items-center gap-1.5 px-4 py-2 font-bold rounded-lg border shadow transition-all ${
                saveStatus
                  ? 'bg-slate-800 text-slate-400 border-slate-700 cursor-not-allowed'
                  : lineItems.length > 0
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500/50 shadow-emerald-900/40 ring-2 ring-emerald-500/30 cursor-pointer'
                  : 'bg-slate-800/80 hover:bg-slate-700/80 text-slate-100 border-slate-700/60 backdrop-blur-sm cursor-pointer'
              }`}
            >
              {saveStatus === 'saving' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                  <span>Saving Bill...</span>
                </>
              ) : saveStatus === 'sending_email' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
                  <span className="text-sky-300">Sending Email...</span>
                </>
              ) : (
                <>
                  <Save className={`w-4 h-4 ${lineItems.length > 0 ? 'text-white' : 'text-emerald-400'}`} />
                  <span>Save Bill [F5]</span>
                </>
              )}
            </button>

            <button
              id="btn-save-and-print"
              type="button"
              disabled={Boolean(saveStatus) || lineItems.length === 0}
              onClick={() => handleSaveInvoice(true)}
              className={`flex items-center gap-1.5 px-5 py-2 font-bold rounded-lg shadow-lg border transition-all ${
                saveStatus
                  ? 'bg-slate-800 text-slate-400 border-slate-700 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30 border-emerald-500/30 cursor-pointer'
              }`}
            >
              {saveStatus === 'saving' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Saving Bill...</span>
                </>
              ) : saveStatus === 'sending_email' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-sky-200" />
                  <span className="text-sky-200">Sending Email...</span>
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4" />
                  <span>Save & Print Invoice [F7]</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Item Catalog Search Dialog (frmItemSearch) */}
      {showItemSearch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-2xl max-h-[80vh] flex flex-col text-slate-100">
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-700/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-slate-100">Find Item / Product Catalog [F2]</h3>
              </div>
              <button
                onClick={() => setShowItemSearch(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 text-xs transition"
              >
                Esc to Close
              </button>
            </div>

            <div className="p-3 border-b border-slate-700/50 bg-slate-950/40">
              <input
                autoFocus
                type="text"
                placeholder="Type item name, code, barcode, or category..."
                value={itemSearchQuery}
                onChange={(e) => setItemSearchQuery(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-3 py-2 text-slate-100 text-sm focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="overflow-y-auto flex-1 p-2 divide-y divide-slate-800/60">
              {filteredSearchItems.map((itm) => (
                <div
                  key={itm.id}
                  onClick={() => handleItemSelect(itm.id)}
                  className="p-2.5 hover:bg-slate-800/50 rounded-lg cursor-pointer flex items-center justify-between gap-3 transition"
                >
                  <div>
                    <div className="font-semibold text-sm text-slate-100">{itm.itemName}</div>
                    <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                      <span className="font-mono text-amber-400">{itm.itemCode}</span>
                      <span>•</span>
                      <span>HSN: {itm.hsnCode}</span>
                      <span>•</span>
                      <span>Cat: {itm.category}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-sm text-emerald-400 font-mono">
                      ₹{itm.sellingRate.toFixed(2)}
                    </div>
                    <div className="text-xs text-slate-400">
                      Stock: <strong className="text-slate-200">{itm.currentStock} {itm.unit}</strong>
                    </div>
                  </div>
                </div>
              ))}
              {filteredSearchItems.length === 0 && (
                <div className="p-6 text-center text-slate-500 text-sm">
                  No matching items found.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Customer Search Modal (frmCustomerSearch) */}
      {showCustomerSearch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-2xl max-h-[80vh] flex flex-col text-slate-100">
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-700/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-purple-400" />
                <h3 className="font-bold text-sm text-slate-100">Find Customer Party [F3]</h3>
              </div>
              <button
                onClick={() => setShowCustomerSearch(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 text-xs transition"
              >
                Esc to Close
              </button>
            </div>

            <div className="p-3 border-b border-slate-700/50 bg-slate-950/40">
              <input
                autoFocus
                type="text"
                placeholder="Search by customer name, mobile, GSTIN..."
                value={customerSearchQuery}
                onChange={(e) => setCustomerSearchQuery(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-3 py-2 text-slate-100 text-sm focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div className="overflow-y-auto flex-1 p-2 divide-y divide-slate-800/60">
              {filteredCustomers.map((cust) => (
                <div
                  key={cust.id}
                  onClick={() => {
                    handleCustomerChange(cust.id);
                    setShowCustomerSearch(false);
                  }}
                  className="p-2.5 hover:bg-slate-800/50 rounded-lg cursor-pointer flex items-center justify-between gap-3 transition"
                >
                  <div>
                    <div className="font-semibold text-sm text-slate-100">{cust.customerName}</div>
                    <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                      <span className="font-mono text-purple-400">{cust.customerCode}</span>
                      <span>•</span>
                      <span>Mob: {cust.mobile}</span>
                      {cust.gstin && (
                        <>
                          <span>•</span>
                          <span>GSTIN: {cust.gstin}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-sm text-amber-400 font-mono">
                      {formatCurrency(cust.currentBalance)}
                    </div>
                    <div className="text-xs text-slate-400">{cust.customerType}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Past Invoices & Reprints Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-4xl max-h-[85vh] flex flex-col text-slate-100">
            <div className="p-3.5 bg-slate-900/80 border-b border-slate-700/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-sm text-slate-100">Past Sales Invoices & Reprints</h3>
              </div>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 text-xs transition"
              >
                Close
              </button>
            </div>

            <div className="overflow-y-auto flex-1 p-3">
              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md">
                  <tr>
                    <th className="p-2.5">Invoice No</th>
                    <th className="p-2.5">Date</th>
                    <th className="p-2.5">Customer</th>
                    <th className="p-2.5 text-center">Items</th>
                    <th className="p-2.5 text-right">Taxable</th>
                    <th className="p-2.5 text-right">GST</th>
                    <th className="p-2.5 text-right">Grand Total</th>
                    <th className="p-2.5 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {pastSales.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-2.5 font-bold text-slate-100">{inv.invoiceNo}</td>
                      <td className="p-2.5 text-slate-300">{inv.invoiceDate}</td>
                      <td className="p-2.5 font-sans font-medium text-slate-200">{inv.customerName}</td>
                      <td className="p-2.5 text-center">{inv.totalQuantity}</td>
                      <td className="p-2.5 text-right">₹{inv.totalTaxable.toFixed(2)}</td>
                      <td className="p-2.5 text-right">₹{inv.totalTax.toFixed(2)}</td>
                      <td className="p-2.5 text-right font-bold text-blue-400 text-sm">
                        ₹{inv.grandTotal.toFixed(2)}
                      </td>
                      <td className="p-2.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedPrintInvoice(inv);
                              setShowHistoryModal(false);
                            }}
                            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-emerald-400 border border-slate-700/50"
                            title="Print Invoice"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              setInvoiceToDelete({ id: inv.id, no: inv.invoiceNo });
                            }}
                            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-900/40 text-rose-400 border border-slate-700/50"
                            title="Delete Invoice"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Delete Confirmation Modal */}
      {invoiceToDelete && (
        <ConfirmModal
          title="Delete Sales Invoice"
          message={`Are you sure you want to delete invoice ${invoiceToDelete.no}? Stock will be reversed.`}
          confirmLabel="Delete Invoice"
          onConfirm={() => {
            const { id } = invoiceToDelete;
            const res = dbService.deleteSaleInvoice(id);
            setInvoiceToDelete(null);
            setFeedback({ type: 'success', text: res.message });
            resetForm();
          }}
          onCancel={() => setInvoiceToDelete(null)}
        />
      )}

      {/* Tax Invoice Print Preview Modal */}
      {selectedPrintInvoice && (
        <InvoicePrintModal
          invoice={selectedPrintInvoice}
          company={company}
          autoPrint={autoPrintModal}
          onClose={() => {
            setSelectedPrintInvoice(null);
            setAutoPrintModal(false);
          }}
          onAttachToNav={
            onOpenPrintPreviewTab
              ? () => {
                  const inv = selectedPrintInvoice;
                  setSelectedPrintInvoice(null);
                  setAutoPrintModal(false);
                  onOpenPrintPreviewTab(inv, false);
                }
              : undefined
          }
        />
      )}
    </div>
  );
};
