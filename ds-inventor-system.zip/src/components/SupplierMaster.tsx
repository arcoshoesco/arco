import React, { useState, useEffect } from 'react';
import {
  Building2,
  Plus,
  Save,
  Trash2,
  Search,
  RotateCcw,
  Landmark,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Supplier } from '../types';
import { dbService } from '../services/storage';
import { INDIAN_STATES, formatCurrency } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';

export const SupplierMasterComponent: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState<boolean>(false);

  // Form fields
  const [supplierCode, setSupplierCode] = useState<string>('');
  const [supplierName, setSupplierName] = useState<string>('');
  const [contactPerson, setContactPerson] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [city, setCity] = useState<string>('Agra');
  const [state, setState] = useState<string>('Uttar Pradesh');
  const [stateCode, setStateCode] = useState<string>('09');
  const [gstin, setGstin] = useState<string>('');
  const [pan, setPan] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');
  const [bankAccountNo, setBankAccountNo] = useState<string>('');
  const [bankIfsc, setBankIfsc] = useState<string>('');
  const [openingBalance, setOpeningBalance] = useState<number>(0);
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [paymentTermsDays, setPaymentTermsDays] = useState<number>(30);
  const [isActive, setIsActive] = useState<boolean>(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadSuppliers = () => {
    const list = dbService.getSuppliers();
    setSuppliers(list);
  };

  useEffect(() => {
    loadSuppliers();
  }, []);

  const resetForm = () => {
    setSelectedId(null);
    const count = suppliers.length + 1;
    setSupplierCode(`SUP-${String(count).padStart(3, '0')}`);
    setSupplierName('');
    setContactPerson('');
    setMobile('');
    setPhone('');
    setEmail('');
    setAddress('');
    setCity('Agra');
    setState('Uttar Pradesh');
    setStateCode('09');
    setGstin('');
    setPan('');
    setBankName('');
    setBankAccountNo('');
    setBankIfsc('');
    setOpeningBalance(0);
    setCurrentBalance(0);
    setPaymentTermsDays(30);
    setIsActive(true);
    setFeedback(null);
  };

  const handleSelectSupplier = (s: Supplier) => {
    setSelectedId(s.id);
    setSupplierCode(s.supplierCode);
    setSupplierName(s.supplierName);
    setContactPerson(s.contactPerson || '');
    setMobile(s.mobile || '');
    setPhone(s.phone || '');
    setEmail(s.email || '');
    setAddress(s.address || '');
    setCity(s.city || '');
    setState(s.state || 'Uttar Pradesh');
    setStateCode(s.stateCode || '09');
    setGstin(s.gstin || '');
    setPan(s.pan || '');
    setBankName(s.bankName || '');
    setBankAccountNo(s.bankAccountNo || '');
    setBankIfsc(s.bankIfsc || '');
    setOpeningBalance(s.openingBalance || 0);
    setCurrentBalance(s.currentBalance || 0);
    setPaymentTermsDays(s.paymentTermsDays || 30);
    setIsActive(s.isActive);
    setFeedback(null);
  };

  const handleStateChange = (selectedStateName: string) => {
    setState(selectedStateName);
    const st = INDIAN_STATES.find((s) => s.name === selectedStateName);
    if (st) {
      setStateCode(st.code);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierName.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Supplier Name is required.' });
      return;
    }

    const isUpdate = Boolean(selectedId);
    const supplier: Supplier = {
      id: selectedId || `SUP-${Date.now()}`,
      supplierCode: supplierCode.trim().toUpperCase() || `SUP-${Date.now()}`,
      supplierName: supplierName.trim(),
      contactPerson: contactPerson.trim(),
      mobile: mobile.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      city: city.trim(),
      state,
      stateCode,
      gstin: gstin.trim().toUpperCase(),
      pan: pan.trim().toUpperCase(),
      bankName: bankName.trim(),
      bankAccountNo: bankAccountNo.trim(),
      bankIfsc: bankIfsc.trim().toUpperCase(),
      openingBalance: Number(openingBalance) || 0,
      currentBalance: selectedId ? Number(currentBalance) : Number(openingBalance) || 0,
      paymentTermsDays: Number(paymentTermsDays) || 0,
      isActive,
      createdAt: selectedId ? suppliers.find((s) => s.id === selectedId)?.createdAt || '' : new Date().toISOString().split('T')[0],
    };

    dbService.saveSupplier(supplier);
    loadSuppliers();
    setFeedback({
      type: 'success',
      title: isUpdate ? 'Supplier Updated Successfully' : 'Supplier Saved Successfully',
      text: isUpdate
        ? `Supplier "${supplier.supplierName}" has been updated successfully!`
        : `Supplier "${supplier.supplierName}" has been saved successfully!`,
    });
    if (!selectedId) {
      resetForm();
    }
  };

  const handleDelete = () => {
    if (!selectedId) return;
    setShowConfirmDelete(true);
  };

  const confirmDeleteSupplier = () => {
    if (!selectedId) return;
    const res = dbService.deleteSupplier(selectedId);
    setShowConfirmDelete(false);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Supplier Deleted Successfully',
        text: res.message,
      });
      loadSuppliers();
      resetForm();
    } else {
      setFeedback({ type: 'error', title: 'Delete Operation Failed', text: res.message });
    }
  };

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.supplierCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.mobile && s.mobile.includes(searchQuery)) ||
      (s.gstin && s.gstin.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal */}
      {showConfirmDelete && (
        <ConfirmModal
          title="Delete Supplier Account"
          message="Are you sure you want to delete this supplier account? This action cannot be undone."
          confirmLabel="Delete Supplier"
          onConfirm={confirmDeleteSupplier}
          onCancel={() => setShowConfirmDelete(false)}
        />
      )}

      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Supplier Form Panel (frmSupplierMaster) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
          <div className="flex items-center justify-between border-b border-slate-700/40 pb-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center shadow-inner">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <span>{selectedId ? 'Edit Supplier' : 'Supplier / Vendor Master'}</span>
                  <span className="text-xs font-mono bg-slate-800/60 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700/50">
                    frmSupplierMaster
                  </span>
                </h2>
                <p className="text-xs text-slate-400">Manufacturer/Distributor details & payables</p>
              </div>
            </div>

            <button
              id="btn-new-supplier"
              type="button"
              onClick={resetForm}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 text-xs font-medium border border-slate-700/50 backdrop-blur-sm transition"
            >
              <RotateCcw className="w-3.5 h-3.5 text-orange-400" />
              <span>New</span>
            </button>
          </div>

          <form id="form-supplier-master" onSubmit={handleSave} className="space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Supplier Code</label>
                <input
                  type="text"
                  value={supplierCode}
                  onChange={(e) => setSupplierCode(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono font-bold uppercase focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-slate-400 font-medium mb-1">Supplier / Firm Name *</label>
                <input
                  type="text"
                  required
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  placeholder="Leathercraft Tanneries Ltd."
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="Mr. Vivek Mathur"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Mobile No.</label>
                <input
                  type="text"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="9837012345"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Factory / Office Address</label>
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Plot 45, Leather Industrial Zone, Sikandra"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-orange-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">State</label>
                <select
                  value={state}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-1.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none text-xs"
                >
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.name}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">GST State Code</label>
                <input
                  type="text"
                  readOnly
                  value={stateCode}
                  className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-2 py-1.5 text-orange-400 font-mono font-bold text-center"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Supplier GSTIN (15 Digit)</label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  placeholder="09AABCL8890P1ZN"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">PAN No.</label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={(e) => setPan(e.target.value.toUpperCase())}
                  placeholder="AABCL8890P"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Bank Details & Khata */}
            <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
                Bank & Payment Terms
              </span>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Bank Name</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="PNB / HDFC"
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">A/C Number</label>
                  <input
                    type="text"
                    value={bankAccountNo}
                    onChange={(e) => setBankAccountNo(e.target.value)}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">IFSC Code</label>
                  <input
                    type="text"
                    value={bankIfsc}
                    onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Opening Payable Bal (₹)</label>
                  <input
                    type="number"
                    disabled={Boolean(selectedId)}
                    value={openingBalance}
                    onChange={(e) => {
                      setOpeningBalance(Number(e.target.value));
                      if (!selectedId) setCurrentBalance(Number(e.target.value));
                    }}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono disabled:opacity-50 focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Payment Terms (Days)</label>
                  <input
                    type="number"
                    value={paymentTermsDays}
                    onChange={(e) => setPaymentTermsDays(Number(e.target.value))}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/40">
              {selectedId ? (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold backdrop-blur-sm transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              ) : (
                <div />
              )}

              <button
                id="btn-save-supplier-master"
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg shadow-lg shadow-orange-900/20 border border-orange-500/30 transition"
              >
                <Save className="w-4 h-4" />
                <span>{selectedId ? 'Update Supplier' : 'Save Supplier [F10]'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Suppliers Directory Table */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3 mb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Supplier / Vendor Directory</span>
                <span className="bg-slate-800/60 text-orange-400 font-mono text-xs px-2 py-0.5 rounded border border-slate-700/50">
                  {filteredSuppliers.length} vendors
                </span>
              </h3>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search vendor name/code/GSTIN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 text-xs focus:border-orange-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto flex-1 max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-2.5">Code</th>
                  <th className="py-2.5 px-2">Supplier Name</th>
                  <th className="py-2.5 px-2">Mobile / City</th>
                  <th className="py-2.5 px-2 text-center">GSTIN</th>
                  <th className="py-2.5 px-2 text-right">Payable Balance (Cr)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredSuppliers.map((s) => {
                  const isSelected = selectedId === s.id;
                  return (
                    <tr
                      key={s.id}
                      onClick={() => handleSelectSupplier(s)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-orange-950/40 border-l-4 border-orange-500 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-mono font-bold text-orange-400">{s.supplierCode}</td>
                      <td className="py-2.5 px-2 font-medium">
                        <div className="text-slate-100">{s.supplierName}</div>
                        {s.contactPerson && <div className="text-[10px] text-slate-400">Attn: {s.contactPerson}</div>}
                      </td>
                      <td className="py-2.5 px-2">
                        <div className="font-mono">{s.mobile || '-'}</div>
                        <div className="text-[10px] text-slate-400">{s.city}, {s.stateCode}</div>
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-[11px]">
                        {s.gstin ? <span className="text-emerald-400 font-semibold">{s.gstin}</span> : <span className="text-slate-500">Unregistered</span>}
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-orange-400 text-sm">
                        {formatCurrency(s.currentBalance)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
