import React, { useState, useEffect } from 'react';
import {
  FileText,
  ShoppingCart,
  Package,
  Users,
  Building2,
  Receipt,
  RotateCcw,
  ClipboardCheck,
  BarChart3,
  FileSpreadsheet,
  Settings,
  Printer,
  Keyboard,
  Store,
  Palette,
  ShieldCheck,
  LogOut,
  Lock,
  QrCode,
  ChevronDown,
  LayoutDashboard,
  BookOpen,
  Menu,
  X,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppTheme, CompanyInfo, ModuleTab } from '../types';

interface NavbarProps {
  currentTab: ModuleTab;
  onSelectTab: (tab: ModuleTab) => void;
  company: CompanyInfo;
  onOpenMigration?: () => void;
  onOpenShortcuts: () => void;
  onOpenQrModal?: (amount?: number) => void;
  currentTheme: AppTheme;
  onOpenThemeSelector: () => void;
  onLogout?: () => void;
  hasPrintInvoice?: boolean;
  onClosePrintTab?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  company,
  onOpenMigration,
  onOpenShortcuts,
  onOpenQrModal,
  currentTheme,
  onOpenThemeSelector,
  onLogout,
  hasPrintInvoice = false,
  onClosePrintTab,
}) => {
  const currentDateStr = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const getThemeLabel = (theme: AppTheme) => {
    switch (theme) {
      case 'cream':
        return { label: 'Warm Cream', emoji: '🌾' };
      case 'linen':
        return { label: 'Linen Emerald', emoji: '🌿' };
      case 'porcelain':
        return { label: 'Pure White', emoji: '⚪' };
      case 'cashmere':
        return { label: 'Cashmere Sand', emoji: '🍁' };
      case 'dark':
        return { label: 'Dark Mode', emoji: '🌙' };
      case 'oxford':
        return { label: 'Royal Oxford', emoji: '👑' };
      case 'institutional':
        return { label: 'Directorate Gold', emoji: '🏛️' };
      default:
        return { label: 'Theme', emoji: '🎨' };
    }
  };

  const currentThemeInfo = getThemeLabel(currentTheme);

  // Mobile menu drawer state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [mobileOpenSection, setMobileOpenSection] = useState<'reports' | 'master' | 'transactions' | 'returns' | 'ledgers' | null>(null);

  // Navigation dropdown states
  const [openDropdown, setOpenDropdown] = useState<'reports' | 'master' | 'transactions' | 'returns' | 'ledgers' | null>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.nav-dropdown-container')) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  const toggleDropdown = (menu: 'reports' | 'master' | 'transactions' | 'returns' | 'ledgers') => {
    setOpenDropdown(openDropdown === menu ? null : menu);
  };

  const toggleMobileSection = (section: 'reports' | 'master' | 'transactions' | 'returns' | 'ledgers') => {
    setMobileOpenSection(mobileOpenSection === section ? null : section);
  };

  const handleSelectSubTab = (tab: ModuleTab) => {
    onSelectTab(tab);
    setOpenDropdown(null);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="bg-slate-900/40 backdrop-blur-md text-white border-b border-slate-700/50 shadow-lg sticky top-0 z-[90] select-none">
      {/* Desktop Header Bar */}
      <div className="flex px-4 sm:px-6 py-3 items-center justify-between gap-3 border-b border-slate-800/60">
        <div className="flex items-center gap-3.5">
          <img
            src="/app-logo.jpg"
            alt="DS Inventory System Logo"
            className="w-9 h-9 rounded-lg object-cover border border-amber-400/40 shadow-lg shadow-amber-500/10 flex-shrink-0"
          />
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="font-bold text-base sm:text-lg text-slate-100 tracking-tight">
                {company.companyName || 'ARCO SHOES CO.'}
              </h1>
              <span className="bg-emerald-400/10 text-emerald-400 text-[11px] font-semibold px-2 py-0.5 rounded-full border border-emerald-400/20">
                GST Ready
              </span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-2">
              <span>GSTIN: <strong className="text-slate-200 font-mono">{company.gstin}</strong></span>
              <span className="text-slate-600">•</span>
              <span>State: <strong className="text-slate-200">{company.state} ({company.stateCode})</strong></span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 text-xs">
          <div className="flex flex-col items-end text-slate-400 bg-slate-900/50 px-3 py-1 rounded-lg border border-slate-700/50 backdrop-blur-sm">
            <span className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">Business Date</span>
            <span className="font-mono text-blue-400 font-semibold">{currentDateStr}</span>
          </div>

          {/* Show QR Code Modal Button */}
          {onOpenQrModal && (
            <button
              id="btn-nav-show-qr"
              onClick={() => onOpenQrModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/40 text-amber-300 hover:text-amber-200 border border-amber-500/40 font-bold shadow-sm backdrop-blur-sm transition-all cursor-pointer"
              title="Display Selected Active QR Code for Counter Payments"
            >
              <QrCode className="w-4 h-4 text-amber-400" />
              <span>Show QR</span>
              <span className="hidden xl:inline text-[10px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30">
                {company.activeQrTitle || 'UPI'}
              </span>
            </button>
          )}

          {/* Theme Palette Switcher Button */}
          <button
            id="btn-nav-theme-selector"
            onClick={onOpenThemeSelector}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 hover:text-amber-200 border border-amber-500/40 shadow-sm backdrop-blur-sm transition-all"
            title="Select Theme & Color Designs (White / Cream / Dark)"
          >
            <Palette className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">{currentThemeInfo.emoji} {currentThemeInfo.label}</span>
            <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded text-[10px] uppercase font-bold border border-amber-500/30">Theme</span>
          </button>

          <button
            id="btn-nav-shortcuts"
            onClick={onOpenShortcuts}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700/50 backdrop-blur-sm transition-all"
            title="Keyboard Shortcuts Guide"
          >
            <Keyboard className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline font-medium">Shortcuts</span>
            <span className="bg-slate-900/80 text-amber-300 px-1.5 py-0.5 rounded text-[10px] font-mono border border-slate-700/40">F1-F10</span>
          </button>

          {/* Admin User Info & Change Password Shortcut */}
          <div className="flex items-center gap-1.5 pl-1.5 border-l border-slate-700/60">
            <button
              id="btn-nav-admin-security"
              onClick={() => onSelectTab('company_settings')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border border-emerald-600/40 text-xs font-medium transition"
              title="Logged in as Administrator (Click to Change Security Password)"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="font-mono text-[11px]">arcoshoesco@gmail.com</span>
            </button>

            {onLogout && (
              <button
                id="btn-nav-logout"
                onClick={onLogout}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-700/50 text-xs font-medium transition"
                title="Lock Session & Return to Welcome Screen"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <div className="flex px-3 py-1.5 bg-slate-950/30 backdrop-blur-md items-center gap-1.5 overflow-visible flex-wrap text-xs">
        {/* Dashboard Tab */}
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
            currentTab === 'dashboard'
              ? 'bg-amber-600/25 text-amber-300 border border-amber-500/40 shadow-inner'
              : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
          }`}
        >
          <LayoutDashboard className="w-3.5 h-3.5 text-amber-400" />
          <span>Dashboard</span>
        </button>

        {/* Master Dropdown */}
        <div className="relative nav-dropdown-container">
          <button
            id="dropdown-master-trigger"
            onClick={() => toggleDropdown('master')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              currentTab === 'item_master' || currentTab === 'customer_master' || currentTab === 'supplier_master'
                ? 'bg-purple-600/25 text-purple-300 border border-purple-500/40 shadow-inner'
                : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Master</span>
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDropdown === 'master' ? 'rotate-180' : ''}`} />
          </button>
          {openDropdown === 'master' && (
            <div className="absolute left-0 mt-1.5 bg-slate-900 border border-slate-700/60 rounded-xl py-1.5 shadow-2xl min-w-[180px] z-[100] animate-in fade-in duration-100 backdrop-blur-md">
              <button
                onClick={() => handleSelectSubTab('item_master')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'item_master' ? 'text-purple-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Package className="w-3.5 h-3.5 text-purple-400" />
                  <span>Items/Products</span>
                </div>
                <span className="text-[9px] bg-slate-950 px-1 py-0.2 rounded font-mono border border-slate-800 text-slate-400">F8</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('customer_master')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'customer_master' ? 'text-purple-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-purple-400" />
                  <span>Customers</span>
                </div>
                <span className="text-[9px] bg-slate-950 px-1 py-0.2 rounded font-mono border border-slate-800 text-slate-400">F9</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('supplier_master')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'supplier_master' ? 'text-purple-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>Suppliers</span>
                </div>
                <span className="text-[9px] bg-slate-950 px-1 py-0.2 rounded font-mono border border-slate-800 text-slate-400">F10</span>
              </button>
            </div>
          )}
        </div>

        {/* Transactions Dropdown */}
        <div className="relative nav-dropdown-container">
          <button
            id="dropdown-transactions-trigger"
            onClick={() => toggleDropdown('transactions')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              currentTab === 'sales_invoice' || currentTab === 'purchase_entry' || currentTab === 'customer_receipt' || currentTab === 'supplier_payment'
                ? 'bg-rose-600/25 text-rose-300 border border-rose-500/40 shadow-inner'
                : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>Transactions</span>
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDropdown === 'transactions' ? 'rotate-180' : ''}`} />
          </button>
          {openDropdown === 'transactions' && (
            <div className="absolute left-0 mt-1.5 bg-slate-900 border border-slate-700/60 rounded-xl py-1.5 shadow-2xl min-w-[190px] z-[100] animate-in fade-in duration-100 backdrop-blur-md">
              <button
                onClick={() => handleSelectSubTab('sales_invoice')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'sales_invoice' ? 'text-blue-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-3.5 h-3.5 text-blue-400" />
                  <span>Sales</span>
                </div>
                <span className="text-[9px] bg-slate-950 px-1 py-0.2 rounded font-mono border border-slate-800 text-slate-400">F1</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('purchase_entry')}
                className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'purchase_entry' ? 'text-indigo-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Purchases</span>
                </div>
                <span className="text-[9px] bg-slate-950 px-1 py-0.2 rounded font-mono border border-slate-800 text-slate-400">F4</span>
              </button>
              <div className="my-1 border-t border-slate-800/80"></div>
              <button
                onClick={() => handleSelectSubTab('customer_receipt')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'customer_receipt' ? 'text-rose-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <Receipt className="w-3.5 h-3.5 text-rose-400" />
                <span>Receipt</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('supplier_payment')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'supplier_payment' ? 'text-rose-300 font-semibold' : 'text-slate-300'
                }`}
              >
                <Receipt className="w-3.5 h-3.5 text-rose-400" />
                <span>Payment</span>
              </button>
            </div>
          )}
        </div>

        {/* Update & Return Dropdown */}
        <div className="relative nav-dropdown-container">
          <button
            id="dropdown-returns-trigger"
            onClick={() => toggleDropdown('returns')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              currentTab === 'sales_return' || currentTab === 'purchase_return'
                ? 'bg-purple-600/25 text-purple-300 border border-purple-500/40 shadow-inner'
                : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Update & Return</span>
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDropdown === 'returns' ? 'rotate-180' : ''}`} />
          </button>
          {openDropdown === 'returns' && (
            <div className="absolute left-0 mt-1.5 bg-slate-900 border border-slate-700/60 rounded-xl py-1.5 shadow-2xl min-w-[185px] z-[100] animate-in fade-in duration-100 backdrop-blur-md">
              <button
                onClick={() => handleSelectSubTab('sales_return')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors cursor-pointer ${
                  currentTab === 'sales_return' ? 'text-purple-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
                <span>Sales</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('purchase_return')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors cursor-pointer ${
                  currentTab === 'purchase_return' ? 'text-purple-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
                <span>Purchases</span>
              </button>
            </div>
          )}
        </div>

        {/* Reports Dropdown */}
        <div className="relative nav-dropdown-container">
          <button
            id="dropdown-reports-trigger"
            onClick={() => toggleDropdown('reports')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              currentTab === 'day_book' ||
              currentTab === 'invoices' ||
              currentTab === 'bills' ||
              currentTab === 'bills_invoices' ||
              currentTab === 'stock_adjustment' ||
              currentTab === 'gst_reports' ||
              currentTab === 'gst_register' ||
              currentTab === 'business_reports'
                ? 'bg-amber-600/25 text-amber-300 border border-amber-500/40 shadow-inner'
                : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Reports</span>
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDropdown === 'reports' ? 'rotate-180' : ''}`} />
          </button>
          {openDropdown === 'reports' && (
            <div className="absolute left-0 mt-1.5 bg-slate-900 border border-slate-700/60 rounded-xl py-1.5 shadow-2xl min-w-[185px] z-[100] animate-in fade-in duration-100 backdrop-blur-md">
              <button
                onClick={() => handleSelectSubTab('day_book')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'day_book' ? 'text-amber-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Day Book</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('invoices')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'invoices' ? 'text-amber-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                <span>Customer Invoices</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('bills')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'bills' ? 'text-amber-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                <span>Supplier Bills</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('stock_adjustment')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'stock_adjustment' ? 'text-amber-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <ClipboardCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Stock Sheet</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('gst_reports')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'gst_reports' || currentTab === 'gst_register' || currentTab === 'business_reports'
                    ? 'text-emerald-300 font-semibold bg-slate-800/40'
                    : 'text-slate-300'
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>GST Reports</span>
              </button>
            </div>
          )}
        </div>

        <div className="w-[1px] h-4 bg-slate-800/80 mx-1"></div>

        {/* Ledgers Dropdown */}
        <div className="relative nav-dropdown-container">
          <button
            id="dropdown-ledgers-trigger"
            onClick={() => toggleDropdown('ledgers')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              currentTab === 'customer_ledger' || currentTab === 'supplier_ledger'
                ? 'bg-blue-600/25 text-blue-300 border border-blue-500/40 shadow-inner'
                : 'text-slate-300 hover:bg-slate-800/40 hover:text-white border border-transparent'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-blue-400" />
            <span>Ledgers</span>
            <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDropdown === 'ledgers' ? 'rotate-180' : ''}`} />
          </button>
          {openDropdown === 'ledgers' && (
            <div className="absolute left-0 mt-1.5 bg-slate-900 border border-slate-700/60 rounded-xl py-1.5 shadow-2xl min-w-[195px] z-[100] animate-in fade-in duration-100 backdrop-blur-md">
              <button
                onClick={() => handleSelectSubTab('customer_ledger')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'customer_ledger' ? 'text-blue-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-blue-400" />
                <span>Customer Ledger</span>
              </button>
              <button
                onClick={() => handleSelectSubTab('supplier_ledger')}
                className={`w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-800/60 transition-colors ${
                  currentTab === 'supplier_ledger' ? 'text-indigo-300 font-semibold bg-slate-800/40' : 'text-slate-300'
                }`}
              >
                <Building2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Supplier Ledger</span>
              </button>
            </div>
          )}
        </div>

        {/* Settings */}
        <div className="flex items-center gap-1">
          <button
            id="tab-company-settings"
            onClick={() => onSelectTab('company_settings')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              currentTab === 'company_settings'
                ? 'bg-slate-700/60 text-white border border-slate-600 shadow-inner'
                : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200 border border-transparent'
            }`}
            title="Company Configuration"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Settings</span>
          </button>
        </div>

        {/* Print Preview Tab (Appears when an invoice is sent for printing or user clicks Print Preview) */}
        {(currentTab === 'print_preview' || hasPrintInvoice) && (
          <div className="flex items-center gap-1 pl-1 border-l border-slate-800">
            <div className="flex items-center rounded-lg overflow-hidden border border-emerald-500/40 bg-emerald-950/40">
              <button
                id="tab-print-preview"
                onClick={() => onSelectTab('print_preview')}
                className={`flex items-center gap-1.5 px-3 py-1.5 font-bold transition-all cursor-pointer ${
                  currentTab === 'print_preview'
                    ? 'bg-emerald-600/40 text-emerald-200 shadow-inner'
                    : 'text-emerald-400 hover:bg-emerald-900/40 hover:text-emerald-200'
                }`}
                title="Print Preview Tab"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>Print Preview</span>
              </button>
              {onClosePrintTab && (
                <button
                  type="button"
                  id="btn-close-print-tab"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClosePrintTab();
                  }}
                  className="px-1.5 py-1.5 text-emerald-400/80 hover:text-rose-300 hover:bg-rose-900/40 transition cursor-pointer border-l border-emerald-600/30"
                  title="Close Print Preview Tab"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>

    </header>
  );
};
