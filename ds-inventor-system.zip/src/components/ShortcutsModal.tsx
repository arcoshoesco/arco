import React from 'react';
import { Keyboard, X } from 'lucide-react';

interface ShortcutsModalProps {
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 select-none">
      <div className="bg-slate-900/90 border border-slate-700/60 rounded-xl shadow-2xl backdrop-blur-xl w-full max-w-2xl p-5 text-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-700/50 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
              <Keyboard className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-base">Legacy VB6 Keyboard Accelerators & Hotkeys</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 bg-slate-950/60 rounded-lg border border-slate-700/50 space-y-2 backdrop-blur-sm">
            <span className="font-bold text-amber-400 uppercase tracking-wider block text-[11px]">
              Sales & Billing Screen
            </span>
            <div className="space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <strong className="text-amber-300">F1</strong>
                <span className="text-slate-300 font-sans">Focus Barcode / Item field</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-amber-300">F2</strong>
                <span className="text-slate-300 font-sans">Open Item Catalog Finder</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-purple-300">F3</strong>
                <span className="text-slate-300 font-sans">Open Customer Party Finder</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-emerald-300">F5</strong>
                <span className="text-slate-300 font-sans">Save Active Bill / Invoice</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-emerald-300">F7</strong>
                <span className="text-slate-300 font-sans">Save & Print Tax Invoice</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-rose-300">Esc</strong>
                <span className="text-slate-300 font-sans">Clear / New Bill Voucher</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-slate-950/60 rounded-lg border border-slate-700/50 space-y-2 backdrop-blur-sm">
            <span className="font-bold text-sky-400 uppercase tracking-wider block text-[11px]">
              Master Entries & Operations
            </span>
            <div className="space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between">
                <strong className="text-blue-300">F4</strong>
                <span className="text-slate-300 font-sans">Jump to Purchase Inward</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-amber-300">F8</strong>
                <span className="text-slate-300 font-sans">Item / Footwear Master</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-purple-300">F9</strong>
                <span className="text-slate-300 font-sans">Customer KYC & Khata</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-orange-300">F10</strong>
                <span className="text-slate-300 font-sans">Supplier / Vendor Master</span>
              </div>
              <div className="flex justify-between">
                <strong className="text-slate-300">Enter</strong>
                <span className="text-slate-300 font-sans">Next Field / Add Row</span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-1 text-center text-xs text-slate-400">
          <p>The web application captures native key events identical to the original Microsoft Visual Basic 6 runtime.</p>
        </div>
      </div>
    </div>
  );
};
