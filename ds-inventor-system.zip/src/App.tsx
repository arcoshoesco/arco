import React, { useState, useEffect } from 'react';
import { AppTheme, CompanyInfo, ModuleTab } from './types';
import { dbService } from './services/storage';
import { authService } from './services/authService';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Navbar } from './components/Navbar';
import { SalesInvoiceComponent } from './components/SalesInvoice';
import { PurchaseInvoiceComponent } from './components/PurchaseInvoice';
import { ItemMasterComponent } from './components/ItemMaster';
import { CustomerMasterComponent } from './components/CustomerMaster';
import { SupplierMasterComponent } from './components/SupplierMaster';
import { StockLedgerComponent } from './components/StockLedger';
import { GstReportsComponent } from './components/GstReports';
import { CompanySettingsComponent } from './components/CompanySettings';
import { VoucherEntryComponent } from './components/VoucherEntry';
import { ShortcutsModal } from './components/ShortcutsModal';
import { MigrationModal } from './components/MigrationModal';
import { ThemeSelectorModal } from './components/ThemeSelectorModal';
import { ShowQrModal } from './components/ShowQrModal';
import { SessionTimeoutModal } from './components/SessionTimeoutModal';
import { useSessionTimeout } from './hooks/useSessionTimeout';
import { SESSION_CONFIG } from './config/sessionConfig';
import { DashboardComponent } from './components/Dashboard';
import { DayBookComponent } from './components/DayBook';
import { BillsInvoicesComponent } from './components/BillsInvoices';
import { SalesReturnComponent } from './components/SalesReturn';
import { PurchaseReturnComponent } from './components/PurchaseReturn';
import { CustomerLedgerComponent } from './components/CustomerLedger';
import { SupplierLedgerComponent } from './components/SupplierLedger';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { SalesInvoice } from './types';
import { BACKEND_DETAILS } from './firebase';

export default function App() {
  // All hooks unconditionally declared at top of component
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => authService.isSessionAuthenticated());
  // Default landing page is 'sales_invoice' (Tax Invoice & Retail Billing)
  const [currentTab, setCurrentTab] = useState<ModuleTab>('sales_invoice');
  const [company, setCompany] = useState<CompanyInfo>(() => dbService.getCompanyInfo());
  const [showShortcuts, setShowShortcuts] = useState<boolean>(false);
  const [showMigration, setShowMigration] = useState<boolean>(false);
  const [showThemeModal, setShowThemeModal] = useState<boolean>(false);
  const [showQrModal, setShowQrModal] = useState<boolean>(false);
  const [qrAmount, setQrAmount] = useState<number | undefined>(undefined);
  const [selectedReturnInvoiceId, setSelectedReturnInvoiceId] = useState<string | undefined>(undefined);
  const [activePrintInvoice, setActivePrintInvoice] = useState<SalesInvoice | null>(null);
  const [activeAutoPrint, setActiveAutoPrint] = useState<boolean>(false);

  // Theme state: defaults to 'dark' (Obsidian Midnight Glass), persists in localStorage
  const [theme, setTheme] = useState<AppTheme>(() => {
    const savedTheme = localStorage.getItem('arco_app_theme') as AppTheme;
    return savedTheme || 'dark';
  });

  // Subscribe to storage and auth state changes
  useEffect(() => {
    const unsubscribeDb = dbService.subscribe(() => {
      setCompany(dbService.getCompanyInfo());
    });
    const unsubscribeAuth = authService.onAuthChange((user) => {
      if (user) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(authService.isSessionAuthenticated());
      }
    });
    return () => {
      unsubscribeDb();
      unsubscribeAuth();
    };
  }, []);

  // Apply theme to DOM documentElement
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('arco_app_theme', theme);
  }, [theme]);

  // Global hotkeys listener
  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      if (!isAuthenticated) return;
      if (e.key === 'F4') {
        e.preventDefault();
        setCurrentTab('purchase_entry');
      } else if (e.key === 'F8') {
        e.preventDefault();
        setCurrentTab('item_master');
      } else if (e.key === 'F9') {
        e.preventDefault();
        setCurrentTab('customer_master');
      } else if (e.key === 'F10') {
        e.preventDefault();
        setCurrentTab('supplier_master');
      }
    };
    window.addEventListener('keydown', handleGlobalKeys);
    return () => window.removeEventListener('keydown', handleGlobalKeys);
  }, [isAuthenticated]);

  const handleLogout = async () => {
    try {
      localStorage.removeItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY);
    } catch {
      // Storage unavailable
    }
    await authService.logout();
    dbService.setSessionAuthenticated(false);
    setIsAuthenticated(false);
  };

  const handleLoginSuccess = () => {
    try {
      localStorage.setItem(SESSION_CONFIG.STORAGE_KEYS.LAST_ACTIVITY, String(Date.now()));
    } catch {
      // Storage unavailable
    }
    dbService.setSessionAuthenticated(true);
    setIsAuthenticated(true);
    setCurrentTab('sales_invoice'); // Automatically land on Tax Invoice & Retail Billing after login
    setCompany(dbService.getCompanyInfo());
  };

  // Centralized Inactivity Session Timeout Hook with Cross-Tab Sync
  const {
    showWarning,
    remainingSeconds,
    continueSession,
    logoutNow,
  } = useSessionTimeout({
    isAuthenticated,
    onLogout: handleLogout,
  });

  // If not authenticated, render Welcome Screen AFTER all hooks are evaluated
  if (!isAuthenticated) {
    return (
      <WelcomeScreen
        company={company}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  return (
    <div 
      className="min-h-screen app-main-bg flex flex-col font-sans antialiased transition-colors duration-200"
    >
      {/* Top Main Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        company={company}
        onOpenMigration={() => setShowMigration(true)}
        onOpenShortcuts={() => setShowShortcuts(true)}
        onOpenQrModal={(amt) => {
          setQrAmount(amt);
          setShowQrModal(true);
        }}
        currentTheme={theme}
        onOpenThemeSelector={() => setShowThemeModal(true)}
        onLogout={handleLogout}
        hasPrintInvoice={Boolean(activePrintInvoice)}
        onClosePrintTab={() => {
          setActivePrintInvoice(null);
          if (currentTab === 'print_preview') {
            setCurrentTab('sales_invoice');
          }
        }}
      />

      {/* Main Module Content Area */}
      <main className="flex-1 pb-12 p-2 sm:p-4">
        {currentTab === 'dashboard' && (
          <DashboardComponent onNavigateToTab={setCurrentTab} />
        )}

        {currentTab === 'day_book' && (
          <DayBookComponent />
        )}

        {currentTab === 'invoices' && (
          <BillsInvoicesComponent
            initialTab="SALES"
            company={company}
            onNavigateToReturnExchange={(invoiceId) => {
              setSelectedReturnInvoiceId(invoiceId);
              setCurrentTab('sales_return');
            }}
            onOpenPrintPreviewTab={(invoice, autoPrint) => {
              setActivePrintInvoice(invoice);
              setActiveAutoPrint(Boolean(autoPrint));
              setCurrentTab('print_preview');
            }}
          />
        )}

        {currentTab === 'bills' && (
          <BillsInvoicesComponent
            initialTab="PURCHASES"
            company={company}
            onOpenPrintPreviewTab={(invoice, autoPrint) => {
              setActivePrintInvoice(invoice);
              setActiveAutoPrint(Boolean(autoPrint));
              setCurrentTab('print_preview');
            }}
          />
        )}

        {currentTab === 'bills_invoices' && (
          <BillsInvoicesComponent
            initialTab="SALES"
            company={company}
            onNavigateToReturnExchange={(invoiceId) => {
              setSelectedReturnInvoiceId(invoiceId);
              setCurrentTab('sales_return');
            }}
            onOpenPrintPreviewTab={(invoice, autoPrint) => {
              setActivePrintInvoice(invoice);
              setActiveAutoPrint(Boolean(autoPrint));
              setCurrentTab('print_preview');
            }}
          />
        )}

        {currentTab === 'sales_invoice' && (
          <SalesInvoiceComponent
            company={company}
            onNavigateToCustomerMaster={() => setCurrentTab('customer_master')}
            onNavigateToItemMaster={() => setCurrentTab('item_master')}
            onNavigateToSalesReturn={() => {
              setSelectedReturnInvoiceId(undefined);
              setCurrentTab('sales_return');
            }}
            onOpenQrModal={(amt) => {
              setQrAmount(amt);
              setShowQrModal(true);
            }}
            onOpenPrintPreviewTab={(invoice, autoPrint) => {
              setActivePrintInvoice(invoice);
              setActiveAutoPrint(Boolean(autoPrint));
              setCurrentTab('print_preview');
            }}
          />
        )}

        {currentTab === 'sales_return' && (
          <SalesReturnComponent
            company={company}
            initialInvoiceId={selectedReturnInvoiceId}
            onNavigateToSales={() => setCurrentTab('sales_invoice')}
            onOpenQrModal={(amt) => {
              setQrAmount(amt);
              setShowQrModal(true);
            }}
            onOpenPrintPreviewTab={(invoice, autoPrint) => {
              setActivePrintInvoice(invoice);
              setActiveAutoPrint(Boolean(autoPrint));
              setCurrentTab('print_preview');
            }}
          />
        )}

        {currentTab === 'purchase_entry' && (
          <PurchaseInvoiceComponent company={company} />
        )}

        {currentTab === 'purchase_return' && (
          <PurchaseReturnComponent
            company={company}
            onNavigateToPurchases={() => setCurrentTab('purchase_entry')}
          />
        )}

        {currentTab === 'item_master' && (
          <ItemMasterComponent />
        )}

        {currentTab === 'customer_master' && (
          <CustomerMasterComponent />
        )}

        {currentTab === 'supplier_master' && (
          <SupplierMasterComponent />
        )}

        {currentTab === 'customer_receipt' && (
          <VoucherEntryComponent type="RECEIPT" />
        )}

        {currentTab === 'supplier_payment' && (
          <VoucherEntryComponent type="PAYMENT" />
        )}

        {currentTab === 'stock_adjustment' && (
          <StockLedgerComponent />
        )}

        {(currentTab === 'gst_reports' || currentTab === 'gst_register' || currentTab === 'business_reports') && (
          <GstReportsComponent company={company} />
        )}

        {currentTab === 'customer_ledger' && (
          <CustomerLedgerComponent
            company={company}
            onNavigateToReceipt={() => setCurrentTab('customer_receipt')}
          />
        )}

        {currentTab === 'supplier_ledger' && (
          <SupplierLedgerComponent
            company={company}
            onNavigateToPayment={() => setCurrentTab('supplier_payment')}
          />
        )}

        {currentTab === 'company_settings' && (
          <CompanySettingsComponent
            company={company}
            onCompanyUpdated={(updated) => setCompany(updated)}
            onLogout={handleLogout}
          />
        )}

        {/* Print Preview Tab (Attached to Top Navigation Bar after Settings) */}
        {currentTab === 'print_preview' && (
          activePrintInvoice ? (
            <InvoicePrintModal
              invoice={activePrintInvoice}
              company={company}
              autoPrint={activeAutoPrint}
              isTabMode={true}
              onClose={() => {
                setActivePrintInvoice(null);
                setCurrentTab('sales_invoice');
              }}
            />
          ) : (
            <div className="bg-slate-900/60 border border-slate-700/60 rounded-xl p-8 max-w-xl mx-auto text-center space-y-4 text-slate-100">
              <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                <span className="text-2xl">🖨️</span>
              </div>
              <h3 className="font-bold text-lg text-slate-200">No Invoice Currently Loaded for Print Preview</h3>
              <p className="text-xs text-slate-400">
                Please open any invoice from Sales Billing or Bills & Invoices and click Print to view and print it here.
              </p>
              <button
                onClick={() => setCurrentTab('sales_invoice')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition"
              >
                Go to Sales Invoice
              </button>
            </div>
          )
        )}
      </main>

      {/* Footer Status Bar with Hotkeys and Theme Indicator */}
      <footer className="fixed bottom-0 left-0 right-0 h-9 border-t backdrop-blur-md flex items-center justify-between px-4 sm:px-6 text-[10px] font-bold uppercase tracking-widest z-30 select-none">
        <div className="flex items-center gap-3 sm:gap-6 overflow-x-auto scrollbar-none">
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">F1</span> Barcode</span>
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">F2</span> Item Finder</span>
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">F3</span> Customer Search</span>
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">F5</span> Save Bill</span>
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">F7</span> Print Invoice</span>
          <span className="flex items-center gap-1.5"><span className="px-1 py-0.5 rounded border font-mono opacity-80">ESC</span> Clear / Close</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowThemeModal(true)}
            className="flex items-center gap-1.5 opacity-90 hover:opacity-100 transition cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: 'var(--theme-accent, #D97706)' }}></span>
            <span>Theme: <strong className="uppercase">{theme}</strong> (Click to change)</span>
          </button>
          {company.databaseType === 'mongodb' ? (
            <span className="flex items-center gap-1.5 opacity-80" title={`Active Database: MongoDB (${company.mongoDbName || 'arco_shoes_db'})`}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              MongoDB: <strong className="font-mono text-emerald-400">{company.mongoDbName || 'arco_shoes_db'} ({company.mongoUri || '127.0.0.1:27017'})</strong>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 opacity-80" title={`Active Database: Firestore (${BACKEND_DETAILS.projectId})`}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Firestore: <strong className="font-mono text-emerald-400">{BACKEND_DETAILS.projectId} (Live)</strong>
            </span>
          )}
        </div>
      </footer>

      {/* Show Payment QR Code Modal */}
      {showQrModal && (
        <ShowQrModal
          company={company}
          amount={qrAmount}
          onClose={() => {
            setShowQrModal(false);
            setQrAmount(undefined);
          }}
        />
      )}

      {/* Theme Selector Modal */}
      {showThemeModal && (
        <ThemeSelectorModal
          currentTheme={theme}
          onSelectTheme={(newTheme) => setTheme(newTheme)}
          onClose={() => setShowThemeModal(false)}
        />
      )}

      {/* Legacy VB6 Keyboard Shortcuts Help Modal */}
      {showShortcuts && (
        <ShortcutsModal onClose={() => setShowShortcuts(false)} />
      )}

      {/* MS Access Migration & Schema Inspector Modal */}
      {showMigration && (
        <MigrationModal onClose={() => setShowMigration(false)} />
      )}

      {/* Automatic Inactivity Session Timeout Warning Modal */}
      <SessionTimeoutModal
        isOpen={showWarning && isAuthenticated}
        remainingSeconds={remainingSeconds}
        onContinueSession={continueSession}
        onLogoutNow={logoutNow}
      />
    </div>
  );
}
